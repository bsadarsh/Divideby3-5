# NewDay.Digital.Servicing.Function.Documents

[![TeamCity Build Success](https://teamcity.newdaycards.com/app/rest/builds/buildType:id:NewDayEServicing_FunctionDocuments_Build/statusIcon)](https://teamcity.newdaycards.com/project.html?projectId=NewDayEServicing_FunctionDocuments&tab=projectOverview)

The Documents function app provides endpoints for listing inbox messages and statements, and retrieving their attachments from blob cache or from Paragon.

The function app replaces the Service Fabric functionality originally implemented in the DstConnector service (DocumentStore).

## 1. Diagrams

### 1.1. Data Flow diagram

![Data Flow](docs/images/data_flow_diagram.png)

Component|Production (ngp) North Europe|Pre-Prod/DR (npp) West Europe
---|---|---
**App Service** (eServicing website)|apsvcngpeswa0101|apsvcngpeswa0101
**Function** (Documents)|funapngpssdo0101|funapnppssdo0101
**Key Vault** (Documents)|keyvtngpssdo0101|keyvtnppssdo0101
**SQL Database** (eServicing DB)|sqldbazuproneuesvc01|-
**Blob Storage** (eServicing storage)|strazuproneuesvc01|-
**APIM**|apimazuproneuapim01|-
**ExpressRoute**|eprazuprocore01|-

### 1.2. Usage

#### 1.2.1. Inbox Messages

The list of inbox messages is retrieved using the GET Messages endpoint.

When a message has been viewed by a customer, the POST MarkMessageAsRead endpoint is called.

When the customer clicks the Download PDF button, the GET Attachment endpoint is called.

#### 1.2.2. Statements

The list of statements is retrieved from FD. To check whether an individual statement is available for download, the GET StatementByDate endpoint is called.

When the customer clicks the Download PDF button, the GET StatementByDate endpoint is called to get the document ID; the GET Attachment endpoint is then called with this ID.

## 2. Resources

### 2.1. Project links

- [Bitbucket](https://bitbucket.org/newdaydigitaldevelopment/servicing.function.documents/src/master/)
- [TeamCity](https://teamcity.newdaycards.com/project.html?projectId=NewDayEServicing_FunctionDocuments)
- [Octopus](https://octopus.newday.co.uk/app#/projects/newday-digital-servicing-function-documents/overview)
- [Confluence](https://newdaycards.atlassian.net/wiki/spaces/ES/pages/160465142/Documents+Function)

APIM setup:

- [Bitbucket](https://bitbucket.org/newdaydigitaldevelopment/servicing.function.documents.apim/src/master/)
- [TeamCity](https://teamcity.newdaycards.com/project.html?projectId=NewDayEServicing_FunctionDocumentsApim)
- [Octopus](https://octopus.newday.co.uk/app#/projects/newday-digital-servicing-function-documents-apim/overview)

### 2.2. Environment links

#### 2.2.1. Dev

- Function URL: [funapngdssdo0101](https://funapngdssdo0101.azurewebsites.net)
- Resource Group: [rgngdssdo01](https://portal.azure.com/#@newday.co.uk/resource/subscriptions/0f8b9bd9-53ae-4493-9477-e048ca720641/resourceGroups/rgngdssdo01/overview)
- App Service: [funapngdssdo0101](https://portal.azure.com/#blade/WebsitesExtension/FunctionsIFrameBlade/id/%2Fsubscriptions%2F0f8b9bd9-53ae-4493-9477-e048ca720641%2FresourceGroups%2Frgngdssdo01%2Fproviders%2FMicrosoft.Web%2Fsites%2Ffunapngdssdo0101)
- Key Vault: [keyvtngdssdo0101](https://portal.azure.com/#@newday.co.uk/resource/subscriptions/0f8b9bd9-53ae-4493-9477-e048ca720641/resourceGroups/rgngdssdo01/providers/Microsoft.KeyVault/vaults/keyvtngdssdo0101/overview)

#### 2.2.2. UAT

- Function URL: [funapngussdo0101](https://funapngussdo0101.azurewebsites.net)
- Resource Group: [rgngussdo01](https://portal.azure.com/#@newday.co.uk/resource/subscriptions/8aae5d53-f263-479e-959c-0c67619ac334/resourceGroups/rgngussdo01/overview)
- App Service: [funapngussdo0101](https://portal.azure.com/#blade/WebsitesExtension/FunctionsIFrameBlade/id/%2Fsubscriptions%2F8aae5d53-f263-479e-959c-0c67619ac334%2FresourceGroups%2Frgngussdo01%2Fproviders%2FMicrosoft.Web%2Fsites%2Ffunapngussdo0101)
- Key Vault: [keyvtngussdo0101](https://portal.azure.com/#@newday.co.uk/resource/subscriptions/8aae5d53-f263-479e-959c-0c67619ac334/resourceGroups/rgngussdo01/providers/Microsoft.KeyVault/vaults/keyvtngussdo0101/overview)

#### 2.2.3. Pre-Prod

- Function URL: <https://funapnppssdo0101.azurewebsites.net>
- Resource Group: [rgnppssdo01](https://portal.azure.com/#@newday.co.uk/resource/subscriptions/57effcb3-b94c-4408-948b-de6afbbdb13c/resourceGroups/rgnppssdo01/overview)
- App Service: [funapnppssdo0101](https://portal.azure.com/#blade/WebsitesExtension/FunctionsIFrameBlade/id/%2Fsubscriptions%2F57effcb3-b94c-4408-948b-de6afbbdb13c%2FresourceGroups%2Frgnppssdo01%2Fproviders%2FMicrosoft.Web%2Fsites%2Ffunapnppssdo0101)
- Key Vault: [keyvtnppssdo0101](https://portal.azure.com/#@newday.co.uk/resource/subscriptions/8aae5d53-f263-479e-959c-0c67619ac334/resourceGroups/rgnppssdo01/providers/Microsoft.KeyVault/vaults/keyvtnppssdo0101/overview)

#### 2.2.4. Prod

- Function URL: <https://funapngpssdo0101.azurewebsites.net>
- Resource Group: [rgngpssdo01](https://portal.azure.com/#@newday.co.uk/resource/subscriptions/57effcb3-b94c-4408-948b-de6afbbdb13c/resourceGroups/rgngpssdo01/overview)
- App Service: [funapngpssdo0101](https://portal.azure.com/#blade/WebsitesExtension/FunctionsIFrameBlade/id/%2Fsubscriptions%2F57effcb3-b94c-4408-948b-de6afbbdb13c%2FresourceGroups%2Frgngpssdo01%2Fproviders%2FMicrosoft.Web%2Fsites%2Ffunapngpssdo0101)
- Key Vault: [keyvtngpssdo0101](https://portal.azure.com/#@newday.co.uk/resource/subscriptions/8aae5d53-f263-479e-959c-0c67619ac334/resourceGroups/rgngpssdo01/providers/Microsoft.KeyVault/vaults/keyvtngpssdo0101/overview)

## 3. Function endpoints

### GET Messages

    GET https://funapngussdo0101.azurewebsites.net/api/Messages?AccountNumber=3915000000002426&Brand=aqua

    No request body

    Response:
    [
        {
            "type": "DDNotification",
            "date": "2019-09-05T16:40:55.8783574",
            "attachment": {
                "id": "4cbc1035-0939-47ad-9c69-a0947a519614",
                "filesize": 117118,
                "doctype": "DDNotification"
            },
            "read": true,
            "title": null
        },
        ...
    ]

### GET Statements

    GET https://funapngussdo0101.azurewebsites.net/api/Statements?AccountNumber=3915000000002426&Brand=aqua

    No request body

    Response:
    [
        {
            "documentId": "d7f8be55-c8ec-4843-9e0d-fa402e2c2a4a",
            "date": "2019-07-17T00:00:00",
            "hasCopyInBlob": false
        },
        ...
    ]

### GET Statement

    GET https://funapngussdo0101.azurewebsites.net/api/Statement?AccountNumber=3915000000002426&Brand=aqua&DocumentId=D7F8BE55-C8EC-4843-9E0D-FA402E2C2A4A

    No request body

    Response:
    {
        "documentId": "d7f8be55-c8ec-4843-9e0d-fa402e2c2a4a",
        "date": "2019-07-17T00:00:00",
        "hasCopyInBlob": false
    }

### GET StatementByDate

    GET https://funapngussdo0101.azurewebsites.net/api/StatementByDate?AccountNumber=3915000000002426&Brand=aqua&Date=2019-07-17

    No request body

    Response:
    {
        "documentId": "d7f8be55-c8ec-4843-9e0d-fa402e2c2a4a",
        "date": "2019-07-17T00:00:00",
        "hasCopyInBlob": false
    }

### POST MarkMessageAsRead

    POST https://funapngussdo0101.azurewebsites.net/api/MarkMessageAsRead?AccountNumber=3915000000002426&Brand=aqua&DocumentId=268E522E-C220-4F2D-9FD8-FF56C668BD6D

    No request body

    Response:
    true

### GET Attachment

    https://funapngussdo0101.azurewebsites.net/api/Attachment?AccountNumber=3915000000002426&Brand=aqua&DocumentId=4CBC1035-0939-47AD-9C69-A0947A519614

    No request body

    Response:
    {
        "documentId": "4cbc1035-0939-47ad-9c69-a0947a519614",
        "type": "DDNotification",
        "content": "<base-64 encoded string>"
    }

### POST Search

    POST https://funapngussdo0101.azurewebsites.net/api/Search?AccountNumber=3915000000002426&Brand=aqua

    No request body

    Response:
    true
