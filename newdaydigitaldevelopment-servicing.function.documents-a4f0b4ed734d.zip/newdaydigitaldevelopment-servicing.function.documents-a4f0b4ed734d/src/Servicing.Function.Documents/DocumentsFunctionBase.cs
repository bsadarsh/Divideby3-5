﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Servicing.Function.Documents.Core.Extensions;
using Servicing.Function.Documents.Core.Helpers;
using Servicing.Function.Documents.Data.Providers;

namespace Servicing.Function.Documents
{
    public abstract class DocumentsFunctionBase
    {
        private readonly IRequestSerializer _requestSerializer;
        private readonly Func<bool, IDocumentsProvider> _documentsProviderDelegate;
        private readonly ITelemetryHelper _telemetryHelper;

        protected DocumentsFunctionBase(
            ITelemetryHelper telemetryHelper, 
            IRequestSerializer requestSerializer,
            Func<bool, IDocumentsProvider> documentsProviderDelegate
            )
        {
            _telemetryHelper = telemetryHelper;
            _requestSerializer = requestSerializer;
            _documentsProviderDelegate = documentsProviderDelegate;
        }

        protected IDocumentsProvider GetDocumentsProvider(HttpRequest request)
        {
            return _documentsProviderDelegate(request.IsMockEnabled());
        }

        protected async Task TrackException(Exception ex, string functionName, string accountNumber, string brand, Guid? documentId = null, DateTime? date = null, HttpRequest request = null)
        {
            var properties = new Dictionary<string, string>
            {
                ["Function"] = functionName,
                ["AccountNumber"] = accountNumber,
                ["Brand"] = brand
            };

            if (request != null)
            {
                var requestProperties = await _requestSerializer.SerializeRequest(request);
                foreach (var requestProperty in requestProperties)
                {
                    properties[requestProperty.Key] = requestProperty.Value;
                }
            }

            if (documentId.HasValue)
                properties.Add("DocumentId", documentId.Value.ToString());

            if (date.HasValue)
                properties.Add("Date", date.Value.ToString(CultureInfo.CurrentCulture));

            _telemetryHelper.TrackException(ex, properties);
        }
    }
}
