using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Servicing.Function.Documents.Core.Extensions;
using Servicing.Function.Documents.Core.Helpers;
using Servicing.Function.Documents.Data.Providers;
using Servicing.Function.Documents.Data.Requests;
using System;
using System.Net;
using System.Threading.Tasks;

namespace Servicing.Function.Documents
{
    public class MarkMessageAsRead : DocumentsFunctionBase
    {
        private readonly IQueryStringHelper _queryStringHelper;

        public MarkMessageAsRead(ITelemetryHelper telemetryHelper,
            IRequestSerializer requestSerializer,
            Func<bool, IDocumentsProvider> documentsProviderDelegate,
            IQueryStringHelper queryStringHelper) : base(telemetryHelper, requestSerializer, documentsProviderDelegate)
        {
            _queryStringHelper = queryStringHelper;
        }

        [FunctionName("MarkMessageAsRead")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] HttpRequest req)
        {
            var accountNumber = string.Empty;
            var brand = string.Empty;
            var documentId = Guid.Empty;

            try
            {
                accountNumber = _queryStringHelper.GetString(req.Query, "AccountNumber", minLength: 16, maxLength: 19);
                brand = _queryStringHelper.GetString(req.Query, "Brand");
                documentId = _queryStringHelper.GetGuid(req.Query, "DocumentID");
            }
            catch (Exception ex)
            {
                await TrackException(ex, "MarkMessageAsRead", accountNumber, brand, documentId, request: req);
                return new BadRequestResult();
            }

            try
            {
                var provider = GetDocumentsProvider(req);

                var result = await provider.MarkMessageAsRead(new MarkMessageRequest
                    {AccountNumber = accountNumber, Brand = brand, DocumentId = documentId});

                return new OkObjectResult(result);
            }
            catch (Exception ex)
            {
                await TrackException(ex, "MarkMessageAsRead", accountNumber, brand, documentId);
                throw;
            }
        }
    }
}
