﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;

namespace Servicing.Function.Documents
{
    public class HeartBeat
    {
        [FunctionName("HeartBeatFunction-GET")]
        public IActionResult Get(
            [HttpTrigger(AuthorizationLevel.Anonymous, "GET", Route = "HeartBeat")]
            HttpRequest req,
            ILogger logger)
        {
            logger.LogDebug("Heartbeat-GET success");
            return new OkObjectResult("OK");
        }

        [FunctionName("HeartBeatFunction-HEAD")]
        public IActionResult Head(
            [HttpTrigger(AuthorizationLevel.Anonymous, "HEAD", Route = "HeartBeat")]
            HttpRequest req,
            ILogger logger)
        {
            logger.LogDebug("Heartbeat-HEAD success");
            return new StatusCodeResult(200);
        }
    }
}