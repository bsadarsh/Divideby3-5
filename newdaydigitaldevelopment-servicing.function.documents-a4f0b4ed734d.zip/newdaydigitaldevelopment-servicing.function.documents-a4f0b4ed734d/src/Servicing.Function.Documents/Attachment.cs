using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Servicing.Function.Documents.Core.Extensions;
using Servicing.Function.Documents.Core.Helpers;
using Servicing.Function.Documents.Data.Providers;
using Servicing.Function.Documents.Data.Requests;
using System;
using System.Net;
using System.Threading.Tasks;
using Servicing.Function.Documents.Core.Exceptions;

namespace Servicing.Function.Documents
{
    public class GetAttachment : DocumentsFunctionBase
    {
        private readonly IQueryStringHelper _queryStringHelper;

        public GetAttachment(ITelemetryHelper telemetryHelper, 
            IRequestSerializer requestSerializer,
            Func<bool, IDocumentsProvider> documentsProviderDelegate,
            IQueryStringHelper queryStringHelper) : base(telemetryHelper, requestSerializer, documentsProviderDelegate)
        {
            _queryStringHelper = queryStringHelper;
        }

        [FunctionName("Attachment")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = null)] HttpRequest req)
        {
            var accountNumber = string.Empty;
            var brand = string.Empty;
            var documentId = Guid.Empty;

            try
            {
                accountNumber = _queryStringHelper.GetString(req.Query, "AccountNumber", minLength: 16, maxLength: 19);
                brand = _queryStringHelper.GetString(req.Query, "Brand");
                documentId = _queryStringHelper.GetGuid(req.Query, "DocumentID");
            }
            catch (Exception ex)
            {
                await TrackException(ex, "Attachment", accountNumber, brand, documentId, request: req);
                return new BadRequestResult();
            }

            try
            {
                var provider = GetDocumentsProvider(req);

                var response = await provider.GetAttachment(new AttachmentRequest
                    {AccountNumber = accountNumber, Brand = brand, DocumentId = documentId});

                if (response.Success)
                    return new OkObjectResult(response.Attachment);

                var statusCode = response.StatusCode switch
                {
                    HttpStatusCode.InternalServerError => 502,
                    HttpStatusCode.RequestTimeout => 504,
                    _ => (int)response.StatusCode
                };

                return new ObjectResult(response.Message)
                {
                    StatusCode = statusCode
                };

            }
            catch (Exception ex)
            {
                await TrackException(ex, "Attachment", accountNumber, brand, documentId);

                if (ex.InnerException is System.ServiceModel.EndpointNotFoundException)
                    return new StatusCodeResult((int) HttpStatusCode.BadGateway);

                throw;
            }
        }
    }
}
