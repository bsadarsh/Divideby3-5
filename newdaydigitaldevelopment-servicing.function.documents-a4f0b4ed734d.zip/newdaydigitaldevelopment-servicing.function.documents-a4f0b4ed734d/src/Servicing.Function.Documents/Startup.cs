﻿using System;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Servicing.Core.Http;
using Servicing.Function.Documents.Core.Config;
using Servicing.Function.Documents.Core.Helpers;
using Servicing.Function.Documents.Core.Security;
using Servicing.Function.Documents.Data.EntityFramework;
using Servicing.Function.Documents.Data.EntityFramework.Interceptors;
using Servicing.Function.Documents.Data.Helpers;
using Servicing.Function.Documents.Data.Providers;

[assembly: FunctionsStartup(typeof(Servicing.Function.Documents.Startup))]
namespace Servicing.Function.Documents
{
    public class Startup : FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)
        {
            ConfigureServices(builder.Services);
        }

        private static void ConfigureServices(IServiceCollection serviceCollection)
        {
            serviceCollection.AddSingleton<IConfig, Config>();
            serviceCollection.AddSingleton<ITelemetryHelper, TelemetryHelper>();
            serviceCollection.AddSingleton<IRequestSerializer, RequestSerializer>();
            serviceCollection.AddScoped<IQueryStringHelper, QueryStringHelper>();
            serviceCollection.AddScoped<IUserAccountsQuery, UserAccountsQuery>();
            serviceCollection.AddScoped<IUserDocumentsQuery, UserDocumentsQuery>();
            serviceCollection.AddSingleton<IFoundationDataStoreProvider, FoundationDataStoreProvider>();

            serviceCollection.AddScoped<IAuthenticationHeaderProvider, AuthenticationHeaderProvider>();
            serviceCollection.AddScoped<IRijndaelManagedEncryption, RijndaelManagedEncryption>();

            serviceCollection.AddScoped<Func<bool, IDocumentsProvider>>
            (
                serviceCollection => isMock =>
                {
                    DocumentRetrievalProviderBase documentRetrievalProvider;
                    DocumentSearchProviderBase documentSearchProvider;

                    if (isMock == true)
                    {
                        documentRetrievalProvider = new MockDocumentRetrievalProvider(serviceCollection.GetService<ITelemetryHelper>(), serviceCollection.GetService<IFoundationDataStoreProvider>());
                        documentSearchProvider = new MockDocumentSearchProvider(serviceCollection.GetService<IConfig>(), serviceCollection.GetService<ITelemetryHelper>());
                    }
                    else
                    {
                       documentRetrievalProvider = new DocumentRetrievalProvider(serviceCollection.GetService<IConfig>(), serviceCollection.GetService<ITelemetryHelper>(),
                           serviceCollection.GetService<IFoundationDataStoreProvider>(), serviceCollection.GetService<IAuthenticationHeaderProvider>());
                       documentSearchProvider = new DocumentSearchProvider(serviceCollection.GetService<IConfig>(), serviceCollection.GetService<ITelemetryHelper>(),
                           serviceCollection.GetService<IAuthenticationHeaderProvider>());
                    }

                    return new DocumentsProvider(serviceCollection.GetService<IConfig>(),
                        serviceCollection.GetService<ITelemetryHelper>(),
                            documentRetrievalProvider, documentSearchProvider,
                            serviceCollection.GetService<IUserDocumentsQuery>(),
                        serviceCollection.GetService<Database>(),
                        serviceCollection.GetService<IFoundationDataStoreProvider>());
                }
            );

            serviceCollection.AddHttpClient();
            serviceCollection.AddTransient<IRestApiClient, RestApiClient>();

            serviceCollection.AddSingleton<AadAuthenticationDbConnectionInterceptor>();

            serviceCollection.AddDbContext<Database>((provider, options) =>
            {
                options.UseSqlServer(Environment.GetEnvironmentVariable("DatabaseConnectionString") ?? throw new InvalidOperationException("Invalid database connection string"));

                options.AddInterceptors(provider.GetRequiredService<AadAuthenticationDbConnectionInterceptor>());
            }, ServiceLifetime.Transient);
        }
    }
}
