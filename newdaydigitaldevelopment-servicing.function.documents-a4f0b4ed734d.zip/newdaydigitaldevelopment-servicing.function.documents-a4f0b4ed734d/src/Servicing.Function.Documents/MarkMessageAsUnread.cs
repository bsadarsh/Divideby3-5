﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Servicing.Function.Documents.Core.Extensions;
using Servicing.Function.Documents.Core.Helpers;
using Servicing.Function.Documents.Data.Providers;
using Servicing.Function.Documents.Data.Requests;

namespace Servicing.Function.Documents
{
    public class MarkMessageAsUnread : DocumentsFunctionBase
    {
        private readonly IQueryStringHelper _queryStringHelper;

        public MarkMessageAsUnread(ITelemetryHelper telemetryHelper,
            IRequestSerializer requestSerializer,
            Func<bool, IDocumentsProvider> documentsProviderDelegate,
            IQueryStringHelper queryStringHelper) : base(telemetryHelper, requestSerializer, documentsProviderDelegate)
        {
            _queryStringHelper = queryStringHelper;
        }

        [FunctionName("MarkMessageAsUnread")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] HttpRequest req)
        {
            var accountNumber = string.Empty;
            var brand = string.Empty;
            var documentId = Guid.Empty;

            try
            {
                accountNumber = _queryStringHelper.GetString(req.Query, "AccountNumber", minLength: 16, maxLength: 19);
                brand = _queryStringHelper.GetString(req.Query, "Brand");
                documentId = _queryStringHelper.GetGuid(req.Query, "DocumentID");
            }
            catch (Exception ex)
            {
                await TrackException(ex, "MarkMessageAsUnread", accountNumber, brand, documentId, request: req);
                return new BadRequestResult();
            }

            try
            {
                var provider = GetDocumentsProvider(req);

                var result = await provider.MarkMessageAsUnread(new MarkMessageRequest
                { 
                    AccountNumber = accountNumber,
                    Brand = brand,
                    DocumentId = documentId
                });

                return new OkObjectResult(result);
            }
            catch (Exception ex)
            {
                await TrackException(ex, "MarkMessageAsUnread", accountNumber, brand, documentId);
                throw;
            }
        }
    }
}
