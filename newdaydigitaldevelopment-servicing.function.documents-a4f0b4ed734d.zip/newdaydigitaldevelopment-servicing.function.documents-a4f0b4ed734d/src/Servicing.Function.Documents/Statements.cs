﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Servicing.Function.Documents.Core.Helpers;
using Servicing.Function.Documents.Data.Providers;
using Servicing.Function.Documents.Data.Requests;
using System;
using System.Threading.Tasks;

namespace Servicing.Function.Documents
{
    public class GetStatements : DocumentsFunctionBase
    {
        private readonly IQueryStringHelper _queryStringHelper;

        public GetStatements(ITelemetryHelper telemetryHelper, 
            IRequestSerializer requestSerializer, 
            Func<bool, IDocumentsProvider> documentsProviderDelegate, 
            IQueryStringHelper queryStringHelper) : base(telemetryHelper, requestSerializer, documentsProviderDelegate)
        {
            _queryStringHelper = queryStringHelper;
        }

        [FunctionName("Statements")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = null)] HttpRequest req)
        {
            var accountNumber = string.Empty;
            var brand = string.Empty;

            try
            {
                accountNumber = _queryStringHelper.GetString(req.Query, "AccountNumber", minLength: 16, maxLength: 19);
                brand = _queryStringHelper.GetString(req.Query, "Brand");
            }
            catch (Exception ex)
            {
                await TrackException(ex, "Statements", accountNumber, brand, request: req);
                return new BadRequestResult();
            }

            try
            {
                var provider = GetDocumentsProvider(req);

                var statements = await provider.GetStatements(new StatementsRequest
                    {AccountNumber = accountNumber, Brand = brand});

                return new OkObjectResult(statements);
            }
            catch (Exception ex)
            {
                await TrackException(ex, "Statements", accountNumber, brand);
                throw;
            }
        }
    }
}
