﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Moq;
using Newtonsoft.Json;
using Servicing.Core.Http;
using Servicing.Function.Documents.Core.Config;
using Servicing.Function.Documents.Data.Models;
using Servicing.Function.Documents.Data.Providers;
using Servicing.Function.Documents.Data.Requests;
using Servicing.Function.Documents.Data.Responses;
using Xunit;

namespace UnitTests.Documents.Core
{
    public class FoundationDataStoreProviderTests
    {
        private readonly IFoundationDataStoreProvider _foundationDataStoreProvider;
        private readonly Mock<IRestApiClient> _restApiClient;

        public FoundationDataStoreProviderTests()
        {
            _restApiClient = new Mock<IRestApiClient>();
            var config = new Mock<IConfig>();

            _foundationDataStoreProvider = new FoundationDataStoreProvider(_restApiClient.Object, config.Object);
        }

        [Fact]
        public async Task FoundationSearch_ReturnsDocuments()
        {
            _restApiClient.Setup(x => x.SendAsync(HttpMethod.Post, It.IsAny<string>(),
                    It.IsAny<string>(), It.Is<FoundationSearchRequest>(req => req.SearchCriteria.Type == "creditcardagreement")))
                .ReturnsAsync(new RestApiResponse(true, "", HttpStatusCode.OK, "application/json", JsonConvert.SerializeObject(_mockFoundationResponse), new MemoryStream()));

            _restApiClient.Setup(x => x.SendAsync(HttpMethod.Post, It.IsAny<string>(),
                    It.IsAny<string>(), It.Is<FoundationSearchRequest>(req => req.SearchCriteria.Type != "creditcardagreement")))
                .ReturnsAsync(new RestApiResponse(true, "", HttpStatusCode.OK, "application/json",
                    JsonConvert.SerializeObject(new FoundationSearchResponse{Results = new List<ResultsItem>()}), new MemoryStream()));

            var documents = await _foundationDataStoreProvider.SearchAsync("7353010200245816");
            Assert.Equal(2, documents.Count);
            Assert.Equal(Guid.Parse("994e5f24-137c-4ae7-a44f-0e0bc17c942d"), documents[0].DocumentId);
            Assert.Equal("7353010200245816", documents[0].AccountNumber);
            Assert.Equal(DateTime.Parse("2020-09-30T13:38:14.2235702+00:00"), documents[0].Date);
        }

        [Fact]
        public async Task FoundationRetrieve_ReturnsRetrieveFoundationDocumentResponse()
        {
            _restApiClient
                .Setup(x => x.SendAsync(HttpMethod.Get, It.IsAny<string>(), It.IsAny<string>(), null))
                .ReturnsAsync(new RestApiResponse(true, "", HttpStatusCode.OK, "application/pdf", "testString", new MemoryStream()));

            var attachment = await _foundationDataStoreProvider.Retrieve("testId");
            Assert.IsType<RetrieveFoundationDocumentResponse>(attachment);
        }

        private readonly FoundationSearchResponse _mockFoundationResponse = new FoundationSearchResponse
        {
            Results = new List<ResultsItem>
            {
                new ResultsItem
                {
                    FileUuid = "994e5f24-137c-4ae7-a44f-0e0bc17c942d",
                    UploadedDate = "2020-09-30T13:38:14.2235702+00:00",
                    Tags = new FoundationTags
                    {
                        AccountId = "0007353010200245816",
                        Type = "creditcardagreement"
                    }
                },
                new ResultsItem
                {
                    FileUuid = "15777d41-386a-44ba-b365-12c2c784eb0a",
                    UploadedDate = "2020-11-03T13:38:14.2235702+00:00",
                    Tags = new FoundationTags
                    {
                        AccountId = "0007353010200245816",
                        Type = "creditcardagreement"
                    }
                }
            }
        };
    }
}
