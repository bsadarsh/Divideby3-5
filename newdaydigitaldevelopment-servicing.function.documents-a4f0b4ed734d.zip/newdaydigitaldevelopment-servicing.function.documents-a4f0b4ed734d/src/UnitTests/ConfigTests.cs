using Servicing.Function.Documents.Core.Config;
using Servicing.Function.Documents.Core.Exceptions;
using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Servicing.Function.Documents.Core.Models;
using Xunit;

namespace UnitTests
{
    public class ConfigTests
    {
        [Fact]
        public void WhenAnEnvironmentVariableIsMissing_ThenThrowAnEnvironmentVariableException()
        {
            Environment.SetEnvironmentVariable("APPINSIGHTS_INSTRUMENTATIONKEY", "");
            Environment.SetEnvironmentVariable("DatabaseConnectionString", "");
            Environment.SetEnvironmentVariable("NumMonthsMessagesKept", "");
            Environment.SetEnvironmentVariable("NumMonthsStatementsKept", "");
            Environment.SetEnvironmentVariable("WelcomeMessageDate", "");
            Environment.SetEnvironmentVariable("BlobStorageConnectionString", "");
            Environment.SetEnvironmentVariable("BlobStorageContainerName", "");
            Environment.SetEnvironmentVariable("AES", "");
            Environment.SetEnvironmentVariable("TenantId", "");
            Environment.SetEnvironmentVariable("ApimApplicationId", "");
            Environment.SetEnvironmentVariable("ApimBaseUrl", "");
            Environment.SetEnvironmentVariable("ApimPath", "");
            Environment.SetEnvironmentVariable("ApimSubscriptionKey", "");
            Environment.SetEnvironmentVariable("ParagonUsername", "");
            Environment.SetEnvironmentVariable("ParagonPasswordToken", "");
            Environment.SetEnvironmentVariable("ParagonSource", "");
            Environment.SetEnvironmentVariable("ParagonRetriesEnabled", "");
            Environment.SetEnvironmentVariable("ParagonRetryCount", "");
            Environment.SetEnvironmentVariable("DocTypeStatement", "");
            Environment.SetEnvironmentVariable("DocTypeDDNotification", "");
            Environment.SetEnvironmentVariable("DocTypeENov", "");
            Environment.SetEnvironmentVariable("NumDaysDocumentsCached", "");
            Environment.SetEnvironmentVariable("MaxStatementsToLoad", "");

            Assert.Throws<EnvironmentVariableException>(() => new Config());
        }

        [Fact]
        public void WhenNoEnvironmentVariableIsMissing_ThenDoNotThrowAnEnvironmentVariableException()
        {
            var foundationSearches = new FoundationSearches { SearchItems = new List<SearchItem>{new SearchItem{Type = "credit card agreement"}} };

            Environment.SetEnvironmentVariable("APPINSIGHTS_INSTRUMENTATIONKEY", "aiik");
            Environment.SetEnvironmentVariable("DatabaseConnectionString", "dcs");
            Environment.SetEnvironmentVariable("NumMonthsMessagesKept", "12");
            Environment.SetEnvironmentVariable("NumMonthsStatementsKept", "6");
            Environment.SetEnvironmentVariable("WelcomeMessageDate", "wmd");
            Environment.SetEnvironmentVariable("BlobStorageConnectionString", "bscs");
            Environment.SetEnvironmentVariable("BlobStorageContainerName", "bscn");
            Environment.SetEnvironmentVariable("AES", "aes");
            Environment.SetEnvironmentVariable("TenantId", "ti");
            Environment.SetEnvironmentVariable("ApimApplicationId", "aai");
            Environment.SetEnvironmentVariable("ApimBaseUrl", "abu");
            Environment.SetEnvironmentVariable("ApimPath", "ap");
            Environment.SetEnvironmentVariable("ApimSubscriptionKey", "ask");
            Environment.SetEnvironmentVariable("ParagonUsername", "pu");
            Environment.SetEnvironmentVariable("ParagonPasswordToken", "ppt");
            Environment.SetEnvironmentVariable("ParagonSource", "ps");
            Environment.SetEnvironmentVariable("ParagonRetriesEnabled", "true");
            Environment.SetEnvironmentVariable("ParagonRetryCount", "3");
            Environment.SetEnvironmentVariable("DocTypeStatement", "dts");
            Environment.SetEnvironmentVariable("DocTypeDDNotification", "dtd");
            Environment.SetEnvironmentVariable("DocTypeENov", "dte");
            Environment.SetEnvironmentVariable("NumDaysDocumentsCached", "365");
            Environment.SetEnvironmentVariable("MaxStatementsToLoad", "6");
            Environment.SetEnvironmentVariable("FoundationDataStore::BaseUrl", "asd1");
            Environment.SetEnvironmentVariable("FoundationDataStore::SearchEndpoint", "asd2");
            Environment.SetEnvironmentVariable("FoundationDataStore::RetrieveEndpoint", "dsa1");
            Environment.SetEnvironmentVariable("FoundationDataStore::TenantId", "asd3");
            Environment.SetEnvironmentVariable("FoundationDataStore::ResourceId", "asd4");
            Environment.SetEnvironmentVariable("FoundationDataStore::SubscriptionKey", "asd4");
            Environment.SetEnvironmentVariable("FoundationCcaBrands", "bip");
            Environment.SetEnvironmentVariable("DefaultApiTimeout", "1000");
            Environment.SetEnvironmentVariable("CcaMessageBody", "asd6");


            var config = new Config();

            Assert.Equal("aiik", config.InstrumentationKey);
            Assert.Equal("dcs", config.DatabaseConnectionString);
            Assert.Equal(12, config.NumMonthsMessagesKept);
            Assert.Equal(6, config.NumMonthsStatementsKept);
            Assert.Equal("wmd", config.WelcomeMessageDate);
            Assert.Equal("bscs", config.BlobStorageConnectionString);
            Assert.Equal("bscn", config.BlobStorageContainerName);
            Assert.Equal("aes", config.AesPassword);
            Assert.Equal("ti", config.TenantId);
            Assert.Equal("aai", config.ApimApplicationId);
            Assert.Equal("abu", config.ApimBaseUrl);
            Assert.Equal("ap", config.ApimPath);
            Assert.Equal("ask", config.ApimSubscriptionKey);
            Assert.Equal("pu", config.ParagonUsername);
            Assert.Equal("ppt", config.ParagonPasswordToken);
            Assert.Equal("ps", config.ParagonSource);
            Assert.True(config.ParagonRetriesEnabled);
            Assert.Equal(3, config.ParagonRetryCount);
            Assert.Equal("dts", config.DocTypeStatement);
            Assert.Equal("dtd", config.DocTypeDDNotification);
            Assert.Equal("dte", config.DocTypeENov);
            Assert.Equal(365, config.NumDaysDocumentsCached);
            Assert.Equal(6, config.MaxStatementsToLoad);
            Assert.Equal("asd1", config.FoundationDataStoreBaseUrl);
            Assert.Equal("asd2", config.FoundationDataStoreSearchEndpoint);
            Assert.Equal("dsa1", config.FoundationDataStoreRetrieveEndpoint);
            Assert.Equal("asd3", config.FoundationDataStoreTenantId);
            Assert.Equal("asd4", config.FoundationDataStoreResourceId);
            Assert.Equal("bip", config.FoundationCcaBrands);
            Assert.Equal("asd6", config.CcaMessageBody);
        }
    }
}
