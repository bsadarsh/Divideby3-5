﻿namespace Servicing.Function.Documents.Data.Requests
{
    public class FoundationSearchRequest
    {
        public FoundationSearchCriteria SearchCriteria { get; set; }
    }

    public class FoundationSearchCriteria
    {
        public string AccountId { get; set; }

        public string Type { get; set; }
    }
}
