﻿using System;

namespace Servicing.Function.Documents.Data.Requests
{
    public class MarkMessageRequest
    {
        /// <summary>
        /// Gets or sets the account number.
        /// </summary>
        /// <value>The account number.</value>
        public string AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets the brand.
        /// </summary>
        /// <value>The brand.</value>
        public string Brand { get; set; }

        /// <summary>
        /// Gets or sets the document's ID.
        /// </summary>
        /// <value>The document's ID.</value>
        public Guid DocumentId { get; set; }
    }
}
