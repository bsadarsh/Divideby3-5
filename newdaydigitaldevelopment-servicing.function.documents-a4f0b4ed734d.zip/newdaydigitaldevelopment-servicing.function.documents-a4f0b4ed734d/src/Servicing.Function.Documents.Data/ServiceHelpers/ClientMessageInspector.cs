﻿using System.Net.Http.Headers;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Dispatcher;

namespace Servicing.Function.Documents.Data.ServiceHelpers
{
    public class ClientMessageInspector : IClientMessageInspector
    {
        private readonly AuthenticationHeaderValue _bearerToken;
        private readonly string _subscriptionKey;

        public ClientMessageInspector(AuthenticationHeaderValue bearerToken, string subscriptionKey)
        {
            _bearerToken = bearerToken;
            _subscriptionKey = subscriptionKey;
        }

        object IClientMessageInspector.BeforeSendRequest(ref Message request, IClientChannel channel)
        {
            HttpRequestMessageProperty httpRequestMessage;

            if (request.Properties.TryGetValue(HttpRequestMessageProperty.Name, out var value))
            {
                httpRequestMessage = (HttpRequestMessageProperty)value;
            }
            else
            {
                httpRequestMessage = new HttpRequestMessageProperty();
                request.Properties.Add(HttpRequestMessageProperty.Name, httpRequestMessage);
            }

            httpRequestMessage.Headers.Add("Authorization", _bearerToken.ToString());
            httpRequestMessage.Headers.Add("Ocp-Apim-Subscription-Key", _subscriptionKey);

            return null;
        }

        void IClientMessageInspector.AfterReceiveReply(ref Message reply, object correlationState)
        {
            //nothing to do
        }
    }
}
