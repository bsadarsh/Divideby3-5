﻿using System.Net.Http.Headers;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;

namespace Servicing.Function.Documents.Data.ServiceHelpers
{
    public class EndpointBehavior : IEndpointBehavior
    {
        private readonly AuthenticationHeaderValue _bearerToken;
        private readonly string _subscriptionKey;

        public EndpointBehavior(AuthenticationHeaderValue bearerToken, string subscriptionKey)
        {
            _bearerToken = bearerToken;
            _subscriptionKey = subscriptionKey;
        }

        void IEndpointBehavior.ApplyClientBehavior(ServiceEndpoint endpoint, ClientRuntime clientRuntime)
        {
            var inspector = new ClientMessageInspector(_bearerToken, _subscriptionKey);
            clientRuntime.ClientMessageInspectors.Add(inspector);
        }

        void IEndpointBehavior.AddBindingParameters(ServiceEndpoint endpoint, BindingParameterCollection bindingParameters)
        {
            //nothing to do
        }

        void IEndpointBehavior.ApplyDispatchBehavior(ServiceEndpoint endpoint, EndpointDispatcher endpointDispatcher)
        {
            //nothing to do
        }

        void IEndpointBehavior.Validate(ServiceEndpoint endpoint)
        {
            //nothing to do
        }
    }
}
