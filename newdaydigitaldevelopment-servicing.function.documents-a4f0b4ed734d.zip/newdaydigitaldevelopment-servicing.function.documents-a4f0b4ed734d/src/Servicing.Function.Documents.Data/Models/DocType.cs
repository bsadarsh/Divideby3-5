﻿namespace Servicing.Function.Documents.Data.Models
{
    /// <summary>
    /// Enum Doctype
    /// </summary>
    public enum DocType
    {
        /// <summary>
        /// Welcome message
        /// </summary>
        Welcome,
        /// <summary>
        /// The statement
        /// </summary>
        Statement,
        /// <summary>
        /// The e nov document
        /// </summary>
        ENovDocument,
        /// <summary>
        /// The direct debit notification document
        /// </summary>
        DDNotification,
        /// <summary>
        /// The e letter document category
        /// </summary>
        ELetter
    }
}
