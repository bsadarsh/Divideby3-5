﻿using System.Net;

namespace Servicing.Function.Documents.Data.Models
{
    public class RetrieveFoundationDocumentResponse
    {
        public bool Success { get; set; }

        public HttpStatusCode StatusCode { get; set; }

        public string Message { get; set; }

        public byte[] Content { get; set; }
    }
}
