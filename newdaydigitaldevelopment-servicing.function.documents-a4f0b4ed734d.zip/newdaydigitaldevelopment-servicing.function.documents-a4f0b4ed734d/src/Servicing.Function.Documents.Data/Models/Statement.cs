﻿using System;

namespace Servicing.Function.Documents.Data.Models
{
    /// <summary>
    /// Class Statement.
    /// </summary>
    public class Statement
    {
        /// <summary>
        /// Gets or sets the document's ID.
        /// </summary>
        /// <value>The document's ID.</value>
        public Guid DocumentId { get; set; }

        /// <summary>
        /// Gets or sets the date.
        /// </summary>
        /// <value>The date.</value>
        public DateTime Date { get; set; }

        /// <summary>
        /// Whether the document has been downloaded from Paragon.
        /// </summary>
        public bool HasCopyInBlob { get; set; }
    }
}
