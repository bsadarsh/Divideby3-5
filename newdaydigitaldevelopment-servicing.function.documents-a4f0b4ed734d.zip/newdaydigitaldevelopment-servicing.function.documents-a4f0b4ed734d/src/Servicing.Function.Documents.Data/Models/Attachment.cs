﻿using System;

namespace Servicing.Function.Documents.Data.Models
{
    /// <summary>
    /// Class Attachment.
    /// </summary>
    public class Attachment
    {
        /// <summary>
        /// Gets or sets the document's ID.
        /// </summary>
        /// <value>The document's ID.</value>
        public Guid DocumentId { get; set; }

        /// <summary>
        /// Gets or sets the document's type.
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// Gets or sets the document's content.
        /// </summary>
        /// <value>The document's content.</value>
        public byte[] Content { get; set; }
    }
}
