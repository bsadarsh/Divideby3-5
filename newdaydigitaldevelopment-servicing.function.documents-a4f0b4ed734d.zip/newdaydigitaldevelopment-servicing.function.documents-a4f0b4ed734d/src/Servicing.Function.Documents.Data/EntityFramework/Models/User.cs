﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Servicing.Function.Documents.Data.EntityFramework.Models
{
    /// <summary>
    /// Class User.
    /// </summary>
    public class User
    {
        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        [Key]
        public Guid Id { get; set; }

        /// <summary>
        /// Gets or sets the name of the user.
        /// </summary>
        /// <value>The name of the user.</value>
        public string UserName { get; set; }

        /// <summary>
        /// Gets or sets the account number.
        /// </summary>
        /// <value>The account number.</value>
        public string AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets the last login.
        /// </summary>
        /// <value>The last login.</value>
        public DateTime LastLogin { get; set; }

        /// <summary>
        /// Gets or sets the current login.
        /// </summary>
        /// <value>The current login.</value>
        public DateTime CurrentLogin { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [first time logon].
        /// </summary>
        /// <value><c>true</c> if [first time user]; otherwise, <c>false</c>.</value>
        public bool FirstTimeUser { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the user is migrated in
        /// </summary>
        public bool IsMigrated { get; set; }

        /// <summary>
        /// Gets or sets the identity server identifier.
        /// </summary>
        /// <value>The identity server identifier.</value>
        public string IdentityServerId { get; set; }

        /// <summary>
        /// Gets or sets the brand.
        /// </summary>
        /// <value>The brand.</value>
        public string Brand { get; set; }
    }
}
