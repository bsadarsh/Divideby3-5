﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Servicing.Function.Documents.Data.EntityFramework.Models
{
    /// <summary>
    /// Class HistoricAccountNumber.
    /// </summary>
    public class HistoricAccountNumber
    {
        /// <summary>
        /// Gets or sets the historic account number.
        /// </summary>
        /// <value>The historic account number.</value>
        [Key]
        [Column("HistoricAccountNumber")]
        public string AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets the user identifier.
        /// </summary>
        /// <value>The user identifier.</value>
        public Guid UserId { get; set; }

        /// <summary>
        /// Gets or sets the user.
        /// </summary>
        /// <value>The user.</value>
        public virtual User User { get; set; }

        /// <summary>
        /// Gets or sets the transfer date.
        /// </summary>
        /// <value>The transfer date.</value>
        public DateTime? TransferDate { get; set; }
    }
}
