﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Servicing.Function.Documents.Data.EntityFramework.Models
{
    public class Document
    {
        /// <summary>
        /// Gets or sets the statement identifier.
        /// </summary>
        /// <value>The statement identifier.</value>
        [Key]
        public long Id { get; set; }

        /// <summary>
        /// Gets or sets the user identifier.
        /// </summary>
        /// <value>The user identifier.</value>
        public Guid DocumentId { get; set; }

        /// <summary>
        /// Gets or sets the account number.
        /// </summary>
        /// <value>The account number.</value>
        public string AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets the type.
        /// </summary>
        /// <value>The type.</value>
        public string Type { get; set; }

        /// <summary>
        /// Gets or sets the issue date.
        /// </summary>
        /// <value>The issue date.</value>
        public DateTime Date { get; set; }

        /// <summary>
        /// Gets or sets the size.
        /// </summary>
        /// <value>The size.</value>
        public long Size { get; set; }

        /// <summary>
        /// Gets or sets the pepper.
        /// </summary>
        /// <value>The pepper.</value>
        public string Salt { get; set; }

        /// <summary>
        /// Gets or sets the expiry date.
        /// </summary>
        /// <value>The expiry date.</value>
        public DateTime ExpiryDate { get; set; }

        /// <summary>
        /// Gets or sets the read/unread status.
        /// </summary>
        /// <value>The read status.</value>
        public bool Read { get; set; }

        /// <summary>
        /// Gets or sets the title.
        /// </summary>
        /// <value>The title.</value>
        public string Title { get; set; } 
    }
}
