﻿using System;
using System.Data;
using System.Data.Common;
using System.Threading;
using System.Threading.Tasks;
using Azure.Core;
using Azure.Identity;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace Servicing.Function.Documents.Data.EntityFramework.Interceptors
{
    public class AadAuthenticationDbConnectionInterceptor : DbConnectionInterceptor
    {
        private static readonly string[] AzureSqlScopes = {
            "https://database.windows.net//.default"
        };

        public override async Task<InterceptionResult> ConnectionOpeningAsync(
            DbConnection connection,
            ConnectionEventData eventData,
            InterceptionResult result,
            CancellationToken cancellationToken)
        {
            var sqlConnection = (SqlConnection)connection;
            if (ConnectionNeedsAccessToken(sqlConnection))
            {
                var tokenRequestContext = new TokenRequestContext(AzureSqlScopes);
                var token = await new DefaultAzureCredential().GetTokenAsync(tokenRequestContext, cancellationToken);
                sqlConnection.AccessToken = token.Token;
            }

            return await base.ConnectionOpeningAsync(connection, eventData, result, cancellationToken);
        }

        public override InterceptionResult ConnectionOpening(
            DbConnection connection,
            ConnectionEventData eventData,
            InterceptionResult result)
        {
            var sqlConnection = (SqlConnection)connection;
            if (ConnectionNeedsAccessToken(sqlConnection))
            {
                var tokenRequestContext = new TokenRequestContext(AzureSqlScopes);
                var token = new DefaultAzureCredential().GetToken(tokenRequestContext);
                sqlConnection.AccessToken = token.Token;
            }

            return base.ConnectionOpening(connection, eventData, result);
        }

        private static bool ConnectionNeedsAccessToken(IDbConnection connection)
        {
            // Only try to get a token from AAD if
            //  - We connect to an Azure SQL instance; and
            //  - The connection doesn't specify a username.

            var connectionStringBuilder = new SqlConnectionStringBuilder(connection.ConnectionString);

            return connectionStringBuilder.DataSource.Contains("database.windows.net", StringComparison.OrdinalIgnoreCase) && string.IsNullOrEmpty(connectionStringBuilder.UserID);
        }
    }
}