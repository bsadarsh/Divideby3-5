﻿using System;
using Microsoft.Azure.Services.AppAuthentication;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Servicing.Function.Documents.Core.Config;
using Servicing.Function.Documents.Data.EntityFramework.Models;

namespace Servicing.Function.Documents.Data.EntityFramework
{
    public class Database : DbContext
    {
        public Database(DbContextOptions options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }

        public DbSet<Document> DstDocuments { get; set; }

        public DbSet<HistoricAccountNumber> HistoricAccountNumbers { get; set; }
    }
}
