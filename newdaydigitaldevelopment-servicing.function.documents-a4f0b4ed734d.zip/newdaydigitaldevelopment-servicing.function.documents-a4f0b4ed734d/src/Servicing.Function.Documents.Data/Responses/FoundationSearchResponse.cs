﻿using System.Collections.Generic;

namespace Servicing.Function.Documents.Data.Responses
{
    public class FoundationSearchResponse
    {
        public List<ResultsItem> Results { get; set; }
    }

    public class ResultsItem
    {
        public string FileUuid { get; set; }

        public FoundationTags Tags { get; set; }

        public string UploadedDate { get; set; }

        public string Classification { get; set; }

        public string DocumentUse { get; set; }

        public string DocumentType { get; set; }

        public string StorageLocation { get; set; }

        public string DocumentEndDate { get; set; }

        public string MediaType { get; set; }
    }

    public class FoundationTags
    {
        public string Type { get; set; }

        public string SubType { get; set; }

        public string AccountId { get; set; }

        public string CustomerLastName { get; set; }

        public string CustomerDob { get; set; }

        public string CustomerMobile { get; set; }

        public string CustomerPostcode { get; set; }

        public string ApplicationId { get; set; }

        public string ApplicationRef { get; set; }

        public string Origin { get; set; }

        public string PersonId { get; set; }

        public string State { get; set; }

        public string SearchByAccountId { get; set; }

        public string SearchByApplicationId { get; set; }

        public string DocumentDataType { get; set; }
    }
}
