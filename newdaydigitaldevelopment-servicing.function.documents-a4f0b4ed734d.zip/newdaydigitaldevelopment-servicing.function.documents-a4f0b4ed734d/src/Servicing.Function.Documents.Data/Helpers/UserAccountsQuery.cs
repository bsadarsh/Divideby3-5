﻿using Microsoft.EntityFrameworkCore;
using Servicing.Function.Documents.Data.EntityFramework;
using Servicing.Function.Documents.Data.EntityFramework.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Servicing.Function.Documents.Data.Helpers
{
    public class UserAccountsQuery : IUserAccountsQuery
    {
        private readonly IQueryable<User> _users;
        private readonly IQueryable<HistoricAccountNumber> _historicAccounts;

        // Dependency injection constructor
        public UserAccountsQuery(Database database)
        {
            _users = database.Users.AsNoTracking();
            _historicAccounts = database.HistoricAccountNumbers;
        }

        public async Task<IEnumerable<string>> Get(string accountNumber, string brand)
        {
            // Entity Framework Core 2.2 performs unions locally and operation generates warnings in logs.
            // To avoid concerns about the warnings, following queries are intentionally merged manually.
           var primaryAccount = await _users.SingleOrDefaultAsync(u =>
                    u.AccountNumber == accountNumber && 
                    u.Brand == brand);

                if (primaryAccount == null)
                    throw new InvalidOperationException($"Account not found: {accountNumber} / {brand}");

                var primaryAccountNumber = primaryAccount.AccountNumber;
                var userId = primaryAccount.Id;

                var historicalAccountNumbers = await _historicAccounts
                    .Where(x => x.UserId == userId)
                    .Select(x => x.AccountNumber)
                    .ToListAsync();

                return new[] { primaryAccountNumber }.Concat(historicalAccountNumbers);
        }
    }
}
