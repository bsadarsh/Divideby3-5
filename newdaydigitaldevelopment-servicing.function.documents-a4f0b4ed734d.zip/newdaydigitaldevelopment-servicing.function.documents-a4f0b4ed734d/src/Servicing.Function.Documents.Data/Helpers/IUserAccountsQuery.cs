﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Servicing.Function.Documents.Data.EntityFramework;

namespace Servicing.Function.Documents.Data.Helpers
{
    public interface IUserAccountsQuery
    {
        Task<IEnumerable<string>> Get(string accountNumber, string brand);
    }
}
