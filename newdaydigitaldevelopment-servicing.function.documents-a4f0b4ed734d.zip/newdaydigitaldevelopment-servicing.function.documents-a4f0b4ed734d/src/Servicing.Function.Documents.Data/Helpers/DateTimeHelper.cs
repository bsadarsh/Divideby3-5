﻿using System;
using System.Globalization;

namespace Servicing.Function.Documents.Data.Helpers
{
    public static class DateTimeHelper
    {
        /// <summary>
        /// Parses the processing date - Paragon has inconsistent processing date time returned
        /// </summary>
        public static DateTime ParseProcessingDate(string dateString)
        {
            if (DateTime.TryParseExact(dateString, "yyyyMMddHHmmss", CultureInfo.InvariantCulture, DateTimeStyles.None, out var dateValue))
                return dateValue;

            if (DateTime.TryParseExact(dateString, "d-MMM-yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out dateValue))
                return dateValue;

            if (DateTime.TryParseExact(dateString, "d-MMM-yy", CultureInfo.InvariantCulture, DateTimeStyles.None, out dateValue))
                return dateValue;

            if (DateTime.TryParseExact(dateString, "d-M-yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out dateValue))
                return dateValue;

            if (DateTime.TryParseExact(dateString, "d-M-yy", CultureInfo.InvariantCulture, DateTimeStyles.None, out dateValue))
                return dateValue;

            if (DateTime.TryParseExact(dateString, "d/M/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out dateValue))
                return dateValue;

            if (DateTime.TryParseExact(dateString, "d/M/yy", CultureInfo.InvariantCulture, DateTimeStyles.None, out dateValue))
                return dateValue;

            throw new FormatException($"Unable to parse processing date {dateString}");
        }
    }
}
