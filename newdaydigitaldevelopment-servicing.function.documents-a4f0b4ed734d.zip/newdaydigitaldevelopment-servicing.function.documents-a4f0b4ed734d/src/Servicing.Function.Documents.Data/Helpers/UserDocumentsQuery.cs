﻿using LinqKit;
using Servicing.Function.Documents.Data.EntityFramework;
using Servicing.Function.Documents.Data.EntityFramework.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Servicing.Function.Documents.Data.Helpers
{
    public class UserDocumentsQuery : IUserDocumentsQuery
    {
        private readonly Database _database;
        private readonly IQueryable<Document> _documents;
        private readonly IUserAccountsQuery _userAccountsQuery;

        // Dependency injection constructor
        public UserDocumentsQuery(Database database, IUserAccountsQuery userAccountsQuery)
        {
            _database = database;
            _documents = database.DstDocuments;
            _userAccountsQuery = userAccountsQuery;
        }

        public async Task<IQueryable<Document>> Get(string accountNumber, string brand, bool trackChanges = false)
        {
            // Entity Framework Core 2.2 executes UNION locally - data is downloaded and merged in memory, not in SQL server.
            // If the result of the union is followed by a filtration, this means that huge amount of data might be downloaded
            // and filtering will be applied locally.
            // Keep that pitfall in mind when editing the query!
            var userAccounts = await _userAccountsQuery.Get(accountNumber, brand);

            // Using .Contains() method instead of custom-built expression will insert the account numbers
            // into the query as values (AccountNumber IN (12345, 67890), not as parameters (AccountNumber IN (@account_0, @account_1)).
            // The latter is preferred to avoid excessive query plan recalculations.
            var documents = _documents.Where(BelongsToAny(userAccounts));

            // Default to no change tracking unless requested
            return trackChanges ? documents : documents.AsNoTracking();
        }

        public Task<bool> MarkMessageAsRead(Guid documentId)
        {
            return UpdateMessageReadFlag(documentId, read: true);
        }

        public Task<bool> MarkMessageAsUnread(Guid documentId)
        {
            return UpdateMessageReadFlag(documentId, read: false);
        }

        private async Task<bool> UpdateMessageReadFlag(Guid documentId, bool read)
        {
            // Unfortunately there are duplicates in the database and until that is fixed we cannot use .Single()
            var docs = await _documents.Where(d => d.DocumentId == documentId).ToListAsync();
            
            if (!docs.Any())
                return false;

            foreach (var doc in docs)
            {
                doc.Read = read;
            }

            await _database.SaveChangesAsync();

            return true;
        }

        private static Expression<Func<Document, bool>> BelongsToAny(IEnumerable<string> accounts)
        {
            return accounts.Aggregate(
                PredicateBuilder.New<Document>(false),
                (current, account) => current.Or(d => d.AccountNumber == account));
        }
    }
}
