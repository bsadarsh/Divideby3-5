﻿using System;
using Servicing.Function.Documents.Data.EntityFramework.Models;
using System.Linq;
using System.Threading.Tasks;
using Servicing.Function.Documents.Data.EntityFramework;

namespace Servicing.Function.Documents.Data.Helpers
{
    public interface IUserDocumentsQuery
    {
        Task<IQueryable<Document>> Get(string accountNumber, string brand, bool trackChanges = false);

        Task<bool> MarkMessageAsRead(Guid documentId);

        Task<bool> MarkMessageAsUnread(Guid documentId);
    }
}
