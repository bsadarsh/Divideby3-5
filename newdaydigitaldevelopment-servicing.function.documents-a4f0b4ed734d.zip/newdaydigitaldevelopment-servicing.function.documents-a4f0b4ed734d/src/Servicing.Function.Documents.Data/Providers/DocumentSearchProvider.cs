﻿using ServiceReference1;
using Servicing.Function.Documents.Core.Config;
using Servicing.Function.Documents.Core.Exceptions;
using Servicing.Function.Documents.Core.Helpers;
using Servicing.Function.Documents.Data.EntityFramework.Models;
using Servicing.Function.Documents.Data.Helpers;
using Servicing.Function.Documents.Data.Models;
using Servicing.Function.Documents.Data.ServiceHelpers;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.ServiceModel;
using System.Threading.Tasks;

namespace Servicing.Function.Documents.Data.Providers
{
    public class DocumentSearchProvider : DocumentSearchProviderBase
    {
        private readonly IConfig _config;
        private readonly IAuthenticationHeaderProvider _authenticationHeaderProvider;
        private readonly ParagonAuthentication _paragonAuthentication;

        public DocumentSearchProvider(
            IConfig config,
            ITelemetryHelper telemetryHelper,
            IAuthenticationHeaderProvider authenticationHeaderProvider
            ):base(
                config,
                telemetryHelper
                )
            
        {
            _config = config;
            _authenticationHeaderProvider = authenticationHeaderProvider;
            _paragonAuthentication = new ParagonAuthentication(config);
        }

        protected async override Task<DocumentSearchResultsData> SearchForDocumentsInternal(string accountNumber)
        {
            var bearerToken = await _authenticationHeaderProvider.GetBearerToken();

            var uri = new Uri(_config.ApimBaseUrl + _config.ApimPath);
            var address = new EndpointAddress(uri);

            var searchData = GetSearchCriteria(accountNumber);

            var authenticationData = _paragonAuthentication.MakeAuthenticationData();

            const int firstRow = 0;
            const int lastRow = 50;
            const int region = 2;

            DocumentSearchResultsData searchResult;
            for (var attempt = 1; ; ++attempt)
            {
                try
                {
                    var client = new DocumentClient(DocumentClient.EndpointConfiguration.BasicHttpBinding_IDocument, address);
                    client.Endpoint.EndpointBehaviors.Add(new EndpointBehavior(bearerToken, _config.ApimSubscriptionKey));
                    searchResult = await client.DocumentSearchMapAsync(authenticationData, firstRow, lastRow, region, null, null, searchData);
                    break;
                }
                catch (Exception ex)
                {
                    TelemetryHelper.Client.TrackTrace(
                        $"Unable to get documents from Paragon (attempt {attempt} of {_config.ParagonRetryCount})",
                        new Dictionary<string, string>
                        {
                            ["Type"] = ex.GetType().ToString(),
                            ["Exception"] = ex.Message,
                            ["StackTrace"] = ex.StackTrace
                        });

                    if (!_config.ParagonRetriesEnabled || attempt >= _config.ParagonRetryCount)
                        throw new DocumentException("Unable to get documents from Paragon", ex);
                }
            }

            return searchResult;
        }



        private static IndexNameCriteriaData[] GetSearchCriteria(string accountNumber)
        {
            if (accountNumber.Length == 19)
                accountNumber = accountNumber.Substring(3);

            return new[]
            {
                MakeSearchCriteria("ACCOUNTNUMBER", accountNumber),
                MakeSearchCriteria("CLIENTACTIVEDISPLAY", "TRUE"),
                MakeSearchCriteria("JOBTYPE", "S"),
                MakeSearchCriteria("JOBTYPE", "T"),
                MakeSearchCriteria("JOBTYPE", "L")
            };
        }

        private static IndexNameCriteriaData MakeSearchCriteria(string indexName, string searchValue)
        {
            return new IndexNameCriteriaData
            {
                IndexName = indexName,
                SearchValue = searchValue,
                ApplicationId = string.Empty,
                Grid = string.Empty
            };
        }
    }
}
