﻿using ServiceReference1;
using Servicing.Function.Documents.Core.Config;
using Servicing.Function.Documents.Core.Helpers;
using Servicing.Function.Documents.Data.EntityFramework.Models;
using Servicing.Function.Documents.Data.Helpers;
using Servicing.Function.Documents.Data.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;


namespace Servicing.Function.Documents.Data.Providers
{
    public abstract class DocumentSearchProviderBase
    {
        private readonly IConfig _config;
        protected readonly ITelemetryHelper TelemetryHelper;

        public DocumentSearchProviderBase(
            IConfig config,
            ITelemetryHelper telemetryHelper
            )
        {
            _config = config;
            TelemetryHelper = telemetryHelper;
        }

        protected abstract Task<DocumentSearchResultsData> SearchForDocumentsInternal(string accountNumber);

        public async Task<IEnumerable<Document>> SearchForDocuments(string accountNumber)
        {
            var searchResult = await SearchForDocumentsInternal(accountNumber);

            Debug.Assert(searchResult != null);

            var docCounts = new DocumentCounts();

            var results = GetDocumentResults(searchResult.DocumentList, docCounts, accountNumber);
            if (results.Any())
            {
                //Find the duplicates from the results
                var duplicates = results
                    .OrderBy(doc => doc.Date)
                    .GroupBy(doc => doc.DocumentId)
                    .Where(doc => doc.Count() > 1)
                    .Select(x => x.First())
                    .ToList();

                //Log the duplicate Ids
                docCounts.DuplicateIds.AddRange(duplicates.Select(duplicate => duplicate.DocumentId.ToString()));

                results = results
                    .Except(duplicates)
                    .OrderByDescending(d => d.Date)
                    .ToList();
            }

            var props = new Dictionary<string, string>()
            {
                ["Account"] = accountNumber,
                ["Doctype added"] = string.Join(",", docCounts.DocTypeValuesAdded.ToArray()),
                ["Doctype removed"] = string.Join(",", docCounts.DocTypeValuesRemoved.ToArray()),
                ["Doctype added BBR"] = string.Join(",", docCounts.DocumentIds.ToArray()),
                ["Document dates"] = string.Join(",", docCounts.DocumentDates.ToArray()),
                ["Duplicate documents"] = string.Join(",", docCounts.DuplicateIds.ToArray())
            };
            var metrics = new Dictionary<string, double>()
            {
                ["Results"] = searchResult.TotalRecordsFound
            };
            TelemetryHelper.Client.TrackEvent("Document List", props, metrics);

            return results;
        }


        private IReadOnlyList<Document> GetDocumentResults(IndexedDocumentData[] searchResultDocumentList,
            DocumentCounts docCounts, string accountNumber)
        {
            var documentResults = new List<Document>();

            foreach (var document in searchResultDocumentList)
            {
                try
                {
                    var doc = CreateDocument(document, docCounts, accountNumber);
                    if (doc != null)
                        documentResults.Add(doc);
                }
                catch (Exception ex)
                {
                    TelemetryHelper.Client.TrackException(ex, new Dictionary<string, string>
                    {
                        ["Doctype"] = string.Intern(DocType.ENovDocument.ToString()),
                        ["DocumentId"] = document.Id.ToString()
                    });
                }
            }

            return documentResults;
        }

        private Document CreateDocument(IndexedDocumentData document, DocumentCounts docCounts, string accountNumber)
        {
            docCounts.DocumentIds.Add(document.Id.ToString());

            var mappedIndexes = document.MappedIndexes.ToDictionary(x => x.IndexName, x => !string.IsNullOrEmpty(x.IndexValue) ? x.IndexValue.ToUpper() : string.Empty);
            var doctypeValue = mappedIndexes["DOCTYPE"];
            var jobType = GetIndexValue(document, "JOBTYPE");

            var isStatement = doctypeValue.Contains(_config.DocTypeStatement);
            var isENov = doctypeValue.Contains(_config.DocTypeENov);
            var isELetter = jobType == "L";

            TelemetryHelper.Client.TrackEvent($"Processing document {isELetter} -  {doctypeValue} called {document.DisplayName} with this fname {document.FileName}");

            if (!isStatement && !isENov && !isELetter)
            {
                docCounts.DocTypeValuesRemoved.Add(doctypeValue);
                return null;
            }

            docCounts.DocTypeValuesAdded.Add(doctypeValue);

            DocType docType;
            DateTime date;
            int expiryMonths;

            if (isStatement)
                (docType, date, expiryMonths) = ProcessStatement(document, docCounts);
            else if (isENov)
                (docType, date, expiryMonths) = ProcessENov(document, docCounts);
            else
            {
                Debug.Assert(isELetter);
                (docType, date, expiryMonths) = ProcessELetter(document, docCounts);
            }

            return new Document
            {
                DocumentId = document.Id,
                AccountNumber = accountNumber,
                Type = docType.ToString(),
                Date = date,
                ExpiryDate = date.AddMonths(expiryMonths),
                Size = document.Size,
                Salt = ""
            };
        }

        private (DocType docType, DateTime date, int expiryMonths) ProcessStatement(
            IndexedDocumentData document, DocumentCounts docCounts)
        {
            var billingDateValue = GetIndexValue(document, "BILLINGDATE");
            docCounts.DocumentDates.Add($"{document.Id}:{billingDateValue}");
            var billingDate = DateTime.ParseExact(billingDateValue, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            return (DocType.Statement, billingDate, _config.NumMonthsStatementsKept);
        }

        private (DocType docType, DateTime date, int expiryMonths) ProcessENov(
            IndexedDocumentData document, DocumentCounts docCounts)
        {
            var processingDateValue = GetIndexValue(document, "PROCESSINGDATE");
            docCounts.DocumentDates.Add($"{document.Id}:{processingDateValue}");
            var processingDate = ParseProcessingDate(processingDateValue);
            return (DocType.ENovDocument, processingDate, _config.NumMonthsMessagesKept);
        }

        private (DocType docType, DateTime date, int expiryMonths) ProcessELetter(
            IndexedDocumentData document, DocumentCounts docCounts)
        {
            var processingDateValue = GetIndexValue(document, "PROCESSINGDATE");
            docCounts.DocumentDates.Add($"{document.Id}:{processingDateValue} but using {DateTime.Now}");
            return (DocType.DDNotification, DateTime.Now, _config.NumMonthsMessagesKept);
        }

        private static DateTime ParseProcessingDate(string processingDateString)
            => DateTimeHelper.ParseProcessingDate(processingDateString);

        private static string GetIndexValue(IndexedDocumentData doc, string indexname)
            => doc.MappedIndexes.FirstOrDefault(o => o.IndexName == indexname)?.IndexValue ?? "";

        private class DocumentCounts
        {
            public List<string> DocumentIds { get; } = new List<string>();
            public List<string> DocTypeValuesAdded { get; } = new List<string>();
            public List<string> DocTypeValuesRemoved { get; } = new List<string>();
            public List<string> DocumentDates { get; } = new List<string>();
            public List<string> DuplicateIds { get; } = new List<string>();
        }
    }
}
