﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Servicing.Function.Documents.Data.EntityFramework.Models;
using Servicing.Function.Documents.Data.Models;

namespace Servicing.Function.Documents.Data.Providers
{
    public interface IFoundationDataStoreProvider
    {
        Task<RetrieveFoundationDocumentResponse> Retrieve(string documentId);

        Task<List<Document>> SearchAsync(string accountNumber);
    }
}