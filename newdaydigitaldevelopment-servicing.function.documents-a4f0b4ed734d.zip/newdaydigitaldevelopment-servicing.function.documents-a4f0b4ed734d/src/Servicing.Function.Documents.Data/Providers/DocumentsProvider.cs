﻿using Microsoft.EntityFrameworkCore;
using Servicing.Function.Documents.Core.Config;
using Servicing.Function.Documents.Core.Exceptions;
using Servicing.Function.Documents.Core.Helpers;
using Servicing.Function.Documents.Data.EntityFramework;
using Servicing.Function.Documents.Data.EntityFramework.Models;
using Servicing.Function.Documents.Data.Helpers;
using Servicing.Function.Documents.Data.Models;
using Servicing.Function.Documents.Data.Requests;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using SharedInterfaces.Models;

namespace Servicing.Function.Documents.Data.Providers
{
    public class DocumentsProvider : IDocumentsProvider
    {
        private static readonly string StatementTypeName = string.Intern(DocType.Statement.ToString());
        private static readonly string WelcomeTypeName = string.Intern(DocType.Welcome.ToString());

        private readonly IConfig _config;
        private readonly ITelemetryHelper _telemetryHelper;
        private readonly DocumentRetrievalProviderBase _documentRetrievalProvider;
        private readonly DocumentSearchProviderBase _documentSearchProvider;
        private readonly IUserDocumentsQuery _userDocumentsQuery;
        private readonly Database _database;
        private readonly IFoundationDataStoreProvider _foundationDataStoreProvider;
        
        public DocumentsProvider(
            IConfig config,
            ITelemetryHelper telemetryHelper,
            DocumentRetrievalProviderBase documentRetrievalProvider,
            DocumentSearchProviderBase documentSearchProvider,
            IUserDocumentsQuery userDocumentsQuery,
            Database database,
            IFoundationDataStoreProvider foundationDataStoreProvider)
        {
            _config = config;
            _telemetryHelper = telemetryHelper;
            _documentRetrievalProvider = documentRetrievalProvider;
            _documentSearchProvider = documentSearchProvider;
            _userDocumentsQuery = userDocumentsQuery;
            _database = database;
            _foundationDataStoreProvider = foundationDataStoreProvider;
        }

        public async Task<IEnumerable<InboxMessage>> GetMessages(MessagesRequest request)
        {
            var welcomeMessageType = WelcomeTypeName;
            var messages = new List<InboxMessage>
            {
                //Welcome message
                new InboxMessage
                {
                    Type = welcomeMessageType,
                    Date = DateTime.ParseExact(_config.WelcomeMessageDate, "dd/MM/yyyy", CultureInfo.InvariantCulture),
                    Read = true,
                    Title = "Welcome to your Inbox"
                }
            };

            var dbDocuments = await RetrieveInboxDocumentsAsync(request.AccountNumber, request.Brand);
            var earliestDate = DateTime.Now.AddMonths(-_config.NumMonthsMessagesKept);
            var lastDbDocuments = dbDocuments.Where(d => d.Date >= earliestDate);

            messages.AddRange(lastDbDocuments.Select(dbDstDocument => new InboxMessage
            {
                Type = dbDstDocument.Type,
                Date = dbDstDocument.Date,
                Attachment = new InboxAttachment
                {
                    Id = dbDstDocument.DocumentId,
                    Filesize = dbDstDocument.Size,
                    Doctype = string.Intern(dbDstDocument.Type)
                },
                Read = dbDstDocument.Read,
                Title = dbDstDocument.Title,
                Message = dbDstDocument.Type == "cca" ? _config.CcaMessageBody : ""
            }));

            // All messages ordered by date (newest first); ensure welcome message is last
            return messages.OrderBy(m => m.Type == welcomeMessageType)
                .ThenByDescending(m => m.Date);
        }

        public async Task<IEnumerable<Statement>> GetStatements(StatementsRequest request)
        {
            var dbDocuments = await RetrieveStatements(request.AccountNumber, request.Brand);

            var searchDate = DateTime.Today.AddMonths(-_config.NumMonthsStatementsKept);
            var lastDbDocuments = dbDocuments.Where(d => d.Date > searchDate).ToList();

            return lastDbDocuments.Select(dbDstDocument => new Statement
            {
                DocumentId = dbDstDocument.DocumentId,
                Date = dbDstDocument.Date,
                HasCopyInBlob = !string.IsNullOrWhiteSpace(dbDstDocument.Salt)
            });
        }

        public async Task<Statement> GetStatement(StatementRequest request)
        {
            var doc = await RetrieveDocument(request.AccountNumber, request.Brand, request.DocumentId);
            Debug.Assert(doc != null);
            if (doc.Type != StatementTypeName)
                throw new DocumentException($"Document is not a statement: {request.DocumentId}");

            return new Statement
            {
                DocumentId = doc.DocumentId,
                Date = doc.Date,
                HasCopyInBlob = !string.IsNullOrWhiteSpace(doc.Salt)
            };
        }

        public async Task<Statement> GetStatementByDate(StatementByDateRequest request)
        {
            var doc = await RetrieveStatement(request.AccountNumber, request.Brand, request.Date);

            if (doc == null)
                return null;

            if (doc.Type != StatementTypeName)
                throw new DocumentException($"Document is not a statement: {request.Date}");

            return new Statement
            {
                DocumentId = doc.DocumentId,
                Date = doc.Date,
                HasCopyInBlob = !string.IsNullOrWhiteSpace(doc.Salt)
            };
        }

        public async Task<bool> MarkMessageAsUnread(MarkMessageRequest request)
        {
            // TODO: review whether we really need to check if the document is associated to the user
            var doc = await RetrieveDocument(request.AccountNumber, request.Brand, request.DocumentId, trackChanges: true);

            if (doc == null)
                return false;

            return await _userDocumentsQuery.MarkMessageAsUnread(request.DocumentId);
        }

        public async Task<bool> MarkMessageAsRead(MarkMessageRequest request)
        {
            // TODO: review whether we really need to check if the document is associated to the user
            var doc = await RetrieveDocument(request.AccountNumber, request.Brand, request.DocumentId, trackChanges: true);

            if (doc == null)
                return false;

            return await _userDocumentsQuery.MarkMessageAsRead(request.DocumentId); 
        }

        public async Task<GetAttachmentResponse> GetAttachment(AttachmentRequest request)
        {
            var doc = await RetrieveDocument(request.AccountNumber, request.Brand, request.DocumentId);
            if (doc != null)
                return await _documentRetrievalProvider.GetAttachment(doc, request.Brand);

            return null;
        }

        public async Task<bool> Search(SearchRequest request)
        {
            var existingDocs = await (await RetrieveDocumentsAsync(request.AccountNumber, request.Brand, true)).ToListAsync();

            var docsFromParagon = await _documentSearchProvider.SearchForDocuments(request.AccountNumber);

            var missingDocs = GetMissingDocuments(docsFromParagon, existingDocs).ToList();

            var success = await LoadMissingDocuments(missingDocs, request.AccountNumber);
            return success;

        }

        private async Task<IQueryable<Document>> RetrieveDocumentsAsync(string accountNumber, string brand, bool trackChanges = false)
        { 
            return await _userDocumentsQuery.Get(accountNumber, brand, trackChanges);
        }

        private async Task<IEnumerable<Document>> RetrieveInboxDocumentsAsync(string accountNumber, string brand, bool trackChanges = false)
        {
            var documentsList = new List<Document>();

            var dbDocuments = await GetDocumentsFromDbAsync(accountNumber, brand, trackChanges);
            documentsList.AddRange(dbDocuments);

            if (dbDocuments.Any(x => x.Type.ToLower() == "cca"))
                return documentsList;

            var foundationCcaBrands = _config.FoundationCcaBrands.Split(',');
            if (!foundationCcaBrands.Contains(brand))
                return documentsList;

            var ccaDocuments = await GetCcaDocumentsAsync(accountNumber);
            documentsList.AddRange(ccaDocuments);

            return documentsList;
        }

        private async Task<List<Document>> GetDocumentsFromDbAsync(string accountNumber, string brand, bool trackChanges)
        {
            var statementType = StatementTypeName;
            var documentsQueryable = await RetrieveDocumentsAsync(accountNumber, brand, trackChanges);
            var dbDocuments = documentsQueryable.Where(d => d.Type != statementType);
            return dbDocuments.ToList();
        }

        private async Task<List<Document>> GetCcaDocumentsAsync(string accountNumber)
        {
            try
            {
                var ccaDocuments = await _foundationDataStoreProvider.SearchAsync(accountNumber);
                if (ccaDocuments.Any())
                    await _database.DstDocuments.AddRangeAsync(ccaDocuments);

                await _database.SaveChangesAsync();
                return ccaDocuments;
            }
            catch (Exception e)
            {
                _telemetryHelper.TrackException(e);
                return new List<Document>();
            }
        }

        private async Task<IEnumerable<Document>> RetrieveStatements(string accountNumber, string brand, bool trackChanges = false)
        {
            var documents = await RetrieveDocumentsAsync(accountNumber, brand, trackChanges);
            var statementType = StatementTypeName;
            return documents.Where(d => d.Type == statementType);
        }

        private async Task<Document> RetrieveDocument(string accountNumber, string brand, Guid documentId, bool trackChanges = false)
        {
            var documents = await _userDocumentsQuery.Get(accountNumber, brand, trackChanges: trackChanges);

            // Unfortunately there are duplicates in the database and until that is fixed we cannot use .Single()
            var doc = await documents.FirstOrDefaultAsync(d => d.DocumentId == documentId);

            return doc;
        }

        private async Task<Document> RetrieveStatement(string accountNumber, string brand, DateTime date, bool trackChanges = false)
        {
            var documents = await _userDocumentsQuery.Get(accountNumber, brand, trackChanges: trackChanges);

            var requiredType = StatementTypeName;

            // Unfortunately there are duplicates in the database and until that is fixed we cannot use .Single()
            var doc = await documents.FirstOrDefaultAsync(d => 
                                d.Type == requiredType &&
                                d.Date.Date == date.Date);

            return doc;
        }

        private IEnumerable<Document> GetMissingDocuments(IEnumerable<Document> docs, IEnumerable<Document> existingDocs)
        {
            var existingDocumentIds = existingDocs.Select(x => x.DocumentId);
            var earliestDate = DateTime.Now.AddDays(-_config.NumDaysDocumentsCached);
            return docs.Where(x => !existingDocumentIds.Contains(x.DocumentId)
                                   && x.Date >= earliestDate);
        }

        public async Task<bool> LoadMissingDocuments(IEnumerable<Document> documents, string accountNumber)
        {
            var startTime = DateTime.UtcNow;
            var timer = Stopwatch.StartNew();

            var statements = 0;
            var enovDocs = 0;
            var ddNotifications = 0;
            var others = 0;

            foreach (var doc in documents)
            {
                switch (Enum.Parse<DocType>(doc.Type))
                {
                    case DocType.Statement:
                        ++statements;
                        break;
                    case DocType.ENovDocument:
                        ++enovDocs;
                        break;
                    case DocType.DDNotification:
                        ++ddNotifications;
                        break;
                    default:
                        ++others;
                        break;
                }
                await _database.DstDocuments.AddAsync(doc);
            }
            await _database.SaveChangesAsync();
            
            timer.Stop();
            var data = $"AccountNumber: {accountNumber} Statements: {statements} ENovDocs: {enovDocs} DDNotifications: {ddNotifications} Others: {others}";
            _telemetryHelper.Client.TrackDependency(nameof(DocumentsProvider), "Servicing.Function.Documents", nameof(LoadMissingDocuments), data, startTime, timer.Elapsed, "200", true);

            return true;
        }
    }
}
