﻿using Servicing.Function.Documents.Core.Helpers;
using Servicing.Function.Documents.Data.EntityFramework.Models;
using Servicing.Function.Documents.Data.Models;
using System;
using System.Diagnostics;
using System.Threading.Tasks;

namespace Servicing.Function.Documents.Data.Providers
{
    public abstract class DocumentRetrievalProviderBase
    {
        protected readonly ITelemetryHelper TelemetryHelper;
        private readonly IFoundationDataStoreProvider _foundationDataStoreProvider;

        private const string BipBrand = "bip";

        public DocumentRetrievalProviderBase(
            ITelemetryHelper telemetryHelper,
            IFoundationDataStoreProvider foundationDataStoreProvider)
        {
            TelemetryHelper = telemetryHelper;
            _foundationDataStoreProvider = foundationDataStoreProvider;
        }

        public async Task<GetAttachmentResponse> GetAttachment(Document doc, string brand)
        {
            byte[] content;
            if (doc.Type == "CCA")
            {
                var result = await _foundationDataStoreProvider.Retrieve(doc.DocumentId.ToString());
                if (!result.Success)
                {
                    return new GetAttachmentResponse
                    {
                        Success = false,
                        StatusCode = result.StatusCode,
                        Message = result.Message
                    };
                }

                content = result.Content;
            }
            else
            {
                content = await GetDocumentFromParagon(doc);
            }

            return new GetAttachmentResponse
            {
                Success = true,
                Attachment = new Attachment
                {
                    DocumentId = doc.DocumentId,
                    Type = doc.Type,
                    Content = content
                }

            };
        }

        private async Task<byte[]> GetDocumentFromParagon(Document doc)
        {
            var startTime = DateTime.UtcNow;
            var timer = Stopwatch.StartNew();

            var contentsBytes = await InternalGetDocumentBytes(doc);

            timer.Stop();
            var data = $"AccountNumber: {doc.AccountNumber} DocumentType: {doc.Type} Statement size: {doc.Size}";
            TelemetryHelper.Client.TrackDependency(doc.Type, "Servicing.Function.Documents", nameof(GetDocumentFromParagon), data, startTime, timer.Elapsed, "200", true);

            return contentsBytes;
        }

        protected abstract Task<byte[]> InternalGetDocumentBytes(Document doc);
    }
}
