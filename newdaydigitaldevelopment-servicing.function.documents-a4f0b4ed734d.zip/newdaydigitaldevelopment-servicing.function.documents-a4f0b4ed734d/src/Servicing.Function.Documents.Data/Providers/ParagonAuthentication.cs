﻿using ServiceReference1;
using Servicing.Function.Documents.Core.Config;
using Servicing.Function.Documents.Core.Helpers;
using Servicing.Function.Documents.Core.Security;
using System;
using System.Security.Cryptography;
using System.Text;

namespace Servicing.Function.Documents.Data.Providers
{
    internal class ParagonAuthentication
    {
        private readonly string _username;
        private readonly string _passwordToken;
        private readonly string _source;

        public ParagonAuthentication(
            IConfig config)
        {
            _username = config.ParagonUsername;
            _passwordToken = config.ParagonPasswordToken;
            _source = config.ParagonSource;
        }

        public AuthenticationData MakeAuthenticationData()
        {
            var rnd = new CryptoRandom();
            var requestId = rnd.Next().ToString();
            var encodedPassToken = GetPassToken(requestId);

            return new AuthenticationData
            {
                UserName = _username,
                PassToken = encodedPassToken,
                RequestId = requestId,
                OriginatingUser = _username,
                Source = _source
            };
        }

        private string GetPassToken(string requestId)
        {
            //1.Concatenate 'Password + RequestId'
            //2.Encode as BigEndianUnicode
            //3.Hash using SHA256
            //4.Encode Hash using Base64
            var concat = _passwordToken + requestId;
            var hashingAlgo = SHA256.Create();
            var hashed =  hashingAlgo.ComputeHash(Encoding.BigEndianUnicode.GetBytes(concat));
            return Convert.ToBase64String(hashed);
        }
    }
}
