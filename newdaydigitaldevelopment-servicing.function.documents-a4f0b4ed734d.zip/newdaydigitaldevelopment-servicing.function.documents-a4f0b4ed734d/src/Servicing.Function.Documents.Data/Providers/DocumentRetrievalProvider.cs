﻿using ServiceReference1;
using Servicing.Function.Documents.Core.Config;
using Servicing.Function.Documents.Core.Exceptions;
using Servicing.Function.Documents.Core.Helpers;
using Servicing.Function.Documents.Data.EntityFramework.Models;
using Servicing.Function.Documents.Data.ServiceHelpers;
using System;
using System.Collections.Generic;
using System.Net.Http.Headers;
using System.ServiceModel;
using System.Threading.Tasks;

namespace Servicing.Function.Documents.Data.Providers
{
    public class DocumentRetrievalProvider : DocumentRetrievalProviderBase
    {
        private readonly IConfig _config;
        private readonly IAuthenticationHeaderProvider _authenticationHeaderProvider;
        private readonly ParagonAuthentication _paragonAuthentication;

        public DocumentRetrievalProvider(
            IConfig config, 
            ITelemetryHelper telemetryHelper, 
            IFoundationDataStoreProvider foundationDataStoreProvider,
            IAuthenticationHeaderProvider authenticationHeaderProvider      
            ) : base(
                telemetryHelper,
                foundationDataStoreProvider
                )
        {
            _config = config;
            _authenticationHeaderProvider = authenticationHeaderProvider;
            _paragonAuthentication = new ParagonAuthentication(config);

        }

        protected async override Task<byte[]> InternalGetDocumentBytes(Document doc)
        {
            AuthenticationHeaderValue bearerToken;
            try
            {
                bearerToken = await _authenticationHeaderProvider.GetBearerToken();
            }
            catch (Exception e)
            {
                TelemetryHelper.TrackException(e, new Dictionary<string, string>
                {
                    {"Resource", _config.ApimApplicationId },
                    {"TenantID", _config.TenantId }
                });

                throw;
            }

            var uri = new Uri(_config.ApimBaseUrl + _config.ApimPath);
            var address = new EndpointAddress(uri);

            var authenticationData = _paragonAuthentication.MakeAuthenticationData();

            for (var attempt = 1; ; ++attempt)
            {
                try
                {
                    var client = new DocumentClient(DocumentClient.EndpointConfiguration.BasicHttpBinding_IDocument, address);
                    client.Endpoint.EndpointBehaviors.Add(new EndpointBehavior(bearerToken, _config.ApimSubscriptionKey));
                    return await client.GetDocumentAsync(authenticationData, doc.DocumentId.ToString());
                }
                catch (Exception ex)
                {
                    TelemetryHelper.Client.TrackTrace(
                        $"Unable to get document from Paragon (attempt {attempt} of {_config.ParagonRetryCount})",
                        new Dictionary<string, string>
                        {
                            ["ParagonUrl"] = address.ToString(),
                            ["DocumentID"] = doc.DocumentId.ToString(),
                            ["AccountNumber"] = doc.AccountNumber,
                            ["Type"] = ex.GetType().ToString(),
                            ["Exception"] = ex.Message,
                            ["StackTrace"] = ex.StackTrace
                        });

                    if (!_config.ParagonRetriesEnabled || attempt >= _config.ParagonRetryCount)
                        throw new DocumentException("Unable to get document from Paragon", ex);
                }
            }
        }
    }
}
