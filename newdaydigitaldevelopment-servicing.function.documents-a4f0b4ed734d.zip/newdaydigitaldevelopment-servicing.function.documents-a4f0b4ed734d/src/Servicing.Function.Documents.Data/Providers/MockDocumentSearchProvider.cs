﻿using ServiceReference1;
using Servicing.Function.Documents.Core.Config;
using Servicing.Function.Documents.Core.Helpers;
using System;
using System.Threading.Tasks;

namespace Servicing.Function.Documents.Data.Providers
{
    public class MockDocumentSearchProvider : DocumentSearchProviderBase
    {
        public MockDocumentSearchProvider(
            IConfig config, 
            ITelemetryHelper telemetryHelper
            ) : base(
                config, 
                telemetryHelper
                )
        {
        }

        protected override Task<DocumentSearchResultsData> SearchForDocumentsInternal(string accountNumber)
        {
            var rnd = new Random();
            var count = rnd.Next(5, 10);
         
            var result = new DocumentSearchResultsData();
            result.DocumentList = new IndexedDocumentData[count];

            for (int i = 0; i < count; i++)
            {
                var docType = new IndexMapped
                {
                    IndexName = "DOCTYPE",
                    IndexValue = "STAT"
                };

                var billingDate = new IndexMapped
                {
                    IndexName = "BILLINGDATE",
                    IndexValue = "01/01/2020"
                };

                var doc = new IndexedDocumentData();
                doc.Id = Guid.NewGuid();
                doc.MappedIndexes = new[] {docType, billingDate};

                result.DocumentList[i] = doc;
            }

            return Task.FromResult(result);
        }
    }
}
