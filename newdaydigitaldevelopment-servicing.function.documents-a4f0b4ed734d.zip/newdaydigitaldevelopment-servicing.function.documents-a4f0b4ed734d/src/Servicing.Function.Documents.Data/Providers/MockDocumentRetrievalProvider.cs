﻿using Servicing.Function.Documents.Core.Helpers;
using Servicing.Function.Documents.Data.EntityFramework.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Servicing.Function.Documents.Data.Providers
{
    public class MockDocumentRetrievalProvider : DocumentRetrievalProviderBase
    {
        public MockDocumentRetrievalProvider(
            ITelemetryHelper telemetryHelper,
            IFoundationDataStoreProvider foundationDataStoreProvider
            ) : base(
                telemetryHelper,
                foundationDataStoreProvider
                )
        {
        }

        protected override Task<byte[]> InternalGetDocumentBytes(Document doc)
        {
            var lengthMin = 5 * 1024 * 10; //50 kb
            var lengthMax = 5 * 1024 * 100; //500 kb

            var rnd = new Random();
            var data = new byte[rnd.Next(lengthMin, lengthMax)];
            rnd.NextBytes(data);

            return Task.FromResult(data);
        }
    }
}
