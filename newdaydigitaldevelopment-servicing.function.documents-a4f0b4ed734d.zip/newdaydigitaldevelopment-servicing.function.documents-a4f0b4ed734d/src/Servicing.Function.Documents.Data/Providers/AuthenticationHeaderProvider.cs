﻿using Microsoft.Azure.Services.AppAuthentication;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Servicing.Function.Documents.Core.Config;

namespace Servicing.Function.Documents.Data.Providers
{
    public class AuthenticationHeaderProvider : IAuthenticationHeaderProvider
    {
        private readonly IConfig _config;

        public AuthenticationHeaderProvider(IConfig config)
        {
            _config = config;
        }

        public async Task<AuthenticationHeaderValue> GetBearerToken()
        {
            var azureServiceTokenProvider = new AzureServiceTokenProvider();
            var token = await azureServiceTokenProvider.GetAccessTokenAsync(_config.ApimApplicationId, _config.TenantId);
            return new AuthenticationHeaderValue("Bearer", token);
        }
    }
}
