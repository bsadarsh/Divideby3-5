﻿using Servicing.Function.Documents.Data.Models;
using Servicing.Function.Documents.Data.Requests;
using System.Collections.Generic;
using System.Threading.Tasks;
using SharedInterfaces.Models;

namespace Servicing.Function.Documents.Data.Providers
{
    public interface IDocumentsProvider
    {
        Task<IEnumerable<InboxMessage>> GetMessages(MessagesRequest request);

        Task<IEnumerable<Statement>> GetStatements(StatementsRequest request);

        Task<Statement> GetStatement(StatementRequest request);

        Task<Statement> GetStatementByDate(StatementByDateRequest request);

        Task<bool> MarkMessageAsRead(MarkMessageRequest request);

        Task<bool> MarkMessageAsUnread(MarkMessageRequest request);

        Task<GetAttachmentResponse> GetAttachment(AttachmentRequest request);

        Task<bool> Search(SearchRequest request);
    }
}
