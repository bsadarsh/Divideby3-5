﻿using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace Servicing.Function.Documents.Data.Providers
{
    public interface IAuthenticationHeaderProvider
    {
        Task<AuthenticationHeaderValue> GetBearerToken();
    }
}
