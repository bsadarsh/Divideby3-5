﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Servicing.Core.Http;
using Servicing.Function.Documents.Core.Config;
using Servicing.Function.Documents.Core.Exceptions;
using Servicing.Function.Documents.Data.EntityFramework.Models;
using Servicing.Function.Documents.Data.Models;
using Servicing.Function.Documents.Data.Requests;
using Servicing.Function.Documents.Data.Responses;

namespace Servicing.Function.Documents.Data.Providers
{
    public class FoundationDataStoreProvider : IFoundationDataStoreProvider
    {
        private readonly IRestApiClient _restApiClient;
        private readonly IConfig _config;

        public FoundationDataStoreProvider(IRestApiClient restApiClient, IConfig config)
        {
            _config = config;
            _restApiClient = restApiClient;
            _restApiClient.SetDefaultTimeout(_config.DefaultApiTimeout);
            _restApiClient.SetAzureAuthorization(_config.FoundationDataStoreTenantId,
                _config.FoundationDataStoreResourceId, _config.FoundationDataStoreSubscriptionKey);
            _restApiClient.IncludeContentStreamOnResponse();
        }

        public async Task<List<Document>> SearchAsync(string accountNumber)
        {
            var request = new FoundationSearchRequest
            {
                SearchCriteria = new FoundationSearchCriteria
                {
                    AccountId = $"000{accountNumber}",
                    Type = "creditcardagreement"
                }
            };

            using var result = await _restApiClient.SendAsync(HttpMethod.Post, _config.FoundationDataStoreBaseUrl,
                _config.FoundationDataStoreSearchEndpoint, request);

            if (result.TryDeserialize<FoundationSearchResponse>(out var response))
                return MapToDocumentList(response);

            if (!result.TryGetProblemDetails(out var problemResponse))
                throw new FoundationClientException(result.AsString());

            var error = problemResponse.Detail;
            throw new FoundationClientException(error);
        }

        public async Task<RetrieveFoundationDocumentResponse> Retrieve(string documentId)
        {
            var path = $"{_config.FoundationDataStoreRetrieveEndpoint}?FileUuid={documentId}";

            using var result = await _restApiClient.SendAsync(HttpMethod.Get, _config.FoundationDataStoreBaseUrl,
                path);
            
            if (!result.IsSuccessStatusCode)
            {
                if (!result.TryGetProblemDetails(out var problemResponse))
                    return new RetrieveFoundationDocumentResponse
                    {
                        Success = false,
                        StatusCode = result.StatusCode,
                        Message = result.AsString()
                    };

                return new RetrieveFoundationDocumentResponse
                {
                    Success = false,
                    StatusCode = result.StatusCode,
                    Message = problemResponse.Detail
                }; 
            }

            try
            {
                return new RetrieveFoundationDocumentResponse
                {
                    Content = result.AsByteArray(),
                    Success = true
                };
            }
            catch
            {
                if (!result.TryGetProblemDetails(out var problemResponse))
                    return new RetrieveFoundationDocumentResponse
                    {
                        Success = false,
                        StatusCode = result.StatusCode,
                        Message = result.AsString()
                    };

                return new RetrieveFoundationDocumentResponse
                {
                    Success = false,
                    StatusCode = result.StatusCode,
                    Message = problemResponse.Detail
                };
            }
        }

        private static List<Document> MapToDocumentList(FoundationSearchResponse response)
        {
            var documents = new List<Document>();
            foreach (var responseResult in response.Results)
            {
                var document = new Document
                {
                    AccountNumber = responseResult.Tags.AccountId.Substring(3),
                    Date = DateTime.Parse(responseResult.UploadedDate),
                    DocumentId = Guid.Parse(responseResult.FileUuid),
                    Read = false,
                    Title = "Credit Card Agreement",
                    Type = "CCA",
                    Salt = ""
                };
                documents.Add(document);
            }

            return documents;
        }
    }
}
