﻿namespace Servicing.Function.Documents.Core.Models
{
    public class SearchItem
    {
        public string Brands { get; set; }

        public string Type { get; set; }
    }
}
