﻿using System.Collections.Generic;

namespace Servicing.Function.Documents.Core.Models
{
    public class FoundationSearches
    {
        public List<SearchItem> SearchItems { get; set; }
    }
}
