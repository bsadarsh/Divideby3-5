﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Security.Permissions;

namespace Servicing.Function.Documents.Core.Exceptions
{
    [Serializable]
    public class DocumentException : Exception
    {
        public DocumentException(string message)
            : base(message)
        {
        }

        public DocumentException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        public string ResourceName { get; }

        public IList<string> ValidationErrors { get; }

        [SecurityPermission(SecurityAction.Demand, SerializationFormatter = true)]
        protected DocumentException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
            ResourceName = info.GetString("DocumentException.ResourceName");
            ValidationErrors = (IList<string>)info.GetValue("DocumentException.ValidationErrors", typeof(IList<string>));
        }

        [SecurityPermission(SecurityAction.Demand, SerializationFormatter=true)]
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);
            info.AddValue("DocumentException.ResourceName", ResourceName);
            info.AddValue("DocumentException.ValidationErrors", ValidationErrors, typeof(IList<string>));
        }
    }
}
