﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Security.Permissions;

namespace Servicing.Function.Documents.Core.Exceptions
{
    [Serializable]
    public class EnvironmentVariableException : Exception
    {
        public EnvironmentVariableException(string variable)
            : base($"Missing environment variable: {variable}")
        {
        }

        public EnvironmentVariableException(string variable, string value)
            : base($"Invalid environment variable: {variable}={value}")
        {
        }

        public string ResourceName { get; }

        public IList<string> ValidationErrors { get; }

        [SecurityPermission(SecurityAction.Demand, SerializationFormatter = true)]
        protected EnvironmentVariableException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
            ResourceName = info.GetString("EnvironmentVariableException.ResourceName");
            ValidationErrors = (IList<string>)info.GetValue("EnvironmentVariableException.ValidationErrors", typeof(IList<string>));
        }

        [SecurityPermission(SecurityAction.Demand, SerializationFormatter=true)]
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);
            info.AddValue("EnvironmentVariableException.ResourceName", ResourceName);
            info.AddValue("EnvironmentVariableException.ValidationErrors", ValidationErrors, typeof(IList<string>));
        }
    }
}
