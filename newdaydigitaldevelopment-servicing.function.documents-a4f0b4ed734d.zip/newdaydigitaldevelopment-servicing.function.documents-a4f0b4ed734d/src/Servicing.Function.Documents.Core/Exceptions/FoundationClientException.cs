﻿using System;

namespace Servicing.Function.Documents.Core.Exceptions
{
    public class FoundationClientException : Exception
    {
        public FoundationClientException() : base()
        {
        }

        public FoundationClientException(string message) : base(message)
        {
        }

        public FoundationClientException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }
}
