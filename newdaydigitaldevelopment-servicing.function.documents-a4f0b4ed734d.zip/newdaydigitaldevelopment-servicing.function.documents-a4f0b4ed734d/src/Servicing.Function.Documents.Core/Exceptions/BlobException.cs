﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Security.Permissions;

namespace Servicing.Function.Documents.Core.Exceptions
{
    [Serializable]
    public class BlobException : Exception
    {
        public BlobException(string message)
            : base(message)
        {
        }

        public string ResourceName { get; }

        public IList<string> ValidationErrors { get; }

        [SecurityPermission(SecurityAction.Demand, SerializationFormatter = true)]
        protected BlobException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
            ResourceName = info.GetString("BlobException.ResourceName");
            ValidationErrors = (IList<string>)info.GetValue("BlobException.ValidationErrors", typeof(IList<string>));
        }

        [SecurityPermission(SecurityAction.Demand, SerializationFormatter=true)]
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);
            info.AddValue("BlobException.ResourceName", ResourceName);
            info.AddValue("BlobException.ValidationErrors", ValidationErrors, typeof(IList<string>));
        }
    }
}
