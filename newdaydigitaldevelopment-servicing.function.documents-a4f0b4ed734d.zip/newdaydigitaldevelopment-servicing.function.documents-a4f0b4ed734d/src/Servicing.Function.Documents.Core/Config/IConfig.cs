﻿namespace Servicing.Function.Documents.Core.Config
{
    public interface IConfig
    {
        string InstrumentationKey { get; }

        string DatabaseConnectionString { get; }

        int NumMonthsMessagesKept { get; }

        int NumMonthsStatementsKept { get; }

        string WelcomeMessageDate { get; }

        string BlobStorageConnectionString { get; }

        string BlobStorageContainerName { get; }

        string AesPassword { get; }

        string TenantId { get; }

        string ApimApplicationId { get; }

        string ApimBaseUrl { get; }

        string ApimPath { get; set; }

        string ApimSubscriptionKey { get; set; }

        string ParagonUsername { get; }

        string ParagonPasswordToken { get; }

        string ParagonSource { get; }

        bool ParagonRetriesEnabled { get; }

        int ParagonRetryCount { get; }

        string DocTypeStatement { get; }

        string DocTypeDDNotification { get; }

        string DocTypeENov { get; }

        int NumDaysDocumentsCached { get; }

        int MaxStatementsToLoad { get; }

        string FoundationDataStoreBaseUrl { get; set; }

        string FoundationDataStoreSearchEndpoint { get; set; }

        string FoundationDataStoreRetrieveEndpoint { get; set; }

        string FoundationCcaBrands { get; set; }

        int DefaultApiTimeout { get; set; }

        string CcaMessageBody { get; set; }

        string FoundationDataStoreTenantId { get; set; }

        string FoundationDataStoreResourceId { get; set; }

        string FoundationDataStoreSubscriptionKey { get; set; }
    }
}
