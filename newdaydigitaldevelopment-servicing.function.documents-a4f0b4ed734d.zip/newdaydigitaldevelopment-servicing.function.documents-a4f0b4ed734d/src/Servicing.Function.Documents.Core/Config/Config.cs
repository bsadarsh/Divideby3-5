﻿using Servicing.Function.Documents.Core.Exceptions;
using System;
using Newtonsoft.Json;
using Servicing.Function.Documents.Core.Models;

namespace Servicing.Function.Documents.Core.Config
{
    public class Config : IConfig
    {
        public Config()
        {
            InstrumentationKey = ReadEnvironmentVariable("APPINSIGHTS_INSTRUMENTATIONKEY");
            DatabaseConnectionString = ReadEnvironmentVariable("DatabaseConnectionString");
            NumMonthsMessagesKept = ReadIntEnvironmentVariable("NumMonthsMessagesKept");
            NumMonthsStatementsKept = ReadIntEnvironmentVariable("NumMonthsStatementsKept");
            WelcomeMessageDate = ReadEnvironmentVariable("WelcomeMessageDate");
            BlobStorageConnectionString = ReadEnvironmentVariable("BlobStorageConnectionString");
            BlobStorageContainerName = ReadEnvironmentVariable("BlobStorageContainerName");
            AesPassword = ReadEnvironmentVariable("AES");
            TenantId = ReadEnvironmentVariable("TenantId");
            ApimApplicationId = ReadEnvironmentVariable("ApimApplicationId");
            ApimBaseUrl = ReadEnvironmentVariable("ApimBaseUrl");
            ApimPath = ReadEnvironmentVariable("ApimPath");
            ApimSubscriptionKey = ReadEnvironmentVariable("ApimSubscriptionKey");
            ParagonUsername = ReadEnvironmentVariable("ParagonUsername");
            ParagonPasswordToken = ReadEnvironmentVariable("ParagonPasswordToken");
            ParagonSource = ReadEnvironmentVariable("ParagonSource");
            ParagonRetriesEnabled = ReadBoolEnvironmentVariable("ParagonRetriesEnabled");
            ParagonRetryCount = ReadIntEnvironmentVariable("ParagonRetryCount");
            DocTypeStatement = ReadEnvironmentVariable("DocTypeStatement");
            DocTypeDDNotification = ReadEnvironmentVariable("DocTypeDDNotification");
            DocTypeENov = ReadEnvironmentVariable("DocTypeENov");
            NumDaysDocumentsCached = ReadIntEnvironmentVariable("NumDaysDocumentsCached");
            MaxStatementsToLoad = ReadIntEnvironmentVariable("MaxStatementsToLoad");
            FoundationDataStoreBaseUrl = ReadEnvironmentVariable("FoundationDataStore::BaseUrl");
            FoundationDataStoreSearchEndpoint = ReadEnvironmentVariable("FoundationDataStore::SearchEndpoint");
            FoundationDataStoreRetrieveEndpoint = ReadEnvironmentVariable("FoundationDataStore::RetrieveEndpoint");
            FoundationDataStoreTenantId = ReadEnvironmentVariable("FoundationDataStore::TenantId");
            FoundationDataStoreResourceId = ReadEnvironmentVariable("FoundationDataStore::ResourceId");
            FoundationDataStoreSubscriptionKey = ReadEnvironmentVariable("FoundationDataStore::SubscriptionKey");
            FoundationCcaBrands = ReadEnvironmentVariable("FoundationCcaBrands");
            DefaultApiTimeout = ReadIntEnvironmentVariable("DefaultApiTimeout");
            CcaMessageBody = ReadEnvironmentVariable("CcaMessageBody");
        }

        public string InstrumentationKey { get; }

        public string DatabaseConnectionString { get; }

        public int NumMonthsMessagesKept { get; }

        public int NumMonthsStatementsKept { get; }

        public string WelcomeMessageDate { get; }

        public string BlobStorageConnectionString { get; }

        public string BlobStorageContainerName { get; }

        public string AesPassword { get; set; }

        public string TenantId { get; set; }

        public string ApimApplicationId { get; set; }

        public string ApimBaseUrl { get; }

        public string ApimPath { get; set; }

        public string ApimSubscriptionKey { get; set; }

        public string ParagonUsername { get; }

        public string ParagonPasswordToken { get; }

        public string ParagonSource { get; }

        public bool ParagonRetriesEnabled { get; }

        public int ParagonRetryCount { get; }

        public string DocTypeStatement { get; }

        public string DocTypeDDNotification { get; }

        public string DocTypeENov { get; }

        public int NumDaysDocumentsCached { get; }

        public int MaxStatementsToLoad { get; }

        public string FoundationDataStoreBaseUrl { get; set; }

        public string FoundationDataStoreSearchEndpoint { get; set; }

        public string FoundationDataStoreRetrieveEndpoint { get; set; }

        public string FoundationDataStoreTenantId { get; set; }

        public string FoundationDataStoreResourceId { get; set; }

        public string FoundationDataStoreSubscriptionKey { get; set; }

        public string FoundationCcaBrands { get; set; }

        public int DefaultApiTimeout { get; set; }

        public string CcaMessageBody { get; set; }

        private static string ReadEnvironmentVariable(string variable)
            => Environment.GetEnvironmentVariable(variable) ?? throw new EnvironmentVariableException(variable);

        private static int ReadIntEnvironmentVariable(string variable)
        {
            var value = ReadEnvironmentVariable(variable);
            if (int.TryParse(value, out var intValue))
                return intValue;

            throw new EnvironmentVariableException(variable, value);
        }

        private static bool ReadBoolEnvironmentVariable(string variable)
        {
            var value = ReadEnvironmentVariable(variable);
            if (bool.TryParse(value, out var boolValue))
                return boolValue;

            switch (value)
            {
                case "1":
                    return true;
                case "0":
                    return false;
                default:
                    throw new EnvironmentVariableException(variable, value);
            }
        }
    }
}
