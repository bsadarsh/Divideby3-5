﻿using Microsoft.AspNetCore.Http;
using System.Linq;

namespace Servicing.Function.Documents.Core.Extensions
{
    public static class HttpRequestExtensions
    {
        public static bool IsMockEnabled(this HttpRequest request)
        {
            return request.Headers.TryGetValue("X-MocksEnabled", out var values) &&
                   values.Any(v => v.ToLower() == "true");
        }
    }
}
