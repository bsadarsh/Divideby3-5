﻿using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.DataContracts;
using Microsoft.ApplicationInsights.Extensibility;
using Servicing.Function.Documents.Core.Config;
using System;
using System.Collections.Generic;

namespace Servicing.Function.Documents.Core.Helpers
{
    public class TelemetryHelper : ITelemetryHelper
    {
        #region Fields

        /// <summary>
        /// The name of the executing service
        /// </summary>
        protected static readonly string ServiceName;

        #endregion

        #region Properties

        /// <inheritdoc cref="ITelemetryHelper"/>
        public TelemetryClient Client { get; }

        #endregion

        #region Constructors

        /// <summary>
        /// Static constructor for the <see cref="TelemetryHelper" /> class.
        /// </summary>
        static TelemetryHelper()
        {
            ServiceName = Environment.GetEnvironmentVariable("ServiceName") ?? "Documents";
        }

        /// <summary>
        /// Initialises a new instance of the <see cref="TelemetryHelper" /> class.
        /// </summary>
        public TelemetryHelper()
        {
            Client = new TelemetryClient(new TelemetryConfiguration(
                Environment.GetEnvironmentVariable("APPINSIGHTS_INSTRUMENTATIONKEY")));
        }

        #endregion

        #region Public Methods

        /// <inheritdoc cref="ITelemetryHelper"/>
        public void TrackDependency(
            string dependencyTypeName,
            string dependencyName,
            string data,
            DateTimeOffset startTime,
            TimeSpan duration,
            bool success)
        {
            Client.TrackDependency(dependencyTypeName, dependencyName, data, startTime, duration, success);
        }

        /// <inheritdoc cref="ITelemetryHelper"/>
        public void TrackEvent(
            string eventName,
            IDictionary<string, string> properties = null,
            IDictionary<string, double> metrics = null)
        {
            if (properties == null)
                properties = new Dictionary<string, string>();

            AddMetadata(properties);

            var traceMessage = $"{ServiceName} - {eventName ?? "Unknown"}";
            Client.TrackEvent(traceMessage, properties, metrics);
        }

        /// <inheritdoc cref="ITelemetryHelper"/>
        public void TrackException(
            Exception exception,
            IDictionary<string, string> properties = null,
            IDictionary<string, double> metrics = null)
        {
            if (properties == null)
                properties = new Dictionary<string, string>();

            AddMetadata(properties);

            Client.TrackException(exception, properties, metrics);
        }

        /// <inheritdoc cref="ITelemetryHelper"/>
        public void TrackTrace(
            string message,
            SeverityLevel severityLevel = SeverityLevel.Information,
            IDictionary<string, string> properties = null)
        {
            if (properties == null)
                properties = new Dictionary<string, string>();

            AddMetadata(properties);

            var traceMessage = $"{ServiceName} - {message ?? "Unknown"}";
            Client.TrackTrace(traceMessage, severityLevel, properties);
        }

        /// <summary>
        /// Adds metadata about the service to the properties dictionary
        /// </summary>
        /// <param name="properties">The properties dictionary</param>
        protected void AddMetadata(IDictionary<string, string> properties)
        {
            if (properties == null)
                return;

            properties["SiteCode"] = "eServicing";
            properties["ProductId"] = "eServicing";
            properties["ApplicationId"] = ServiceName;
        }

        #endregion
    }
}
