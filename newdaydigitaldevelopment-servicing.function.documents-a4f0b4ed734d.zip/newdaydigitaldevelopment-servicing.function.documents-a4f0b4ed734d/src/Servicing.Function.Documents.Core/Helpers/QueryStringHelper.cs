﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using Microsoft.AspNetCore.Http;

namespace Servicing.Function.Documents.Core.Helpers
{
    public class QueryStringHelper : IQueryStringHelper
    {
        public DateTime GetDateTime(IQueryCollection queryCollection, string name, string format = null)
        {
            var value = GetString(queryCollection, name);
            
            DateTime date;
            if (!string.IsNullOrWhiteSpace(format))
            {
                if (!DateTime.TryParseExact(value, format, CultureInfo.InvariantCulture, DateTimeStyles.None,out date))
                    throw new ArgumentException($"Cannot parse {name} with value '{value}' to a DateTime.");
            }
            else
            {
                if (!DateTime.TryParse(value, out date))
                    throw new ArgumentException($"Cannot parse {name} with value '{value}' to a DateTime.");
            }

            return date;
        }

        public Guid GetGuid(IQueryCollection queryCollection, string name)
        {
            var value = GetString(queryCollection, name);

            if (!Guid.TryParse(value, out var guid))
                throw new ArgumentException($"Cannot parse {name} with value '{value}' to a GUID.");

            return guid;
        }

        public string GetString(IQueryCollection queryCollection, string name, bool allowNull = false, bool allowEmpty = false,
            int? minLength = null, int? maxLength = null)
        {
            if (queryCollection == null)
                throw new ArgumentNullException(nameof(queryCollection));

            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentNullException(nameof(name));

            var value = queryCollection[name].FirstOrDefault();
            if (value == null)
            {
                if (allowNull)
                    return null;

                throw new ArgumentNullException(name);
            }

            value = value.Trim();
            if (value.Length == 0)
            {
                if (allowEmpty)
                    return string.Empty;

                throw new ArgumentException($"{name} cannot be empty.");
            }

            if (minLength.HasValue && value.Length < minLength)
                throw new ArgumentOutOfRangeException(name, $"{name} is less than {minLength.Value} characters in length.");

            if (maxLength.HasValue && value.Length > maxLength)
                throw new ArgumentOutOfRangeException(name, $"{name} is greater than {maxLength.Value} characters in length.");

            return value;
        }
    }
}
