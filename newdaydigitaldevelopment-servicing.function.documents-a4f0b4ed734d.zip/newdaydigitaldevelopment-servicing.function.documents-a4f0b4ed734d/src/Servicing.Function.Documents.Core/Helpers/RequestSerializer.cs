﻿using Microsoft.AspNetCore.Http;
using Microsoft.Azure.WebJobs.Extensions.Http;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Servicing.Function.Documents.Core.Helpers
{
    public class RequestSerializer : IRequestSerializer
    {
        public async Task<IDictionary<string, string>> SerializeRequest(HttpRequest request)
        {
            var dict = new Dictionary<string, string>
            {
                ["QueryString"] = request.QueryString.Value
            };

            var body = await request.ReadAsStringAsync();
            if (!string.IsNullOrWhiteSpace(body))
            {
                dict.Add("Body", body);
                dict.Add("ContentType", string.Intern(request.ContentType));
                dict.Add("ContentLength", request.ContentLength?.ToString());
            }

            return dict;
        }
    }
}
