﻿using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Servicing.Function.Documents.Core.Helpers
{
    public interface IRequestSerializer
    {
        Task<IDictionary<string, string>> SerializeRequest(HttpRequest request);
    }
}
