﻿using System;
using Microsoft.AspNetCore.Http;

namespace Servicing.Function.Documents.Core.Helpers
{
    public interface IQueryStringHelper
    {
        DateTime GetDateTime(IQueryCollection queryCollection, string name, string format = null);

        Guid GetGuid(IQueryCollection queryCollection, string name);

        string GetString(IQueryCollection queryCollection, string name, bool allowNull = false, bool allowEmpty = false,
            int? minLength = null, int? maxLength = null);
    }
}