﻿using Servicing.Function.Documents.Core.Config;
using Servicing.Function.Documents.Core.Helpers;
using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace Servicing.Function.Documents.Core.Security
{
    /// <summary>
    /// Class RijndaelManagedEncryption.
    /// </summary>
    public class RijndaelManagedEncryption : IRijndaelManagedEncryption
    {
        internal const int SALTLENGTH = 8;

        private readonly IConfig _config;
        
        /// <summary>
        /// Initializes a new instance of the <see cref="RijndaelManagedEncryption"/> class.
        /// </summary>
        /// <param name="config">The configuration.</param>
        /// <param name="keyVault">The key vault helper.</param>
        public RijndaelManagedEncryption(IConfig config)
        {
            _config = config;
        }

        /// <summary>
        /// Generates the salt.
        /// </summary>
        /// <returns>System.String.</returns>
        public string GenerateSalt()
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            var random = new CryptoRandom();
            return new string(Enumerable.Repeat(chars, SALTLENGTH)
                .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        /// <summary>
        /// Encrypts the rijndael.
        /// </summary>
        /// <param name="text">The text.</param>
        /// <returns>System.String.</returns>
        public string EncryptRijndael(string text)
        {
            var salt = GenerateSalt();
            return salt + EncryptRijndael(text, salt);
        }

        /// <summary>
        /// Encrypt the given text and give the byte array back as a BASE64 string
        /// </summary>
        /// <param name="text">The text to encrypt</param>
        /// <param name="salt">The password salt</param>
        /// <returns>The encrypted text</returns>
        public string EncryptRijndael(string text, string salt)
        {
            if (string.IsNullOrEmpty(text))
                throw new ArgumentNullException(nameof(text));

            using (var aesAlg = NewRijndaelManaged(salt))
            {
                using (var encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV))
                {
                    using (var msEncrypt = new MemoryStream())
                    {
                        using (var swEncrypt = new StreamWriter(new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write)))
                        {
                            swEncrypt.Write(text);
                        }
                        return Convert.ToBase64String(msEncrypt.ToArray());
                    }
                }
            }
        }

        /// <summary>
        /// Decrypts the given text
        /// </summary>
        /// <param name="cipherText">Salt + The encrypted BASE64 text</param>
        /// <returns>The decrypted text</returns>
        public string DecryptRijndael(string cipherText)
        {
            if (string.IsNullOrEmpty(cipherText))
                throw new ArgumentNullException(nameof(cipherText));

            if (cipherText.Length <= SALTLENGTH)
                throw new ArgumentException("Not encrypted message", nameof(cipherText));

            var salt = cipherText.Substring(0, SALTLENGTH);
            var realcipherText = cipherText.Substring(SALTLENGTH);

            return DecryptRijndael(realcipherText, salt);
        }

        /// <summary>
        /// Decrypts the given text
        /// </summary>
        /// <param name="cipherText">The encrypted BASE64 text</param>
        /// <param name="salt">The password salt</param>
        /// <returns>The decrypted text</returns>
        public string DecryptRijndael(string cipherText, string salt)
        {
            if (string.IsNullOrEmpty(cipherText))
                throw new ArgumentNullException(nameof(cipherText));

            if (!IsBase64String(cipherText))
                throw new ArgumentException("Not base64 encoded", nameof(cipherText));

            using (var aesAlg = NewRijndaelManaged(salt))
            {
                using (var decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV))
                {
                    var cipher = Convert.FromBase64String(cipherText);

                    using (var msDecrypt = new MemoryStream(cipher))
                    {
                        using (var srDecrypt = new StreamReader(new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read)))
                        {
                            return srDecrypt.ReadToEnd();
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Create a new RijndaelManaged class and initialize it
        /// </summary>
        /// <param name="salt">The password salt</param>
        /// <returns>RijndaelManaged instance</returns>
        private RijndaelManaged NewRijndaelManaged(string salt)
        {
            if (salt == null)
                throw new ArgumentNullException(nameof(salt));

            var password = _config.AesPassword;
            var saltBytes = Encoding.ASCII.GetBytes(salt);
            var key = new Rfc2898DeriveBytes(password, saltBytes);

            var aesAlg = new RijndaelManaged();
            aesAlg.Key = key.GetBytes(aesAlg.KeySize / 8);
            aesAlg.IV = key.GetBytes(aesAlg.BlockSize / 8);
            return aesAlg;
        }

        /// <summary>
        /// Checks if a string is base64 encoded
        /// </summary>
        /// <param name="base64String">The base64 encoded string</param>
        /// <returns>Base64 encoded string</returns>
        private static bool IsBase64String(string base64String)
        {
            base64String = base64String.Trim();
            return (base64String.Length % 4 == 0) &&
                   Regex.IsMatch(base64String, @"^[a-zA-Z0-9\+/]*={0,3}$", RegexOptions.None);
        }
    }
}
