﻿namespace Servicing.Function.Documents.Core.Security
{
    public interface IRijndaelManagedEncryption
    {
        string GenerateSalt();

        string EncryptRijndael(string text);

        string EncryptRijndael(string text, string salt);

        string DecryptRijndael(string cipherText);

        string DecryptRijndael(string cipherText, string salt);
    }
}
