﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using Microsoft.Azure.Services.AppAuthentication;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;

namespace Servicing.Function.Documents.IntegrationTest
{
    class Helper
    {
        private readonly string _baseurl;

        public Helper()
        {
            _baseurl = Environment.GetEnvironmentVariable("FinalBaseURL");
        }

        public string CurrentDir()
        {
            var startupPath = Path.GetDirectoryName(
                Path.GetDirectoryName(
                    Path.GetDirectoryName(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location))));
            return startupPath;
        }

        public IConfigurationRoot GetConfiguration()
        {
            return new ConfigurationBuilder().SetBasePath(CurrentDir()).AddJsonFile("appsettings.json", false)
                .AddEnvironmentVariables().Build();
        }

        public IRestResponse PostApIMethod(string endpoint, string token)
        {
            var client = new RestClient(_baseurl + endpoint);
            var request = new RestRequest(Method.POST);
            request.AddHeader("authorization", "Bearer " + token);
            var response = client.Execute(request);
            GlobalVariables.RestResponse = response;
            return response;
        }

        public void GetBaseUrl()
        {
            var configuration = GetConfiguration();
            var finalBaseUrl = Environment.GetEnvironmentVariable("BaseURL") ??
                               configuration.GetSection("Data").GetSection("BaseURL").Value;
            Environment.SetEnvironmentVariable("FinalBaseURL", finalBaseUrl);
        }

        public void FetchDb(string tableName)
        {
            var options = new DbContextOptionsBuilder<TestDbDbContext>();
            var configuration = GetConfiguration();
            options.UseSqlServer(configuration.GetSection("Data").GetSection("ConnectionString").Value);
            var context = new TestDbDbContext(options.Options);
            var connection = (SqlConnection) context.Database.GetDbConnection();
            connection.AccessToken = new AzureServiceTokenProvider()
                .GetAccessTokenAsync("https://database.windows.net/").GetAwaiter().GetResult();
            var sb = new StringBuilder();
            sb.Append("select * from dbo." + tableName + ";");
            var sql = sb.ToString();
            var dataTable = new DataTable();
            var command = new SqlCommand(sql, connection);
            connection.Open();
            var reader = command.ExecuteReader();
            dataTable.Load(reader);
            var jsonBody = JsonConvert.SerializeObject(dataTable);
            Environment.SetEnvironmentVariable("TestDB", jsonBody);
        }

        public string FetchValue(string id)
        {
            var dict = Environment.GetEnvironmentVariables();
            var testTable = (string) dict["TestDB"];
            var users = JsonConvert.DeserializeObject(testTable);
            var array = (JArray) users;
            var list = array.ToObject<List<DbClass>>();
            var search = id;
            var result = list.Where(item => item.Id == search).Select(item => item.Value).FirstOrDefault();
            return result;
        }

        public IRestResponse GetApIMethod(string endpoint, string token)
        {
            var client = new RestClient(_baseurl + endpoint);
            var request = new RestRequest(Method.GET);
            request.AddHeader("authorization", "Bearer " + token);
            var response = client.Execute(request);
            GlobalVariables.RestResponse = response;
            return response;
        }

        public string GetToken(string resourceId, string tenantId)
        {
            try
            {
                var azureServiceTokenProvider = new AzureServiceTokenProvider();
                return azureServiceTokenProvider.GetAccessTokenAsync(resourceId, tenantId).GetAwaiter().GetResult();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        public List<DstDocTable> FetchDetailsFromEServicingDstDocDb(string tableName, string acctNbr, string type)
        {
            SqlConnection connection = null;
            SqlDataReader reader = null;
            SqlCommand command = null;
            try
            {
                var options = new DbContextOptionsBuilder<TestDbDbContext>();
                var configuration = GetConfiguration();

                options.UseSqlServer(configuration.GetSection("Data").GetSection("ConnString").Value);
                var context = new TestDbDbContext(options.Options);
                connection = (SqlConnection) context.Database.GetDbConnection();

                var sb = "select * from dbo." + tableName + " where AccountNumber = " + "'" + acctNbr + "'" +
                         "and Type = '" + type + "'" + "and ExpiryDate > SYSDATETIME()" + ";";
                var sql = sb;
                var dataTable = new DataTable();
                command = new SqlCommand(sql, connection);
                connection.Open();
                command.CommandTimeout = 20000;
                reader = command.ExecuteReader();
                dataTable.Load(reader);
                var jsonBody = JsonConvert.SerializeObject(dataTable);
                var users = JsonConvert.DeserializeObject(jsonBody);
                var array = (JArray) users;
                var list = array.ToObject<List<DstDocTable>>();
                return list;
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                    connection.Dispose();
                }

                if (reader != null)
                {
                    reader.Close();
                    reader.Dispose();
                }

                command?.Dispose();
            }
        }

        public List<DstDocTable> FetchDetailsFromEServicingDstDocDbforAttachment(string tableName, string acctNbr, string type, string documentId)
        {
            SqlConnection connection = null;
            SqlDataReader reader = null;
            SqlCommand command = null;
            try
            {
                var options = new DbContextOptionsBuilder<TestDbDbContext>();
                var configuration = GetConfiguration();

                options.UseSqlServer(configuration.GetSection("Data").GetSection("ConnString").Value);
                var context = new TestDbDbContext(options.Options);
                connection = (SqlConnection)context.Database.GetDbConnection();

                var sb = "select * from dbo." + tableName + " where AccountNumber = " + "'" + acctNbr + "'" +
                         "and Type = '" + type + "'" + "and ExpiryDate > SYSDATETIME()" + "and Size>0 " + "and DocumentId= " + "'" + documentId + "'" + ";";
                var sql = sb;
                var dataTable = new DataTable();
                command = new SqlCommand(sql, connection);
                connection.Open();
                command.CommandTimeout = 20000;
                reader = command.ExecuteReader();
                dataTable.Load(reader);
                var jsonBody = JsonConvert.SerializeObject(dataTable);

                var users = JsonConvert.DeserializeObject(jsonBody);
                var array = (JArray)users;
                var list = array.ToObject<List<DstDocTable>>();
                return list;
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                    connection.Dispose();
                }

                if (reader != null)
                {
                    reader.Close();
                    reader.Dispose();
                }

                command?.Dispose();
            }
        }
        public List<DstDocTable> FetchDetailsFromEServicingDstDocDbforNoAttachment(string tableName, string acctNbr, string type, string documentIdNoAttachment)
        {
            SqlConnection connection = null;
            SqlDataReader reader = null;
            SqlCommand command = null;
            try
            {
                var options = new DbContextOptionsBuilder<TestDbDbContext>();
                var configuration = GetConfiguration();

                options.UseSqlServer(configuration.GetSection("Data").GetSection("ConnString").Value);
                var context = new TestDbDbContext(options.Options);
                connection = (SqlConnection)context.Database.GetDbConnection();

                var sb = "select * from dbo." + tableName + " where AccountNumber = " + "'" + acctNbr + "'" +
                         "and Type = '" + type + "'" + "and ExpiryDate > SYSDATETIME()" + "and Size=0 " + "and DocumentId= " + "'" + documentIdNoAttachment + "'" + ";";
                var sql = sb;
                var dataTable = new DataTable();
                command = new SqlCommand(sql, connection);
                connection.Open();
                command.CommandTimeout = 20000;
                reader = command.ExecuteReader();
                dataTable.Load(reader);
                var jsonBody = JsonConvert.SerializeObject(dataTable);

                var users = JsonConvert.DeserializeObject(jsonBody);
                var array = (JArray)users;
                var list = array.ToObject<List<DstDocTable>>();
                return list;
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                    connection.Dispose();
                }

                if (reader != null)
                {
                    reader.Close();
                    reader.Dispose();
                }

                command?.Dispose();
            }
        }

        public List<DstDocTable> FetchDetailsFromEServicingDstDocDbforMarkAsRead(string tableName, string acctNbr, string type, string documentId)
        {
            SqlConnection connection = null;
            SqlDataReader reader = null;
            SqlCommand command = null;
            try
            {
                var options = new DbContextOptionsBuilder<TestDbDbContext>();
                var configuration = GetConfiguration();

                options.UseSqlServer(configuration.GetSection("Data").GetSection("ConnString").Value);
                var context = new TestDbDbContext(options.Options);
                connection = (SqlConnection)context.Database.GetDbConnection();

                var sb = "select * from dbo." + tableName + " where AccountNumber = " + "'" + acctNbr + "'" +
                         "and Type = '" + type + "'" + "and ExpiryDate > SYSDATETIME()" + "and Size>0 " + "and DocumentId= " + "'" + documentId + "'" + " and [Read] = 1" + ";";
                var sql = sb;
                var dataTable = new DataTable();
                command = new SqlCommand(sql, connection);
                connection.Open();
                command.CommandTimeout = 20000;
                reader = command.ExecuteReader();
                dataTable.Load(reader);
                var jsonBody = JsonConvert.SerializeObject(dataTable);

                var users = JsonConvert.DeserializeObject(jsonBody);
                var array = (JArray)users;
                var list = array.ToObject<List<DstDocTable>>();
                return list;
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                    connection.Dispose();
                }

                if (reader != null)
                {
                    reader.Close();
                    reader.Dispose();
                }

                command?.Dispose();
            }
        }
    }
}