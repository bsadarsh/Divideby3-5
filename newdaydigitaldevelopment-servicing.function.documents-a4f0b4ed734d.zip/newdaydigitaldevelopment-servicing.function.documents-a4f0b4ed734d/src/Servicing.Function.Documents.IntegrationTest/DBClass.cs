﻿
using System;
using Microsoft.EntityFrameworkCore;
using RestSharp;

namespace Servicing.Function.Documents.IntegrationTest
{
    public class DbClass
    {

        public string Id { get; set; }
        public string Value { get; set; }

    }


    public class TestDbDbContext : DbContext
    {
        public TestDbDbContext(DbContextOptions<TestDbDbContext> options) : base(options)
        {
        }


    }

    public static class GlobalVariables
    {


        public static IRestResponse RestResponse;

        public static string DbDataTable;
        public static string DocumentId;
        public static string FileSize;
        public static string DocumentType;
        public static string Date;

    }

    public class MonitoringAndLoggingDb
    {
        public int Id { get; set; }
        public string UserId { get; set; }
        public DateTime TimeStamp { get; set; }
        public string ChannelId { get; set; }
        public object DeviceId { get; set; }
        public string EventType { get; set; }
        public string ClientId { get; set; }
        public string Org { get; set; }
        public string Logo { get; set; }
        public string AccountNumber { get; set; }
        public string PortFolioId { get; set; }
        public object EventId { get; set; }
        public string Journey { get; set; }
    }

    public class DstDocTable
    {
        public string Type { get; set; }
        public DateTime Date { get; set; }
        public object Attachment { get; set; }
        public bool Read { get; set; }
        public string Title { get; set; }
        public string EventType { get; set; }
        public string DocumentId { get; set; }
        public string AccountNumber { get; set; }
        public string Size { get; set; }
        public string Salt { get; set; }
        public string Expirydate { get; set; }
    }
}
