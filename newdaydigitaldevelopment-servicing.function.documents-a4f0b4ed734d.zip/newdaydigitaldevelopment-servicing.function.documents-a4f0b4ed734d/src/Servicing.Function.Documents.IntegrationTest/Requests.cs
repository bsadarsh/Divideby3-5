﻿using System;
using NUnit.Framework;


namespace Servicing.Function.Documents.IntegrationTest
{
    class GetMessage : Helper
    {
        public GetMessage()
        {
            var links = new Links();
            string resource = FetchValue("Resource");
            string tenantId = FetchValue("TenantID");

            string token = GetToken(resource, tenantId);


            var getMessageresponse = GetApIMethod(links.MessagesEp + "?AccountNumber=" +
                                                  FetchValue("AccountNumber") + "&Brand=" +
                                                  FetchValue("Brand"), token);

            var dBresponse = FetchDetailsFromEServicingDstDocDb("DstDocuments",
                FetchValue("AccountNumber"), "Statement");
            int dbcount = dBresponse.Count;
            for (int i = 0; i <= dbcount; i++)
                foreach (var dstDocTable in dBresponse)
                {
                    Assert.True(getMessageresponse.Content.Contains(dstDocTable.DocumentId[i]));
                }
        }


        public class Attachment
        {
            public string Id { get; set; }
            public int Filesize { get; set; }
            public string Doctype { get; set; }
        }

        public class GetMessageRs
        {
            public string Type { get; set; }
            public DateTime Date { get; set; }
            public Attachment Attachment { get; set; }
            public bool Read { get; set; }
            public string Title { get; set; }
        }
    }


    class GetStatement : Helper
    {
        public GetStatement()
        {
            var links = new Links();
            string resource = FetchValue("Resource");
            string tenantId = FetchValue("TenantID");
            string token = GetToken(resource, tenantId);
            var response = GetApIMethod(links.StatementsEp + "?AccountNumber=" +
                                        FetchValue("AccountNumber") + "&Brand=" +
                                        FetchValue("Brand"), token);

            var dBresponse = FetchDetailsFromEServicingDstDocDb("DstDocuments",
                FetchValue("AccountNumber"), "Statement");
            int dbcount = dBresponse.Count;
            for (int i = 0; i <= dbcount; i++)
                foreach (var dstDocTable in dBresponse)
                {
                    Assert.True(response.Content.Contains(dstDocTable.DocumentId[i]));
                }
        }


        public class Attachment
        {
            public string Id { get; set; }
            public int Filesize { get; set; }
            public string Doctype { get; set; }
        }

        public class RootObject
        {
            public string Type { get; set; }
            public DateTime Date { get; set; }
            public Attachment Attachment { get; set; }
            public bool Read { get; set; }
            public string Title { get; set; }
        }
    }

    class GetAttachment : Helper
    {
        public GetAttachment()
        {
            var links = new Links();
            string resource = FetchValue("Resource");
            string tenantId = FetchValue("TenantID");
            string token = GetToken(resource, tenantId);
            var attachmentResponse = GetApIMethod(
                links.AttachmentEp + "?AccountNumber=" + FetchValue("AccountNumber") + "&Brand=" +
                FetchValue("Brand") + "&DocumentId=" + FetchValue("DocumentId"), token);
            var dBresponse = FetchDetailsFromEServicingDstDocDbforAttachment("DstDocuments",
                FetchValue("AccountNumber"), "Statement", FetchValue("DocumentId"));
            int dbcount = dBresponse.Count;
            for (int i = 0; i < dbcount; i++)
                foreach (var dstDocTable in dBresponse)
                {
                    Assert.True(attachmentResponse.Content.Contains(dstDocTable.DocumentId[i]));
                }
        }

        public class GetStatementRs
        {
            public string DocumentId { get; set; }
            public DateTime Date { get; set; }
            public bool HasCopyInBlob { get; set; }
        }
    }

    class GetNoAttachment : Helper
    {
        public GetNoAttachment()
        {
            var links = new Links();
            string resource = FetchValue("Resource");
            string tenantId = FetchValue("TenantID");
            string token = GetToken(resource, tenantId);
            var attachmentResponse = GetApIMethod(
                links.AttachmentEp + "?AccountNumber=" + FetchValue("AccountNumber") + "&Brand=" +
                FetchValue("Brand") + "&DocumentId=" + FetchValue("DocumentIdWithNoAttachment"), token);
            var dBresponse = FetchDetailsFromEServicingDstDocDbforNoAttachment("DstDocuments",
                FetchValue("AccountNumber"), "Statement",
                FetchValue("DocumentIdWithNoAttachment"));
            int dbcount = dBresponse.Count;
            for (int i = 0; i < dbcount; i++)
                foreach (var dstDocTable in dBresponse)
                {
                    Assert.True(attachmentResponse.Content.Contains(dstDocTable.DocumentId[i]));
                }
        }

        public class GetStatementRs
        {
            public string DocumentId { get; set; }
            public DateTime Date { get; set; }
            public bool HasCopyInBlob { get; set; }
        }
    }

    class GetAttachmentRequest : Helper
    {
        public GetAttachmentRequest()
        {
            var links = new Links();
            string resource = FetchValue("Resource");
            string tenantId = FetchValue("TenantID");
            string token = GetToken(resource, tenantId);
            GetApIMethod(
                links.MessagesEp + "?AccountNumber=" + FetchValue("AccountNumber") + "&Brand=" +
                FetchValue("Brand") + "&DocumentId=" + FetchValue("DocumentId"), token);
        }
    }

    class PostMarkMessageAsRead : Helper
    {
        public PostMarkMessageAsRead()
        {
            var links = new Links();
            string resource = FetchValue("Resource");
            string tenantId = FetchValue("TenantID");

            string token = GetToken(resource, tenantId);
            var postMarkReadResponse = PostApIMethod(
                links.MarkMessageAsReadEp + "?AccountNumber=" + FetchValue("AccountNumber") +
                "&Brand=" + FetchValue("Brand") + "&DocumentId=" + FetchValue("DocumentId"), token);

            Assert.True(postMarkReadResponse.Content.Contains("true"));
        }
    }
}