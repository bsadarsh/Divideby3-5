﻿using System;
using NUnit.Framework;
using TechTalk.SpecFlow;

namespace Servicing.Function.Documents.IntegrationTest
{
    [Binding]
    class ParagonStepDefination : Helper
    {
        public ParagonStepDefination()
        {
            FetchDb("EservDocumentsAPITestData");
            GetBaseUrl();
        }

        [Given(@"I have the account with Statement")]
        public void GivenIHaveTheAccountWithStatement()
        {
        }

        [When(@"I call Get Statement function")]
        public void WhenICallGetStatementFunction()
        {
            try
            {
                var dummy = new GetStatement();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        [Then(@"I should receive all the statement document id for the account")]
        public void ThenIShouldReceiveAllTheStatementDocumentIdForTheAccount()
        {
            try
            {
                var response = GlobalVariables.RestResponse.StatusCode;
                Assert.True(response.ToString().Contains("OK"));
                //var documentId = Environment.GetEnvironmentVariable("StatusCode");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }


        [Given(@"I have the account with Message")]
        public void GivenIHaveTheAccountWithMessage()
        {
        }

        [When(@"I call Get Message function")]
        public void WhenICallGetMessageFunction()
        {
            try
            {
                var dummy = new GetMessage();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                
            }
        }

        [Then(@"I should receive all the Message document id for the account")]
        public void ThenIShouldReceiveAllTheMessageDocumentIdForTheAccount()
        {
            try
            {
                 
                //Assert.True(response.ToString().Contains("OK"));
                //var documentId = Environment.GetEnvironmentVariable("StatusCode");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                
            }
        }

        [Given(@"I have the account with PDF Statements")]
        public void GivenIHaveTheAccountWithPdfStatements()
        {
        }

        [When(@"I call Get Attachment function with account and document id")]
        public void WhenICallGetAttachmentFunctionWithAccountAndDocumentId()
        {
            try
            {
                var dummy = new GetAttachment();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        [When(@"I call Get Attachment function with account and document id for no attachment")]
        public void WhenICallGetAttachmentFunctionWithAccountAndDocumentIdForNoAttachment()
        {
            try
            {
                var dummy = new GetNoAttachment();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }


        [Then(@"I should receive the statement PDF for the account")]
        public void ThenIShouldReceiveTheStatementPdfForTheAccount()
        {
            try
            {
                var response = GlobalVariables.RestResponse.StatusCode;
                Assert.True(response.ToString().Contains("OK"));
                //var documentId = Environment.GetEnvironmentVariable("StatusCode");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }


        [When(@"I use GetAttachment in Paragon API")]
        public void WhenIUseGetAttachmentInParagonApi()
        {
            try
            {
                var dummy = new GetAttachmentRequest();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }
        [Given(@"I have the account with PDF Letters")]
        public void GivenIHaveTheAccountWithPdfLetters()
        {
            
        }
        [Given(@"I have the account with no PDF Statements")]
        public void GivenIHaveTheAccountWithNoPdfStatements()
        {
            
        }
        [Then(@"I should not receive the statement PDF for the account")]
        public void ThenIShouldNotReceiveTheStatementPdfForTheAccount()
        {
            
        }

        [Then(@"I should receive the Letter PDF for the account")]
        public void ThenIShouldReceiveTheLetterPdfForTheAccount()
        {
            try
            {
                var response = GlobalVariables.RestResponse.StatusCode;
                Assert.True(response.ToString().Contains("OK"));
                //var documentId = Environment.GetEnvironmentVariable("StatusCode");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }
        [Given(@"I have the account with unread messages")]
        public void GivenIHaveTheAccountWithUnreadMessages()
        {
            
        }
        [When(@"I call Post MarkMessageAsRead function with account and document id")]
        public void WhenICallPostMarkMessageAsReadFunctionWithAccountAndDocumentId()
        {
            try
            {
                var dummy = new PostMarkMessageAsRead();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }
        [Then(@"The message should mark as read")]
        public void ThenTheMessageShouldMarkAsRead()
        {
            try
            {
                var response = GlobalVariables.RestResponse.StatusCode;
                Assert.True(response.ToString().Contains("OK"));
                //var documentId = Environment.GetEnvironmentVariable("StatusCode");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }



    }
}