﻿namespace Servicing.Function.Documents.IntegrationTest
{
    class Links : Helper
    {
        public string MessagesEp;
        public string StatementsEp;
        public string AttachmentEp;
        public string MarkMessageAsReadEp;

        public Links()
        {
            MessagesEp = GetConfiguration()
                .GetSection("Uri")
                .GetSection("MessagesEp")
                .Value;
            StatementsEp = GetConfiguration()
                .GetSection("Uri")
                .GetSection("StatementsEp")
                .Value;
            AttachmentEp = GetConfiguration()
                .GetSection("Uri")
                .GetSection("AttachmentEp")
                .Value;
            MarkMessageAsReadEp = GetConfiguration()
                .GetSection("Uri")
                .GetSection("MarkMessageAsReadEp")
                .Value;
        }
    }
}