## NewDay.Digital.Foundation.Service.CardAccount

CardAccount represents a credit card account with NewDay, comprising own brand and co-brand accounts.

### Resources

- [Bitbucket](https://bitbucket.org/newdaydigitaldevelopment/foundation.service.cardaccount/src/master/)
- [TeamCity](https://teamcity.newdaycards.com/project.html?projectId=NewDay_Digital_Foundation_ServiceCardAccount)
- [SonarQube](https://digitalsonarqube.newdaycards.com/dashboard?id=NewDay.Digital.Foundation.Service.CardAccount)

|Environment|Function Address| 
|---|---|
|Dev|https://funapngdfdacc0101.azurewebsites.net/|
|UAT|https://funapngufdacc0101.azurewebsites.net/|
|Pre-Prod|https://funapnppfdacc0101.azurewebsites.net/|
|Prod|https://funapngpfdacc0101.azurewebsites.net/|
|DR|https://funapngffdacc0101.azurewebsites.net/|

### How to use it

Install related NuGet packages: 

- **NewDay.Digital.Foundation.Core.Caching.Redis** - Library that contains Redis caching implementation. ([Readme](https://bitbucket.org/newdaydigitaldevelopment/foundation.core.caching.redis/src/master/README.md))
- **NewDay.Digital.Foundation.Core.HealthCheck** - Library what provide service which will allow to perform health checks for all dependencies in project. ([Readme](https://bitbucket.org/newdaydigitaldevelopment/foundation.core.healthcheck/src/master/README.md))
- **NewDay.Digital.Foundation.Domain.CardAccount** - Library that contains the domain objects and the functions contracts (requests and responses). ([Readme](https://bitbucket.org/newdaydigitaldevelopment/foundation.core.domain.cardaccount/src/master/README.md))
- **NewDay.Digital.Foundation.Connector.ApiClient** - Package to be used to connect to NewDay domain services that contains logic for MSI authentication. ([Readme](https://bitbucket.org/newdaydigitaldevelopment/foundation.connector.apiclient/src/master/README.md))

#### Configuration file

Below you can find most important keys for configuring Service:

- `FirstData::ApiBaseAddress` - FirstData URL Address
- `FirstData::ApiResourceIdentifier` - FirstData API Resource Identifier audience URL
- `FirstData::ConnectionString::Brands` - SQL Connection String pointing to database with Brands data
- `CardAccountApplication::AccountHolder_CacheTimeInSeconds` - How long function should cache data returned from GetAccountHolderByCardAccountId endpoint expressed in seconds
- `CardAccountApplication::CardAccount_CacheTimeInSeconds` - How long function should cache data returned from GetCardsByAccount, GetCardAccount, GetMemos and GetAccountByCard endpoints expressed in seconds
- `Redis::ConnectionString` - Redis ConnectionString
- `HealthCheckData::AccountInquiryRequest` - JSON plain text request to FirstData which will be executed during HealthCheck for AccountInquiry endpoint

### End-points

#### V1

#### GetCardAccount

**Route**

v1/getCardAccount

**Request**

```JSON
{
  "cardAccountId": "3925900000000001"
}
```

**Response**

```JSON
{
    "account": {
        "cardAccountId": "0003925900000000001",
        "accountHolder": {
            "accountHolderId": "0003921000012046397",
            "title": "MRS",
            "firstName": "SHONA",
            "lastName": "ARCHIBALD"
        },
        "status": "A",
        "dateOpened": "2017-03-01T00:00:00",
        "creditLimit": 600.0,
        "availableCredit": 343.66,
        "currentBalance": 256.34,
        "blockCode": null,
        "productDescription": null,
        "shortName": "ARCHIBALD SHONA",
        "customerEmbossedName": "ARCHIBALD SHONA",
        "customerSignatureName": "ARCHIBALD SHONA",
        "directDebitAmount": 0.0,
        "arrearsAmount": 0.0,
        "totalAmountDue": 0.0,
        "transferCardAccountId": null,
        "instantSpend": false
    }
}
```

#### GetAccountHolder

**Route**

v1/getAccountHolder

**Request**

```JSON
{
  "cardAccountId": "3925900000000001"
}
```

**Response**

```JSON
{
  "accountHolder": {
    "accountHolderId": "0003925900000000001",
    "firstName": "SHONA",
    "lastName": "ARCHIBALD"
  },
  "personalDetails": {
    "email": "NICOBER.MANI@NEWDAY.CO.UK",
    "phone": null,
    "mobile": "0000000000000000",
    "dateOfBirth": "1991-08-20",
    "addresses": [
      {
        "houseName": null,
        "houseNumber": null,
        "addressLine1": "6 First Lane",
        "addressLine2": null,
        "addressLine3": null,
        "addressLine4": null,
        "postCode": "TQ3 3YF",
        "city": "PAIGNTON",
        "county": null
      }
    ]
  }
}
```

#### GetCardsByAccount

**Route**

v1/getCardsByAccount

**Request**

```JSON
{
  "cardAccountId": "3925900000000001"
}

```

**Response**
```JSON
{
  "cards": [
    {
      "cardNumber": "5193453000452463",
      "isActive": true,
      "isPrimary": true,
      "isBlocked": false,
      "isPendingActivation": false,
	  "customerEmbossedName": "JAMES",
      "expiryDate": "20230731",
      "isFrozen": false
    }
  ]
}
```

#### GetAccountByCard

**Route**

v1/getAccountByCard

**Request**

```JSON
{
  "cardNumber": "5193453000452463"
}
```

**Response**

```JSON
{
  "cardAccountId": "3925900000000001"
}
```

#### GetInsuranceProducts

**Route**

v1/getInsuranceProducts

**Request**

```JSON
{
    "cardAccountId": "3925900000000001"
}
```

**Response**
```JSON
{
    "insuranceProducts": [
        {
            "effectiveDate": "10000",
            "Active": "Y",
            "productName": "2407000",
            "billingFrequency": "1776",
            "policyReferenceNumber": "0",
            "productCode": "Retail",
            "cancellationDate": "0",
            "premium": "STANDARD RETAIL",
            "cancellationReason": "reachedexpirationage"   
        },
        {
            "effectiveDate": "10000",
            "Active": "N",
            "productName": "2407000",
            "billingFrequency": "1776",
            "policyReferenceNumber": "0",
            "productCode": "Retail",
            "cancellationDate": "0",
            "premium": "STANDARD RETAIL",
            "cancellationReason": "reachedexpirationage" 
        }
    ]
}
```

#### CancelInsurance

**Route**

v1/CancelInsurance

**Request**

```JSON
{
  "cardAccountId": "3925900000000001",
  "productCode": "00",
  "cancellationReason": "reachedexpirationage"
}
```

**Response**

```
HTTP OK status, no content
```

#### GetMemos

**Route**

v1/getMemos

**Additional information**

Example response has been shortened due to clarity reason.

**Request**

```JSON
{
  "cardAccountId": "3925900000000001"
}
```

**Response**

```JSON
{
  "memos": [
    {
      "id": 0,
      "text": "E-SERVICING - REGISTRATION SUCCESSFUL",
      "code": "ESPM"
    },
    {
      "id": 0,
      "text": "STATEMENT MESSAGESTATEMENT MESSAGE : 29TRIAD STATEMENT VERSION : 0",
      "code": "AUTO"
    }
  ]
}
```

#### ChargeOff

**Route**

v1/chargeOff

**Request**

```JSON
{
    "cardAccountId": "3925900000000001",
    "reason": "B1"
}
```

**Response**

```
{

}
```

#### CreateMemo

**Route**

v1/createMemo

**Request**

```JSON
{
  "cardAccountId": "3925900000000001",
  "text": "test"
}
```

**Response**

```
HTTP OK status, no content
```

#### GetSpendCap

**Route**

v1/getSpendCap

**Request**

```JSON
{
    "cardAccountId": "3925900000000001",
}
```

**Response**

```JSON
{
    "spendCapType": "Soft",
    "spendCapEnabled": true,
    "spendCapAmount": 150.00,
    "spendCapExceededAmount": 50.00,
    "spendCapReached": true
}
```

#### SetPaymentHoliday

**Route**

v1/setPaymentHoliday

**Request**

```JSON
{
    "cardAccountId": "3925900000000069",
    "term": "1"
}
```

**Response**

```JSON
{

}
```

#### SendSpendCap

**Route**

v1/setSpendCap

**Request**

```JSON
{
    "cardAccountId": "3925900000000001",
    "capAmount": 99.00,
    "capType": "Soft",
    "alertType": "Sms"
}
```

**Response**

```JSON
{
}
```

#### UpdateAccount ####

**Route**

v1/updateAccount

The endpoint consolidates 4 separate FD routes for account date into one

**Request**

All fields except cardAccountId are optional and should be filled as needed when updating data pertaining to one of those endpoints 

Custom fields update request
```JSON
{
  "cardAccountId": "3925900000000001",
  "fixedPaymentAmount": 10.00
}
```

**Account block status update requests**

Add block status
```JSON
{
  "cardAccountId": "3925900000000001",
  "status": "COLHOLDOUT",
}
```

Remove block status
```JSON
{
  "cardAccountId": "3925900000000001",
  "status": "NORMAL",
  "statusIndicator": "1",
}
```

Remove block status with functionCode
```JSON
{
  "cardAccountId": "3925900000000001",
  "status": "COLHOLDOUT",
  "functionCode": "REMOVE"
}
```

All block code request fields listed below
```JSON
{
  "cardAccountId": "3925900000000001",
  "status": "COLHOLDOUT",
  "subStatus": "01",
  "statusIndicator": "1" or "2"
  "productCode": "01",
  "restructureFlag": false,
  "functionCode": "ADD" or "REMOVE"
}
```

Disablity indicator update request
```JSON
{
  "cardAccountId": "3925900000000001",
  "disabilityIndicator": "AUDIO"
}
```

Update user fields request
```JSON
{
  "cardAccountId": "3925900000000001",
  "Code1": "T1",
  "Code2": "T2",
  "Code3": "T3",
  "Code4": "T4",
  "Code5": "T5",
  "Code6": "T6",
  "Code7": "T7",
  "Code8": "T8",
  "Code9": "T9",
  "Code10": "10",
  "Code11": "11",
  "Code12": "12",
  "Amount1": 10.00,
  "Amount2": 10.00,
  "Amount3": 10.00,
  "Amount4": 10.00,
  "Amount5": 10.00,
  "Amount6": 10.00,
  "Amount7": 10.00,
  "Amount8": 10.00,
  "Amount9": 10.00,
  "Amount10": 10.00,
  "Amount11": 10.00,
  "Amount12": 10.00,
  "Miscellaneous1": "Test",
  "Miscellaneous2": "Test",
  "Miscellaneous3": "Test",
  "Miscellaneous4": "Test",
  "Miscellaneous5": "Test",
  "Miscellaneous6": "Test",
  "Miscellaneous7": "Test",
  "Miscellaneous8": "Test",
  "Miscellaneous9": "Test",
  "Miscellaneous10": "Test",
  "Miscellaneous11": "Test",
  "Miscellaneous12": "Test",
  "Date1": "2020-02-16",
  "Date2": "2020-02-16",
  "Date3": "2020-02-16",
  "Date4": "2020-02-16",
  "Date5": "2020-02-16",
  "Date6": "2020-02-16",
  "Date7": "2020-02-16",
  "Date8": "2020-02-16",
  "Date9": "2020-02-16",
  "Date10": "2020-02-16",
  "Date11": "2020-02-16",
  "Date12": "2020-02-16",
}
```

**Response**

```JSON
{
}
```

**Returns 400 if no fields other than cardAccountId were provided**

#### UpdateAccountBlockStatus ####

**Route**
v1/updateAccountBlockStatus

** Request **

```JSON
{
  "cardNumber": "0005474106035282723",
  "status": "COLHOLDOUT",
  "subStatus": "BREATHING_SPACE",
  "cardAccountId": "3925900000000001"
}
```

**Response**

```JSON
{
}
```

#### UpdateBillingCycle

**Route**

v1/updateBillingCycle

**Request**

```JSON
{
    "cardAccountId": "3925900000000001",
    "billingCycle": 5
}
```

**Response**

```JSON
{
}
```

#### CreateInstallmentPlan

**Route**

v1/createInstallmentPlan

**Request**

```JSON
{
    "cardAccountId": "3925900000000001",
    "installmentPlan": "57906",
    "amount": 22,
    "sourcePlan": "57000"
}
```

**Response**

```JSON
{

}
```

#### InstallmentQuote

**Route**

v1/installmentQuote

**Request**

```JSON
{
    "cardAccountId": "3925900000000001",
    "plan": "50906",
    "totalAmount": 300,
    "fixedAmount": 12
}
```

OR

```JSON
{
    "cardAccountId": "3925900000000001",
    "plan": "50906",
    "totalAmount": 300
    "terms": 22
}
```

**Response**

```JSON
{
    "fixedAmount": 12,
    "totalAmount": 300,
    "interestEstimated": 10,
    "terms": 22,
    "monthlyRate": 1200,
    "annualRate": 1200
}
```

#### PostGoodwill

**Route**

v1/postGoodwill

**Request**

```JSON
{
    "cardAccountId": "3925900000000001",
    "amount": 12
}
````

**Response**

```JSON
{
    
}
```

#### RemoveFee

**Route**

v1/removeFee

**Request**

Removing a Fee
```JSON
{
    "cardAccountId": "3925900000000069",
    "feeType": "DDReturn",
    "amount": 49,
    "planNumber": "12345",
    "planSeqNumber": "123",
    "date": "2020-12-22"
}
```
OR

```JSON
{
    "cardAccountId": "3925900000000001",
    "feeType": "LateFee|Interest",
    "amount": 49.99
}
```

**Response**

```JSON
{
}
```

#### Request Letter

**Route**

v1/requestLetter

**Request**

```JSON
{
    "cardAccountId": "3925900000000001",
    "letterCode": "023"
}
```

**Response**

```JSON
{
}
```

#### Return Funds

**Route**

v1/returnFunds

**Request**

Return funds where an account has a positive balance
```JSON
{
    "cardAccountId": "3925900000000001",
    "amount": 49.99
}
```

**Response**

```JSON
{
}
```

#### Create Plan

**Route**

v1/createPlan

**Request**

```JSON
{
    "cardAccountId": "3915000001749033",
    "retailPlan": "10004"
}
```

**Response**

```JSON
{
}
```

#### GetPlan

**Route**

v1/getPlans

**Request**

```JSON
{
    "cardAccountId": "3925900000000001"
}
```

**Response**

```JSON
{
    "plans": [
        {
            "identifier": "10000",
            "balance": "0",
            "Aer": "2407000",
            "dailyInterest": "1776",
            "interestEstimated": "0",
            "type": "Retail",
            "interestAccrued": "0",
            "description": "STANDARD RETAIL",
            "openDate": "20171003"   
            "Active": "Y"
        },
        {
            "identifier": "10001",
            "balance": "0",
            "Aer": "2407000",
            "dailyInterest": "1776",
            "interestEstimated": "0",
            "type": "Cash",
            "interestAccrued": "0",
            "description": "CASH",
            "openDate": "20171003"              
            "Active": "N"
            }
        }
    ]
}
```

#### Remove Payment Holiday

**Route**

v1/removePaymentHoliday

**Request**
```JSON
{
  "cardAccountId": "3925900000000069",
  "term": "1"
}
```

**Response**
```JSON
{
}
```

#### Re Age By Code

**Route**

v1/reAgeByCode

**Request**
```JSON
{
  "cardAccountId": "7355010000088950",
  "Code": 1
}
```

**Response**
```JSON
{
}
```

#### Re Age By Amount

**Route**

v1/reAgeByAmount

**Request**
```JSON
{
  "cardAccountId": "7355010000088950",
  "dueBuckets": ["10.10", "20.20"]
}
```

**Response**
```JSON
{
}
```

#### PlanTransfer

**Route**

v1/PlanTransfer

**Request**

```JSON
{
  "cardAccountId":"7325401645390350",
  "fromPlan":"12345",
  "fromRecordNumber":"1",
  "toPlan":"12347",
  "toRecordNumber":"3"
}
```

**Response**

```
HTTP OK status, no content
```

#### V2

#### GetCardAccount

**Route**

v2/getCardAccount

**Request**

```JSON
{
  "cardAccountId": "3915000004732085"
}
```

**Response**

```JSON
{
    "account": {
        "accountNumber": "0003915000004732085",
        "status": "Active",
        "subStatus": "Normal",
        "openDate": "2013-11-20",
        "availableCredit": 2587.3,
        "creditLimit": 4350.0,
        "vulnerableCustomerFlag": null,
        "currentBalance": 1762.7,
        "bnplBalance": 0.0,
        "nonBnplBalance": 1762.7,
        "currentPaymentDue": 0.0,
        "arrearAmount": 0.0,
        "paymentRequested": 129.25,
        "boostedPayment": null,
        "lastPaymentAmount": 100.0,
        "paymentDueDate": "2021-04-16T00:00:00",
        "lastStatementBalance": 1862.7,
        "lastStatementDate": "2021-03-30",
        "nextStatementDate": "2021-04-30",
        "lastPaymentDate": "2021-04-16",
        "cycleDue": "0",
        "directDebitStatus": "2",
        "accountHolder": {
            "title": "MR",
            "firstName": "COLIN",
            "middleName": null,
            "lastName": "WATER",
            "dateOfBirth": "1967-06-15"
        },
        "persistentDebt": {
            "currentTerm": null,
            "originalTerm": null,
            "totalInstallmentAmount": null,
            "totalBalance": null
        },
        "address": {
            "houseNumber": null,
            "addressLine1": "45",
            "addressLine2": "SUGAR TERRACE",
            "addressLine3": null,
            "city": "PORT TALBOT",
            "postCode": "X98 7AA",
            "countryCode": "GBR"
        },
        "contactDetails": {
            "email": "PASS_THREATMETRIX@GMAIL.COM",
            "mobileNumber": "07405475897",
            "homePhoneNumber": "01115949839",
            "workPhoneNumber": null
        }
    }
}
```

### Resources

#### FirstData

|Environment|FirstData| 
|---|---|
|Dev|[Mock Server](http://first-data.digitalsandbox.newdaycards.com:8080)|
|UAT|[First Data Api in UAT](https://uat-fsapi.firstdata.com:9758/api/fs/fv_emea/)|
|Prod|   |

[Following link](https://atlassian.newday.co.uk/confluence/display/ES/CardAccount+Domain+Service) details how the CardAccount service handles FirstData failure response.

### Architecture

https://newdaycards.atlassian.net/wiki/spaces/ES/pages/1708704/Services+architecture

### Response format

HTTP response inline with our [NewDay standard](https://newdaycards.atlassian.net/wiki/spaces/ES/pages/1708906/HTTP+Status+Codes).