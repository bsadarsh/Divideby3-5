﻿using System.Collections.Generic;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Service.CardAccount.Data.Models;

namespace NewDay.Digital.Foundation.Service.CardAccount.Data
{
    public interface IRandomUserClient
    {
        Task<IEnumerable<RandomUser>> GetPersons(int limit);
    }
}