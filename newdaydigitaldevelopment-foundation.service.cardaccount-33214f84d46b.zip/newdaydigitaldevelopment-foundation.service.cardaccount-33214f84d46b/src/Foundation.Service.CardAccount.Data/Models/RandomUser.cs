﻿namespace NewDay.Digital.Foundation.Service.CardAccount.Data.Models
{
    public class RandomUser
    {
        public string Gender { get; set; }
        public Name Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Cell { get; set; }
        public Id Id { get; set; }
    }

    public class Name
    {
        public string Title { get; set; }
        public string First { get; set; }
        public string Last { get; set; }
    }
    
    public class Id
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }
}
