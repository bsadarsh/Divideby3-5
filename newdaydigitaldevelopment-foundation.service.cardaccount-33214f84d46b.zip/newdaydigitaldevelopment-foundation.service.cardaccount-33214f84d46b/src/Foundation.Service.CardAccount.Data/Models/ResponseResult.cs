﻿namespace NewDay.Digital.Foundation.Service.CardAccount.Data.Models
{
    public class ResponseResult
    {
        public RandomUser[] Results { get; set; }
    }
}
