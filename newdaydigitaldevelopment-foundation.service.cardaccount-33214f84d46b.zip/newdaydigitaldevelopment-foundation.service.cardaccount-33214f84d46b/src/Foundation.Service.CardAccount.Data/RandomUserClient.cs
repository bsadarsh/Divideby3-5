﻿using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Service.CardAccount.Data.Models;
using Newtonsoft.Json;

namespace NewDay.Digital.Foundation.Service.CardAccount.Data
{
    public class RandomUserClient : IRandomUserClient
    {
        private readonly HttpClient _httpClient;

        public RandomUserClient(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        
        public async Task<IEnumerable<RandomUser>> GetPersons(int limit)
        {
            using (var response = await _httpClient.GetAsync($"https://randomuser.me/api/?results={limit}"))
            {
                var content = await response.Content.ReadAsStringAsync();
                var result = JsonConvert.DeserializeObject<ResponseResult>(content);
                return result.Results;
            }
        }
    }
}
