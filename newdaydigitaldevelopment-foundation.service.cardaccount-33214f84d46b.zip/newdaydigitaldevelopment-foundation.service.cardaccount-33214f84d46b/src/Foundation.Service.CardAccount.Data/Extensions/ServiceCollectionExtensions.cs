﻿using System.Net.Http;
using Microsoft.Extensions.DependencyInjection;

namespace NewDay.Digital.Foundation.Service.CardAccount.Data.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static void AddData(this IServiceCollection services)
        {
            services.AddSingleton(_ => new HttpClient());
            services.AddSingleton<IRandomUserClient, RandomUserClient>();
        }
    }
}
