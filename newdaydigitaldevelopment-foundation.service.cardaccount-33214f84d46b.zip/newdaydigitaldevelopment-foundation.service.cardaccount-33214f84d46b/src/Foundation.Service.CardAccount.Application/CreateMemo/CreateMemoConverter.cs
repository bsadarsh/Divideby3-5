﻿using System.Linq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountActivityUpdates.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Extensions;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.CreateMemo
{
    public class CreateMemoConverter : ICreateMemoConverter
    {
        private const string MemoAddAction = "CSPM";

        private readonly IBrandHelper _brandHelper;

        public CreateMemoConverter(IBrandHelper brandHelper)
        {
            _brandHelper = brandHelper;
        }

        public MemoAddRequest ToAddAMemoRequest(CreateCardAccountMemoRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId);
            if (brand == null)
            {
                throw new InvalidBrandException();
            }
            var splitIntoLines = request.Text.SplitByLength(60).ToList();

            return new MemoAddRequest(brand.ClientNumber)
            {
                Account = request.CardAccountId,
                ActnCd = MemoAddAction,
                MemoLine1 = splitIntoLines[0],
                MemoLine2 = splitIntoLines.Count > 1 ? splitIntoLines[1] : string.Empty,
                MemoLine3 = splitIntoLines.Count > 2 ? splitIntoLines[2] : string.Empty,
                MemoLine4 = splitIntoLines.Count > 3 ? splitIntoLines[3] : string.Empty,
                MemoLine5 = splitIntoLines.Count > 4 ? splitIntoLines[4] : string.Empty
            };
        }
    }
}
