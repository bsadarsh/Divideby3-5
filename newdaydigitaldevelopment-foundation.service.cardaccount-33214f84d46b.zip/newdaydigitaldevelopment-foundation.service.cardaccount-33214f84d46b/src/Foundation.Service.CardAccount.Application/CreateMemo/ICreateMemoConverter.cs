﻿using NewDay.Digital.Foundation.Connector.FirstData.AccountActivityUpdates.v1.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.CreateMemo
{
    public interface ICreateMemoConverter
    {
        MemoAddRequest ToAddAMemoRequest(CreateCardAccountMemoRequest request);
    }
}