﻿using System;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.AccountActivityUpdates.v1;
using NewDay.Digital.Foundation.Connector.FirstData.AccountActivityUpdates.v1.Models;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.CreateMemo
{
    public class CreateMemoService : IExecutable<CreateCardAccountMemoRequest, DataManagerResponse<MemoAddResponse>>
    {
        private readonly ICreateMemoConverter _createMemoConverter;
        private readonly IAccountActivityUpdatesApiClient _memoApiClient;

        public CreateMemoService(
            ICreateMemoConverter createMemoConverter,
            IAccountActivityUpdatesApiClient memoApiClient)
        {
            _createMemoConverter = createMemoConverter;
            _memoApiClient = memoApiClient;
        }

        public async Task<DataManagerResponse<MemoAddResponse>> ExecuteAsync(CreateCardAccountMemoRequest request)
        {
            var fdRequest = _createMemoConverter.ToAddAMemoRequest(request);
            await _memoApiClient.MemoAddAsync(fdRequest);

            return new DataManagerResponse<MemoAddResponse>(new MemoAddResponse(), DateTime.UtcNow, TimeSpan.Zero);
        }
    }
}
