﻿using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.UpdateBlockCode;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.UpdateAccountBlockStatus
{
    public class UpdateAccountBlockStatusConverter : IUpdateAccountBlockStatusConverter
    {
        private const string UnblockFunctionCode = "U";
        private const string BlockFunctionCode = "B";
        private const string AccountRestructureYesCode = "Y";
        private readonly IBrandHelper _brandHelper;
        private static readonly UpdateAccountBlockStatusResponse UpdateBlockCodeResponse = new UpdateAccountBlockStatusResponse();

        public UpdateAccountBlockStatusConverter(IBrandHelper brandHelper)
        {
            _brandHelper = brandHelper;
        }

        public AccountBlockCodeUpdateRequest ToAccountBlockCodeUpdateRequest(UpdateAccountBlockStatusRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId);
            if (brand == null)
            {
                throw new InvalidBrandException();
            }

            var blockCode = StatusMap.StatusBlockCodeMap[request.Status];
            var subStatus = request.SubStatus.HasValue ? StatusMap.SubStatusMap[request.SubStatus.Value] : "";

            return new AccountBlockCodeUpdateRequest(brand.ClientNumber)
            {
                Account = request.CardAccountId,
                CardNbr = request.CardNumber,
                BlkCdInd = "1", // TODO: decision should be made depending on which blkcd is empty: https://newdaycards.atlassian.net/browse/ESERV-19714
                BlkCd = blockCode,
                FunctionCd = string.IsNullOrEmpty(blockCode) ? UnblockFunctionCode : BlockFunctionCode, //decides if we are adding or removing block code
                SubStatus = subStatus,
                AcctRestructure = DetermineAccountRestructureCode(request)
            };
        }

        private static bool IsBreathingSpace(UpdateAccountBlockStatusRequest request) => request.SubStatus.HasValue && request.SubStatus.Equals(SubStatus.BREATHING_SPACE);

        private static bool IsNfa(UpdateAccountBlockStatusRequest request) => request.Status.Equals(Status.NFA);

        private static string DetermineAccountRestructureCode(UpdateAccountBlockStatusRequest request)
        {
            if (IsBreathingSpace(request) || IsNfa(request))
            {
                return AccountRestructureYesCode;
            }

            return null;
        }

        public UpdateAccountBlockStatusResponse ToUpdateAccountBlockStatusResponse(AccountBlockCodeUpdateResponse response) =>
            UpdateBlockCodeResponse;
    }
}