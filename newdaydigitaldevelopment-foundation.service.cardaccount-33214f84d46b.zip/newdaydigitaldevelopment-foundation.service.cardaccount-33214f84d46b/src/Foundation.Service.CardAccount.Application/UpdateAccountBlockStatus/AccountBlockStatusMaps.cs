﻿using System.Collections.Generic;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.UpdateBlockCode;
using static NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.UpdateBlockCode.Status;
using static NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.UpdateBlockCode.SubStatus;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.UpdateAccountBlockStatus
{
    public static class StatusMap
    {
        public static readonly IDictionary<Status, List<SubStatus>> ValidStatusAndSubStatusCombinationsMap = new Dictionary<Status, List<SubStatus>>
        {
            {
                COLHOLDOUT, new List<SubStatus>
                {
                    BREATHING_SPACE
                }
            }
        };

        public static readonly IDictionary<Status, string> StatusBlockCodeMap = new Dictionary<Status, string>
        {
            {NORMAL, ""},
            {COLHOLDOUT, "A"},
            {NFA, "N"}
        };

        public static readonly IDictionary<SubStatus, string> SubStatusMap = new Dictionary<SubStatus, string>
        {
            {BREATHING_SPACE, "01"}
        };
    }
}