﻿using System;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Core.Caching.Generators;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.UpdateBlockCode;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.UpdateAccountBlockStatus
{
    public class UpdateAccountBlockStatusService : IExecutable<UpdateAccountBlockStatusRequest, DataManagerResponse<UpdateAccountBlockStatusResponse>>
    {
        private readonly IAccountMaintenanceApiClient _fdApi;
        private readonly IUpdateAccountBlockStatusConverter _converter;
        private readonly IDataManager _dataManager;

        public UpdateAccountBlockStatusService(IUpdateAccountBlockStatusConverter converter, IAccountMaintenanceApiClient fdApi, IDataManager dataManager)
        {
            _converter = converter;
            _fdApi = fdApi;
            _dataManager = dataManager;
        }

        public async Task<DataManagerResponse<UpdateAccountBlockStatusResponse>> ExecuteAsync(UpdateAccountBlockStatusRequest request)
        {
            if (!IsSubStatusValid(request.Status, request.SubStatus))
            {
                throw new AccountBlockStatusAndSubStatusInvalidCombinationException($"Invalid subStatus: {request.SubStatus} and status: {request.Status} combination");
            }

            var fdRequest = _converter.ToAccountBlockCodeUpdateRequest(request);
            var fdResponse = await _fdApi.AccountBlockCodeUpdateAsync(fdRequest);
            await InvalidateCardAccountCache(request.CardAccountId);
            return new DataManagerResponse<UpdateAccountBlockStatusResponse>(_converter.ToUpdateAccountBlockStatusResponse(fdResponse), DateTime.UtcNow, TimeSpan.Zero);
        }

        private static bool IsSubStatusValid(Status requestStatus, SubStatus? requestSubStatus) => !requestSubStatus.HasValue || StatusMap.ValidStatusAndSubStatusCombinationsMap.TryGetValue(requestStatus, out var subStatuses) && subStatuses.Contains(requestSubStatus.Value);

        private async Task InvalidateCardAccountCache(string cardAccountId)
        {
            var cardAccountRequest = new GetCardAccountRequest
            {
                CardAccountId = cardAccountId
            };

            var key = CacheKeyGenerator.Generate(cardAccountRequest, cardAccountId);
            if (await _dataManager.IsSetAsync(key))
            {
                await _dataManager.RemoveAsync(key);
            }
        }
    }
}