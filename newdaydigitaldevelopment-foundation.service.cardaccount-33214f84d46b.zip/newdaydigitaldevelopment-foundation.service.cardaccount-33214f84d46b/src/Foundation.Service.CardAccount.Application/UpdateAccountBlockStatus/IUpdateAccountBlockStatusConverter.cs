﻿using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.UpdateAccountBlockStatus
{
    public interface IUpdateAccountBlockStatusConverter
    {
        AccountBlockCodeUpdateRequest ToAccountBlockCodeUpdateRequest(UpdateAccountBlockStatusRequest request);
        UpdateAccountBlockStatusResponse ToUpdateAccountBlockStatusResponse(AccountBlockCodeUpdateResponse response);
    }
}