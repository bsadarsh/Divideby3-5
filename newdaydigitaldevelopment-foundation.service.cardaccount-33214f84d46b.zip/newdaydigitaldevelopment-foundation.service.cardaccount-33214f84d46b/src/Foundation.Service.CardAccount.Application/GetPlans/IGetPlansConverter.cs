﻿using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v2.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetPlans;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetPlans
{
    public interface IGetPlansConverter
    {
        public AccountPlanInquiryRequest2 ToAccountPlanInquiry(GetPlansRequest request);

        public GetPlansResponse ToGetPlansResponse(AccountPlanInquiryResponse2 response);
    }
}
