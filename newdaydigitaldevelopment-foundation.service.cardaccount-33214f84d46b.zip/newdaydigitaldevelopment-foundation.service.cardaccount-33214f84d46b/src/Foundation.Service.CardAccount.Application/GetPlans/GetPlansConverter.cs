﻿using System.Globalization;
using System.Linq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v2.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Extensions;
using NewDay.Digital.Foundation.Core.Domain.CardAccount;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetPlans;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetPlans
{
    public class GetPlansConverter : IGetPlansConverter
    {
        private readonly IBrandHelper _brandHelper;

        public GetPlansConverter(IBrandHelper brandHelper)
        {
            _brandHelper = brandHelper;
        }

        public AccountPlanInquiryRequest2 ToAccountPlanInquiry(GetPlansRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId);
            if (brand == null)
            {
                throw new InvalidBrandException();
            }

            return new AccountPlanInquiryRequest2(brand.ClientNumber)
            {
                Acct = request.CardAccountId
            };
        }

        public GetPlansResponse ToGetPlansResponse(AccountPlanInquiryResponse2 response)
        {
            var plans = response.PlanCtdData.Select(plan => new Plan
            {
                Identifier = plan.PlanNbr,
                Balance = ToDecimal(plan.PlanCurrBal),
                Aer = ToDecimal(plan.PlanCurrAer, 7),
                DailyInterest = ToDecimal(plan.PerDiemInterest, 4),
                InterestEstimated = ToDecimal(plan.EstimatedInterest),
                Type = MapFdPlanType(plan.PlanType),
                InterestAccrued = ToDecimal(plan.AccruedInterest, 4),
                Description = plan.PlanDesc,
                OpenDate = plan.PlanOpenDte != "0" ? plan.PlanOpenDte.DateTimeFromFDDateString() : null,
                Active = plan.PlanOpenDte == "0" ? "N" : "Y"
            }).ToList();

            return new GetPlansResponse
            {
                Plans = plans
            };
        }

        private static PlanType MapFdPlanType(string planType)
        {
            return planType switch
            {
                "A" => PlanType.AccessCheck,
                var x when x == "B" || x == "T" => PlanType.BalanceTransfer,
                "C" => PlanType.Cash,
                "L" => PlanType.ClosedEndInstallmentLoan,
                "R" => PlanType.Retail,
                "Y" => PlanType.Prepaid,
                _ => PlanType.Unknown
            };
        }

        private static string ToDecimal(string data, int numberOfDecimals = 2)
        {
            var result = data.DecimalFromFDAmountString(numberOfDecimals);
            return result.ToString(CultureInfo.InvariantCulture);
        }
    }
}
