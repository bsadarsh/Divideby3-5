﻿using System;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v2;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetPlans;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Cache;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetPlans
{
    public class GetPlansService : IExecutable<GetPlansRequest, DataManagerResponse<GetPlansResponse>>
    {
        private readonly IGetPlansConverter _getPlansConverter;
        private readonly IAccountManagementApiClient _accountManagementApiClient;
        private readonly IDataManager _dataManager;
        private readonly TimeSpan _cacheTime;
        private readonly IAccountPlanInquiryCacheKeyProvider _cacheKeyProvider;

        public GetPlansService(
            IGetPlansConverter getPlansConverter,
            IAccountManagementApiClient accountManagementApiClient,
            IDataManager dataManager,
            ITimeoutProvider timeoutProvider, 
            IAccountPlanInquiryCacheKeyProvider cacheKeyProvider)
        {
            _getPlansConverter = getPlansConverter;
            _accountManagementApiClient = accountManagementApiClient;
            _dataManager = dataManager;
            _cacheKeyProvider = cacheKeyProvider;
            _cacheTime = timeoutProvider.Timeout;
        }

        public async Task<DataManagerResponse<GetPlansResponse>> ExecuteAsync(GetPlansRequest request)
        {
            var accountPlanInquiry = _getPlansConverter.ToAccountPlanInquiry(request);

            var cacheKey = _cacheKeyProvider.GetKey(request.CardAccountId);
            var dataManagerResponse = await _dataManager.FetchWithCacheAsync(cacheKey, _cacheTime, () => _accountManagementApiClient.AccountPlanInquiryAsync(accountPlanInquiry));
            
            var response = _getPlansConverter.ToGetPlansResponse(dataManagerResponse.Value);

            return new DataManagerResponse<GetPlansResponse>(response, dataManagerResponse.CacheAge, dataManagerResponse.CacheLifetime);
        }
    }
}
