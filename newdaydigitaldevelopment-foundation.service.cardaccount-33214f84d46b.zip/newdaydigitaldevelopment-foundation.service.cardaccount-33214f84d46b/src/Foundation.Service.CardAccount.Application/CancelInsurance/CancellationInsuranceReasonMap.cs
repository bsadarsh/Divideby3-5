﻿using System.Collections.Generic;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.CancelInsurance;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.CancelInsurance
{
    public static class CancellationInsuranceReasonMap
    {
        public static readonly IDictionary<CancellationReason, string> FirstDataCancellationReasonMap = new Dictionary<CancellationReason, string>
        {
            {CancellationReason.ReachedExpirationAge, "A"},
            {CancellationReason.Delinquency, "D" },
            {CancellationReason.DOBEnrollment, "G" },
            {CancellationReason.DOBMinimumage, "I" },
            {CancellationReason.CreditLineAccountClosed, "P"},
            {CancellationReason.RequestOfCustomer, "R"},
            {CancellationReason.AmountAtRisk, "T" },
            {CancellationReason.Underwriter, "U" },
            {CancellationReason.Other, "X" }
        };
    }
}