﻿using NewDay.Digital.Foundation.Connector.FirstData.Insurance.v1.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.CancelInsurance;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.CancelInsurance
{
    public interface ICancelInsuranceConverter
    {
        InsuranceStatusUpdateRequest ToInsuranceStatusUpdateRequest(CancelInsuranceRequest request);
    }
}
