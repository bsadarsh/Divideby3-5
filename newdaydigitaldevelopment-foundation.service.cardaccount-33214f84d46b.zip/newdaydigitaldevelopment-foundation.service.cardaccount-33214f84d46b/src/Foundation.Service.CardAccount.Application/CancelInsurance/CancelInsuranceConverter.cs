﻿using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Insurance.v1.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.CancelInsurance;
using NewDay.Digital.Foundation.Core.Utils;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Constants;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.CancelInsurance
{ 
    public class CancelInsuranceConverter : ICancelInsuranceConverter
    {
        private readonly IBrandHelper _brandHelper;

        public CancelInsuranceConverter(IBrandHelper brandHelper) => _brandHelper = brandHelper.ArgNotNull(nameof(brandHelper));

        public InsuranceStatusUpdateRequest ToInsuranceStatusUpdateRequest(CancelInsuranceRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId)
                        ?? throw new InvalidBrandException();


            var cancellationReasonCode = CancellationInsuranceReasonMap.FirstDataCancellationReasonMap[request.CancellationReason];

            return new InsuranceStatusUpdateRequest(brand.ClientNumber)
            {
                Account = request.CardAccountId,
                InsProdCode = request.ProductCode,
                InsStatusCode = FirstDataConstants.CancelCode,
                CanReasonCode = cancellationReasonCode
            };
        }
    }

}
