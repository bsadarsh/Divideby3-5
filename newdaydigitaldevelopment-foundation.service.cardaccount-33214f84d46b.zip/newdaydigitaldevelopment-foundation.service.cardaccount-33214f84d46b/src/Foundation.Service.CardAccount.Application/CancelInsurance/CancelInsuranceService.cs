﻿using System;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.Insurance.v1;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.CancelInsurance;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.CancelInsurance
{
    public class CancelInsuranceService : IExecutable<CancelInsuranceRequest, DataManagerResponse<CancelInsuranceResponse>>
    {
        private readonly ICancelInsuranceConverter _converter;
        private readonly IInsuranceApiClient _insuranceApiClient;

        public CancelInsuranceService(
            ICancelInsuranceConverter converter,
            IInsuranceApiClient insuranceApiClient)
        {
            _converter = converter;
            _insuranceApiClient = insuranceApiClient;
        }

        public async Task<DataManagerResponse<CancelInsuranceResponse>> ExecuteAsync(CancelInsuranceRequest request)
        {
            var insuranceStatusUpdateRequest = _converter.ToInsuranceStatusUpdateRequest(request);
            await _insuranceApiClient.InsuranceStatusUpdateAsync(insuranceStatusUpdateRequest);

            return new DataManagerResponse<CancelInsuranceResponse>(new CancelInsuranceResponse(), DateTime.UtcNow, TimeSpan.Zero);
        }
    }
}
