﻿using System;
using Microsoft.Extensions.Logging;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Extensions;
using NewDay.Digital.Foundation.Core.Domain.CardAccount;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;
using DomainCardAccount = NewDay.Digital.Foundation.Core.Domain.CardAccount.CardAccount;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetCardAccountV1
{
    public class GetCardAccountConverter : IGetCardAccountConverter
    {
        private readonly IBrandHelper _brandHelper;
        private readonly ILogger<GetCardAccountConverter> _logger;
        private const string BlankAccountNumber = "0000000000000000000";

        public GetCardAccountConverter(IBrandHelper brandHelper, ILogger<GetCardAccountConverter> logger)
        {
            _brandHelper = brandHelper;
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public AccountDetailInquiryRequest3 ToAccountDetailInquiryRequest(GetCardAccountRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId);
            if (brand == null)
            {
                throw new InvalidBrandException();
            }
            return new AccountDetailInquiryRequest3(brand.ClientNumber)
            {
                Account = request.CardAccountId
            };
        }

        public GetCardAccountResponse ToGetCardAccountResponse(AccountDetailInquiryResponse3 response)
        {
            if (response == null)
                return null;

            var decimalPositions = Convert.ToInt16(response.CurrencyNod);

            var currentCycleBillWasPaid = Convert.ToInt32(response.PmtCtd) >= Convert.ToInt32(response.PmtTotAmtDue);

            // Amount is past due 1-29 days or 'X' days
            var isCustomerDelinquent = Convert.ToInt32(response.PmtCycleDue) >= 2;

            //CurrentBalance > CreditLimit
            var isOverlimit  = response.CurrBal.DecimalFromFDAmountString(decimalPositions) >
                               response.Crlim.DecimalFromFDAmountString(decimalPositions);
            var account = new DomainCardAccount
            {
                CardAccountId = response.Account,
                AccountHolder = new AccountHolder
                {
                    AccountHolderId = response.CustomerNumber,
                    FirstName = response.FirstName1,
                    LastName = response.LastName1,
                    Title = response.Title1
                },
                AvailableCredit = response.AvailCredit.DecimalFromFDAmountString(decimalPositions),
                CurrentBalance = response.CurrBal.DecimalFromFDAmountString(decimalPositions),
                CreditLimit = response.Crlim.DecimalFromFDAmountString(decimalPositions),
                BlockCode = CardAccountUtils.GetProperBlockCode(response),
                DateOpened = response.DateOpened.DateTimeFromFDDateString().GetValueOrDefault(),
                Status = response.IntStatus,
                ShortName = response.ShortName,
                CustomerEmbossedName = $"{response.Title1} {response.FirstName1} {response.LastName1}",
                CustomerSignatureName = response.EdEmbFullName,
                DirectDebitAmount = response.ProjAchPmt.DecimalFromFDAmountString(decimalPositions),
                ArrearsAmount = response.PmtPastDue.DecimalFromFDAmountString(decimalPositions),
                TotalAmountDue = response.PmtTotAmtDue.DecimalFromFDAmountString(decimalPositions),

                CurrentCycleBillWasPaid = currentCycleBillWasPaid,
                IsCustomerDelinquent = isCustomerDelinquent,
                IsCustomerOverlimit = isOverlimit,
                PaymentDueDate = CardAccountUtils.ConvertToDateTime(_logger, response.DatePmtDue, "PaymentDueDate"),
                NextStatementDate = CardAccountUtils.ConvertToDateTime(_logger, response.DateNextStmt, "NextStatementDate"),
                TransferCardAccountId = response.XfrAcct != BlankAccountNumber ? response.XfrAcct : null,
                InstantSpend = response.InstSpndFl == "1"
            };

            var getCardAccountResponse = new GetCardAccountResponse
            {
                Account = account,
            };

            return getCardAccountResponse;
        }
    }
}
