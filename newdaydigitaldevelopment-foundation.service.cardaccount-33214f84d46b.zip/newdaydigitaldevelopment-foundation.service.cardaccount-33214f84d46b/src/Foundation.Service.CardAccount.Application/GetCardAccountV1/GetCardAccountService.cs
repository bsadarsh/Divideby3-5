﻿using System;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Cache;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetCardAccountV1
{
    public class GetCardAccountService : IExecutable<GetCardAccountRequest, DataManagerResponse<GetCardAccountResponse>>
    {
        private readonly TimeSpan _cardAccountCacheTime;
        private readonly IAccountManagementApiClient _accountManagementApiClient;
        private readonly IGetCardAccountConverter _detailsConverter;
        private readonly IDataManager _dataManager;
        private readonly IAccountDetailInquiryCacheKeyProvider _cacheKeyProvider;

        public GetCardAccountService(
            ITimeoutProvider timeoutProvider,
            IAccountManagementApiClient accountManagementApiClient,
            IGetCardAccountConverter detailsConverter,
            IDataManager dataManager, IAccountDetailInquiryCacheKeyProvider cacheKeyProvider)
        {
            _cardAccountCacheTime = timeoutProvider.Timeout;
            _accountManagementApiClient = accountManagementApiClient;
            _detailsConverter = detailsConverter;
            _dataManager = dataManager;
            _cacheKeyProvider = cacheKeyProvider;
        }

        public async Task<DataManagerResponse<GetCardAccountResponse>> ExecuteAsync(GetCardAccountRequest request)
        {
            var fdRequest = _detailsConverter.ToAccountDetailInquiryRequest(request);

            var cacheKey = _cacheKeyProvider.GetKey(request.CardAccountId);
            var dataManagerResponse = await _dataManager.FetchWithCacheAsync(cacheKey, _cardAccountCacheTime,
                async () => await _accountManagementApiClient.AccountDetailInquiryAsync(fdRequest));

            var response = _detailsConverter.ToGetCardAccountResponse(dataManagerResponse.Value);

            return new DataManagerResponse<GetCardAccountResponse>(response, dataManagerResponse.CacheAge, dataManagerResponse.CacheLifetime);
        }
    }
}
