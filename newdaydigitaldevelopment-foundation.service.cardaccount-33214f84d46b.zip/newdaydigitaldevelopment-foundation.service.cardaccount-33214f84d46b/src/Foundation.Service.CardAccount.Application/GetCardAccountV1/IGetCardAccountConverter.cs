﻿using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetCardAccountV1
{
    public interface IGetCardAccountConverter
    {
        AccountDetailInquiryRequest3 ToAccountDetailInquiryRequest(GetCardAccountRequest request);

        GetCardAccountResponse ToGetCardAccountResponse(AccountDetailInquiryResponse3 response);
    }
}
