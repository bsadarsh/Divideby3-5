﻿using System;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.UpdateBillingCycle;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.UpdateBillingCycle
{
    public class UpdateBillingCycleConverter : IUpdateBillingCycleConverter
    {
        private readonly IBrandHelper _brandHelper;

        /// <summary>
        /// A static instance to use, as the response is always the same.
        /// </summary>
        private static readonly UpdateBillingCycleResponse UpdateBillingCycleResponseInstance = new UpdateBillingCycleResponse();

        public UpdateBillingCycleConverter(IBrandHelper brandHelper)
        {
            _brandHelper = brandHelper ?? throw new ArgumentNullException(nameof(brandHelper));
        }

        public BillingCycleUpdateRequest ToBillingCycleUpdateRequest(UpdateBillingCycleRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId);
            if (brand == null)
            {
                throw new InvalidBrandException();
            }

            var fdRequest = new BillingCycleUpdateRequest(brand.ClientNumber)
            {
                Account = request.CardAccountId,
                BillCyc = request.BillingCycle.ToString()
            };
            return fdRequest;
        }

        public UpdateBillingCycleResponse ToUpdateBillingCycleResponse(BillingCycleUpdateResponse response)
        {
            return UpdateBillingCycleResponseInstance;
        }
    }
}