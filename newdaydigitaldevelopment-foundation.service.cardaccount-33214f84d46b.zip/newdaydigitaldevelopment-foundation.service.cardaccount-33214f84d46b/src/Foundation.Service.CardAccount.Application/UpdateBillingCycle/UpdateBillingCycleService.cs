﻿using System;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.UpdateBillingCycle;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.UpdateBillingCycle
{
    public class UpdateBillingCycleService : IExecutable<UpdateBillingCycleRequest, DataManagerResponse<UpdateBillingCycleResponse>>
    {
        private readonly IUpdateBillingCycleConverter _converter;
        private readonly IAccountMaintenanceApiClient _accountMaintenanceApiClient;

        public UpdateBillingCycleService(IUpdateBillingCycleConverter converter, IAccountMaintenanceApiClient accountMaintenanceApiClient)
        {
            _converter = converter;
            _accountMaintenanceApiClient = accountMaintenanceApiClient;
        }

        public async Task<DataManagerResponse<UpdateBillingCycleResponse>> ExecuteAsync(UpdateBillingCycleRequest request)
        {
            var billingCycleUpdateRequest = _converter.ToBillingCycleUpdateRequest(request);
            var billingCycleUpdateResponse = await _accountMaintenanceApiClient.BillingCycleUpdateAsync(billingCycleUpdateRequest);

            var domainResponse = _converter.ToUpdateBillingCycleResponse(billingCycleUpdateResponse);
            return new DataManagerResponse<UpdateBillingCycleResponse>(domainResponse, DateTime.UtcNow, TimeSpan.Zero);
        }
    }
}