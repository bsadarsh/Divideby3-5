﻿using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.UpdateBillingCycle;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.UpdateBillingCycle
{
    public interface IUpdateBillingCycleConverter
    {
        BillingCycleUpdateRequest ToBillingCycleUpdateRequest(UpdateBillingCycleRequest request);

        UpdateBillingCycleResponse ToUpdateBillingCycleResponse(BillingCycleUpdateResponse response);
    }
}