﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.ReAgeByCode;
using NewDay.Digital.Foundation.Core.Utils;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.ReAgeByCode
{
    public class ReAgeByCodeService : IExecutable<ReAgeByCodeRequest, DataManagerResponse<ReAgeByCodeResponse>>
    {
        private readonly IReAgeByCodeConverter _converter;
        private readonly IAccountManagementApiClient _accountManagementApiClient;
        private readonly IAccountMaintenanceApiClient _accountMaintenanceApiClient;
        private readonly IList<string> _bucketFieldNames = new List<string>()
        {
            "CurrDue", "PastDue", "DaysDue030", "DaysDue060", "DaysDue090", "DaysDue120", "DaysDue150", "DaysDue180",
            "DaysDue210"
        };

        public ReAgeByCodeService(IReAgeByCodeConverter converter, IAccountManagementApiClient accountManagementApiClient, IAccountMaintenanceApiClient accountMaintenanceApiClient)
        {
            _converter = converter;
            _accountManagementApiClient = accountManagementApiClient;
            _accountMaintenanceApiClient = accountMaintenanceApiClient;
        }

        public async Task<DataManagerResponse<ReAgeByCodeResponse>> ExecuteAsync(ReAgeByCodeRequest request)
        {
            var delinquencyAdjustmentInquiry = await GetDelinquencyAdjustmentsInquiry(request);

            if (!IsDelinquencyCodeValid(delinquencyAdjustmentInquiry, request.Code))
            {
                throw new InvalidReAgeRequestValuesException("Delinquency code cannot be same or greater than the current code");
            }

            var calculationResponse =
                await CalculateAccountValuesAfterReAge(request, delinquencyAdjustmentInquiry);

            if (!ReAgeCommonMethods.IsAccountValidForReAge(calculationResponse))
            {
                throw new AccountRecalculationException("Adjust amount in due buckets");
            }

            var submitReAge = await SubmitReAge(request, calculationResponse);

            if (!ReAgeCommonMethods.IsAccountValidForReAge(submitReAge))
            {
                throw new AccountRecalculationException("Adjust amount in due buckets");
            }

            return new DataManagerResponse<ReAgeByCodeResponse>(new ReAgeByCodeResponse(), DateTime.UtcNow, TimeSpan.Zero);
        }

        private async Task<DelinquencyAdjustmentsInquiryResponse3> GetDelinquencyAdjustmentsInquiry(ReAgeByCodeRequest request)
        {
            var fdRequest = _converter.ToDelinquencyAdjustmentsInquiry(request);
            return await _accountManagementApiClient.DelinquencyAdjustmentsInquiryAsync(fdRequest);
        }

        private async Task<DelinquencyAdjustmentUpdateResponse> CalculateAccountValuesAfterReAge(
            ReAgeByCodeRequest request, DelinquencyAdjustmentsInquiryResponse3 delinquencyAdjustmentsInquiryResponse)
        {
            var calculationRequest =
                _converter.ToDelinquencyAdjustmentCalculationRequest(request, delinquencyAdjustmentsInquiryResponse);
            return await _accountMaintenanceApiClient.DelinquencyAdjustmentUpdateAsync(calculationRequest);
        }

        private async Task<DelinquencyAdjustmentUpdateResponse> SubmitReAge(ReAgeByCodeRequest request,
            DelinquencyAdjustmentUpdateResponse calculationResponse)
        {
            var submitRequest = _converter.ToDelinquencyAdjustmentSubmitRequest(request, calculationResponse);
            return await _accountMaintenanceApiClient.DelinquencyAdjustmentUpdateAsync(submitRequest);
        }

        private bool IsDelinquencyCodeValid(DelinquencyAdjustmentsInquiryResponse3 fdResponse, int delinquencyCode)
        {
            var bucketCount = _bucketFieldNames.Select(bucketFieldName => (string) typeof(DelinquencyAdjustmentsInquiryResponse3).GetProperty(bucketFieldName).GetValue(fdResponse)).Count(bucketValue => !IsBucketEmpty(bucketValue));

            return delinquencyCode < bucketCount;
        }

        private static bool IsBucketEmpty(string value) => value.IsNullOrEmpty() || int.Parse(value) == 0;
    }
}
