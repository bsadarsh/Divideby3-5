﻿using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.ReAgeByCode;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.ReAgeByCode
{
    public class ReAgeByCodeConverter : IReAgeByCodeConverter
    {
        private readonly IBrandHelper _brandHelper;
        private const string CalculationActionCode = "C";
        private const string SubmitActionCode = "S";

        public ReAgeByCodeConverter(IBrandHelper brandHelper)
        {
            _brandHelper = brandHelper;
        }

        public DelinquencyAdjustmentsInquiryRequest3 ToDelinquencyAdjustmentsInquiry(ReAgeByCodeRequest request)
        {
            var brand = GetBrand(request.CardAccountId);

            return new DelinquencyAdjustmentsInquiryRequest3(brand.ClientNumber)
            {
                AcctNbr = GeneralPurposeMethods.CardAccountIdWithLeadingZeros(request.CardAccountId)
            };
        }

        public DelinquencyAdjustmentUpdateRequest ToDelinquencyAdjustmentCalculationRequest(ReAgeByCodeRequest request,
            DelinquencyAdjustmentsInquiryResponse3 delinquencyAdjustmentsInquiryResponse)
        {
            var brand = GetBrand(request.CardAccountId);

            return new DelinquencyAdjustmentUpdateRequest(brand.ClientNumber)
            {
                CardNbr = GeneralPurposeMethods.CardAccountIdWithLeadingZeros(request.CardAccountId),
                PaymentPsData = delinquencyAdjustmentsInquiryResponse.PlanData.MapPlanDataToPaymentPSData(),
                Action = CalculationActionCode,
                NbrItems = delinquencyAdjustmentsInquiryResponse.NbrReturnedItems,
                CurrDue = delinquencyAdjustmentsInquiryResponse.CurrDue,
                PastDue = delinquencyAdjustmentsInquiryResponse.PastDue,
                DaysDue030 = delinquencyAdjustmentsInquiryResponse.DaysDue030,
                DaysDue060 = delinquencyAdjustmentsInquiryResponse.DaysDue060,
                DaysDue090 = delinquencyAdjustmentsInquiryResponse.DaysDue090,
                DaysDue120 = delinquencyAdjustmentsInquiryResponse.DaysDue120,
                DaysDue150 = delinquencyAdjustmentsInquiryResponse.DaysDue150,
                DaysDue180 = delinquencyAdjustmentsInquiryResponse.DaysDue180,
                DaysDue210 = delinquencyAdjustmentsInquiryResponse.DaysDue210,
                ReageCd = request.Code.ToString()
            };
        }

        public DelinquencyAdjustmentUpdateRequest ToDelinquencyAdjustmentSubmitRequest(ReAgeByCodeRequest request,
            DelinquencyAdjustmentUpdateResponse calculationResponse)
        {
            var brand = GetBrand(request.CardAccountId);

            return new DelinquencyAdjustmentUpdateRequest(brand.ClientNumber)
            {
                CardNbr = GeneralPurposeMethods.CardAccountIdWithLeadingZeros(request.CardAccountId),
                PaymentPsData = calculationResponse.PlanData.MapPlanDataToPaymentPSData(),
                Action = SubmitActionCode,
                NbrItems = calculationResponse.NbrReturnedItems,
                CurrDue = calculationResponse.CurrDue,
                PastDue = calculationResponse.PastDue,
                DaysDue030 = calculationResponse.DaysDue30,
                DaysDue060 = calculationResponse.DaysDue60,
                DaysDue090 = calculationResponse.DaysDue90,
                DaysDue120 = calculationResponse.DaysDue120,
                DaysDue150 = calculationResponse.DaysDue150,
                DaysDue180 = calculationResponse.DaysDue180,
                DaysDue210 = calculationResponse.DaysDue210,
                ReageCd = request.Code.ToString()
            };
        }

        private Brand GetBrand(string cardAccountId)
        {
            return _brandHelper.GetBrandFromAccountNumber(cardAccountId)
                   ?? throw new InvalidBrandException();
        }
    }
}
