﻿using System;
using System.Collections.Generic;
using System.Text;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.ReAgeByCode;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.ReAgeByCode
{
    public interface IReAgeByCodeConverter
    {
        DelinquencyAdjustmentsInquiryRequest3 ToDelinquencyAdjustmentsInquiry(ReAgeByCodeRequest request);

        DelinquencyAdjustmentUpdateRequest ToDelinquencyAdjustmentCalculationRequest(ReAgeByCodeRequest request,
            DelinquencyAdjustmentsInquiryResponse3 delinquencyAdjustmentsInquiryResponse);

        DelinquencyAdjustmentUpdateRequest ToDelinquencyAdjustmentSubmitRequest(ReAgeByCodeRequest request,
            DelinquencyAdjustmentUpdateResponse calculationResponse);
    }
}
