﻿using NewDay.Digital.Foundation.Core.Caching.Generators;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetPlans;
using NewDay.Digital.Foundation.Service.CardAccount.Application.GetPlans;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Cache
{
    public class AccountPlanInquiryCacheKeyProvider : IAccountPlanInquiryCacheKeyProvider
    {
        private readonly IGetPlansConverter _getPlansConverter;

        public AccountPlanInquiryCacheKeyProvider(IGetPlansConverter getPlansConverter)
        {
            _getPlansConverter = getPlansConverter;
        }

        public string GetKey(string cardAccountId)
        {
            cardAccountId = cardAccountId.TrimStart('0');
            var accountPlanInquiry = _getPlansConverter.ToAccountPlanInquiry(new GetPlansRequest
            {
                CardAccountId = cardAccountId
            });
            return CacheKeyGenerator.Generate(accountPlanInquiry, cardAccountId);
        }
    }
}
