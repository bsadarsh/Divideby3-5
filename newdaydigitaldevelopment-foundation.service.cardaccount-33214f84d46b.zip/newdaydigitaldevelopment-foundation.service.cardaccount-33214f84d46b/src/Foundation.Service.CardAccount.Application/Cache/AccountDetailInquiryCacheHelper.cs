﻿using NewDay.Digital.Foundation.Core.Caching.Generators;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;
using NewDay.Digital.Foundation.Service.CardAccount.Application.GetCardAccountV1;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Cache
{
    public class AccountDetailInquiryCacheKeyProvider : IAccountDetailInquiryCacheKeyProvider
    {
        private readonly IGetCardAccountConverter _cardAccountConverter;

        public AccountDetailInquiryCacheKeyProvider(IGetCardAccountConverter cardAccountConverter)
        {
            _cardAccountConverter = cardAccountConverter;
        }

        public string GetKey(string cardAccountId)
        {
            cardAccountId = cardAccountId.TrimStart('0');
            var accountDetailInquiry = _cardAccountConverter.ToAccountDetailInquiryRequest(new GetCardAccountRequest
            {
                CardAccountId = cardAccountId
            });

            return CacheKeyGenerator.Generate(accountDetailInquiry, cardAccountId);
        }
    }
}
