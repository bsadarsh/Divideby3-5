﻿namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Cache
{
    public interface IAccountDetailInquiryCacheKeyProvider
    {
        public string GetKey(string cardAccountId);
    }
}
