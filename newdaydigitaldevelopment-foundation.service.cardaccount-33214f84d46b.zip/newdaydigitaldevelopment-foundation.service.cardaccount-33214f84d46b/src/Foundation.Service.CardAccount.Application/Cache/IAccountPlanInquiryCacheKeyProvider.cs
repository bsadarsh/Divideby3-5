﻿namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Cache
{
    public interface IAccountPlanInquiryCacheKeyProvider
    {
        public string GetKey(string cardAccountId);
    }
}
