﻿using System;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.Customer.v1;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Core.Caching.Generators;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetAccountHolder
{
    public class GetAccountHolderService : IExecutable<GetAccountHolderByCardAccountIdRequest, DataManagerResponse<GetAccountHolderResponse>>
    {
        private readonly TimeSpan _accountHolderCacheTime;
        private readonly IGetAccountHolderConverter _converter;
        private readonly ICustomerApiClient _customerApiClient;
        private readonly IDataManager _dataManager;       

        public GetAccountHolderService(ITimeoutProvider timeoutProvider, IGetAccountHolderConverter converter, ICustomerApiClient customerApiClient, IDataManager dataManager)
        {
            _accountHolderCacheTime = timeoutProvider.Timeout;
            _converter = converter;
            _customerApiClient = customerApiClient;
            _dataManager = dataManager;            
        }

        public async Task<DataManagerResponse<GetAccountHolderResponse>> ExecuteAsync(GetAccountHolderByCardAccountIdRequest request)
        {
            var cacheKey = CacheKeyGenerator.Generate(request, request.CardAccountId);

            var fdRequest = _converter.ToCustomerDemographicInquiryRequest(request);
            var dataManagerResponse = await _dataManager.FetchWithCacheAsync(cacheKey, _accountHolderCacheTime, async () => await _customerApiClient.CustomerDemographicInquiryAsync(fdRequest));
            var response = _converter.ToGetAccountHolderResponse(dataManagerResponse.Value);

            return new DataManagerResponse<GetAccountHolderResponse>(response, dataManagerResponse.CacheAge, dataManagerResponse.CacheLifetime);
        }
    }
}