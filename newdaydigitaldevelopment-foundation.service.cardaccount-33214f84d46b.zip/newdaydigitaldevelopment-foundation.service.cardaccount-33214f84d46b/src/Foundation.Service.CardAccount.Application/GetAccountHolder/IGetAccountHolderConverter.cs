﻿using NewDay.Digital.Foundation.Connector.FirstData.Customer.v1.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetAccountHolder
{
    public interface IGetAccountHolderConverter
    {
        CustomerDemographicInquiryRequest ToCustomerDemographicInquiryRequest(GetAccountHolderByCardAccountIdRequest request);
        GetAccountHolderResponse ToGetAccountHolderResponse(CustomerDemographicInquiryResponse response);
    }
}
