﻿using System;
using System.Collections.Generic;
using System.Linq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Customer.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Extensions;
using NewDay.Digital.Foundation.Core.Domain.CardAccount;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetAccountHolder
{
    public class GetAccountHolderConverter : IGetAccountHolderConverter
    {
        private readonly IBrandHelper _brandHelper;

        public GetAccountHolderConverter(IBrandHelper brandHelper)
        {
            _brandHelper = brandHelper;
        }

        public CustomerDemographicInquiryRequest ToCustomerDemographicInquiryRequest(GetAccountHolderByCardAccountIdRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId);
            if (brand == null)
            {
                throw new InvalidBrandException();
            }
            return new CustomerDemographicInquiryRequest(brand.ClientNumber)
            {
                CustAcctCardNbr = request.CardAccountId
            };
        }

        public GetAccountHolderResponse ToGetAccountHolderResponse(CustomerDemographicInquiryResponse response)
        {
            var customerData = response?.OwnerCoownerData?.FirstOrDefault();

            if (customerData == null)
            {
                return null;
            }

            return new GetAccountHolderResponse
            {
                AccountHolder = new AccountHolder
                {
                    AccountHolderId = response.CustNbr,
                    FirstName = customerData.FirstName,
                    LastName = customerData.LastName,
                    Title = customerData.Title
                },
                PersonalDetails = new PersonalDetails
                {
                    Email = customerData.Email,
                    Phone = customerData.HomePhone,
                    Mobile = customerData.MobilePhone,
                    DateOfBirth = customerData.Dob.DateTimeFromFDDateString() ?? throw new FormatException(),
                    Addresses = new List<Address>
                    {
                        new Address
                        {
                            HouseName = customerData.HouseName,
                            HouseNumber = customerData.HouseNumber,
                            AddressLine1 = customerData.Addr1,
                            AddressLine4 = customerData.Address4,
                            PostCode = customerData.PstlCd,
                            City = customerData.City,
                            County = customerData.County
                        }
                    }
                }
            };
        }
    }
}
