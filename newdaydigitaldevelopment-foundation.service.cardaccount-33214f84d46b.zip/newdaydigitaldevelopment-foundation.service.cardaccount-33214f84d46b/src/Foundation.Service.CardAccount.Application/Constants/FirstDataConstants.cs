﻿using System;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Constants
{
    internal static class FirstDataConstants
    {
        /// <summary>
        /// The amount to set FD's SpndLmtAmt field when disabling a spending cap.
        /// </summary>
        public const Int32 SpendCapDisabledAmount = 0;

        /// <summary>
        /// The string value that FirstData uses to represent that a spendcap is disabled.
        /// <see cref="AccountCustomFieldsUpdateRequest.SpndLmtAlert"/> for the list of possible values.
        /// </summary>
        public const string SpendCapDisabledAlert = "0";

        /// <summary>
        /// The string value to set cancel status eg. for cancelInsurance insStatusCode
        /// </summary>
        public const string CancelCode = "C";
    }

}