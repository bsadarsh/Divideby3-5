﻿using System;
using System.Collections.Generic;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Extensions
{
    public static class StringExtensions
    {
        public static IEnumerable<string> SplitByLength(this string value, int desiredLength)
        {
            if (value == null) return null;

            var currentPosition = 0;
            var result = new List<string>();

            while (currentPosition < value.Length)
            {
                result.Add(value.Length - currentPosition < desiredLength
                    ? value.Substring(currentPosition, value.Length - currentPosition)
                    : value.Substring(currentPosition, desiredLength));

                currentPosition += desiredLength;
            }

            return result;
        }

        /// <summary>
        /// Converts from the string literal "1" to true and "0" to false.
        /// </summary>
        /// <exception cref="ArgumentNullException"/>
        /// <exception cref="InvalidOperationException">Unable to convert <seealso cref="input"/> to boolean value.</exception>
        public static bool ToBoolFromBinaryString(this string input)
        {
            switch (input)
            {
                case null:
                    throw new ArgumentNullException(nameof(input));
                case "1":
                    return true;
                case "0":
                    return false;
                default:
                    throw new InvalidOperationException($"Unable to convert {input} to boolean value.");
            }
        }

        public static decimal ToDecimalFromFDAmount(this string input)
        {
            return decimal.Parse(input) * 0.01m;
        }
    }
}
