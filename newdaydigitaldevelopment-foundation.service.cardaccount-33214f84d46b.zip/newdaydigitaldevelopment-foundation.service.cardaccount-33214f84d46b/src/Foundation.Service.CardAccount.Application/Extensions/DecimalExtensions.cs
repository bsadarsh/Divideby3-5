﻿using System;
using System.Globalization;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Extensions
{
    public static class DecimalExtensions
    {
        /// <summary>
        /// Converts a decimal value of pounds and pence to the number of pennies, as a string.
        ///
        /// 50.50 would be converted into "5050"
        /// </summary>
        public static string ToFDAmountString(this decimal poundsAndPence)
        {
            var pennies = poundsAndPence * 100m;
            var result = decimal.Floor(pennies).ToString(CultureInfo.InvariantCulture);
            return result;
        }
    }
}