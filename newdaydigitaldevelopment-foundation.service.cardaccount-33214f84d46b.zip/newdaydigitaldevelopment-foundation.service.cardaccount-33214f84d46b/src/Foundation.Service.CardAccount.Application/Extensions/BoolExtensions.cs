﻿namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Extensions
{
    public static class BoolExtensions
    {
        public static string ToBinaryString(this bool input)
        {
            return input ? "1" : "0";
        }

        public static string ToYesNoBinaryString(this bool input)
        {
            return input ? "Y" : "N";
        }
    }
}