using Microsoft.Extensions.DependencyInjection;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Caching.Redis.Extensions;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetCardsByAccount;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetSpendCap;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.SetSpendCap;
using NewDay.Digital.Foundation.Service.CardAccount.Application.CreateMemo;
using NewDay.Digital.Foundation.Service.CardAccount.Application.GetAccountByCard;
using NewDay.Digital.Foundation.Service.CardAccount.Application.GetAccountHolder;
using NewDay.Digital.Foundation.Service.CardAccount.Application.GetCardsByAccount;
using NewDay.Digital.Foundation.Service.CardAccount.Application.GetMemos;
using NewDay.Digital.Foundation.Service.CardAccount.Application.GetSpendCap;
using NewDay.Digital.Foundation.Service.CardAccount.Application.SetSpendCap;
using System;
using NewDay.Digital.Foundation.Connector.FirstData.AccountActivityUpdates.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.AccountAdd.v1.Extensions;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Extensions;
using NewDay.Digital.Foundation.Connector.FirstData.Customer.v1.Extensions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;
using NewDay.Digital.Foundation.Connector.FirstData.Insurance.v3.Extensions;
using NewDay.Digital.Foundation.Connector.FirstData.Letters.v2.Extensions;
using NewDay.Digital.Foundation.Connector.FirstData.Loans.v2;
using NewDay.Digital.Foundation.Connector.FirstData.Transactions.v1;
using NewDay.Digital.Foundation.Connector.FirstData.Transactions.v1.Extensions;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.CancelInsurance;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.ChargeOff;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.CreateInstallmentPlan;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.CreatePlan;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetInsuranceProducts;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetPlans;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.InstallmentQuote;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.PostGoodwill;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.ReAgeByAmount;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.ReAgeByCode;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.RemoveFee;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.RemovePaymentHoliday;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.RequestLetter;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.ReturnFunds;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.SetPaymentHoliday;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.UpdateAccount;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.UpdateBillingCycle;
using NewDay.Digital.Foundation.Service.CardAccount.Application.ChargeOff;
using NewDay.Digital.Foundation.Service.CardAccount.Application.CreateInstallmentPlan;
using NewDay.Digital.Foundation.Service.CardAccount.Application.CreatePlan;
using NewDay.Digital.Foundation.Service.CardAccount.Application.GetCardAccountV1;
using NewDay.Digital.Foundation.Service.CardAccount.Application.GetInsuranceProducts;
using NewDay.Digital.Foundation.Service.CardAccount.Application.GetPlans;
using NewDay.Digital.Foundation.Service.CardAccount.Application.InstallmentQuote;
using NewDay.Digital.Foundation.Service.CardAccount.Application.PlanTransfer;
using NewDay.Digital.Foundation.Service.CardAccount.Application.PostGoodwill;
using NewDay.Digital.Foundation.Service.CardAccount.Application.ReAgeByAmount;
using NewDay.Digital.Foundation.Service.CardAccount.Application.ReAgeByCode;
using NewDay.Digital.Foundation.Service.CardAccount.Application.RemoveFee;
using NewDay.Digital.Foundation.Service.CardAccount.Application.RemovePaymentHoliday;
using NewDay.Digital.Foundation.Service.CardAccount.Application.RequestLetter;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Resources;
using NewDay.Digital.Foundation.Service.CardAccount.Application.ReturnFunds;
using NewDay.Digital.Foundation.Service.CardAccount.Application.SetPaymentHoliday;
using NewDay.Digital.Foundation.Service.CardAccount.Application.UpdateAccount;
using NewDay.Digital.Foundation.Service.CardAccount.Application.UpdateBillingCycle;
using NewDay.Digital.Foundation.Service.CardAccount.Application.UpdateAccountBlockStatus;
using NewDay.Digital.Foundation.Service.CardAccount.Application.CancelInsurance;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Cache;
using PlanTransferRequest = NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.PlanTransfer.PlanTransferRequest;
using PlanTransferResponse = NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.PlanTransfer.PlanTransferResponse;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static void AddApplication(this IServiceCollection services,
            string redisConnectionMultiplexerConfiguration,
            TimeSpan cardAccountCacheTime)
        {
            Connector.FirstData.AccountManagement.v1.Extensions.ServiceCollectionExtensions.AddNewDayFirstDataAccountManagementConnector(services);
            Connector.FirstData.AccountManagement.v2.Extensions.ServiceCollectionExtensions.AddNewDayFirstDataAccountManagementConnector(services);
            Connector.FirstData.AccountManagement.v3.Extensions.ServiceCollectionExtensions.AddNewDayFirstDataAccountManagementConnector(services);
            services.AddNewDayFirstDataTransactionsConnector();
            services.AddNewDayFirstDataLettersConnector();
            services.AddNewDayFirstDataInsuranceConnector();
            Connector.FirstData.Insurance.v1.Extensions.ServiceCollectionExtensions.AddNewDayFirstDataInsuranceConnector(services);
            Connector.FirstData.Loans.v1.Extensions.ServiceCollectionExtensions.AddNewDayFirstDataLoansConnector(services);
            Connector.FirstData.Loans.v2.Extensions.ServiceCollectionExtensions.AddNewDayFirstDataLoansConnector(services);

            Connector.FirstData.AccountActivityUpdates.v1.Extensions.ServiceCollectionExtensions.AddNewDayFirstDataAccountActivityUpdatesConnector(services);
            Connector.FirstData.AccountActivityUpdates.v2.Extensions.ServiceCollectionExtensions.AddNewDayFirstDataAccountActivityUpdatesConnector(services);
            services.AddNewDayFirstDataAccountAddConnector();
            services.AddNewDayFirstDataCustomerConnector();

            Connector.FirstData.CardManagement.v1.Extensions.ServiceCollectionExtensions.AddNewDayFirstDataCardManagementConnector(services);
            Connector.FirstData.CardManagement.v2.Extensions.ServiceCollectionExtensions.AddNewDayFirstDataCardManagementConnector(services);

            services.AddNewDayFirstDataAccountMaintenanceConnector();
            Connector.FirstData.AccountMaintenance.v2.Extensions.ServiceCollectionExtensions.AddNewDayFirstDataAccountMaintenanceConnector(services);
            services.AddConnectionMultiplexer(redisConnectionMultiplexerConfiguration);
            services.AddNewDayRedisCacheManager();

            services.AddSingleton<IDataManager, DataManager>();
            services.AddSingleton<ITimeoutProvider>(new TimeoutProvider(cardAccountCacheTime));

            services.AddTransient<ICreateMemoConverter, CreateMemoConverter>();
            services.AddTransient<IGetAccountHolderConverter, GetAccountHolderConverter>();
            services.AddTransient<IGetCardAccountConverter, GetCardAccountConverter>();
            services.AddTransient<IGetCardsByAccountConverter, GetCardsByAccountConverter>();
            services.AddTransient<IGetMemosConverter, GetMemosConverter>();
            services.AddTransient<IGetAccountByCardConverter, GetAccountByCardConverter>();
            services.AddTransient<IGetSpendCapConverter, GetSpendCapConverter>();
            services.AddTransient<ISetSpendCapConverter, SetSpendCapConverter>();
            services.AddTransient<IUpdateBillingCycleConverter, UpdateBillingCycleConverter>();
            services.AddTransient<IUpdateAccountConverter, UpdateAccountConverter>();
            services.AddTransient<IUpdateAccountBlockStatusConverter, UpdateAccountBlockStatusConverter>();
            services.AddTransient<IRemoveFeeConverter, RemoveFeeConverter>();
            services.AddTransient<IReturnFundsConverter, ReturnFundsConverter>();
            services.AddTransient<IRequestLetterConverter, RequestLetterConverter>();
            services.AddTransient<ICreatePlanConverter, CreatePlanConverter>();
            services.AddTransient<IGetPlansConverter, GetPlansConverter>();
            services.AddTransient<IGetInsuranceProductsConverter, GetInsuranceProductsConverter>();
            services.AddTransient<ISetPaymentHolidayConverter, SetPaymentHolidayConverter>();
            services.AddTransient<IRemovePaymentHolidayConverter, RemovePaymentHolidayConverter>();
            services.AddTransient<IPostGoodwillConverter, PostGoodwillConverter>();
            services.AddTransient<IChargeOffConverter, ChargeOffConverter>();
            services.AddTransient<ICancelInsuranceConverter, CancelInsuranceConverter>();
            services.AddTransient<IReAgeByCodeConverter, ReAgeByCodeConverter>();
            services.AddTransient<IReAgeByAmountConverter, ReAgeByAmountConverter>();
            services.AddTransient<IInstallmentQuoteConverter, InstallmentQuoteConverter>();
            services.AddTransient<ICreateInstallmentPlanConverter, CreateInstallmentPlanConverter>();
            services.AddTransient<IPlanTransferConverter, PlanTransferConverter>();
            services.AddTransient<GetCardAccountV2.IGetCardAccountConverter, GetCardAccountV2.GetCardAccountConverter>();

            services.AddSingleton<IAccountDetailInquiryCacheKeyProvider, AccountDetailInquiryCacheKeyProvider>();
            services.AddSingleton<IAccountPlanInquiryCacheKeyProvider, AccountPlanInquiryCacheKeyProvider>();
            
            services.AddSingleton<ILoansV2Resource>(x => new LoansV2Resource(
                x.GetRequiredService<ILoansApiClient>(),
                x.GetRequiredService<IDataManager>(),
                cardAccountCacheTime));
            services.AddSingleton<ITransactionsV1Resource>(x => new TransactionsV1Resource(
                x.GetRequiredService<ITransactionsApiClient>(),
                x.GetRequiredService<IDataManager>(),
                cardAccountCacheTime));

            services.AddTransient<IExecutable<CreateCardAccountMemoRequest, DataManagerResponse<MemoAddResponse>>, CreateMemoService>();
            services.AddTransient<IExecutable<GetAccountHolderByCardAccountIdRequest, DataManagerResponse<GetAccountHolderResponse>>, GetAccountHolderService>();
            services.AddTransient<IExecutable<GetCardAccountRequest, DataManagerResponse<GetCardAccountResponse>>, GetCardAccountService>();
            services.AddTransient<IExecutable<GetCardsByAccountRequest, DataManagerResponse<GetCardsByAccountResponse>>, GetCardsByAccountService>();
            services.AddTransient<IExecutable<GetCardAccountMemosRequest, DataManagerResponse<GetCardAccountMemosResponse>>, GetMemosService>();
            services.AddTransient<IExecutable<GetAccountByCardRequest, DataManagerResponse<GetAccountByCardResponse>>,GetAccountByCardService >();
            services.AddTransient<IExecutable<GetSpendCapRequest, DataManagerResponse<GetSpendCapResponse>>, GetSpendCapService>();
            services.AddTransient<IExecutable<SetSpendCapRequest, DataManagerResponse<SetSpendCapResponse>>, SetSpendCapService>();
            services.AddTransient<IExecutable<UpdateBillingCycleRequest, DataManagerResponse<UpdateBillingCycleResponse>>, UpdateBillingCycleService>();
            services.AddTransient<IExecutable<UpdateAccountBlockStatusRequest, DataManagerResponse<UpdateAccountBlockStatusResponse>>, UpdateAccountBlockStatusService>();
            services.AddTransient<IExecutable<RemoveFeeRequest, DataManagerResponse<RemoveFeeResponse>>, RemoveFeeService>();
            services.AddTransient<IExecutable<ReturnFundsRequest, DataManagerResponse<ReturnFundsResponse>>, ReturnFundsService>();
            services.AddTransient<IExecutable<RequestLetterRequest, DataManagerResponse<RequestLetterResponse>>, RequestLetterService>();
            services.AddTransient<IExecutable<CreatePlanRequest, DataManagerResponse<CreatePlanResponse>>, CreatePlanService>();
            services.AddTransient<IExecutable<GetPlansRequest, DataManagerResponse<GetPlansResponse>>, GetPlansService>();
            services.AddTransient<IExecutable<UpdateAccountRequest, DataManagerResponse<UpdateAccountResponse>>, UpdateAccountService>();
            services.AddTransient<IExecutable<GetInsuranceProductsRequest, DataManagerResponse<GetInsuranceProductsResponse>>, GetInsuranceProductsService>();
            services.AddTransient<IExecutable<SetPaymentHolidayRequest, DataManagerResponse<SetPaymentHolidayResponse>>, SetPaymentHolidayService>();
            services.AddTransient<IExecutable<RemovePaymentHolidayRequest, DataManagerResponse<RemovePaymentHolidayResponse>>, RemovePaymentHolidayService>();
            services.AddTransient<IExecutable<PostGoodwillRequest, DataManagerResponse<PostGoodwillResponse>>, PostGoodwillService>();
            services.AddTransient<IExecutable<ChargeOffRequest, DataManagerResponse<ChargeOffResponse>>, ChargeOffService>();
            services.AddTransient<IExecutable<CancelInsuranceRequest, DataManagerResponse<CancelInsuranceResponse>>, CancelInsuranceService>();
            services.AddTransient<IExecutable<ReAgeByCodeRequest, DataManagerResponse<ReAgeByCodeResponse>>, ReAgeByCodeService>();
            services.AddTransient<IExecutable<ReAgeByAmountRequest, DataManagerResponse<ReAgeByAmountResponse>>, ReAgeByAmountService>();
            services.AddTransient<IExecutable<InstallmentQuoteRequest, DataManagerResponse<InstallmentQuoteResponse>>, InstallmentQuoteService>();
            services.AddTransient<IExecutable<CreateInstallmentPlanRequest, DataManagerResponse<CreateInstallmentPlanResponse>>, CreateInstallmentPlanService>();
            services.AddTransient<IExecutable<PlanTransferRequest, DataManagerResponse<PlanTransferResponse>>, PlanTransferService>();
            services.AddTransient<IExecutable<Core.Domain.CardAccount.Contracts.v2.GetCardAccount.GetCardAccountRequest,
                DataManagerResponse<Core.Domain.CardAccount.Contracts.v2.GetCardAccount.GetCardAccountResponse>>, GetCardAccountV2.GetCardAccountService>();
        }
    }
}
