﻿using NewDay.Digital.Foundation.Connector.FirstData.Letters.v2.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.RequestLetter;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.RequestLetter
{
    public interface IRequestLetterConverter
    {
        LetterRequestRequest2 ToLetterRequestRequest(RequestLetterRequest request);

        RequestLetterResponse ToLetterRequestResponse(LetterRequestResponse2 response);
    }
}