﻿using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Letters.v2.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.RequestLetter;
using NewDay.Digital.Foundation.Core.Utils;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.RequestLetter
{
    public class RequestLetterConverter : IRequestLetterConverter
    {
        private readonly IBrandHelper _brandHelper;

        private static readonly RequestLetterResponse RequestLetterResponseInstance = new RequestLetterResponse();

        public RequestLetterConverter(IBrandHelper brandHelper) => _brandHelper = brandHelper.ArgNotNull(nameof(brandHelper));

        public LetterRequestRequest2 ToLetterRequestRequest(RequestLetterRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId)
                        ?? throw new InvalidBrandException();
            var org = request.CardAccountId.TrimStart('0').Substring(0, 3);

            return new LetterRequestRequest2(brand.ClientNumber)
            {
                LetterCode = request.LetterCode,
                LetterOrg = org,
                KiCmsSelect = "X",
                KiCmsAcct = request.CardAccountId,
                KiCmsOrg = org
            };
        }

        public RequestLetterResponse ToLetterRequestResponse(LetterRequestResponse2 response)
        {
            return RequestLetterResponseInstance;
        }
    }
}