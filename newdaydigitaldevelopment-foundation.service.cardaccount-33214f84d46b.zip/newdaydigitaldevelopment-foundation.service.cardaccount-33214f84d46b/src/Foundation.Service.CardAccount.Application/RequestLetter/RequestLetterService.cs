﻿using System;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.Letters.v2;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.RequestLetter;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.RequestLetter
{
    public class RequestLetterService : IExecutable<RequestLetterRequest, DataManagerResponse<RequestLetterResponse>>
    {
        private readonly IRequestLetterConverter _requestLetterConverter;
        private readonly ILettersApiClient _lettersApiClient;

        public RequestLetterService(
            IRequestLetterConverter requestLetterConverter,
            ILettersApiClient lettersApiClient)
        {
            _requestLetterConverter = requestLetterConverter;
            _lettersApiClient = lettersApiClient;
        }

        public async Task<DataManagerResponse<RequestLetterResponse>> ExecuteAsync(RequestLetterRequest request)
        {
            var fdRequest = _requestLetterConverter.ToLetterRequestRequest(request);

            var fdResponse = await _lettersApiClient.LetterRequestAsync(fdRequest);
            var domainResponse = _requestLetterConverter.ToLetterRequestResponse(fdResponse);

            return new DataManagerResponse<RequestLetterResponse>(domainResponse, DateTime.UtcNow, TimeSpan.Zero);
        }
    }
}