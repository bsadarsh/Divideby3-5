﻿using System;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Extensions;
using NewDay.Digital.Foundation.Connector.FirstData.Transactions.v1.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.CreatePlan;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Extensions;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.CreatePlan
{
    public class CreatePlanConverter : ICreatePlanConverter
    {
        private readonly IBrandHelper _brandHelper;

        private const string CreatePlanActionCode = "1MPU";
        private const string ReversePaymentActionCode = "2MPU";
        private const decimal TxnAmount = 0.01m;
        private const string StoreNumber = "999999998";
        private const string ForeignUse = "0";

        public CreatePlanConverter(IBrandHelper brandHelper)
        {
            _brandHelper = brandHelper;
        }

        public MonetaryActionRequest CreatePlanMonetaryActionRequest(CreatePlanRequest request)
        {
            return CreateMonetaryActionRequest(request, CreatePlanActionCode);
        }

        public MonetaryActionRequest ReversePaymentMonetaryActionRequest(CreatePlanRequest request)
        {
            return CreateMonetaryActionRequest(request, ReversePaymentActionCode);
        }

        private MonetaryActionRequest CreateMonetaryActionRequest(CreatePlanRequest request, string actionCode)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId);
            if (brand == null)
            {
                throw new InvalidBrandException();
            }

            return new MonetaryActionRequest(brand.ClientNumber)
            {
                AcctNbr = request.CardAccountId,
                ActionCode = actionCode,
                TxnAmount = TxnAmount.ToFDAmountString(),
                PlanNbr = request.RetailPlan,
                StoreNbr = StoreNumber,
                EffDate = DateTime.UtcNow.ToFDDateString(),
                ForeignUse = ForeignUse
            };
        }
    }
}
