﻿using NewDay.Digital.Foundation.Connector.FirstData.Transactions.v1.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.CreatePlan;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.CreatePlan
{
    public interface ICreatePlanConverter
    {
        MonetaryActionRequest CreatePlanMonetaryActionRequest(CreatePlanRequest request);
        MonetaryActionRequest ReversePaymentMonetaryActionRequest(CreatePlanRequest request);
    }
}
