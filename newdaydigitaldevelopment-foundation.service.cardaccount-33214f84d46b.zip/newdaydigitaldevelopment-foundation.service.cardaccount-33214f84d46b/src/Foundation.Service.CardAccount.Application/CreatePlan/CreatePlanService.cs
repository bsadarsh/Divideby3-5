﻿using System;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.Transactions.v1;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.CreatePlan;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.CreatePlan
{
    public class CreatePlanService : IExecutable<CreatePlanRequest, DataManagerResponse<CreatePlanResponse>>
    {
        private readonly ITransactionsApiClient _transactionsApiClient;
        private readonly ICreatePlanConverter _createPlanConverter;

        public CreatePlanService(ITransactionsApiClient transactionsApiClient, ICreatePlanConverter createPlanConverter)
        {
            _transactionsApiClient = transactionsApiClient;
            _createPlanConverter = createPlanConverter;
        }

        public async Task<DataManagerResponse<CreatePlanResponse>> ExecuteAsync(CreatePlanRequest request)
        {
            var createPlanFdRequest = _createPlanConverter.CreatePlanMonetaryActionRequest(request);
            await _transactionsApiClient.MonetaryActionAsync(createPlanFdRequest);

            var reversePaymentFdRequest = _createPlanConverter.ReversePaymentMonetaryActionRequest(request);
            await _transactionsApiClient.MonetaryActionAsync(reversePaymentFdRequest);

            return new DataManagerResponse<CreatePlanResponse>(new CreatePlanResponse(), DateTime.UtcNow, TimeSpan.Zero);
        }
    }
}
