﻿using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Loans.v2.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.PlanTransfer;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;
using FirstDataPlanTransferRequest = NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models.PlanTransferRequest;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.PlanTransfer
{
    public class PlanTransferConverter : IPlanTransferConverter
    {
        public const string TransferTypeCode = "T";
        private readonly IBrandHelper _brandHelper;

        public PlanTransferConverter(IBrandHelper brandHelper)
        {
            _brandHelper = brandHelper;
        }
        
        public FirstDataPlanTransferRequest ToFirstDataPlanTransferRequest(PlanTransferRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId)
                        ?? throw new InvalidBrandException();

            return new FirstDataPlanTransferRequest(brand.ClientNumber)
            {
                Account = GeneralPurposeMethods.CardAccountIdWithLeadingZeros(request.CardAccountId),
                TransferFunction = TransferTypeCode,
                PlanNbr = request.FromPlan,
                RecNbr = request.FromRecordNumber,
                ToPlanNbr = request.ToPlan,
                ToRecNbr = request.ToRecordNumber
            };
        }

        public AccountPlanListRequest2 ToAccountPlanListRequest2(FirstDataPlanTransferRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.Account)
                        ?? throw new InvalidBrandException();
            return new AccountPlanListRequest2(brand.ClientNumber) {Acct = request.Account};
        }
    }
}
