﻿using NewDay.Digital.Foundation.Connector.FirstData.Loans.v2.Models;
using FirstDataPlanTransferRequest = NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models.PlanTransferRequest;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.PlanTransfer;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.PlanTransfer
{
    public interface IPlanTransferConverter
    {
        FirstDataPlanTransferRequest ToFirstDataPlanTransferRequest(PlanTransferRequest request);

        AccountPlanListRequest2 ToAccountPlanListRequest2(FirstDataPlanTransferRequest request);
    }
}