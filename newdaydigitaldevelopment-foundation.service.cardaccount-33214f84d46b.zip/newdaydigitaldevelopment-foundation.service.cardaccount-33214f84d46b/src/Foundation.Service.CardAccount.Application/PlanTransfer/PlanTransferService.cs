﻿using System;
using System.Linq;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.PlanTransfer;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1;
using NewDay.Digital.Foundation.Connector.FirstData.Loans.v2;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Cache;
using FirstDataPlanTransferRequest = NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models.PlanTransferRequest;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.PlanTransfer
{
    public class PlanTransferService : IExecutable<PlanTransferRequest, DataManagerResponse<PlanTransferResponse>>
    {
        private readonly IPlanTransferConverter _planTransferConverter;
        private readonly IAccountMaintenanceApiClient _accountMaintenanceApiClientV1;
        private readonly ILoansApiClient _loansApiClientV2;
        private readonly IDataManager _dataManager;
        private readonly IAccountPlanInquiryCacheKeyProvider _cacheKeyProvider;

        public PlanTransferService(IPlanTransferConverter planTransferConverter,
            IAccountMaintenanceApiClient accountMaintenanceApiClientV1,
            ILoansApiClient loansApiClientV2, 
            IDataManager dataManager,
            IAccountPlanInquiryCacheKeyProvider cacheKeyProvider)
        {
            _planTransferConverter = planTransferConverter;
            _accountMaintenanceApiClientV1 = accountMaintenanceApiClientV1;
            _loansApiClientV2 = loansApiClientV2;
            _dataManager = dataManager;
            _cacheKeyProvider = cacheKeyProvider;
        }

        public async Task<DataManagerResponse<PlanTransferResponse>> ExecuteAsync(PlanTransferRequest request)
        {
            var firstDataRequest = _planTransferConverter.ToFirstDataPlanTransferRequest(request);

            if (firstDataRequest.RecNbr == null || firstDataRequest.ToRecNbr == null)
            {
                 firstDataRequest = await PopulateRecNbrs(firstDataRequest);
            }

            await _accountMaintenanceApiClientV1.PlanTransferAsync(firstDataRequest);

            await ClearCache(request);

            return new DataManagerResponse<PlanTransferResponse>(new PlanTransferResponse(), DateTime.UtcNow, TimeSpan.Zero);
        }

        private async Task<FirstDataPlanTransferRequest> PopulateRecNbrs(FirstDataPlanTransferRequest request)
        {
            var orchestrationRequest = _planTransferConverter.ToAccountPlanListRequest2(request);
            var response = await _loansApiClientV2.AccountPlanListAsync(orchestrationRequest);
            string fromPlan = null;
            string toPlan = null;
            if (response?.PlanCtdData != null)
            {
                fromPlan = response.PlanCtdData.FirstOrDefault(plan => plan.PlanNbr == request.PlanNbr)?.PlanRecNbr;
                toPlan = response.PlanCtdData.FirstOrDefault(plan => plan.PlanNbr == request.ToPlanNbr)?.PlanRecNbr;
            }

            if (fromPlan == null  || toPlan == null)
            {
                throw new NoPlanFoundException("No plan found to transfer balance");
            }

            request.RecNbr = fromPlan;
            request.ToRecNbr = toPlan;

            return request;
        }

        private async Task ClearCache(PlanTransferRequest request)
        {
            var cacheKey = _cacheKeyProvider.GetKey(request.CardAccountId);

            await _dataManager.RemoveAsync(cacheKey);
        }
    }
}