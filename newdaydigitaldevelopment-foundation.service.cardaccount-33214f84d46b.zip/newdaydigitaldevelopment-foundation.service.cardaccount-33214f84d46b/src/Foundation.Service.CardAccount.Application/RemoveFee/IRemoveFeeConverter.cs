﻿using NewDay.Digital.Foundation.Connector.FirstData.Loans.v2.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Transactions.v1.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.RemoveFee;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.RemoveFee
{
    public interface IRemoveFeeConverter
    {
        MonetaryActionRequest ToMonetaryActionRequest(RemoveFeeRequest request);
        AccountPlanListRequest2 ToAccountPlanListRequest2(RemoveFeeRequest request);
    }
}