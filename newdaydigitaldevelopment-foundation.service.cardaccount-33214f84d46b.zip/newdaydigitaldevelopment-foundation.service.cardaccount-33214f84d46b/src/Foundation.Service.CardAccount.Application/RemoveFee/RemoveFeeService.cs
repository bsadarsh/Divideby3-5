﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NewDay.Digital.Foundation.Connector.FirstData.Exceptions;
using NewDay.Digital.Foundation.Connector.FirstData.Loans.v2.Models;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.RemoveFee;
using NewDay.Digital.Foundation.Core.Utils;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Resources;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.RemoveFee
{
    public class RemoveFeeService : IExecutable<RemoveFeeRequest, DataManagerResponse<RemoveFeeResponse>>
    {
        private const string PlanNumberNotFoundErrorCode = "FS000006";
        private const string PlanNumberNotFoundOdsMessage = "Backend request failed VPE8SE CREDIT PLAN RECORD NOT FOUND OR IN ADD PENDING STATUS";
        private const string PlanNumberNotFoundExceptionMessage = "PlanNumber {planNumber} was not found";
        private const string DefaultRetailPlanNbrNotAvailableExceptionMessage = "Default Retail Plan number not available";
        private const string PlanNbrNotValidExceptionMessage = "Plan number is not valid";

        private readonly ITransactionsV1Resource _transactionsV1Resource;
        private readonly ILoansV2Resource _loansV2Resource;
        private readonly IRemoveFeeConverter _converter;
        private readonly ILogger<RemoveFeeService> _logger;

        private static readonly DataManagerResponse<RemoveFeeResponse> Response =
            new DataManagerResponse<RemoveFeeResponse>(new RemoveFeeResponse(), default, TimeSpan.Zero);

        public RemoveFeeService(
            ITransactionsV1Resource transactionsV1Resource,
            ILoansV2Resource loansV2Resource,
            IRemoveFeeConverter converter,
            ILogger<RemoveFeeService> logger)
        {
            _loansV2Resource = loansV2Resource;
            _transactionsV1Resource = transactionsV1Resource;
            _converter = converter.ArgNotNull(nameof(converter));
            _logger = logger.ArgNotNull(nameof(logger));
        }

        public async Task<DataManagerResponse<RemoveFeeResponse>> ExecuteAsync(RemoveFeeRequest request)
        {
            try
            {
                if (request.PlanSeqNumber.IsNullOrEmpty() || request.PlanNumber.IsNullOrEmpty())
                {
                    var accountPlanListRequest = _converter.ToAccountPlanListRequest2(request);
                    var dataManagerResponse = await _loansV2Resource.AccountPlanListAsyncAsync(accountPlanListRequest);
                    var fdResponse = dataManagerResponse.Value;

                    if (request.PlanNumber.IsNullOrEmpty())
                    {
                        var planCtdData = GetDefaultRetailPlanParameters(fdResponse);

                        request.PlanSeqNumber = planCtdData.PlanRecNbr;
                        request.PlanNumber = planCtdData.PlanNbr;
                    }
                    else
                    {
                        request.PlanSeqNumber = GetPlanRecNumber(fdResponse, request.PlanNumber);
                    }
                }

                var fiServRequest = _converter.ToMonetaryActionRequest(request);

                await _transactionsV1Resource.MonetaryActionAsync(fiServRequest);

                return Response;
            }
            catch (FirstDataApiException e)
                when (e.ResponseStatus.ErrorCode == PlanNumberNotFoundErrorCode &&
                      e.ResponseStatus.OdsMessages.Contains(PlanNumberNotFoundOdsMessage))
            {
                _logger.LogError(PlanNumberNotFoundExceptionMessage, request.PlanNumber);
                throw new PlanNumberNotFoundException();
            }
        }

        private PlanCtdData2ForAccountPlanList2 GetDefaultRetailPlanParameters(AccountPlanListResponse2 response)
        {
            var planCtdData = response.PlanCtdData
                .FirstOrDefault(x => x.PlanType == "R");

            if (planCtdData == null)
            {
                _logger.LogError(DefaultRetailPlanNbrNotAvailableExceptionMessage);
                throw new RetailPlanNotFoundException(DefaultRetailPlanNbrNotAvailableExceptionMessage);
            }
            return planCtdData;
        }

        private string GetPlanRecNumber(AccountPlanListResponse2 response, string planNumber)
        {
            var planCtdData = response.PlanCtdData
                .FirstOrDefault(x => x.PlanNbr == planNumber && !x.PlanRecNbr.IsNullOrEmpty());

            if (planCtdData == null)
            {
                _logger.LogError(PlanNumberNotFoundExceptionMessage);
                throw new PlanNumberNotFoundException(PlanNbrNotValidExceptionMessage);
            }

            return planCtdData.PlanRecNbr;
        }
    }
}