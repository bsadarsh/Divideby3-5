﻿using System;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Loans.v2.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Transactions.v1.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.RemoveFee;
using NewDay.Digital.Foundation.Core.Utils;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
// ReSharper disable PossibleInvalidOperationException

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.RemoveFee
{
    public class RemoveFeeConverter : IRemoveFeeConverter
    {
        private readonly IBrandHelper _brandHelper;

        private const string StoreNumber = "999999998";
        private const string DateTimeFormat = "yyyyMMdd";
        private const string ForeignUseCode = "0";

        public RemoveFeeConverter(IBrandHelper brandHelper) => _brandHelper = brandHelper.ArgNotNull(nameof(brandHelper));

        public MonetaryActionRequest ToMonetaryActionRequest(RemoveFeeRequest request)
        {
            request.ArgNotNull(nameof(request));

            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId);

            return new MonetaryActionRequest(brand.ClientNumber)
            {
                Account = request.CardAccountId,
                AcctNbr = request.CardAccountId,
                ActionCode = ConvertToActionCode(request.FeeType.Value, brand.IsOwnBrand),
                TxnAmount = Math.Floor(request.Amount.Value * 100).ToString(),
                StoreNbr = StoreNumber,
                EffDate = request.Date?.ToString(DateTimeFormat) ?? DateTimeOffset.Now.ToString(DateTimeFormat),
                PlanNbr = request.PlanNumber,
                PlanSeq = request.PlanSeqNumber,
                ForeignUse = ForeignUseCode
            };
        }

        public AccountPlanListRequest2 ToAccountPlanListRequest2(RemoveFeeRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId)
                               ?? throw new InvalidBrandException();

            return new AccountPlanListRequest2(brand.ClientNumber)
            {
                Acct = request.CardAccountId
            };
        }

        private static string ConvertToActionCode(FeeType feeType, bool isOwnBrands) => feeType switch
        {
            FeeType.LateFee => "2LAF",
            FeeType.OverLimit => "2OLF",
            FeeType.Interest => "2IRA",
            FeeType.DDReturn => isOwnBrands ? "2NSF" : "2DDR",
            _ => throw new ArgumentOutOfRangeException(nameof(feeType))
        };
    }
}