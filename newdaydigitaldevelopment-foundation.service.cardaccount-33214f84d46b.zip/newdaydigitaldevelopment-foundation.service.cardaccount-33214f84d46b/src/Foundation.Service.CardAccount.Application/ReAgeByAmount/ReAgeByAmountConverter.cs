﻿using System.Collections.Generic;
using System.Globalization;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.ReAgeByAmount;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Extensions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.ReAgeByAmount
{
    public class ReAgeByAmountConverter : IReAgeByAmountConverter
    {
        private readonly IBrandHelper _brandHelper;
        private const string CalculationActionCode = "C";
        private const string SubmitActionCode = "S";
        private const string DelinquencyCodeForBuckets = "x";

        public ReAgeByAmountConverter(IBrandHelper brandHelper)
        {
            _brandHelper = brandHelper;
        }

        public DelinquencyAdjustmentsInquiryRequest3 ToDelinquencyAdjustmentsInquiry(ReAgeByAmountRequest request)
        {
            var brand = GetBrand(request.CardAccountId);

            return new DelinquencyAdjustmentsInquiryRequest3(brand.ClientNumber)
            {
                AcctNbr = GeneralPurposeMethods.CardAccountIdWithLeadingZeros(request.CardAccountId)
            };
        }

        public DelinquencyAdjustmentUpdateRequest ToDelinquencyAdjustmentCalculationRequest(ReAgeByAmountRequest request,
            DelinquencyAdjustmentsInquiryResponse3 delinquencyAdjustmentsInquiryResponse)
        {
            var brand = GetBrand(request.CardAccountId);

            return new DelinquencyAdjustmentUpdateRequest(brand.ClientNumber)
            {
                CardNbr = GeneralPurposeMethods.CardAccountIdWithLeadingZeros(request.CardAccountId),
                PaymentPsData = delinquencyAdjustmentsInquiryResponse.PlanData.MapPlanDataToPaymentPSData(),
                Action = CalculationActionCode,
                NbrItems = delinquencyAdjustmentsInquiryResponse.NbrReturnedItems,
                CurrDue = ConvertElementToFDAmount(request.DueBuckets, 0),
                PastDue = ConvertElementToFDAmount(request.DueBuckets, 1),
                DaysDue030 = ConvertElementToFDAmount(request.DueBuckets, 2),
                DaysDue060 = ConvertElementToFDAmount(request.DueBuckets, 3),
                DaysDue090 = ConvertElementToFDAmount(request.DueBuckets, 4),
                DaysDue120 = ConvertElementToFDAmount(request.DueBuckets, 5),
                DaysDue150 = ConvertElementToFDAmount(request.DueBuckets, 6),
                DaysDue180 = ConvertElementToFDAmount(request.DueBuckets, 7),
                DaysDue210 = ConvertElementToFDAmount(request.DueBuckets, 8),
                ReageCd = DelinquencyCodeForBuckets
            };
        }

        public DelinquencyAdjustmentUpdateRequest ToDelinquencyAdjustmentSubmitRequest(ReAgeByAmountRequest request,
            DelinquencyAdjustmentUpdateResponse calculationResponse)
        {
            var brand = GetBrand(request.CardAccountId);

            return new DelinquencyAdjustmentUpdateRequest(brand.ClientNumber)
            {
                CardNbr = GeneralPurposeMethods.CardAccountIdWithLeadingZeros(request.CardAccountId),
                PaymentPsData = calculationResponse.PlanData.MapPlanDataToPaymentPSData(),
                Action = SubmitActionCode,
                NbrItems = calculationResponse.NbrReturnedItems,
                CurrDue = ConvertElementToFDAmount(request.DueBuckets, 0),
                PastDue = ConvertElementToFDAmount(request.DueBuckets, 1),
                DaysDue030 = ConvertElementToFDAmount(request.DueBuckets, 2),
                DaysDue060 = ConvertElementToFDAmount(request.DueBuckets, 3),
                DaysDue090 = ConvertElementToFDAmount(request.DueBuckets, 4),
                DaysDue120 = ConvertElementToFDAmount(request.DueBuckets, 5),
                DaysDue150 = ConvertElementToFDAmount(request.DueBuckets, 6),
                DaysDue180 = ConvertElementToFDAmount(request.DueBuckets, 7),
                DaysDue210 = ConvertElementToFDAmount(request.DueBuckets, 8),
                ReageCd = DelinquencyCodeForBuckets
            };
        }

        private static string ConvertElementToFDAmount(IList<decimal> list, int index) 
            => index >= list.Count ? "0" : list[index].ToFDAmountString();

        private Brand GetBrand(string cardAccountId) => _brandHelper.GetBrandFromAccountNumber(cardAccountId)
                                                        ?? throw new InvalidBrandException();
    }
}
