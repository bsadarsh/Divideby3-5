﻿using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.ReAgeByAmount;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.ReAgeByAmount
{
    public interface IReAgeByAmountConverter
    {
        DelinquencyAdjustmentsInquiryRequest3 ToDelinquencyAdjustmentsInquiry(ReAgeByAmountRequest request);

        DelinquencyAdjustmentUpdateRequest ToDelinquencyAdjustmentCalculationRequest(ReAgeByAmountRequest request,
            DelinquencyAdjustmentsInquiryResponse3 delinquencyAdjustmentsInquiryResponse);

        DelinquencyAdjustmentUpdateRequest ToDelinquencyAdjustmentSubmitRequest(ReAgeByAmountRequest request,
            DelinquencyAdjustmentUpdateResponse calculationResponse);
    }
}
