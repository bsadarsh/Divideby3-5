﻿using System;
using System.Linq;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.ReAgeByAmount;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Extensions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.ReAgeByAmount
{
    public class ReAgeByAmountService : IExecutable<ReAgeByAmountRequest, DataManagerResponse<ReAgeByAmountResponse>>
    {
        private readonly IReAgeByAmountConverter _converter;
        private readonly IAccountManagementApiClient _accountManagementApiClient;
        private readonly IAccountMaintenanceApiClient _accountMaintenanceApiClient;

        public ReAgeByAmountService(IReAgeByAmountConverter converter, IAccountManagementApiClient accountManagementApiClient, IAccountMaintenanceApiClient accountMaintenanceApiClient)
        {
            _converter = converter;
            _accountManagementApiClient = accountManagementApiClient;
            _accountMaintenanceApiClient = accountMaintenanceApiClient;
        }

        public async Task<DataManagerResponse<ReAgeByAmountResponse>> ExecuteAsync(ReAgeByAmountRequest request)
        {
            var delinquencyAdjustmentInquiry = await GetDelinquencyAdjustmentsInquiry(request);

            if (!IsBucketAmountValid(delinquencyAdjustmentInquiry, request))
            {
                throw new InvalidReAgeRequestValuesException("Adjusted due amount cannot be greater than current balance");
            }

            var calculationResponse =
                await CalculateAccountValuesAfterReAge(request, delinquencyAdjustmentInquiry);

            if (!ReAgeCommonMethods.IsAccountValidForReAge(calculationResponse))
            {
                throw new AccountRecalculationException("Adjust amount in due buckets");
            }

            var submitReAge = await SubmitReAge(request, calculationResponse);

            if (!ReAgeCommonMethods.IsAccountValidForReAge(submitReAge))
            {
                throw new AccountRecalculationException("Adjust amount in due buckets");
            }

            return new DataManagerResponse<ReAgeByAmountResponse>(new ReAgeByAmountResponse(), DateTime.UtcNow, TimeSpan.Zero);
        }

        private async Task<DelinquencyAdjustmentsInquiryResponse3> GetDelinquencyAdjustmentsInquiry(ReAgeByAmountRequest request)
        {
            var fdRequest = _converter.ToDelinquencyAdjustmentsInquiry(request);
            return await _accountManagementApiClient.DelinquencyAdjustmentsInquiryAsync(fdRequest);
        }

        private async Task<DelinquencyAdjustmentUpdateResponse> CalculateAccountValuesAfterReAge(
            ReAgeByAmountRequest request, DelinquencyAdjustmentsInquiryResponse3 delinquencyAdjustmentsInquiryResponse)
        {
            var calculationRequest =
                _converter.ToDelinquencyAdjustmentCalculationRequest(request, delinquencyAdjustmentsInquiryResponse);
            return await _accountMaintenanceApiClient.DelinquencyAdjustmentUpdateAsync(calculationRequest);
        }

        private async Task<DelinquencyAdjustmentUpdateResponse> SubmitReAge(ReAgeByAmountRequest request,
            DelinquencyAdjustmentUpdateResponse calculationResponse)
        {
            var submitRequest = _converter.ToDelinquencyAdjustmentSubmitRequest(request, calculationResponse);
            return await _accountMaintenanceApiClient.DelinquencyAdjustmentUpdateAsync(submitRequest);
        }

        private bool IsBucketAmountValid(DelinquencyAdjustmentsInquiryResponse3 fdResponse, ReAgeByAmountRequest request)
        {
            var bucketSum = request.DueBuckets.Sum();

            return bucketSum <= fdResponse.CurrentBalance.ToDecimalFromFDAmount();
        }
    }
}
