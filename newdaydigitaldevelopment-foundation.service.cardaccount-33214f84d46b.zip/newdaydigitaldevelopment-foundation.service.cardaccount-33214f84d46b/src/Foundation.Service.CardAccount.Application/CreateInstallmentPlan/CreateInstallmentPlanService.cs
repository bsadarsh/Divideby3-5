﻿using System.Linq;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.CreateInstallmentPlan;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.Loans.v2.Models;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Extensions;
using System;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Cache;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.CreateInstallmentPlan
{
    public class CreateInstallmentPlanService : IExecutable<CreateInstallmentPlanRequest, DataManagerResponse<CreateInstallmentPlanResponse>>
    {

        private readonly ICreateInstallmentPlanConverter _createInstallmentPlanConverter;
        private readonly Connector.FirstData.Loans.v1.ILoansApiClient _loansApiClientV1;
        private readonly Connector.FirstData.Loans.v2.ILoansApiClient _loansApiClientV2;
        private readonly IDataManager _dataManager;
        private readonly IAccountPlanInquiryCacheKeyProvider _accountPlanInquiryCacheKeyProvider;

        public CreateInstallmentPlanService(ICreateInstallmentPlanConverter createInstallmentPlanConverter,
            Connector.FirstData.Loans.v1.ILoansApiClient loansApiClientV1,
            Connector.FirstData.Loans.v2.ILoansApiClient loansApiClientV2, 
            IDataManager dataManager,
            IAccountPlanInquiryCacheKeyProvider accountPlanInquiryCacheKeyProvider)
        {
            _createInstallmentPlanConverter = createInstallmentPlanConverter;
            _loansApiClientV1 = loansApiClientV1;
            _loansApiClientV2 = loansApiClientV2;
            _dataManager = dataManager;
            _accountPlanInquiryCacheKeyProvider = accountPlanInquiryCacheKeyProvider;
        }

        public async Task<DataManagerResponse<CreateInstallmentPlanResponse>> ExecuteAsync(CreateInstallmentPlanRequest request)
        {
            var accountPlanListRequest = _createInstallmentPlanConverter.ToAccountPlanListRequest2(request);

            var accountPlanListResponse = await _loansApiClientV2.AccountPlanListAsync(accountPlanListRequest);

            var (matchingSourcePlan, matchingInstallmentPlan) = GetMatchingPlans(accountPlanListResponse, request.SourcePlan, request.InstallmentPlan);

            if (request.Amount != null)
            {
                if (IsRequestAmountHigerThanEligibleBalance((decimal)request.Amount, matchingSourcePlan.FppEligBal))
                {
                    throw new EligibleBalanceExceededException("Quote amount exceeds eligible plan balance");
                }
            }
            else
            {
                request.Amount = matchingSourcePlan.FppEligBal.ToDecimalFromFDAmount();
            }

            var fppAddRequest = _createInstallmentPlanConverter.ToFppAddRequest(request, matchingSourcePlan, matchingInstallmentPlan);

            var fdResponse = await _loansApiClientV1.FppAddAsync(fppAddRequest);
            var domainResponse = _createInstallmentPlanConverter.ToCreateInstallmentPlanResponse(fdResponse);

            await ClearCache(request);

            return new DataManagerResponse<CreateInstallmentPlanResponse>(domainResponse, DateTime.UtcNow, TimeSpan.Zero);
        }

        private bool IsRequestAmountHigerThanEligibleBalance(decimal requestedAmount, string eligibleBalance)
        {
            return requestedAmount > eligibleBalance.ToDecimalFromFDAmount();
        }

        private (PlanCtdData2ForAccountPlanList2, PlanCtdData2ForAccountPlanList2) GetMatchingPlans(AccountPlanListResponse2 accountPlanListResponse, string sourcePlanNumber, string installmentPlanNumber)
        {
            var matchingSourcePlan = accountPlanListResponse.PlanCtdData.FirstOrDefault(p => p.PlanNbr == sourcePlanNumber);
            if (matchingSourcePlan == null)
            {
                throw new InstallmentPlanMatchException("Matching source plan not found");
            }

            var matchingInstallmentPlan = accountPlanListResponse.PlanCtdData.FirstOrDefault(p => p.PlanNbr == installmentPlanNumber);
            if (matchingInstallmentPlan == null)
            {
                throw new InstallmentPlanMatchException("Matching installment plan not found");
            }

            return (matchingSourcePlan, matchingInstallmentPlan);
        }

        private async Task ClearCache(CreateInstallmentPlanRequest request)
        {
            var cacheKey = _accountPlanInquiryCacheKeyProvider.GetKey(request.CardAccountId);

            await _dataManager.RemoveAsync(cacheKey);
        }
    }
}