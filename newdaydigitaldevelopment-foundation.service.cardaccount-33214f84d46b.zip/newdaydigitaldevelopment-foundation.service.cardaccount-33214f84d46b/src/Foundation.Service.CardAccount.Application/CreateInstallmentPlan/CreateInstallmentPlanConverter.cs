﻿using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Loans.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Loans.v2.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.CreateInstallmentPlan;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Extensions;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.CreateInstallmentPlan
{
    public class CreateInstallmentPlanConverter : ICreateInstallmentPlanConverter
    {
        private readonly IBrandHelper _brandHelper;
        private readonly string PlanAddFunctionCode = "O";

        private static readonly CreateInstallmentPlanResponse CreateInstallmentPlanResponseInstance =
            new CreateInstallmentPlanResponse();

        public CreateInstallmentPlanConverter(IBrandHelper brandHelper)
        {
            _brandHelper = brandHelper;
        }

        public FppAddRequest ToFppAddRequest(CreateInstallmentPlanRequest request, PlanCtdData2ForAccountPlanList2 matchingSourcePlan, PlanCtdData2ForAccountPlanList2 matchingInstallmentPlan)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId)
                        ?? throw new InvalidBrandException();

            return new FppAddRequest(brand.ClientNumber)
            {
                Acct = request.CardAccountId,
                Plan = request.InstallmentPlan,
                AgrdPmtAmt = matchingInstallmentPlan.FppAgrdPmtAmt,
                FppBal = request.Amount == null ? matchingSourcePlan.FppEligBal : request.Amount?.ToFDAmountString(),
                Term = matchingInstallmentPlan.FppOrigTerm,
                PlanGroup = new[]
                {
                    new PlanGroupForFppAdd1()
                    {
                        AzfxPlan = request.SourcePlan,
                        AzfxPlanBal = matchingSourcePlan.FppEligBal,
                        AzfxPlanRec = matchingSourcePlan.PlanRecNbr
                    }
                },
                Function = PlanAddFunctionCode
            };
        }

        public AccountPlanListRequest2 ToAccountPlanListRequest2(CreateInstallmentPlanRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId)
                        ?? throw new InvalidBrandException();

            return new AccountPlanListRequest2(brand.ClientNumber)
            {
                Acct = request.CardAccountId
            };
        }

        public CreateInstallmentPlanResponse ToCreateInstallmentPlanResponse(FppAddResponse response)
        {
            return CreateInstallmentPlanResponseInstance;
        }
    }
}