﻿using NewDay.Digital.Foundation.Connector.FirstData.Loans.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Loans.v2.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.CreateInstallmentPlan;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.CreateInstallmentPlan
{
    public interface ICreateInstallmentPlanConverter
    {
        FppAddRequest ToFppAddRequest(CreateInstallmentPlanRequest request, PlanCtdData2ForAccountPlanList2 matchingSourcePlan, PlanCtdData2ForAccountPlanList2 matchingInstallmentPlan);

        AccountPlanListRequest2 ToAccountPlanListRequest2(CreateInstallmentPlanRequest request);

        CreateInstallmentPlanResponse ToCreateInstallmentPlanResponse(FppAddResponse response);
    }
}