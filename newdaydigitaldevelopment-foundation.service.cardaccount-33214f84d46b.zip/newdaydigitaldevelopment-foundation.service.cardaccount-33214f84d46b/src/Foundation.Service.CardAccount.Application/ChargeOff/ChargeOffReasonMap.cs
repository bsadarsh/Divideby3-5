﻿using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.ChargeOff;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.ChargeOff
{
    public static class ChargeOffReasonMap
    {
        public static string ToFDChargeOffReason(ChargeOffReason reason)
        {
            return reason.ToString();
        }
    }
}
