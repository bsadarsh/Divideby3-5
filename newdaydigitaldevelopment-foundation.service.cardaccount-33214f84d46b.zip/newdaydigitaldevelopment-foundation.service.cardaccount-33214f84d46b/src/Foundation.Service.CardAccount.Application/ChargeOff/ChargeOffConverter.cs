﻿using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.ChargeOff;
using NewDay.Digital.Foundation.Core.Utils;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.ChargeOff
{
    public class ChargeOffConverter : IChargeOffConverter
    {
        private readonly string ReasonCodeInitiated = "2";

        private readonly IBrandHelper _brandHelper;

        private static readonly ChargeOffResponse ChargeOffResponseInstance = new ChargeOffResponse();

        public ChargeOffConverter(IBrandHelper brandHelper) => _brandHelper = brandHelper.ArgNotNull(nameof(brandHelper));

        public AccountCloseRequest ToAccountCloseRequest(ChargeOffRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId)
                        ?? throw new InvalidBrandException();

            return new AccountCloseRequest(brand.ClientNumber)
            {
                AcctNbr = request.CardAccountId,
                FunctionCode = ReasonCodeInitiated,
                ChgoffReason = ChargeOffReasonMap.ToFDChargeOffReason(request.Reason)
            };
        }

        public ChargeOffResponse ToChargeOffResponse(AccountCloseResponse response)
        {
            return ChargeOffResponseInstance;
        }
    }
}