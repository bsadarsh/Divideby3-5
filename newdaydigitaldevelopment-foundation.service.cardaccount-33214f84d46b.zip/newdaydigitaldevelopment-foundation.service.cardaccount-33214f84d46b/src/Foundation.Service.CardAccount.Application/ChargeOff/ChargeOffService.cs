﻿using System;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.ChargeOff;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.ChargeOff
{
    public class ChargeOffService : IExecutable<ChargeOffRequest, DataManagerResponse<ChargeOffResponse>>
    {
        private readonly IChargeOffConverter _chargeOffConverter;
        private readonly IAccountMaintenanceApiClient _accountMaintenanceApiClient;

        public ChargeOffService(IChargeOffConverter chargeOffConverter, IAccountMaintenanceApiClient accountMaintenanceApi)
        {
            _chargeOffConverter = chargeOffConverter;
            _accountMaintenanceApiClient = accountMaintenanceApi;
        }

        public async Task<DataManagerResponse<ChargeOffResponse>> ExecuteAsync(ChargeOffRequest request)
        {
            var fdRequest = _chargeOffConverter.ToAccountCloseRequest(request);

            var fdResponse = await _accountMaintenanceApiClient.AccountCloseAsync(fdRequest);

            var domainResponse = _chargeOffConverter.ToChargeOffResponse(fdResponse);

            return new DataManagerResponse<ChargeOffResponse>(domainResponse, DateTime.UtcNow, TimeSpan.Zero);
        }
    }
}