﻿using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.Transactions.v1.Models;
using NewDay.Digital.Foundation.Core.Caching.Models;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Resources
{
    public interface ITransactionsV1Resource
    {
        Task<DataManagerResponse<MonetaryActionResponse>> MonetaryActionAsync(MonetaryActionRequest request);
    }
}
