﻿using System;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.Loans.v2;
using NewDay.Digital.Foundation.Connector.FirstData.Loans.v2.Models;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Core.Caching.Generators;
using NewDay.Digital.Foundation.Core.Caching.Models;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Resources
{
    public class LoansV2Resource : ILoansV2Resource
    {
        private readonly ILoansApiClient _loansApiClient;
        private readonly IDataManager _dataManager;
        private readonly TimeSpan _cacheTime;

        public LoansV2Resource(
            ILoansApiClient loansApiClient,
            IDataManager dataManager,
            TimeSpan cacheTime)
        {
            _loansApiClient = loansApiClient;
            _dataManager = dataManager;
            _cacheTime = cacheTime;
        }

        public async Task<DataManagerResponse<AccountPlanListResponse2>> AccountPlanListAsyncAsync(AccountPlanListRequest2 request)
        {
            var loansCacheKey = CacheKeyGenerator.Generate(request, request.Acct);

            return await _dataManager.FetchWithCacheAsync(loansCacheKey,
                _cacheTime,
                async () => await _loansApiClient.AccountPlanListAsync(request));
        }
    }
}
