﻿using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.Loans.v2.Models;
using NewDay.Digital.Foundation.Core.Caching.Models;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Resources
{
    public interface ILoansV2Resource
    {
        Task<DataManagerResponse<AccountPlanListResponse2>> AccountPlanListAsyncAsync(
            AccountPlanListRequest2 request);
    }
}
