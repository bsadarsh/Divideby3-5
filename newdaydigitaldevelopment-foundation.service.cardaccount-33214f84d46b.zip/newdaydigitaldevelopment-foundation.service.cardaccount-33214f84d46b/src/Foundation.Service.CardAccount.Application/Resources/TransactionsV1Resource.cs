﻿using System;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.Transactions.v1;
using NewDay.Digital.Foundation.Connector.FirstData.Transactions.v1.Models;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Core.Caching.Generators;
using NewDay.Digital.Foundation.Core.Caching.Models;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Resources
{
    public class TransactionsV1Resource : ITransactionsV1Resource
    {
        private readonly ITransactionsApiClient _transactionsApiClient;
        private readonly IDataManager _dataManager;
        private readonly TimeSpan _cacheTime;

        public TransactionsV1Resource(
            ITransactionsApiClient transactionsApiClient,
            IDataManager dataManager,
            TimeSpan cacheTime)
        {
            _transactionsApiClient = transactionsApiClient;
            _dataManager = dataManager;
            _cacheTime = cacheTime;
        }

        public async Task<DataManagerResponse<MonetaryActionResponse>> MonetaryActionAsync(MonetaryActionRequest request)
        {
            var transactionsCacheKey = CacheKeyGenerator.Generate(request, request.Account);

            return await _dataManager.FetchWithCacheAsync(transactionsCacheKey,
                _cacheTime,
                async () => await _transactionsApiClient.MonetaryActionAsync(request));
        }
    }
}
