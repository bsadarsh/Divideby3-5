﻿using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v1.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.SetPaymentHoliday;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.SetPaymentHoliday
{
    public interface ISetPaymentHolidayConverter
    {
        PaymentHolidayRequest ToPaymentHolidayRequest(SetPaymentHolidayRequest request);

        SetPaymentHolidayResponse ToSetPaymentHolidayResponse(PaymentHolidayResponse response);
    }
}