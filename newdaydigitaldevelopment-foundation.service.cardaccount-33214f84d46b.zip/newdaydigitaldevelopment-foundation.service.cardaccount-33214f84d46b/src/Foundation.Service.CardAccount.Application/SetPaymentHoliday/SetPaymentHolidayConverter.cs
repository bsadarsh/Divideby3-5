﻿using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.SetPaymentHoliday;
using NewDay.Digital.Foundation.Core.Utils;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.SetPaymentHoliday
{
    public class SetPaymentHolidayConverter : ISetPaymentHolidayConverter
    {
        private readonly IBrandHelper _brandHelper;

        public SetPaymentHolidayConverter(IBrandHelper brandHelper) => _brandHelper = brandHelper.ArgNotNull(nameof(brandHelper));

        private static readonly SetPaymentHolidayResponse SetPaymentHolidayResponseInstance = new SetPaymentHolidayResponse();

        public PaymentHolidayRequest ToPaymentHolidayRequest(SetPaymentHolidayRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId)
                        ?? throw new InvalidBrandException();
            var org = request.CardAccountId.TrimStart('0').Substring(0, 3);

            return new PaymentHolidayRequest(brand.ClientNumber)
            {
                Account = GeneralPurposeMethods.CardAccountIdWithLeadingZeros(request.CardAccountId),
                HolidayTerm = request.Term,
                PmtHolidayFlag = "1",
                Common =
                {
                    ClientNumber = brand.ClientNumber,
                    Org = org
                }
            };
        }

        public SetPaymentHolidayResponse ToSetPaymentHolidayResponse(PaymentHolidayResponse response)
        {
            return SetPaymentHolidayResponseInstance;
        }
    }
}