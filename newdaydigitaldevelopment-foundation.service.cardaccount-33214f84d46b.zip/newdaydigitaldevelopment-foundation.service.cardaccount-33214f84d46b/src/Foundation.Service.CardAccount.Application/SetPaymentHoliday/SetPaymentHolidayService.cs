﻿using System;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.SetPaymentHoliday;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v1;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.SetPaymentHoliday
{
    public class SetPaymentHolidayService : IExecutable<SetPaymentHolidayRequest, DataManagerResponse<SetPaymentHolidayResponse>>
    {
        private readonly ISetPaymentHolidayConverter _setPaymentHolidayConverter;
        private readonly IAccountManagementApiClient _accountManagementApiClient;

        public SetPaymentHolidayService(ISetPaymentHolidayConverter setPaymentHolidayConverter, IAccountManagementApiClient accountManagementApiClient)
        {
            _setPaymentHolidayConverter = setPaymentHolidayConverter;
            _accountManagementApiClient = accountManagementApiClient;
        }

        public async Task<DataManagerResponse<SetPaymentHolidayResponse>> ExecuteAsync(SetPaymentHolidayRequest request)
        {
            var fdRequest = _setPaymentHolidayConverter.ToPaymentHolidayRequest(request);

            var fdResponse = await _accountManagementApiClient.PaymentHolidayAsync(fdRequest);
            var domainResponse = _setPaymentHolidayConverter.ToSetPaymentHolidayResponse(fdResponse);

            return new DataManagerResponse<SetPaymentHolidayResponse>(domainResponse, DateTime.UtcNow, TimeSpan.Zero);
        }
    }
}