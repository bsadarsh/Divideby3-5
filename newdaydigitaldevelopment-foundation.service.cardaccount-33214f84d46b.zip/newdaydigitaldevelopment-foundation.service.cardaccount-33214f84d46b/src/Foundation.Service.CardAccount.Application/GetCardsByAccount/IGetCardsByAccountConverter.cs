using NewDay.Digital.Foundation.Connector.FirstData.CardManagement.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.CardManagement.v2.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetCardsByAccount;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetCardsByAccount
{
    public interface IGetCardsByAccountConverter
    {
        CardsListByCardRequest2 ToCardsListByAccountRequest(GetCardsByAccountRequest request);
        GetCardsByAccountResponse ToGetCardsByAccountResponse(CardsListByCardResponse2 response);

        CardInquiryRequest ToCardInquiryRequest(GetCardsByAccountRequest request, string cardNumber);

    }
}