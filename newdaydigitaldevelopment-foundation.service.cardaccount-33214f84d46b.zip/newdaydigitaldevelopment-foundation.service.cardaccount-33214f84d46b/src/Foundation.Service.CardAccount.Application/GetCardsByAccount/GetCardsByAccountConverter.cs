using System;
using System.Linq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.CardManagement.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.CardManagement.v2.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetCardsByAccount;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using CardInfo = NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetCardsByAccount.CardInfo;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetCardsByAccount
{
    public class GetCardsByAccountConverter : IGetCardsByAccountConverter
    {
        private const string PrimaryCardHolderType = "1";
        private const string PermanentRecordStatus = "0";
        private const string CardActivationRequiredFlag = "Y";

        private readonly IBrandHelper _brandHelper;

        public GetCardsByAccountConverter(IBrandHelper brandHelper)
        {
            _brandHelper = brandHelper;
        }

        public CardsListByCardRequest2 ToCardsListByAccountRequest(GetCardsByAccountRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId);
            if (brand == null)
            {
                throw new InvalidBrandException();
            }

            return new CardsListByCardRequest2(brand.ClientNumber)
            {
                // this can be either CardNumber or AccountNumber, in our case its Account number
                CardNbr = request.CardAccountId
            };
        }

        public GetCardsByAccountResponse ToGetCardsByAccountResponse(CardsListByCardResponse2 response)
        {
            return new GetCardsByAccountResponse
            {
                Cards = response.OutputData
                    .Where(x => !string.IsNullOrEmpty(x.CardNbr))  // only return populated responses
                    .Select(card => new CardInfo()
                    {
                        CardNumber = card.CardNbr.TrimStart('0'),
                        IsActive = PermanentRecordStatus.Equals(card.Stat, StringComparison.InvariantCultureIgnoreCase),
                        IsBlocked = !string.IsNullOrEmpty(card.BlkCd),
                        IsPendingActivation = CardActivationRequiredFlag.Equals(card.CurrFstUsgFlg, StringComparison.InvariantCultureIgnoreCase),
                        IsPrimary = PrimaryCardHolderType.Equals(card.CardholderType, StringComparison.InvariantCultureIgnoreCase),
                        CustomerEmbossedName = card.EmbossedName1,
                        ExpiryDate = card.DtExp
                    })
            };
        }

        public CardInquiryRequest ToCardInquiryRequest(GetCardsByAccountRequest request, string cardNumber)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId);
            if (brand == null)
            {
                throw new InvalidBrandException();
            }

            return new CardInquiryRequest(brand.ClientNumber)
            {
                Account = cardNumber,
            };
        }
    }
}