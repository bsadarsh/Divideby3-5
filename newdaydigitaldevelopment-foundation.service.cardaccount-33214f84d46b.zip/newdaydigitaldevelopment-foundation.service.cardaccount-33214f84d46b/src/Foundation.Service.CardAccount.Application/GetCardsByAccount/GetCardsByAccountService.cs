﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.CardManagement.v1;
using NewDay.Digital.Foundation.Connector.FirstData.CardManagement.v2;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Core.Caching.Generators;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetCardsByAccount;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetCardsByAccount
{
    public class GetCardsByAccountService : IExecutable<GetCardsByAccountRequest, DataManagerResponse<GetCardsByAccountResponse>>
    {
        private readonly TimeSpan _cardAccountCacheTime;
        private readonly Connector.FirstData.CardManagement.v1.ICardManagementApiClient _cardManagementApiClientV1;
        private readonly Connector.FirstData.CardManagement.v2.ICardManagementApiClient _cardManagementApiClientV2;
        private readonly IGetCardsByAccountConverter _accountConverter;
        private readonly IDataManager _dataManager;

        public GetCardsByAccountService(
            ITimeoutProvider timeoutProvider,
            IGetCardsByAccountConverter accountConverter,
            IDataManager dataManager,
            Connector.FirstData.CardManagement.v1.ICardManagementApiClient cardManagementApiClientV1,
            Connector.FirstData.CardManagement.v2.ICardManagementApiClient cardManagementApiClientV2)
        {
            _cardAccountCacheTime = timeoutProvider.Timeout;
            _cardManagementApiClientV1 = cardManagementApiClientV1;
            _cardManagementApiClientV2 = cardManagementApiClientV2;
            _accountConverter = accountConverter;
            _dataManager = dataManager;
        }

        public async Task<DataManagerResponse<GetCardsByAccountResponse>> ExecuteAsync(GetCardsByAccountRequest request)
        {
            var cacheKey = CacheKeyGenerator.Generate(request, request.CardAccountId);

            var fdRequest = _accountConverter.ToCardsListByAccountRequest(request);
            var dataManagerResponse = await _dataManager.FetchWithCacheAsync(cacheKey, _cardAccountCacheTime, async () => await _cardManagementApiClientV2.CardsListByCardAsync(fdRequest));
            var response = _accountConverter.ToGetCardsByAccountResponse(dataManagerResponse.Value);

            var cards = await UpdateResponseWithFrozenStatus(request, response);

            return new DataManagerResponse<GetCardsByAccountResponse>(new GetCardsByAccountResponse { Cards = cards }, dataManagerResponse.CacheAge, dataManagerResponse.CacheLifetime);
        }

        private async Task<IEnumerable<CardInfo>> UpdateResponseWithFrozenStatus(GetCardsByAccountRequest request, GetCardsByAccountResponse response)
        {
            var cards = new List<CardInfo>();
            foreach (var card in response.Cards)
            {
                if (card.IsActive && !card.IsPendingActivation)
                {
                    var cardInquiryRequest = await _cardManagementApiClientV1.CardInquiryAsync(_accountConverter.ToCardInquiryRequest(request, card.CardNumber));
                    card.IsFrozen = cardInquiryRequest.RestrAll == "1";
                }
                cards.Add(card);
            }
            return cards;
        }
    }
}
