﻿using System.Collections.Generic;
using System.Linq;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.SetSpendCap;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Utils
{
    public class SpendCapMapper
    {
        private static readonly Dictionary<SpendCapType, string> SpendCapTypeDictionary =
            new Dictionary<SpendCapType, string>()
            {
                {SpendCapType.None, "0"},
                {SpendCapType.Soft, "1"},
                {SpendCapType.Hard, "2"}
            };

        private static readonly Dictionary<SpendCapAlertType, string> SpendCapAlertTypeDictionary =
            new Dictionary<SpendCapAlertType, string>()
            {
                {SpendCapAlertType.None, "0"},
                {SpendCapAlertType.Sms, "1"},
                {SpendCapAlertType.Email, "2"},
                {SpendCapAlertType.SmsAndEmail, "3"}
            };

        public static string MapSpendCapTypeToFDValue(SpendCapType type)
        {
            return SpendCapTypeDictionary[type];
        }

        public static SpendCapType MapSpendCapIndToEnum(string spendCapInd)
        {
            return SpendCapTypeDictionary.Single(x => x.Value == spendCapInd).Key;
        }

        public static string MapSpendCapAlertTypeToFDValue(SpendCapAlertType alertType)
        {
            return SpendCapAlertTypeDictionary[alertType];
        }
    }
}
