﻿using System;
using System.Collections.Generic;
using System.Linq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Core.Utils;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Utils
{
    public static class ReAgeCommonMethods
    {
        public static IEnumerable<PaymentPsDataForDelinquencyAdjustmentUpdate1> MapPlanDataToPaymentPSData(this IEnumerable<PlanData3ForDelinquencyAdjustmentsInquiry3> planData)
        {
            return planData.Select(item => new PaymentPsDataForDelinquencyAdjustmentUpdate1
            {
                CurrBal = item.CurrBal,
                PlanNbr = item.PlanNbr,
                RecNbr = item.RecNbr,
                TotDue = item.TotDue
            });
        }

        public static IEnumerable<PaymentPsDataForDelinquencyAdjustmentUpdate1> MapPlanDataToPaymentPSData(
            this IEnumerable<PlanDataForDelinquencyAdjustmentUpdate1> planData)
        {
            return planData.Select(item => new PaymentPsDataForDelinquencyAdjustmentUpdate1
            {
                CurrBal = item.CurrBal,
                PlanNbr = item.PlanNbr,
                RecNbr = item.RecNbr,
                TotDue = item.TotDue
            });
        }

        public static bool IsAccountValidForReAge(DelinquencyAdjustmentUpdateResponse fdResponse) => int.Parse(fdResponse.DiffInDue) == 0;
    }
}
