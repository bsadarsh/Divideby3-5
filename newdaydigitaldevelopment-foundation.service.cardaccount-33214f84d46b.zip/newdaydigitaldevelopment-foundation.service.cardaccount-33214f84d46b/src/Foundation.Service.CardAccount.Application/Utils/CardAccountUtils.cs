﻿using System;
using System.Globalization;
using Microsoft.Extensions.Logging;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Utils
{
    public static class CardAccountUtils
    {
        private static readonly string DateTimeFormat = "yyyyMMdd";
        private static readonly DateTimeKind DateTimeKind = DateTimeKind.Utc;

        /// <summary>
        /// Converts a string to a dateTime with the defined format and kind.
        /// </summary>
        public static DateTime ConvertToDateTime(ILogger logger, string dateTimeString, string fieldName)
        {
            if (string.IsNullOrEmpty(dateTimeString))
            {
                logger.LogError($"{dateTimeString} is not in a valid date format yyyyMMdd for {fieldName}");
                return DateTime.MinValue;
            }

            DateTime dateTime;
            try
            {
                dateTime = DateTime.SpecifyKind(
                    DateTime.ParseExact(dateTimeString, DateTimeFormat, CultureInfo.InvariantCulture), DateTimeKind);
            }
            catch (FormatException)
            {
                logger.LogError($"{dateTimeString} is not in a valid date format yyyyMMdd for {fieldName}");
                dateTime = DateTime.MinValue;
            }

            return dateTime;
        }

        public static string GetProperBlockCode(AccountDetailInquiryResponse3 response)
        {
            var blockCode1IsNullOrWhiteSpace = String.IsNullOrWhiteSpace(response.BlockCode1);
            var blockCode2IsNullOrWhiteSpace = String.IsNullOrWhiteSpace(response.BlockCode2);

            string blockCode;

            if (!blockCode1IsNullOrWhiteSpace && blockCode2IsNullOrWhiteSpace)
            {
                blockCode = response.BlockCode1;
            }
            else if (blockCode1IsNullOrWhiteSpace && !blockCode2IsNullOrWhiteSpace)
            {
                blockCode = response.BlockCode2;
            }
            else
            {
                var blockCode1Priority = Convert.ToInt32(response.BlockCode1Priority);
                var blockCode2Priority = Convert.ToInt32(response.BlockCode2Priority);

                blockCode = blockCode2Priority > blockCode1Priority ? response.BlockCode2 : response.BlockCode1;
            }

            return blockCode;
        }
    }
}
