﻿namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Utils
{
    public static class GeneralPurposeMethods
    {
        /// <summary>
        /// Pads the CardAccountId with 0's to the length of 19 characters.
        /// </summary>
        public static string CardAccountIdWithLeadingZeros(string cardAccountId)
        {
            var result = cardAccountId
                .TrimStart('0')
                .PadLeft(19, '0'); // 19 is max length of account field.

            return result;
        }
    }
}