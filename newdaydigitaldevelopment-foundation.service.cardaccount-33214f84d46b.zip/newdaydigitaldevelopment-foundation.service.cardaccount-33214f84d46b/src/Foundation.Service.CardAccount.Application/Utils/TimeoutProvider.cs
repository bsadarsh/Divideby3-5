﻿using System;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Utils
{
    public class TimeoutProvider : ITimeoutProvider
    {
        public TimeSpan Timeout { get; }

        public TimeoutProvider(TimeSpan duration) => Timeout = duration;
    }

    public interface ITimeoutProvider
    {
        TimeSpan Timeout { get; }
    }
}