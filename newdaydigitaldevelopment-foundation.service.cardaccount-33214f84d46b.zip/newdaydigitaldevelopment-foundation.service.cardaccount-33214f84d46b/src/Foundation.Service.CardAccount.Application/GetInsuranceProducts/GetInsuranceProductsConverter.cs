﻿using System.Linq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Insurance.v3.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetInsuranceProducts;
using NewDay.Digital.Foundation.Core.Utils;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetInsuranceProducts
{
    public class GetInsuranceProductsConverter : IGetInsuranceProductsConverter
    {
        private readonly IBrandHelper _brandHelper;

        public GetInsuranceProductsConverter(IBrandHelper brandHelper) => _brandHelper = brandHelper.ArgNotNull(nameof(brandHelper));

        public InsuranceInquiryRequest3 ToInsuranceInquiryRequest(GetInsuranceProductsRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId) ??
                        throw new InvalidBrandException();

            return new InsuranceInquiryRequest3(brand.ClientNumber)
            {
                Account = request.CardAccountId,
            };
        }

        public GetInsuranceProductsResponse ToGetInsuranceProductsResponse(InsuranceInquiryResponse3 response)
        {
            var insuranceProducts = response.InsData?.Select(MapInsuranceProduct);

            return new GetInsuranceProductsResponse()
            {
                InsuranceProducts = insuranceProducts
            };
        }

        private static InsuranceProduct MapInsuranceProduct(InsData3ForInsuranceInquiry3 product)
        {
            return new InsuranceProduct()
            {
                EffectiveDate = product.EffDt,
                Active = product.InsStatCd == "F",
                ProductName = product.InsPrdDesc,
                BillingFrequency = product.InsBlngFreq,
                PolicyReferenceNumber = product.PlcChnl,
                ProductCode = product.InsTyp,
                CancellationDate = product.InsCanDt,
                Premium = product.InsInsPrem,
                CancellationReason = InsuranceCancellationReasonMap.FirstDataCancellationReasonMap[product.CanRsn]
            };
        }
    }
}