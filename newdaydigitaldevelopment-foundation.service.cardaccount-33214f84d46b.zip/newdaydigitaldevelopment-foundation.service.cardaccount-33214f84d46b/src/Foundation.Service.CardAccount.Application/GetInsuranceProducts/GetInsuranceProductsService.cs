﻿using System;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.Insurance.v3;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Core.Caching.Generators;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetInsuranceProducts;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetInsuranceProducts
{
    public class GetInsuranceProductsService : IExecutable<GetInsuranceProductsRequest, DataManagerResponse<GetInsuranceProductsResponse>>
    {
        private readonly IGetInsuranceProductsConverter _getInsuranceProductsConverter;
        private readonly IInsuranceApiClient _insuranceApiClient;
        private readonly IDataManager _dataManager;
        private readonly TimeSpan _cardAccountCacheTime;

        public GetInsuranceProductsService(
            IGetInsuranceProductsConverter getInsuranceProductsConverter,
            IInsuranceApiClient insuranceApiClient,
            IDataManager dataManager,
            ITimeoutProvider timeoutProvider)
        {
            _getInsuranceProductsConverter = getInsuranceProductsConverter;
            _insuranceApiClient = insuranceApiClient;
            _dataManager = dataManager;
            _cardAccountCacheTime = timeoutProvider.Timeout;
        }

        public async Task<DataManagerResponse<GetInsuranceProductsResponse>> ExecuteAsync(GetInsuranceProductsRequest request)
        {
            var insuranceInquiry = _getInsuranceProductsConverter.ToInsuranceInquiryRequest(request);

            var cacheKey = CacheKeyGenerator.Generate(insuranceInquiry, request.CardAccountId);
            var dataManagerResponse = await _dataManager.FetchWithCacheAsync(cacheKey, _cardAccountCacheTime, () => _insuranceApiClient.InsuranceInquiryAsync(insuranceInquiry));

            var response = _getInsuranceProductsConverter.ToGetInsuranceProductsResponse(dataManagerResponse.Value);

            return new DataManagerResponse<GetInsuranceProductsResponse>(response, dataManagerResponse.CacheAge, dataManagerResponse.CacheLifetime);
        }
    }
}