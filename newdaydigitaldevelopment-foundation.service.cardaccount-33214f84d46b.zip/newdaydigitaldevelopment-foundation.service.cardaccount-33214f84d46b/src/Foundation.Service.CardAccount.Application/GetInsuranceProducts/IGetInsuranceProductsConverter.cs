﻿using NewDay.Digital.Foundation.Connector.FirstData.Insurance.v3.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetInsuranceProducts;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetInsuranceProducts
{
    public interface IGetInsuranceProductsConverter
    {
        InsuranceInquiryRequest3 ToInsuranceInquiryRequest(GetInsuranceProductsRequest request);

        GetInsuranceProductsResponse ToGetInsuranceProductsResponse(InsuranceInquiryResponse3 response);
    }
}