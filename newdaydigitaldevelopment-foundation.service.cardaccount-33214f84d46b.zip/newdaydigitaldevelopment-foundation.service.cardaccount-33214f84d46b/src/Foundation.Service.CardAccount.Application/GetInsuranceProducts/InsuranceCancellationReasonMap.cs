﻿using System.Collections.Generic;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetInsuranceProducts;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetInsuranceProducts
{
    public static class InsuranceCancellationReasonMap
    {
        public static readonly IDictionary<string, CancellationReason> FirstDataCancellationReasonMap = new Dictionary<string, CancellationReason>
        {
            {"A", CancellationReason.ReachedExpirationAge},
            {"B", CancellationReason.BlockCode},
            {"C", CancellationReason.ChargedOff},
            {"D", CancellationReason.PastDue},
            {"P", CancellationReason.CreditLineAccountClosed},
            {"R", CancellationReason.RequestOfCustomer}
        };
    }
}