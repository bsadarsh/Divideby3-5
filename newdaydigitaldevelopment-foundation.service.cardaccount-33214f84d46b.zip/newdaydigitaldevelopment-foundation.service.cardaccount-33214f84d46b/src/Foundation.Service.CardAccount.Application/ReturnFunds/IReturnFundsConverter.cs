﻿using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v2.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Transactions.v1.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.ReturnFunds;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.ReturnFunds
{
    public interface IReturnFundsConverter
    {
        MonetaryActionRequest ToMonetaryActionRequest(ReturnFundsRequest request, string planNumber, string planSequenceNumber);
        AccountPlanInquiryRequest2 ToAccountPlanInquiryRequest(ReturnFundsRequest request);
    }
}