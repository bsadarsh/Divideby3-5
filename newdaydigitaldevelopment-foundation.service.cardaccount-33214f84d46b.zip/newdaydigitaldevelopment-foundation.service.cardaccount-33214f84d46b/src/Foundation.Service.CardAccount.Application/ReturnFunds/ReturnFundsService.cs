﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v2;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v2.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Exceptions;
using NewDay.Digital.Foundation.Connector.FirstData.Transactions.v1;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.ReturnFunds;
using NewDay.Digital.Foundation.Core.Utils;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.ReturnFunds
{
    public class ReturnFundsService : IExecutable<ReturnFundsRequest, DataManagerResponse<ReturnFundsResponse>>
    {
        private const string PlanNumberNotFoundErrorCode = "FS000006";

        private const string PlanNumberNotFoundOdsMessage = "VPE8SS CARD/ACCOUNT NUMBER NOT FOUND";

        private readonly ILogger<ReturnFundsService> _logger;
        private readonly IAccountManagementApiClient _accountManagementApiClient;
        private readonly ITransactionsApiClient _transactionsApiClient;
        private readonly IReturnFundsConverter _converter;

        private static readonly DataManagerResponse<ReturnFundsResponse> Response =
            new DataManagerResponse<ReturnFundsResponse>(new ReturnFundsResponse(), default, TimeSpan.Zero);

        public ReturnFundsService(
            ITransactionsApiClient transactionsApiClient,
            IAccountManagementApiClient accountManagementApiClient,
            IReturnFundsConverter converter,
            ILogger<ReturnFundsService> logger)
        {
            _logger = logger.ArgNotNull(nameof(logger));
            _accountManagementApiClient = accountManagementApiClient.ArgNotNull(nameof(accountManagementApiClient));
            _transactionsApiClient = transactionsApiClient.ArgNotNull(nameof(transactionsApiClient));
            _converter = converter.ArgNotNull(nameof(converter));
        }

        public async Task<DataManagerResponse<ReturnFundsResponse>> ExecuteAsync(ReturnFundsRequest request)
        {
            request.ArgNotNull(nameof(request));

            var plan = await RetrievePlan(request);
            
            try
            {
                var fiServRequest = _converter.ToMonetaryActionRequest(request, plan.PlanNbr, plan.PlanSeqNbr);

                _ = await _transactionsApiClient.MonetaryActionAsync(fiServRequest);

                return Response;
            }
            catch (FirstDataApiException e)
                when (e.ResponseStatus.ErrorCode == PlanNumberNotFoundErrorCode &&
                      e.ResponseStatus.OdsMessages.Contains(PlanNumberNotFoundOdsMessage))
            {
                _logger.LogError("PlanNumber {planNumber} was not found", plan.PlanNbr);
                throw new PlanNumberNotFoundException();
            }
        }

        private async Task<PlanCtdData2ForAccountPlanInquiry2> RetrievePlan(ReturnFundsRequest request)
        {
            var accountPlanInquiryRequest = _converter.ToAccountPlanInquiryRequest(request);

            var accountPlanInquiryResponse =
                await _accountManagementApiClient.AccountPlanInquiryAsync(accountPlanInquiryRequest);

            var plan = accountPlanInquiryResponse.PlanCtdData.FirstOrDefault(p => PlanHasEnoughCreditToCoverRequest(p, request));

            if (plan is null)
            {
                _logger.LogError("No Plan with sufficient credit was found for account '{account}' while trying to refund amount '{amount}'", request.CardAccountId, request.Amount);
                throw new PlanNumberNotFoundException();
            }

            return plan;
        }

        private static bool PlanHasEnoughCreditToCoverRequest(PlanCtdData2ForAccountPlanInquiry2 plan, ReturnFundsRequest request)
        {
            var requestedAmountInPence = Math.Floor(request.Amount.Value * 100m); //FiServ balance is in pence whereas the request is in Pounds and pence 
            var parsedBalance = decimal.TryParse(plan.PlanCurrBal, out var balance);
            return parsedBalance && (balance * -1) >= requestedAmountInPence; //-ve balance indicates an account in credit
        }
    }
}