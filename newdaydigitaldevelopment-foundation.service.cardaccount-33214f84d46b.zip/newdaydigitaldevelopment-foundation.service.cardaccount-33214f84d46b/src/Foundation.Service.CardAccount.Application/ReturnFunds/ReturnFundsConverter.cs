﻿using System;
using Microsoft.Extensions.Logging;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v2.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Exceptions;
using NewDay.Digital.Foundation.Connector.FirstData.Transactions.v1.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.ReturnFunds;
using NewDay.Digital.Foundation.Core.Utils;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;

// ReSharper disable PossibleInvalidOperationException

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.ReturnFunds
{
    public class ReturnFundsConverter : IReturnFundsConverter
    {
        private readonly ILogger<ReturnFundsConverter> _logger;
        private readonly IBrandHelper _brandHelper;

        private const string StoreNumber = "999999998";
        private const string DateTimeFormat = "yyyyMMdd";
        private const string ActionCode = "CBRD"; //stands for Credit Balance Refund

        public ReturnFundsConverter(IBrandHelper brandHelper, ILogger<ReturnFundsConverter> logger)
        {
            _brandHelper = brandHelper.ArgNotNull(nameof(brandHelper));
            _logger = logger.ArgNotNull(nameof(logger));
        }

        public MonetaryActionRequest ToMonetaryActionRequest(ReturnFundsRequest request, string planNumber,
            string planSequenceNumber)
        {
            request.ArgNotNull(nameof(request));
            planNumber.ArgNotNull(nameof(planNumber));
            planSequenceNumber.ArgNotNull(nameof(planSequenceNumber));

            var brand = GetBrandForAccountId(request.CardAccountId);

            return new MonetaryActionRequest(brand.ClientNumber)
            {
                Account = request.CardAccountId,
                AcctNbr = request.CardAccountId,
                ActionCode = ActionCode,
                TxnAmount = Math.Floor(request.Amount.Value * 100).ToString().PadLeft(10, '0'),
                StoreNbr = StoreNumber,
                EffDate = DateTimeOffset.Now.ToString(DateTimeFormat),
                PlanNbr = planNumber,
                PlanSeq = planSequenceNumber,
                ForeignUse = "0"
            };
        }

        public AccountPlanInquiryRequest2 ToAccountPlanInquiryRequest(ReturnFundsRequest request)
        {
            request.ArgNotNull(nameof(request));

            var brand = GetBrandForAccountId(request.CardAccountId);

            return new AccountPlanInquiryRequest2(brand.ClientNumber)
            {
                Account = request.CardAccountId,
                Acct = request.CardAccountId
            };
        }

        private Brand GetBrandForAccountId(string cardAccountId)
        {
            try
            {
                return _brandHelper.GetBrandFromAccountNumber(cardAccountId);
            }
            catch (BrandNotFoundException e)
            {
                _logger.LogInformation("Card Account ID {cardAccountId} not found in Brand DB", cardAccountId);
                throw new AccountNumberNotFoundInBrandDbException(e.Message);
            }
        }
    }
}