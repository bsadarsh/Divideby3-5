﻿using System;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Extensions;
using NewDay.Digital.Foundation.Connector.FirstData.Transactions.v1.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.PostGoodwill;
using NewDay.Digital.Foundation.Core.Utils;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Extensions;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.PostGoodwill
{
    public class PostGoodwillConverter : IPostGoodwillConverter
    {
        private readonly IBrandHelper _brandHelper;

        private const string PostGoodwillActionCode = "2GOG";
        private const string StoreNumber = "999999998";
        private const string ForeignUseDisabledFlag = "0";

        private static readonly PostGoodwillResponse PostGoodwillResponseInstance = new PostGoodwillResponse();

        public PostGoodwillConverter(IBrandHelper brandHelper) => _brandHelper = brandHelper.ArgNotNull(nameof(brandHelper));

        /// <summary>
        /// Converts a PostGoodwillRequest to a MonetaryActionRequest
        /// Does not set the plan number, it needs to be supplemented after the object is created
        /// </summary>
        /// <param name="request">PostGoodwillRequest</param>
        /// <returns>MonetaryActionRequest</returns>
        public MonetaryActionRequest ToMonetaryActionRequest(PostGoodwillRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId) ?? throw new InvalidBrandException();

            return new MonetaryActionRequest(brand.ClientNumber)
            {
                AcctNbr = request.CardAccountId,
                ActionCode = PostGoodwillActionCode,
                TxnAmount = request.Amount.ToFDAmountString(),
                StoreNbr = StoreNumber,
                EffDate = DateTime.UtcNow.ToFDDateString(),
                ForeignUse = ForeignUseDisabledFlag
            };
        }

        public PostGoodwillResponse ToPostGoodwillResponse(MonetaryActionResponse response)
        {
            return PostGoodwillResponseInstance;
        }
    }
}