﻿using System;
using System.Linq;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.PostGoodwill;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.Transactions.v1;
using NewDay.Digital.Foundation.Core.Domain.CardAccount;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.CreatePlan;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetPlans;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.PostGoodwill
{
    public class PostGoodwillService : IExecutable<PostGoodwillRequest, DataManagerResponse<PostGoodwillResponse>>
    {
        private readonly IPostGoodwillConverter _postGoodwillConverter;
        private readonly ITransactionsApiClient _transactionsApiClient;
        private readonly IExecutable<GetPlansRequest, DataManagerResponse<GetPlansResponse>> _getPlansService;
        private readonly IExecutable<CreatePlanRequest, DataManagerResponse<CreatePlanResponse>> _createPlanService;

        public PostGoodwillService(IPostGoodwillConverter postGoodwillConverter, ITransactionsApiClient transactionsApiClient, IExecutable<GetPlansRequest, DataManagerResponse<GetPlansResponse>> getPlansService, IExecutable<CreatePlanRequest, DataManagerResponse<CreatePlanResponse>> createPlanService)
        {
            _postGoodwillConverter = postGoodwillConverter;
            _transactionsApiClient = transactionsApiClient;
            _getPlansService = getPlansService;
            _createPlanService = createPlanService;
        }

        public async Task<DataManagerResponse<PostGoodwillResponse>> ExecuteAsync(PostGoodwillRequest request)
        {
            var activePlanIdentifier = await FindOrCreateActivePlan(request.CardAccountId);

            var fdRequest = _postGoodwillConverter.ToMonetaryActionRequest(request);

            fdRequest.PlanNbr = activePlanIdentifier;

            var fdResponse = await _transactionsApiClient.MonetaryActionAsync(fdRequest);
            var domainResponse = _postGoodwillConverter.ToPostGoodwillResponse(fdResponse);

            return new DataManagerResponse<PostGoodwillResponse>(domainResponse, DateTime.UtcNow, TimeSpan.Zero);
        }

        private async Task<string> FindOrCreateActivePlan(string cardAccountId)
        {
            var getPlansRequest = new GetPlansRequest()
            {
                CardAccountId = cardAccountId
            };

            var getPlansResponse = await _getPlansService.ExecuteAsync(getPlansRequest);
            var retailPlans = getPlansResponse.Value.Plans.Where(p => p.Type == PlanType.Retail).OrderByDescending(p => p.OpenDate);
            var activePlan = retailPlans.FirstOrDefault(p => p.Active == "Y");

            if (activePlan == null)
            {
                var planToActivate = retailPlans.FirstOrDefault();

                if (planToActivate == null)
                {
                    throw new RetailPlanNotFoundException(
                        "No retail plan found to perform a gesture of goodwill transaction");
                }

                await ActivatePlan(cardAccountId, planToActivate);

                activePlan = planToActivate;
            }

            return activePlan.Identifier;
        }

        private async Task ActivatePlan(string cardAccountId, Plan planToActivate)
        {
            var createPlanRequest = new CreatePlanRequest()
            {
                CardAccountId = cardAccountId,
                RetailPlan = planToActivate.Identifier
            };

            await _createPlanService.ExecuteAsync(createPlanRequest);
        }
    }
}