﻿using NewDay.Digital.Foundation.Connector.FirstData.AccountActivityUpdates.v2.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetMemos
{
    public interface IGetMemosConverter
    {
        MemoInquiryRequest2 ToMemoInquiryRequest(GetCardAccountMemosRequest request);
        GetCardAccountMemosResponse ToGetCardAccountMemosResponse(MemoInquiryResponse2 response);
    }
}