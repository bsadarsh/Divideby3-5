﻿using System;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.AccountActivityUpdates.v2;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Core.Caching.Generators;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetMemos
{
    public class GetMemosService : IExecutable<GetCardAccountMemosRequest, DataManagerResponse<GetCardAccountMemosResponse>>
    {
        private readonly TimeSpan _cardAccountCacheTime;
        private readonly IGetMemosConverter _converter;
        private readonly IAccountActivityUpdatesApiClient _memoApiClient;
        private readonly IDataManager _dataManager;

        public GetMemosService(
            ITimeoutProvider timeoutProvider,
            IGetMemosConverter getMemosConverter,
            IAccountActivityUpdatesApiClient memoApiClient,
            IDataManager dataManager)
        {
            _cardAccountCacheTime = timeoutProvider.Timeout;
            _converter = getMemosConverter;
            _memoApiClient = memoApiClient;
            _dataManager = dataManager;
        }

        public async Task<DataManagerResponse<GetCardAccountMemosResponse>> ExecuteAsync(GetCardAccountMemosRequest request)
        {
            var cacheKey = CacheKeyGenerator.Generate(request, request.CardAccountId);

            var fdRequest = _converter.ToMemoInquiryRequest(request);
            var dataManagerResponse = await _dataManager.FetchWithCacheAsync(cacheKey, _cardAccountCacheTime, () => _memoApiClient.MemoInquiryAsync(fdRequest));
            var response = _converter.ToGetCardAccountMemosResponse(dataManagerResponse.Value);

            return new DataManagerResponse<GetCardAccountMemosResponse>(response, dataManagerResponse.CacheAge, dataManagerResponse.CacheLifetime);
        }
    }
}
