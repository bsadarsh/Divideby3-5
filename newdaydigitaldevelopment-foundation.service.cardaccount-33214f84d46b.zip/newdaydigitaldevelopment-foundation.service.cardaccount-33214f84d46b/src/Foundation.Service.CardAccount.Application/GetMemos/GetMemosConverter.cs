﻿using System.Linq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountActivityUpdates.v2.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetMemos
{
    public class GetMemosConverter : IGetMemosConverter
    {
        private readonly IBrandHelper _brandHelper;
        public GetMemosConverter(IBrandHelper brandHelper)
        {
            _brandHelper = brandHelper;
        }

        public MemoInquiryRequest2 ToMemoInquiryRequest(GetCardAccountMemosRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId);
            if (brand == null)
            {
                throw new InvalidBrandException();
            }
            return new MemoInquiryRequest2(brand.ClientNumber)
            {
                AcctNbr = request.CardAccountId,
                NbrRec = "50"
            };
        }

        public GetCardAccountMemosResponse ToGetCardAccountMemosResponse(MemoInquiryResponse2 response)
        {
            if (response == null)
            {
                return null;
            }

            var result = new GetCardAccountMemosResponse
            {
                Memos = response.MemoDtl.Select(ToCardAccountMemo)
            };

            return result;
        }

        public CardAccountMemo ToCardAccountMemo(MemoDtl2ForMemoInquiry2 memoDtl)
        {
            if (memoDtl == null) return null;

            return new CardAccountMemo
            {
                Code = memoDtl.ActnCd,
                Text = string.Concat(memoDtl.MemoLine1, memoDtl.MemoLine2, memoDtl.MemoLine3, memoDtl.MemoLine4,
                    memoDtl.MemoLine5)
            };
        }
    }
}
