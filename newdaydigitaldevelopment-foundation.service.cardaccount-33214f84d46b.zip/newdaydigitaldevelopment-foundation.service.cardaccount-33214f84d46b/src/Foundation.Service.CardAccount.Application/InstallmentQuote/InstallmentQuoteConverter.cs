﻿using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Loans.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Loans.v2.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.InstallmentQuote;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Extensions;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.InstallmentQuote
{
    public class InstallmentQuoteConverter : IInstallmentQuoteConverter
    {
        private readonly IBrandHelper _brandHelper;

        public InstallmentQuoteConverter(IBrandHelper brandHelper)
        {
            _brandHelper = brandHelper;
        }

        public FppQuoteGenerationRequest ToFppQuoteGenerationRequest(InstallmentQuoteRequest request, PlanCtdData2ForAccountPlanList2 matchingPlan)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId)
                        ?? throw new InvalidBrandException();
            var org = request.CardAccountId.TrimStart('0').Substring(0, 3);

            return new FppQuoteGenerationRequest(brand.ClientNumber)
            {
                Acct = request.CardAccountId,
                FppPlan = request.Plan,
                InitAmt = request.TotalAmount?.ToFDAmountString(),
                EmiAmount = request.FixedAmount == null ? matchingPlan.FppAgrdPmtAmt : request.FixedAmount?.ToFDAmountString(),
                OrigTerm = request.Terms == null ? matchingPlan.FppOrigTerm : request.Terms.ToString(),
                Common =
                {
                    ClientNumber = brand.ClientNumber,
                    Org = org
                }
            };
        }

        public AccountPlanListRequest2 ToAccountPlanListRequest2(InstallmentQuoteRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId)
                        ?? throw new InvalidBrandException();

            return new AccountPlanListRequest2(brand.ClientNumber)
            {
                Acct = request.CardAccountId
            };
        }

        public InstallmentQuoteResponse ToInstallmentQuoteResponse(FppQuoteGenerationResponse response)
        {
            return new InstallmentQuoteResponse()
            {
                FixedAmount = response.FppFixedPmtAmt.ToDecimalFromFDAmount(),
                TotalCost = response.FppTotalCost.ToDecimalFromFDAmount(),
                InterestEstimated = response.FppEstInt.ToDecimalFromFDAmount(),
                Terms = int.Parse(response.FppNbrOfPmts),
                MonthlyRate = int.Parse(response.FppMthlyRate),
                AnnualRate = int.Parse(response.FppCurrAer)
            };
        }
    }
}