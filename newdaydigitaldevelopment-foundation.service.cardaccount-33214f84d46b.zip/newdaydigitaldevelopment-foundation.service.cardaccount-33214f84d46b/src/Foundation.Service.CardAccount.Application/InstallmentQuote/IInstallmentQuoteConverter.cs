﻿using NewDay.Digital.Foundation.Connector.FirstData.Loans.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Loans.v2.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.InstallmentQuote;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.InstallmentQuote
{
    public interface IInstallmentQuoteConverter
    {
        FppQuoteGenerationRequest ToFppQuoteGenerationRequest(InstallmentQuoteRequest request, PlanCtdData2ForAccountPlanList2 matchingPlan);

        AccountPlanListRequest2 ToAccountPlanListRequest2(InstallmentQuoteRequest request);

        InstallmentQuoteResponse ToInstallmentQuoteResponse(FppQuoteGenerationResponse response);
    }
}