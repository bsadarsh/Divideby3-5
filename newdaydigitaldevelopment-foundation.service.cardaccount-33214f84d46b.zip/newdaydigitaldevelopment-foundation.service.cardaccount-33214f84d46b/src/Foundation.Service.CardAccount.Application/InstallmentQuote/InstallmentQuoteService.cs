﻿using System.Linq;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.InstallmentQuote;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.Loans.v2.Models;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Core.Caching.Generators;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Extensions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.InstallmentQuote
{
    public class InstallmentQuoteService : IExecutable<InstallmentQuoteRequest, DataManagerResponse<InstallmentQuoteResponse>>
    {
        private readonly IInstallmentQuoteConverter _installmentQuoteConverter;
        private readonly Connector.FirstData.Loans.v1.ILoansApiClient _loansApiClientV1;
        private readonly Connector.FirstData.Loans.v2.ILoansApiClient _loansApiClientV2;
        private readonly IDataManager _dataManager;
        private readonly ITimeoutProvider _timeoutProvider;

        public InstallmentQuoteService(IInstallmentQuoteConverter installmentQuoteConverter,
            Connector.FirstData.Loans.v1.ILoansApiClient loansApiClientV1,
            Connector.FirstData.Loans.v2.ILoansApiClient loansApiClientV2, IDataManager dataManager,
            ITimeoutProvider timeoutProvider)
        {
            _installmentQuoteConverter = installmentQuoteConverter;
            _loansApiClientV1 = loansApiClientV1;
            _loansApiClientV2 = loansApiClientV2;
            _dataManager = dataManager;
            _timeoutProvider = timeoutProvider;
        }

        public async Task<DataManagerResponse<InstallmentQuoteResponse>> ExecuteAsync(InstallmentQuoteRequest request)
        {
            var accountPlanListRequest = _installmentQuoteConverter.ToAccountPlanListRequest2(request);

            var accountPlanListResponse = await _loansApiClientV2.AccountPlanListAsync(accountPlanListRequest);

            if (request.TotalAmount != null)
            {
                if (IsRequestAmountHigerThanEligibleBalance((decimal)request.TotalAmount, accountPlanListResponse.AcctFppEligBal))
                {
                    throw new EligibleBalanceExceededException("Quote amount exceeds eligible balance");
                }
            }
            else
            {
                request.TotalAmount = accountPlanListResponse.AcctFppEligBal.ToDecimalFromFDAmount();
            }

            var matchingPlan = GetMatchingPlan(accountPlanListResponse, request.Plan);

            var fppQuoteGenerationRequest = _installmentQuoteConverter.ToFppQuoteGenerationRequest(request, matchingPlan);

            var cacheKey = CacheKeyGenerator.Generate(fppQuoteGenerationRequest, request.CardAccountId);
            var dataManagerResponse = await _dataManager.FetchWithCacheAsync(cacheKey, _timeoutProvider.Timeout,
                async () => await _loansApiClientV1.FppQuoteGenerationAsync(fppQuoteGenerationRequest));

            var domainResponse = _installmentQuoteConverter.ToInstallmentQuoteResponse(dataManagerResponse.Value);

            return new DataManagerResponse<InstallmentQuoteResponse>(domainResponse, dataManagerResponse.CacheAge, dataManagerResponse.CacheLifetime);
        }

        private bool IsRequestAmountHigerThanEligibleBalance(decimal requestedAmount, string eligibleBalance)
        {
            return requestedAmount > eligibleBalance.ToDecimalFromFDAmount();
        }

        private PlanCtdData2ForAccountPlanList2 GetMatchingPlan(AccountPlanListResponse2 accountPlanListResponse, string planNumber)
        {
            var matchingPlan = accountPlanListResponse.PlanCtdData.FirstOrDefault(p => p.PlanNbr == planNumber);
            if (matchingPlan == null)
            {
                throw new InstallmentPlanMatchException("Matching installment plan not found");
            }

            return matchingPlan;
        }
    }
}