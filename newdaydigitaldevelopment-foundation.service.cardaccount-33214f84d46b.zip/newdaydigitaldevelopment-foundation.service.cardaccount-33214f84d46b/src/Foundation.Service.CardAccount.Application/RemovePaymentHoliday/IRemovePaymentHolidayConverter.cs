﻿using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.RemovePaymentHoliday;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.RemovePaymentHoliday
{
    public interface IRemovePaymentHolidayConverter
    {
        public PaymentHolidayRequest ToPaymentHolidayRequest(RemovePaymentHolidayRequest request);
        public AccountDetailInquiryRequest3 ToAccountDetailInquiry(RemovePaymentHolidayRequest request);
    }
}
