﻿using System;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.RemovePaymentHoliday;
using NewDay.Digital.Foundation.Core.Utils;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.RemovePaymentHoliday
{
    public class RemovePaymentHolidayService : IExecutable<RemovePaymentHolidayRequest, DataManagerResponse<RemovePaymentHolidayResponse>>
    {
        private readonly IRemovePaymentHolidayConverter _removePaymentHolidayConverter;
        private readonly IAccountManagementApiClient _accountManagementApiClient;
        private readonly Connector.FirstData.AccountManagement.v1.IAccountManagementApiClient
            _accountManagementApiClientV1;

        private readonly string NoPaymentHolidayTermValue = "0";

        public RemovePaymentHolidayService(IRemovePaymentHolidayConverter removePaymentHolidayConverter, IAccountManagementApiClient accountManagementApiClient, Connector.FirstData.AccountManagement.v1.IAccountManagementApiClient accountManagementApiClientV1)
        {
            _removePaymentHolidayConverter = removePaymentHolidayConverter;
            _accountManagementApiClient = accountManagementApiClient;
            _accountManagementApiClientV1 = accountManagementApiClientV1;
        }

        public async Task<DataManagerResponse<RemovePaymentHolidayResponse>> ExecuteAsync(RemovePaymentHolidayRequest request)
        {
            if (request.Term.IsNullOrEmpty())
            {
                var accountDetailInquiry = _removePaymentHolidayConverter.ToAccountDetailInquiry(request);
                var accountDetailInquiryResponse = await _accountManagementApiClient.AccountDetailInquiryAsync(accountDetailInquiry);

                if (accountDetailInquiryResponse.PmtHolidayTerm == NoPaymentHolidayTermValue)
                {
                    throw new NoPaymentHolidaySetException("This account has no active payment holidays");
                }

                request.Term = accountDetailInquiryResponse.PmtHolidayTerm;
            }

            var fdRequest = _removePaymentHolidayConverter.ToPaymentHolidayRequest(request);
            await _accountManagementApiClientV1.PaymentHolidayAsync(fdRequest);

            return new DataManagerResponse<RemovePaymentHolidayResponse>(new RemovePaymentHolidayResponse(), DateTime.UtcNow, TimeSpan.Zero);
        }
    }
}
