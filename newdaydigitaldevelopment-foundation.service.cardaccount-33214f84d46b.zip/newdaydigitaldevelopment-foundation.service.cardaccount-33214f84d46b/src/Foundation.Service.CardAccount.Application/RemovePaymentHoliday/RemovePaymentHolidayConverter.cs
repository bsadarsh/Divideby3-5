﻿using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.RemovePaymentHoliday;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.RemovePaymentHoliday
{
    public class RemovePaymentHolidayConverter : IRemovePaymentHolidayConverter
    {
        private readonly IBrandHelper _brandHelper;
        private static readonly string RemovePaymentHolidayFlag = "0";

        public RemovePaymentHolidayConverter(IBrandHelper brandHelper)
        {
            _brandHelper = brandHelper;
        }

        public PaymentHolidayRequest ToPaymentHolidayRequest(RemovePaymentHolidayRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId);
            return new PaymentHolidayRequest(brand.ClientNumber)
            {
                Account = request.CardAccountId.PadLeft(19, '0'),
                HolidayTerm = request.Term,
                PmtHolidayFlag = RemovePaymentHolidayFlag,
                Common =
                {
                    ClientNumber = brand.ClientNumber,
                    Org = request.CardAccountId.TrimStart('0').Substring(0,3)
                }
            };
        }

        public AccountDetailInquiryRequest3 ToAccountDetailInquiry(RemovePaymentHolidayRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId);

            return new AccountDetailInquiryRequest3(brand.ClientNumber)
            {
                Account = request.CardAccountId
            };
        }
    }
}
