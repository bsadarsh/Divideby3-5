﻿using System;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions
{
    public class RetailPlanNotFoundException : Exception
    {
        public RetailPlanNotFoundException(string message) : base(message)
        {
            
        }
    }
}