﻿using System;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions
{
    public class BlockCodeMatchException : Exception
    {
        public BlockCodeMatchException(string message) : base(message)
        {
            
        }
    }
}