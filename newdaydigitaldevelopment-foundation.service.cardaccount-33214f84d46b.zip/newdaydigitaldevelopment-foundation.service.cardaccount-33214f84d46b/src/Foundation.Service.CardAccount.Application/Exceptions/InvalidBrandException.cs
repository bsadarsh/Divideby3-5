﻿using System;
using System.Runtime.Serialization;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions
{
    [Serializable]
    public class InvalidBrandException : Exception
    {
        public InvalidBrandException()
        {
        }

        public InvalidBrandException(string message)
            : base(message)
        {
        }

        public InvalidBrandException(string message, Exception inner)
            : base(message, inner)
        {
        }

        protected InvalidBrandException(SerializationInfo serializationInInfo, StreamingContext context)
            : base(serializationInInfo, context)
        {
        }
    }
}
