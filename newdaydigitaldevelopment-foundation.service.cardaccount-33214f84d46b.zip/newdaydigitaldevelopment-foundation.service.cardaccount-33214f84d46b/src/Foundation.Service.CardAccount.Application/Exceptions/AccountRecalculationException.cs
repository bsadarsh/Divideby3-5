﻿using System;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions
{
    public class AccountRecalculationException : Exception
    {
        public AccountRecalculationException(string message) : base(message) {}
    }
}
