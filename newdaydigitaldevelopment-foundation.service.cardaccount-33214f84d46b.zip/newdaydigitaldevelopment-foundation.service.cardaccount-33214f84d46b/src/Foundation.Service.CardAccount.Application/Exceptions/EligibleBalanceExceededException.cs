﻿using System;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions
{
    public class EligibleBalanceExceededException : Exception
    {
        public EligibleBalanceExceededException(string message) : base(message)
        {
            
        }
    }
}