﻿using System;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions
{
    public class AccountNumberNotFoundInBrandDbException : Exception
    {
        public AccountNumberNotFoundInBrandDbException(string message) : base(message)
        {
        }
    }
}