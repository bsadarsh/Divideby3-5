﻿using System;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions
{
    public class InvalidReAgeRequestValuesException : Exception
    {
        public InvalidReAgeRequestValuesException(string message) : base(message) {}
    }
}
