﻿using System;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions
{
    /// <summary>
    /// Thrown when a client attempts to set a spend cap limit which is greater than their credit limit. 
    /// </summary>
    /// <seealso cref="System.Exception" />
    public class SpendCapLimitGreaterThanCreditLimitException : Exception
    {
        public const string ErrorMessage = "Spend cap limit must be less than credit limit";
    }
}