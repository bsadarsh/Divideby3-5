﻿using System;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions
{
    public class EmptyUpdateAccountRequestException : Exception
    {
        public EmptyUpdateAccountRequestException(string message) : base(message)
        {
            
        }
    }
}