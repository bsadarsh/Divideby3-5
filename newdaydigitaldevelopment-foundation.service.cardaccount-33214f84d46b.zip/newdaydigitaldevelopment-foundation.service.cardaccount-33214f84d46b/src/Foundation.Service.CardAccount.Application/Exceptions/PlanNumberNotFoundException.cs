﻿using System;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions
{
    public class PlanNumberNotFoundException : Exception
    {
        public PlanNumberNotFoundException()
        {
        }

        public PlanNumberNotFoundException(string message) : base(message)
        {
        }
    }
}