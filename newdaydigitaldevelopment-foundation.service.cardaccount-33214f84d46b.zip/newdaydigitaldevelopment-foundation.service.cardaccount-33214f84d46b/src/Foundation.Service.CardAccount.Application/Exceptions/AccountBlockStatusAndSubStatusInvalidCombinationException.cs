﻿using System;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions
{
    /// <summary>
    /// Thrown when client tries to set subStatus that is not supported by given status (fd blockCode)
    /// </summary>
    public class AccountBlockStatusAndSubStatusInvalidCombinationException : Exception
    {
        public AccountBlockStatusAndSubStatusInvalidCombinationException(string message) : base(message)
        {
        }
    }
}