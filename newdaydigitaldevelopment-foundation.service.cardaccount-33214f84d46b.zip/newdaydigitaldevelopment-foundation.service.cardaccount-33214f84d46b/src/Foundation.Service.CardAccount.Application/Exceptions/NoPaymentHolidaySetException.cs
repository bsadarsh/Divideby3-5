﻿using System;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions
{
    public class NoPaymentHolidaySetException : Exception
    {
        public NoPaymentHolidaySetException(string message) : base(message) {}
    }
}
