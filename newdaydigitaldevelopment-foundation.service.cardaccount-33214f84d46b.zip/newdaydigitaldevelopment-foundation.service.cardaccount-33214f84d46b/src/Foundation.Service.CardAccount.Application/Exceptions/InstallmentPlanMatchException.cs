﻿using System;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions
{
    public class InstallmentPlanMatchException : Exception
    {
        public InstallmentPlanMatchException(string message) : base(message)
        {
            
        }
    }
}