﻿using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetAccountByCard
{
    public class GetAccountByCardConverter : IGetAccountByCardConverter
    {
        private readonly IBrandHelper _brandHelper;

        public GetAccountByCardConverter(IBrandHelper brandHelper)
        {
            _brandHelper = brandHelper;
        }

        public AccountDetailInquiryRequest3 ToAccountDetailInquiryRequest(GetAccountByCardRequest request)
        {
            var clientNumber = _brandHelper.GetClientNumberFromCardNumber(request.CardNumber);
            if (clientNumber == null)
            {
                throw new InvalidBrandException();
            }
            return new AccountDetailInquiryRequest3(clientNumber)
            {
                Account = request.CardNumber
            };
        }

        public GetAccountByCardResponse ToGetAccountByCardResponse(AccountDetailInquiryResponse3 response)
        {
            var cardAccountId = response.Account.TrimStart('0');

            return new GetAccountByCardResponse()
            {
                CardAccountId = cardAccountId
            };
        }
    }
}
