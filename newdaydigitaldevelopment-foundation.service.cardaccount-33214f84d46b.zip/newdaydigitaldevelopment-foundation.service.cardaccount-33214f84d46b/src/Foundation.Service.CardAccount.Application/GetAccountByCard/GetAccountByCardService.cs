﻿using System;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Core.Caching.Generators;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetAccountByCard
{
    public class GetAccountByCardService : IExecutable<GetAccountByCardRequest, DataManagerResponse<GetAccountByCardResponse>>
    {
        private readonly TimeSpan _accountHolderCacheTime;
        private readonly IGetAccountByCardConverter _converter;
        private readonly IAccountManagementApiClient _accountManagementApiClient;
        private readonly IDataManager _dataManager;

        public GetAccountByCardService(ITimeoutProvider timeoutProvider, IGetAccountByCardConverter converter, IAccountManagementApiClient accountManagementApiClient, IDataManager dataManager)
        {
            _accountHolderCacheTime = timeoutProvider.Timeout;
            _converter = converter;
            _accountManagementApiClient = accountManagementApiClient;
            _dataManager = dataManager;
        }

        public async Task<DataManagerResponse<GetAccountByCardResponse>> ExecuteAsync(GetAccountByCardRequest request)
        {
            var cacheKey = CacheKeyGenerator.Generate(request, request.CardNumber);

            var fdRequest = _converter.ToAccountDetailInquiryRequest(request);
            var dataManagerResponse = await _dataManager.FetchWithCacheAsync(cacheKey, _accountHolderCacheTime, async () => await _accountManagementApiClient.AccountDetailInquiryAsync(fdRequest));
            var response = _converter.ToGetAccountByCardResponse(dataManagerResponse.Value);

            return new DataManagerResponse<GetAccountByCardResponse>(response, dataManagerResponse.CacheAge, dataManagerResponse.CacheLifetime);
        }
    }
}