﻿using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetAccountByCard
{
    public interface IGetAccountByCardConverter
    {
        AccountDetailInquiryRequest3 ToAccountDetailInquiryRequest(GetAccountByCardRequest request);

        GetAccountByCardResponse ToGetAccountByCardResponse(AccountDetailInquiryResponse3 response);
    }
}