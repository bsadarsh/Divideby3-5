﻿using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1;
using NewDay.Digital.Foundation.Connector.FirstData.Extensions;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.SetSpendCap;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Cache;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.SetSpendCap
{
    public class SetSpendCapService : IExecutable<SetSpendCapRequest, DataManagerResponse<SetSpendCapResponse>>
    {
        private readonly ISetSpendCapConverter _converter;
        private readonly IAccountMaintenanceApiClient _accountMaintenanceApiClient;
        private readonly IAccountManagementApiClient _accountManagementV3ApiClient;
        private readonly IAccountDetailInquiryCacheKeyProvider _cacheKeyProvider;
        private readonly IDataManager _dataManager;
        private readonly TimeSpan _cacheTime;
        private readonly ILogger<SetSpendCapService> _logger;

        public SetSpendCapService(ISetSpendCapConverter converter,
            IAccountMaintenanceApiClient accountMaintenanceApiClient,
            IAccountManagementApiClient accountApiClient,
            IAccountDetailInquiryCacheKeyProvider cacheKeyProvider,
            IDataManager dataManager,
            ITimeoutProvider timeoutProvider,
            ILogger<SetSpendCapService> logger)
        {
            _converter = converter ?? throw new ArgumentNullException(nameof(converter));
            _accountMaintenanceApiClient = accountMaintenanceApiClient ?? throw new ArgumentNullException(nameof(accountMaintenanceApiClient));
            _accountManagementV3ApiClient = accountApiClient ?? throw new ArgumentNullException(nameof(accountApiClient));
            _cacheKeyProvider = cacheKeyProvider ?? throw new ArgumentNullException(nameof(cacheKeyProvider));
            _dataManager = dataManager ?? throw new ArgumentNullException(nameof(dataManager));
            _cacheTime = timeoutProvider.Timeout;
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task<DataManagerResponse<SetSpendCapResponse>> ExecuteAsync(SetSpendCapRequest request)
        {
            if (IsSettingSpentCap(request) && await IsSpendCapGreaterThanCreditLimit(request))
            {
                throw new SpendCapLimitGreaterThanCreditLimitException();
            }

            var fdSetSpendCapRequest = _converter.ToAccountCustomFieldsUpdate(request);
            var fdSetSpendCapResponse = await _accountMaintenanceApiClient.AccountCustomFieldsUpdateAsync(fdSetSpendCapRequest);

            // Clients will be calling GetSpendCap after SetSpendCap, and will expect to see their newly set cap value,
            // rather than the value from cache.
            await ClearCache(request);

            var domainResponse = _converter.ToSetSpendCapResponse(fdSetSpendCapResponse);
            return new DataManagerResponse<SetSpendCapResponse>(domainResponse, DateTime.UtcNow, TimeSpan.Zero);
        }

        private bool IsSettingSpentCap(SetSpendCapRequest request)
        {
            return request.CapType != SpendCapType.None;
        }

        private async Task<bool> IsSpendCapGreaterThanCreditLimit(SetSpendCapRequest request)
        {
            var spendCapLimit = request.CapAmount.Value;
            var creditLimit = await GetCreditLimit(request);

            return spendCapLimit > creditLimit;
        }

        private async Task ClearCache(SetSpendCapRequest request)
        {
            var cacheKey = _cacheKeyProvider.GetKey(request.CardAccountId);

            if (await _dataManager.IsSetAsync(cacheKey))
            {
                await _dataManager.RemoveAsync(cacheKey);
                _logger.LogDebug("Invalidated key {key}", cacheKey);
            }
        }

        private async Task<decimal> GetCreditLimit(SetSpendCapRequest request)
        {
            var fdRequest = _converter.ToAccountDetailInquiryRequest3(request);

            var cacheKey = _cacheKeyProvider.GetKey(request.CardAccountId);

            var dataManagerResponse = await _dataManager.FetchWithCacheAsync(cacheKey, _cacheTime,
                async () => await _accountManagementV3ApiClient.AccountDetailInquiryAsync(fdRequest));

            var fdResponse = dataManagerResponse.Value;
            var decimalPositions = Convert.ToInt16(fdResponse.CurrencyNod);

            var creditLimit = fdResponse.Crlim.DecimalFromFDAmountString(decimalPositions);
            return creditLimit;
        }
    }
}