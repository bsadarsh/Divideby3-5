﻿using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.SetSpendCap;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.SetSpendCap
{
    public interface ISetSpendCapConverter
    {
        AccountCustomFieldsUpdateRequest ToAccountCustomFieldsUpdate(SetSpendCapRequest request);
        SetSpendCapResponse ToSetSpendCapResponse(AccountCustomFieldsUpdateResponse request);
        AccountDetailInquiryRequest3 ToAccountDetailInquiryRequest3(SetSpendCapRequest request);
    }
}