﻿using System;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.SetSpendCap;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Constants;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Extensions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.SetSpendCap
{
    public class SetSpendCapConverter : ISetSpendCapConverter
    {
        private readonly IBrandHelper _brandHelper;

        /// <summary>
        /// A static instance to use, as the response is always the same.
        /// </summary>
        private static readonly SetSpendCapResponse SetSpendCapResponseInstance = new SetSpendCapResponse();

        public SetSpendCapConverter(IBrandHelper brandHelper)
        {
            _brandHelper = brandHelper ?? throw new ArgumentNullException(nameof(brandHelper));
        }

        public AccountCustomFieldsUpdateRequest ToAccountCustomFieldsUpdate(SetSpendCapRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId);
            if (brand == null)
            {
                throw new InvalidBrandException();
            }

            string spendLimitAmountString;
            string spendLimitAlertString;

            if (request.CapType == SpendCapType.None)
            {
                // disable the cap
                spendLimitAmountString = FirstDataConstants.SpendCapDisabledAmount.ToString();
                spendLimitAlertString =
                    SpendCapMapper.MapSpendCapAlertTypeToFDValue(SpendCapAlertType.None);
            }
            else
            {
                spendLimitAmountString = request.CapAmount.Value.ToString().PadLeft(9, '0');
                spendLimitAlertString = SpendCapMapper.MapSpendCapAlertTypeToFDValue(request.AlertType.Value);
            }

            var fdRequest = new AccountCustomFieldsUpdateRequest(brand.ClientNumber)
            {
                Account = GeneralPurposeMethods.CardAccountIdWithLeadingZeros(request.CardAccountId),
                SpendCapInd = SpendCapMapper.MapSpendCapTypeToFDValue(request.CapType.Value),
                SpndLmtAlert = spendLimitAlertString,
                SpndLmtAmt = spendLimitAmountString,
            };

            return fdRequest;
        }

        public AccountDetailInquiryRequest3 ToAccountDetailInquiryRequest3(SetSpendCapRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId);
            if (brand == null)
            {
                throw new InvalidBrandException();
            }

            return new AccountDetailInquiryRequest3(brand.ClientNumber)
            {
                Account = request.CardAccountId
            };
        }

        public SetSpendCapResponse ToSetSpendCapResponse(AccountCustomFieldsUpdateResponse request)
        {
            return SetSpendCapResponseInstance;
        }
    }
}