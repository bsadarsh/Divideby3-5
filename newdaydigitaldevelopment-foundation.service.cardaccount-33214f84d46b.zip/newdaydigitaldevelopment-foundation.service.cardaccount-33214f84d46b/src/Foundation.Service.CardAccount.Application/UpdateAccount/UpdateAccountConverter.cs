﻿using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v2.Models;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.UpdateAccount;
using NewDay.Digital.Foundation.Core.Utils;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Extensions;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.UpdateAccount
{
    public class UpdateAccountConverter : IUpdateAccountConverter
    {
        private const string FixedPaymentFlag = "F";
        private const string UnblockFunctionCode = "U";
        private const string BlockFunctionCode = "B";
        private const string DefaultStatusIndicator = "0";
        private readonly IBrandHelper _brandHelper;

        public UpdateAccountConverter(IBrandHelper brandHelper) => _brandHelper = brandHelper.ArgNotNull(nameof(brandHelper));

        public AccountBlockCodeUpdateRequest ToAccountBlockCodeUpdateRequest(UpdateAccountRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId)
                        ?? throw new InvalidBrandException();

            return new AccountBlockCodeUpdateRequest(brand.ClientNumber)
            {
                CardNbr = request.CardAccountId,
                BlkCd = request.Status.HasValue ? AccountBlockStatusMap.StatusBlockCodeMap[request.Status.Value] : null,
                FunctionCd = request.Status != Status.NORMAL ? BlockFunctionCode : UnblockFunctionCode,
                BlkCdInd = request.Status == Status.NORMAL ? request.StatusIndicator : DefaultStatusIndicator,
                SubStatus = request.SubStatus,
                ProdCodeAccType = request.ProductCode,
                AcctRestructure = request.RestructureFlag?.ToYesNoBinaryString()
            };
        }

        public AccountCustomFieldsUpdateRequest ToAccountCustomFieldsUpdateRequest(UpdateAccountRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId)
                        ?? throw new InvalidBrandException();

            return new AccountCustomFieldsUpdateRequest(brand.ClientNumber)
            {
                Account = request.CardAccountId.PadLeft(19, '0'),
                FixedPmtAmt = request.FixedPaymentAmount?.ToFDAmountString(),
                PlanPmtOvrdFlag = request.FixedPaymentAmount > 0 ? FixedPaymentFlag : ""
            };
        }

        public AccountDisabilityIndicatorUpdateRequest ToAccountDisabilityIndicatorUpdateRequest(UpdateAccountRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId)
                        ?? throw new InvalidBrandException();

            return new AccountDisabilityIndicatorUpdateRequest(brand.ClientNumber)
            {
                AcctNbr = request.CardAccountId.PadLeft(19, '0'),
                DisabltyInd = request.DisabilityIndicator.HasValue ? AccountDisabilityIndicatorMap.DisabilityIndicatorMap[request.DisabilityIndicator.Value] : null
            };
        }

        public AccountUserFieldsUpdateRequest2 ToAccountUserFieldsUpdateRequest(UpdateAccountRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId)
                        ?? throw new InvalidBrandException();

            return new AccountUserFieldsUpdateRequest2(brand.ClientNumber)
            {
                AcctNbr = request.CardAccountId,
                UserCode1 = request.Code1,
                UserCode2 = request.Code2,
                UserCode3 = request.Code3,
                UserCode4 = request.Code4,
                UserCode5 = request.Code5,
                UserCode6 = request.Code6,
                UserCode7 = request.Code7,
                UserCode8 = request.Code8,
                UserCode9 = request.Code9,
                UserCode10 = request.Code10,
                UserCode11 = request.Code11,
                UserCode12 = request.Code12,
                UserAmt1 = request.Amount1?.ToFDAmountString(),
                UserAmt2 = request.Amount2?.ToFDAmountString(),
                UserAmt3 = request.Amount3?.ToFDAmountString(),
                UserAmt4 = request.Amount4?.ToFDAmountString(),
                UserAmt5 = request.Amount5?.ToFDAmountString(),
                UserAmt6 = request.Amount6?.ToFDAmountString(),
                UserAmt7 = request.Amount7?.ToFDAmountString(),
                UserAmt8 = request.Amount8?.ToFDAmountString(),
                UserAmt9 = request.Amount9?.ToFDAmountString(),
                UserAmt10 = request.Amount10?.ToFDAmountString(),
                UserAmt11 = request.Amount11?.ToFDAmountString(),
                UserAmt12 = request.Amount12?.ToFDAmountString(),
                MiscUser1 = request.Miscellaneous1,
                MiscUser2 = request.Miscellaneous2,
                MiscUser3 = request.Miscellaneous3,
                MiscUser4 = request.Miscellaneous4,
                MiscUser5 = request.Miscellaneous5,
                MiscUser6 = request.Miscellaneous6,
                MiscUser7 = request.Miscellaneous7,
                MiscUser8 = request.Miscellaneous8,
                MiscUser9 = request.Miscellaneous9,
                MiscUser10 = request.Miscellaneous10,
                MiscUser11 = request.Miscellaneous11,
                MiscUser12 = request.Miscellaneous12,
                UserDate1 = request.Date1?.ToString("yyyyMMdd"),
                UserDate2 = request.Date2?.ToString("yyyyMMdd"),
                UserDate3 = request.Date3?.ToString("yyyyMMdd"),
                UserDate4 = request.Date4?.ToString("yyyyMMdd"),
                UserDate5 = request.Date5?.ToString("yyyyMMdd"),
                UserDate6 = request.Date6?.ToString("yyyyMMdd"),
                UserDate7 = request.Date7?.ToString("yyyyMMdd"),
                UserDate8 = request.Date8?.ToString("yyyyMMdd"),
                UserDate9 = request.Date9?.ToString("yyyyMMdd"),
                UserDate10 = request.Date10?.ToString("yyyyMMdd"),
                UserDate11 = request.Date11?.ToString("yyyyMMdd"),
                UserDate12 = request.Date12?.ToString("yyyyMMdd"),
            };
        }

        public AccountDetailInquiryRequest3 ToAccountDetailInquiryRequest(UpdateAccountRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId)
                        ?? throw new InvalidBrandException();

            return new AccountDetailInquiryRequest3(brand.ClientNumber)
            {
                Account = request.CardAccountId
            };
        }
    }
}