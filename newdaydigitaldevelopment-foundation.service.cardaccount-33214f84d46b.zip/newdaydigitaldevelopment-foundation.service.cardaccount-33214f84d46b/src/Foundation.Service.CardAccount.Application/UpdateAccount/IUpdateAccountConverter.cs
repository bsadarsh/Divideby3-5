﻿using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v2.Models;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.UpdateAccount;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.UpdateAccount
{
    public interface IUpdateAccountConverter
    {
        AccountDisabilityIndicatorUpdateRequest ToAccountDisabilityIndicatorUpdateRequest(UpdateAccountRequest request);

        AccountBlockCodeUpdateRequest ToAccountBlockCodeUpdateRequest(UpdateAccountRequest request);

        AccountCustomFieldsUpdateRequest ToAccountCustomFieldsUpdateRequest(UpdateAccountRequest request);

        AccountUserFieldsUpdateRequest2 ToAccountUserFieldsUpdateRequest(UpdateAccountRequest request);

        AccountDetailInquiryRequest3 ToAccountDetailInquiryRequest(UpdateAccountRequest request);
    }
}