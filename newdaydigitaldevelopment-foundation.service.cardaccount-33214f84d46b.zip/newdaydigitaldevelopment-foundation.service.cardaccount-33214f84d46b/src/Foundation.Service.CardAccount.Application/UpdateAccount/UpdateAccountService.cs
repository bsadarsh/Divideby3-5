﻿using System;
using System.Linq;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.UpdateAccount;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Cache;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.UpdateAccount
{
    public class UpdateAccountService : IExecutable<UpdateAccountRequest, DataManagerResponse<UpdateAccountResponse>>
    {
        private readonly IUpdateAccountConverter _updateAccountConverter;
        private readonly Connector.FirstData.AccountMaintenance.v1.IAccountMaintenanceApiClient _accountMaintenanceApiClientV1;
        private readonly Connector.FirstData.AccountMaintenance.v2.IAccountMaintenanceApiClient _accountMaintenanceApiClientV2;
        private readonly IAccountManagementApiClient _accountManagementApiClient;
        private readonly IDataManager _dataManager;
        private readonly IAccountDetailInquiryCacheKeyProvider _cacheKeyProvider;

        public UpdateAccountService(IUpdateAccountConverter updateAccountConverter,
            Connector.FirstData.AccountMaintenance.v1.IAccountMaintenanceApiClient accountMaintenanceApiClientV1,
            Connector.FirstData.AccountMaintenance.v2.IAccountMaintenanceApiClient accountMaintenanceApiClientV2,
            IAccountManagementApiClient accountManagementApiClient, 
            IDataManager dataManager, 
            IAccountDetailInquiryCacheKeyProvider cacheKeyProvider)
        {
            _updateAccountConverter = updateAccountConverter;
            _accountMaintenanceApiClientV1 = accountMaintenanceApiClientV1;
            _accountMaintenanceApiClientV2 = accountMaintenanceApiClientV2;
            _accountManagementApiClient = accountManagementApiClient;
            _dataManager = dataManager;
            _cacheKeyProvider = cacheKeyProvider;
        }

        public async Task<DataManagerResponse<UpdateAccountResponse>> ExecuteAsync(UpdateAccountRequest request)
        {
            var hasBlockStatusFields = request.GetType().GetProperties()
                .Where(p => Attribute.IsDefined(p, typeof(BlockStatusPrimeFieldAttribute)))
                .Any(p => p.GetValue(request) != null);

            var hasUserFields = request.GetType().GetProperties()
                .Where(p => Attribute.IsDefined(p, typeof(UserFieldAttribute))).Any(p => p.GetValue(request) != null);

            if (request.DisabilityIndicator == null && request.FixedPaymentAmount == null && !hasBlockStatusFields && !hasUserFields)
            {
                throw new EmptyUpdateAccountRequestException("No valid parameters provided");
            }

            if (request.DisabilityIndicator != null)
            {
                var disabilityIndicatorFdRequest =
                    _updateAccountConverter.ToAccountDisabilityIndicatorUpdateRequest(request);

                await _accountMaintenanceApiClientV1
                    .AccountDisabilityIndicatorUpdateAsync(disabilityIndicatorFdRequest);
            }

            if (request.FixedPaymentAmount != null)
            {
                var customFieldsFdRequest = _updateAccountConverter.ToAccountCustomFieldsUpdateRequest(request);

                await _accountMaintenanceApiClientV1.AccountCustomFieldsUpdateAsync(customFieldsFdRequest);
            }

            if (hasBlockStatusFields)
            {
                request = await HandleUnknownBlockStatusRemoveRequest(request);

                var blockCodeFdRequest = _updateAccountConverter.ToAccountBlockCodeUpdateRequest(request);

                await _accountMaintenanceApiClientV1.AccountBlockCodeUpdateAsync(blockCodeFdRequest);
            }

            if (hasUserFields)
            {
                var userFieldsFdRequest = _updateAccountConverter.ToAccountUserFieldsUpdateRequest(request);

                await _accountMaintenanceApiClientV2.AccountUserFieldsUpdateAsync(userFieldsFdRequest);
            }

            var domainResponse = new UpdateAccountResponse();

            await ClearCache(request);

            return new DataManagerResponse<UpdateAccountResponse>(domainResponse, DateTime.UtcNow, TimeSpan.Zero);
        }

        private async Task<UpdateAccountRequest> HandleUnknownBlockStatusRemoveRequest(UpdateAccountRequest request)
        {
            if (request.Status.HasValue && request.StatusIndicator == null && request.FunctionCode == FunctionCode.REMOVE)
            {
                var accountInquiryRequest = _updateAccountConverter.ToAccountDetailInquiryRequest(request);

                var accountInquiryResponse =
                    await _accountManagementApiClient.AccountDetailInquiryAsync(accountInquiryRequest);

                if (accountInquiryResponse.BlockCode1 == AccountBlockStatusMap.StatusBlockCodeMap[request.Status.Value])
                {
                    request.StatusIndicator = "1";
                    request.Status = Status.NORMAL;
                }
                else if (accountInquiryResponse.BlockCode2 == AccountBlockStatusMap.StatusBlockCodeMap[request.Status.Value])
                {
                    request.StatusIndicator = "2";
                    request.Status = Status.NORMAL;
                }
                else
                {
                    throw new BlockCodeMatchException("No matching block code to remove");
                }
            }

            return request;
        }

        private async Task ClearCache(UpdateAccountRequest request)
        {
            var cacheKey = _cacheKeyProvider.GetKey(request.CardAccountId);

            await _dataManager.RemoveAsync(cacheKey);
        }
    }
}