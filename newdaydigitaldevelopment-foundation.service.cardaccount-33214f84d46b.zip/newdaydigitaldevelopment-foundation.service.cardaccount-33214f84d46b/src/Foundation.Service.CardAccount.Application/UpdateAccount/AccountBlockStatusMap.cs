﻿using System.Collections.Generic;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.UpdateAccount;
using static NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.UpdateAccount.Status;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.UpdateAccount
{
    public static class AccountBlockStatusMap
    {
        public static readonly IDictionary<Status, string> StatusBlockCodeMap = new Dictionary<Status, string>
        {
            {NORMAL, ""},
            {COLHOLDOUT, "A"},
            {BAD_BUREAU, "B"},
            {CLOSED, "C"},
            {SUSPECTFRD, "D"},
            {NO_CONTACT, "E"},
            {FRAUD, "F"},
            {DEADPEND, "G"},
            {CONV_CLEAN, "H"},
            {PD36SPDFRZ, "I"},
            {COLLPEND, "J"},
            {FPP, "K"},
            {LOST, "L"},
            {MISSING_AP, "M"},
            {NFA, "N"},
            {FAIR_TRMNT, "O"},
            {DECEASED, "P"},
            {VIP, "Q"},
            {CLOSEDBYUS, "R"},
            {MC_DAT_COM, "S"},
            {COMP_SERV, "T"},
            {DCA, "U"},
            {NO_AUTH, "V"},
            {RUNAWAY, "W"},
            {CHARGE_OFF_NON_CREDIT, "X"},
            {CHROFFFRD, "Y"},
            {CHARGE_OFF_CREDIT, "Z"}
        };
    }
}
