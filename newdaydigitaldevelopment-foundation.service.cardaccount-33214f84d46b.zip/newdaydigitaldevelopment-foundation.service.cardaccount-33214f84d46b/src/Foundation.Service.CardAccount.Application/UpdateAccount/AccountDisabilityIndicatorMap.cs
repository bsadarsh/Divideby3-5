﻿using System.Collections.Generic;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.UpdateAccount;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.UpdateAccount
{
    public static class AccountDisabilityIndicatorMap
    {
        public static readonly IDictionary<DisabilityIndicator, string> DisabilityIndicatorMap = new Dictionary<DisabilityIndicator, string>
        {
            {DisabilityIndicator.Audio, "A"},
            {DisabilityIndicator.Braille, "B"},
            {DisabilityIndicator.CDROM, "C"},
            {DisabilityIndicator.HardOfHearing, "H"},
            {DisabilityIndicator.LargePrint, "L"},
            {DisabilityIndicator.PlainPrint, "P"}
        };
    }
}