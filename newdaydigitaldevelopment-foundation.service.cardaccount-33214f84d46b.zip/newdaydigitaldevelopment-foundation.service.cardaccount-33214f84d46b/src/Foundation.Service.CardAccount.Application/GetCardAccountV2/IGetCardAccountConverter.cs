﻿using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v2.GetCardAccount;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetCardAccountV2
{
    public interface IGetCardAccountConverter
    {
        AccountDetailInquiryRequest3 ToAccountDetailInquiryRequestV3(GetCardAccountRequest request);

        GetCardAccountResponse ToGetCardAccountResponseV2(AccountDetailInquiryResponse3 response);
    }
}
