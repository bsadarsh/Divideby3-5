﻿using System;
using System.Linq;
using Microsoft.Extensions.Logging;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Extensions;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v2.GetCardAccount;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Entities.v2;
using NewDay.Digital.Foundation.Core.Utils;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;
using DomainCardAccountV2 = NewDay.Digital.Foundation.Core.Domain.CardAccount.Entities.v2.CardAccount;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetCardAccountV2
{
    public class GetCardAccountConverter : IGetCardAccountConverter
    {
        private readonly IBrandHelper _brandHelper;
        private readonly ILogger<GetCardAccountConverter> _logger;

        public GetCardAccountConverter(IBrandHelper brandHelper, ILogger<GetCardAccountConverter> logger)
        {
            _brandHelper = brandHelper;
            _logger = logger.ArgNotNull(nameof(logger));
        }

        public AccountDetailInquiryRequest3 ToAccountDetailInquiryRequestV3(GetCardAccountRequest request)
        {
            var cardAccountId = request.CardAccountId;
            var brand = _brandHelper.GetBrandFromAccountNumber(cardAccountId);

            return new AccountDetailInquiryRequest3(brand.ClientNumber)
            {
                Account = cardAccountId
            };
        }
        
        public GetCardAccountResponse ToGetCardAccountResponseV2(AccountDetailInquiryResponse3 response)
        {
            if (response == null)
                return null;

            var decimalPositions = Convert.ToInt16(response.CurrencyNod);
            var naDataFirst = response.NaData.First();

            var account = new DomainCardAccountV2
            {
                AccountNumber = response.Account,
                Status = GetStatusByIntStatus(response.IntStatus),
                SubStatus = GetSubStatusByResponse(response),
                OpenDate = response.DateOpened.DateTimeFromFDDateString().GetValueOrDefault(),
                AvailableCredit = response.AvailCredit.DecimalFromFDAmountString(decimalPositions),
                CreditLimit = response.Crlim.DecimalFromFDAmountString(decimalPositions),
                CurrentBalance = response.CurrBal.DecimalFromFDAmountString(decimalPositions),
                BnplBalance = response.CurrBnplBal.DecimalFromFDAmountString(decimalPositions),
                NonBnplBalance = response.CurrNonBnplBal.DecimalFromFDAmountString(decimalPositions),
                CurrentPaymentDue = response.PmtCurrDue.DecimalFromFDAmountString(decimalPositions),
                ArrearAmount = response.PmtPastDue.DecimalFromFDAmountString(decimalPositions),
                PaymentRequested = response.RpdAmount.DecimalFromFDAmountString(decimalPositions),
                LastPaymentAmount = response.PmtLastAmt.DecimalFromFDAmountString(decimalPositions),
                PaymentDueDate = CardAccountUtils.ConvertToDateTime(_logger, response.DatePmtDue, nameof(DomainCardAccountV2.PaymentDueDate)),
                LastStatementBalance = response.PsLastStmtBal.DecimalFromFDAmountString(decimalPositions),
                LastStatementDate = CardAccountUtils.ConvertToDateTime(_logger, response.DateLastStmt, nameof(DomainCardAccountV2.LastStatementDate)),
                NextStatementDate = CardAccountUtils.ConvertToDateTime(_logger, response.DateNextStmt, nameof(DomainCardAccountV2.NextStatementDate)),
                LastPaymentDate = response.DateLastPmt.DateTimeFromFDDateString().GetValueOrDefault(),
                CycleDue = response.PmtCycleDue,
                DirectDebitStatus = response.PmtAch,
                AccountHolder = new AccountHolder
                {
                    Title = naDataFirst.Title,
                    FirstName = naDataFirst.FirstName,
                    MiddleName = naDataFirst.MidName,
                    LastName = naDataFirst.LastName,
                    DateOfBirth = naDataFirst.Dob.DateTimeFromFDDateString().GetValueOrDefault()
                },
                Address = new Address
                {
                    HouseNumber = naDataFirst.HouseNumber,
                    AddressLine1 = naDataFirst.Addr1,
                    AddressLine2 = naDataFirst.Addr2,
                    AddressLine3 = naDataFirst.Addr3,
                    City = naDataFirst.CityState,
                    PostCode = naDataFirst.ZipCode,
                    CountryCode = naDataFirst.CntryCd
                },
                ContactDetails = new ContactDetails
                {
                    Email = naDataFirst.Email,
                    MobileNumber = naDataFirst.MobPhone,
                    HomePhoneNumber = naDataFirst.HomePhone,
                    WorkPhoneNumber = naDataFirst.EmpPhone
                },
                PersistentDebt = new PersistentDebt()
            };

            var getCardAccountResponse = new GetCardAccountResponse {Account = account};

            return getCardAccountResponse;
        }

        #region Private methods

        private CardAccountStatus GetStatusByIntStatus(string intStatus)
        {
            switch (intStatus)
            {
                case "D":
                    return CardAccountStatus.Dormant;

                case "8":
                case "9":
                    return CardAccountStatus.Closed;

                case "A":
                    return CardAccountStatus.Active;

                default:
                    return CardAccountStatus.Unavailable;
            }
        }

        private CardAccountSubStatus? GetSubStatusByResponse(AccountDetailInquiryResponse3 response)
        {
            var blockCode = CardAccountUtils.GetProperBlockCode(response);
            var subStatus = GetSubStatusByBlockCode(blockCode);
            return subStatus;
        }

        private CardAccountSubStatus? GetSubStatusByBlockCode(string blockCode)
        {
            if (String.IsNullOrWhiteSpace(blockCode))
                return CardAccountSubStatus.Normal;

            switch (blockCode)
            {
                case "G":
                    return CardAccountSubStatus.DeceasedPending;

                case "Y":
                    return CardAccountSubStatus.ChargeOffFraud;

                case "Z":
                    return CardAccountSubStatus.ChargeOffCollections;

                case "A":
                    return CardAccountSubStatus.Collections;

                case "D":
                    return CardAccountSubStatus.SuspectedFraud;

                case "F":
                    return CardAccountSubStatus.ConfirmedFraud;

                case "W":
                    return CardAccountSubStatus.NoContact;

                case "R":
                    return CardAccountSubStatus.ClosedByBusiness;

                case "I":
                    return CardAccountSubStatus.PersistentDebtSpendFreeze;

                default:
                    return null;
            }
        }

        #endregion Private methods
    }
}
