﻿using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetSpendCap;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetSpendCap
{
    public interface IGetSpendCapConverter
    {
        AccountDetailInquiryRequest3 ToAccountDetailInquiryRequest(GetSpendCapRequest request);
        GetSpendCapResponse ToGetSpendCapResponse(AccountDetailInquiryResponse3 fdResponse);
    }
}