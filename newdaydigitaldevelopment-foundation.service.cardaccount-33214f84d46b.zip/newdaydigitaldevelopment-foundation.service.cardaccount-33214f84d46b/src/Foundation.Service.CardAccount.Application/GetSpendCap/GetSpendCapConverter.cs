﻿using System;
using System.Linq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetSpendCap;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.SetSpendCap;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Constants;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetSpendCap
{
    public class GetSpendCapConverter : IGetSpendCapConverter
    {
        private readonly IBrandHelper _brandHelper;

        private static readonly GetSpendCapResponse SpendCapDisabledResponse = new GetSpendCapResponse
        {
            SpendCapEnabled = false,
            SpendCapType = SpendCapType.None
        };

        public GetSpendCapConverter(IBrandHelper brandHelper)
        {
            _brandHelper = brandHelper ?? throw new ArgumentNullException(nameof(brandHelper));
        }

        public AccountDetailInquiryRequest3 ToAccountDetailInquiryRequest(GetSpendCapRequest request)
        {
            var brand = _brandHelper.GetBrandFromAccountNumber(request.CardAccountId);
            if (brand == null)
            {
                throw new InvalidBrandException();
            }

            return new AccountDetailInquiryRequest3(brand.ClientNumber)
            {
                Account = request.CardAccountId
            };
        }

        public GetSpendCapResponse ToGetSpendCapResponse(AccountDetailInquiryResponse3 fdResponse)
        {
            var isSpendCapEnabled = FirstDataConstants.SpendCapDisabledAlert != fdResponse.SpndLmtAlert;
            
            if (!isSpendCapEnabled)
            {
                return SpendCapDisabledResponse;
            }

            var currentCycleSpentAmount = CurrentCycleSpentAmount(fdResponse);
            var spendCapExceededAmount = PenniesToPounds(SpendCapExceededAmount(fdResponse, currentCycleSpentAmount));
            var spendCapReached = spendCapExceededAmount > 0;

            return new GetSpendCapResponse()
            {
                SpendCapType = SpendCapMapper.MapSpendCapIndToEnum(fdResponse.SpendCapInd),
                SpendCapEnabled = true,
                SpendCapAmount = int.Parse(fdResponse.SpndLmtAmt),
                SpendCapReached = spendCapReached,
                SpendCapExceededAmount = spendCapExceededAmount
            };
        }

        private static decimal PenniesToPounds(long input)
        {
            return input * 0.01m;
        }

        private static long PoundsToPennies(string input)
        {
            return long.Parse(input + "00");
        }

        private static long CurrentCycleSpentAmount(AccountDetailInquiryResponse3 response)
        {
            long spentAmount = 0;

            foreach (var element in response.AtmOtcQsiRtlAccum)
            {
                var list = element.DlyCtdYtdLtd.ToList();

                //we need 'cycle to date' value which is second element of the list
                spentAmount += long.Parse(list[1].AuthAmtAccum);
            }

            return spentAmount;
        }

        private static long SpendCapExceededAmount(AccountDetailInquiryResponse3 response, long spentAmount)
        {
            var spendLimitAmount = PoundsToPennies(response.SpndLmtAmt);

            return Math.Max(spentAmount - spendLimitAmount, 0);
        }
    }
}