﻿using System;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetSpendCap;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Cache;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;

namespace NewDay.Digital.Foundation.Service.CardAccount.Application.GetSpendCap
{
    public class GetSpendCapService : IExecutable<GetSpendCapRequest, DataManagerResponse<GetSpendCapResponse>>
    {
        private readonly IGetSpendCapConverter _converter;
        private readonly IAccountManagementApiClient _accountManagementApiClient;
        private readonly IDataManager _dataManager;
        private readonly TimeSpan _cacheTime;
        private readonly IAccountDetailInquiryCacheKeyProvider _cacheKeyProvider;

        public GetSpendCapService(IGetSpendCapConverter converter, IAccountManagementApiClient accountManagementApiClient,
            IDataManager dataManager, ITimeoutProvider timeoutProvider, IAccountDetailInquiryCacheKeyProvider cacheKeyProvider)
        {
            _converter = converter ?? throw new ArgumentNullException(nameof(converter));
            _accountManagementApiClient = accountManagementApiClient ?? throw new ArgumentNullException(nameof(accountManagementApiClient));
            _dataManager = dataManager ?? throw new ArgumentNullException(nameof(dataManager));
            _cacheTime = timeoutProvider.Timeout;
            _cacheKeyProvider = cacheKeyProvider ?? throw new ArgumentNullException(nameof(cacheKeyProvider));
        }

        public async Task<DataManagerResponse<GetSpendCapResponse>> ExecuteAsync(GetSpendCapRequest request)
        {
            var fdRequest = _converter.ToAccountDetailInquiryRequest(request);

            var cacheKey = _cacheKeyProvider.GetKey(request.CardAccountId);
            var dataManagerResponse = await _dataManager.FetchWithCacheAsync(cacheKey, _cacheTime,
                async () => await _accountManagementApiClient.AccountDetailInquiryAsync(fdRequest));
            var domainResponse = _converter.ToGetSpendCapResponse(dataManagerResponse.Value);

            return new DataManagerResponse<GetSpendCapResponse>(
                domainResponse, dataManagerResponse.CacheAge, dataManagerResponse.CacheLifetime);
        }
    }
}