﻿using System.Net;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;
using NewDay.Digital.Foundation.Core.HealthCheck.Extensions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Extensions;
using System.Net.Http;
using System.Text;
using NewDay.Digital.Foundation.Core.Azure.Function.ServiceErrors;
using NewDay.Digital.Foundation.Service.CardAccount.Functions.Helpers;

[assembly: FunctionsStartup(typeof(NewDay.Digital.Foundation.Service.CardAccount.Functions.Startup))]

namespace NewDay.Digital.Foundation.Service.CardAccount.Functions
{
    internal class Startup : FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)
        {
            ConfigureServices(builder.Services);
        }

        private static void ConfigureServices(IServiceCollection serviceCollection)
        {
            serviceCollection.AddLogging();
            serviceCollection.AddApplication(
                EnvironmentVariablesHelper.RedisConnectionString,
                EnvironmentVariablesHelper.CacheTimeInSeconds);
            serviceCollection.AddHealthChecks(c =>
            {
                c.AddSelfCheck("Function is OK!");

                c.AddFdUrlCheck("v3/accountDetailInquiry is OK!", options =>
                {
                    options.BaseAddress = EnvironmentVariablesHelper.FirstDataApiBaseAddress;
                    options.MsiAdApplicationId = EnvironmentVariablesHelper.FirstDataApiResourceIdentifier;
                }, "v3/accountDetailInquiry", new StringContent(EnvironmentVariablesHelper.HealthCheckDataAccountInquiryRequest, Encoding.UTF8, "application/json"));

                c.AddFdUrlCheck("v1/monetaryAction is OK!", options =>
                {
                    options.BaseAddress = EnvironmentVariablesHelper.FirstDataApiBaseAddress;
                    options.MsiAdApplicationId = EnvironmentVariablesHelper.FirstDataApiResourceIdentifier;

                    /*
                        We only need to check connectivity to the FiServe endpoint. 
                        So we send a request that we know should fail, and as long as we get a 4XX back from FiServe we're good.
                     */
                    options.HealthyHttpStatusCode = (HttpStatusCode)465;
                }, "v1/monetaryAction", new StringContent(EnvironmentVariablesHelper.HealthCheckDataMonetaryActionRequest, Encoding.UTF8, "application/json"));

                c.AddRedisCheck("Redis is OK!");
            });

            serviceCollection.AddSingleton<IServiceErrorConverter, ServiceErrorConverter>();
        }
    }
}
