﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NewDay.Digital.Foundation.Connector.FirstData.Exceptions;
using NewDay.Digital.Foundation.Core.Azure.Function.Extensions;
using NewDay.Digital.Foundation.Core.Azure.Function.Functions;
using NewDay.Digital.Foundation.Core.Azure.Function.Models;
using NewDay.Digital.Foundation.Core.Azure.Function.ServiceErrors;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.PostGoodwill;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.RemoveFee;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.ReturnFunds;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.SetSpendCap;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Functions.Validators;

namespace NewDay.Digital.Foundation.Service.CardAccount.Functions
{
    public class FunctionEndpoint<TFuncRequest, TFuncResponse> : FunctionEndpointBase<TFuncRequest> where TFuncRequest : class, new()
    {
        private readonly string _functionName;
        private readonly IExecutable<TFuncRequest, DataManagerResponse<TFuncResponse>> _executable;

        public FunctionEndpoint(string functionName, IExecutable<TFuncRequest, DataManagerResponse<TFuncResponse>> executable, IServiceErrorConverter serviceErrorConverter,
            ILogger logger)
            : base(serviceErrorConverter, logger)
        {
            _functionName = functionName;
            _executable = executable;
        }

        protected override async Task<IActionResult> ExecuteAsync(TFuncRequest request)
        {
            try
            {
                Logger.LogInformation($"{_functionName} function processed a request.");

                if (!request.TryValidateObject(out var results))
                {
                    return new BadRequestObjectResult(
                        ServiceErrorConverter.ConvertToServiceError(ErrorOrigin.NewDay, results));
                }

                var response = await _executable.ExecuteAsync(request);

                if (response.IsFromCache)
                {
                    return new CachedObjectResult<TFuncResponse>(response);
                }

                return new OkObjectResult(response.Value);
            }
            catch (Exception ex) when (ex is AccountNotFoundException || ex is CardNotFoundException)
            {
                return new NotFoundResult();
            }
            catch (SpendCapLimitGreaterThanCreditLimitException)
            {
                var results = new[]
                {
                    new ValidationResult(SpendCapLimitGreaterThanCreditLimitException.ErrorMessage,
                        new[] {nameof(SetSpendCapRequest.CapAmount)})
                };
                return new BadRequestObjectResult(
                    ServiceErrorConverter.ConvertToServiceError(ErrorOrigin.NewDay, results));
            }
            catch (AccountBlockStatusAndSubStatusInvalidCombinationException ex)
            {
                var results = new[]
                    {new ValidationResult(ex.Message, new[] {nameof(UpdateAccountBlockStatusRequest.SubStatus)})};
                return new BadRequestObjectResult(
                    ServiceErrorConverter.ConvertToServiceError(ErrorOrigin.NewDay, results));
            }
            catch (PlanNumberNotFoundException ex)
            {
                var results = new[] {new ValidationResult(ex.Message, new[] {nameof(RemoveFeeRequest.PlanNumber)})};
                return new BadRequestObjectResult(
                    ServiceErrorConverter.ConvertToServiceError(ErrorOrigin.NewDay, results));
            }
            catch (RetailPlanNotFoundException ex)
            {
                var results = new[]
                    {new ValidationResult(ex.Message, new[] {nameof(PostGoodwillRequest.CardAccountId)})};
                return new BadRequestObjectResult(
                    ServiceErrorConverter.ConvertToServiceError(ErrorOrigin.NewDay, results));
            }
            catch (AccountNumberNotFoundInBrandDbException ex)
            {
                var results = new[]
                    {new ValidationResult(ex.Message, new[] {nameof(ReturnFundsRequest.CardAccountId)})};
                return new BadRequestObjectResult(
                    ServiceErrorConverter.ConvertToServiceError(ErrorOrigin.NewDay, results));
            }
            catch (EmptyUpdateAccountRequestException ex)
            {
                var results = new[] {new ValidationResult(ex.Message)};
                return new BadRequestObjectResult(
                    ServiceErrorConverter.ConvertToServiceError(ErrorOrigin.NewDay, results));
            }
            catch (BlockCodeMatchException ex)
            {
                var results = new[] {new ValidationResult(ex.Message)};
                return new BadRequestObjectResult(
                    ServiceErrorConverter.ConvertToServiceError(ErrorOrigin.NewDay, results));
            }
            catch (NoPaymentHolidaySetException ex)
            {
                var results = new[] {new ValidationResult(ex.Message)};
                return new BadRequestObjectResult(
                    ServiceErrorConverter.ConvertToServiceError(ErrorOrigin.NewDay, results));
            }
            catch (InvalidReAgeRequestValuesException ex)
            {
                var results = new[] {new ValidationResult(ex.Message)};
                return new BadRequestObjectResult(
                    ServiceErrorConverter.ConvertToServiceError(ErrorOrigin.NewDay, results));
            }
            catch (AccountRecalculationException ex)
            {
                var results = new[] {new ValidationResult(ex.Message)};
                return new BadRequestObjectResult(
                    ServiceErrorConverter.ConvertToServiceError(ErrorOrigin.NewDay, results));
            }
            catch (EligibleBalanceExceededException ex)
            {
                var results = new[] {new ValidationResult(ex.Message)};
                return new BadRequestObjectResult(
                    ServiceErrorConverter.ConvertToServiceError(ErrorOrigin.NewDay, results));
            }
            catch (InstallmentPlanMatchException ex)
            {
                var results = new[] {new ValidationResult(ex.Message)};
                return new BadRequestObjectResult(
                    ServiceErrorConverter.ConvertToServiceError(ErrorOrigin.NewDay, results));
            }
            catch (NoPlanFoundException ex)
            {
                var results = new[] { new ValidationResult(ex.Message) };
                return new BadRequestObjectResult(
                    ServiceErrorConverter.ConvertToServiceError(ErrorOrigin.NewDay, results));
            }
            catch (FirstDataApiException ex) when (!string.IsNullOrEmpty(ex.ResponseStatus.ErrorCode))
            {
                var response = ServiceErrorConverter.CreateServiceError(ErrorOrigin.FirstData, ex.ResponseStatus.Message, ex.ResponseStatus.ErrorCode);
                if (response.Errors.Any(n => n.ErrorCode.Contains('S')) &&
                    response.Errors.All(x => x.ErrorMessage != "Backend request failed VPE8SE CREDIT PLAN RECORD NOT FOUND OR IN ADD PENDING STATUS"))
                {
                    Logger.LogError(ex, ex.Message);
                    return new InternalServerErrorObjectResult(response);
                }

                Logger.LogWarning(ex, ex.Message);
                return new BadRequestObjectResult(response);
            }
            catch (Exception ex) when (ExceptionValidator.IsValidationException(ex))
            {
                Logger.LogWarning(ex, ex.Message);
                return new BadRequestResult();
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, ex.Message);
                return new InternalServerErrorResult();
            }
        }
    }
}