﻿
using Microsoft.Azure.WebJobs.Hosting;
using NewDay.Digital.Foundation.Service.CardAccount.Functions;
using System.Runtime.CompilerServices;

[assembly: WebJobsStartup(typeof(Startup))]
[assembly: InternalsVisibleTo("Foundation.Service.CardAccount.Tests.Integration")]
[assembly: InternalsVisibleTo("Foundation.Service.CardAccount.Tests.Unit")]