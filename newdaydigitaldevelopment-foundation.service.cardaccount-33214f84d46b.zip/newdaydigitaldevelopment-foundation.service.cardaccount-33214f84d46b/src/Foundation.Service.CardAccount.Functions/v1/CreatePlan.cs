﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using NewDay.Digital.Foundation.Core.Azure.Function.ServiceErrors;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.CreatePlan;

namespace NewDay.Digital.Foundation.Service.CardAccount.Functions.v1
{
    public class CreatePlan : FunctionEndpoint<CreatePlanRequest, CreatePlanResponse>
    {
        public CreatePlan(
            IExecutable<CreatePlanRequest, DataManagerResponse<CreatePlanResponse>> executable,
            IServiceErrorConverter serviceErrorConverter,
            ILogger<CreatePlan> logger) : base(nameof(CreatePlan), executable, serviceErrorConverter, logger)
        {
        }

        [FunctionName(nameof(CreatePlan))]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "POST", Route = "v1/createPlan")]
            HttpRequest request)
        {
            return await RunAsync(request);
        }
    }
}
