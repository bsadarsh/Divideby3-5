﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using NewDay.Digital.Foundation.Core.Azure.Function.ServiceErrors;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.RemoveFee;

namespace NewDay.Digital.Foundation.Service.CardAccount.Functions.v1
{
    public class RemoveFee : FunctionEndpoint<RemoveFeeRequest, RemoveFeeResponse>
    {
        public RemoveFee(
            IExecutable<RemoveFeeRequest, DataManagerResponse<RemoveFeeResponse>> executable,
            IServiceErrorConverter serviceErrorConverter,
            ILogger<RemoveFee> logger) : base(nameof(RemoveFee), executable, serviceErrorConverter, logger)
        {
        }


        [FunctionName(nameof(RemoveFee))]
        public async Task<IActionResult> Run(
            [HttpTriggerAttribute(AuthorizationLevel.Anonymous, "POST", Route = "v1/RemoveFee")]
            HttpRequest request) => await RunAsync(request);
    }
}