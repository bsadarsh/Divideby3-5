using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using NewDay.Digital.Foundation.Connector.FirstData.AccountActivityUpdates.v1.Models;
using NewDay.Digital.Foundation.Core.Azure.Function.ServiceErrors;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;

namespace NewDay.Digital.Foundation.Service.CardAccount.Functions.v1
{
    public class CreateMemo : FunctionEndpoint<CreateCardAccountMemoRequest, MemoAddResponse>
    {
        public CreateMemo(
            IExecutable<CreateCardAccountMemoRequest, DataManagerResponse<MemoAddResponse>> executable,
            IServiceErrorConverter serviceErrorConverter,
            ILogger<CreateMemo> logger) : base(nameof(CreateMemo), executable, serviceErrorConverter, logger)
        {
        }

        [FunctionName(nameof(CreateMemo))]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "POST", Route = "v1/createMemo")] HttpRequest request)
        {
            return await RunAsync(request);
        }
    }
}
