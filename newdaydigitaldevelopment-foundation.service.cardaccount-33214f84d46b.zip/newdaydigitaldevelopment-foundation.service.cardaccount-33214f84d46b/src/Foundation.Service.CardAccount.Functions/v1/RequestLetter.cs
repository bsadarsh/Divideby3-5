﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using NewDay.Digital.Foundation.Core.Azure.Function.ServiceErrors;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.RequestLetter;

namespace NewDay.Digital.Foundation.Service.CardAccount.Functions.v1
{
    public class RequestLetter : FunctionEndpoint<RequestLetterRequest, RequestLetterResponse>
    {
        public RequestLetter(
            IExecutable<RequestLetterRequest, DataManagerResponse<RequestLetterResponse>> executable,
            IServiceErrorConverter serviceErrorConverter,
            ILogger<RequestLetterRequest> logger) : base(nameof(RequestLetter), executable, serviceErrorConverter, logger)
        {
        }

        [FunctionName(nameof(RequestLetter))]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "POST", Route = "v1/RequestLetter")] HttpRequest request)
        {
            return await RunAsync(request);
        }
    }
}