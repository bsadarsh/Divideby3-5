﻿using System;
using System.Data;
using NewDay.Digital.Foundation.Connector.FirstData.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using Newtonsoft.Json;

namespace NewDay.Digital.Foundation.Service.CardAccount.Functions.Validators
{
    internal static class ExceptionValidator
    {
        public static bool IsValidationException(Exception exception)
        {
            return exception is ValidationException || exception is DataException || exception is JsonException;
        }
    }
}
