﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using NewDay.Digital.Foundation.Connector.FirstData.Extensions;
using NewDay.Digital.Foundation.Core.HealthCheck.Services;

namespace NewDay.Digital.Foundation.Service.CardAccount.Functions
{
    public class HealthCheck
    {
        private readonly IHealthCheckService _healthCheckService;

        public HealthCheck(IHealthCheckService healthCheckService)
        {
            _healthCheckService = healthCheckService;
        }

        [FunctionName(nameof(HealthCheck))]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "GET", Route = "HealthCheck")] HttpRequest req,
            ILogger logger)
        {
            logger.LogIfEnabled(LogLevel.Debug, () => "HealthCheck in progress...");
            var result = await _healthCheckService.CheckAll();
            logger.LogIfEnabled(LogLevel.Debug, () => "HealthCheck done");
            return new OkObjectResult(result);
        }
    }
}
