﻿using System;
using NewDay.Digital.Foundation.Core.Security;

namespace NewDay.Digital.Foundation.Service.CardAccount.Functions.Helpers
{
    internal static class EnvironmentVariablesHelper
    {
        public static TimeSpan CacheTimeInSeconds => TimeSpan.FromSeconds(Convert.ToInt32(EnvironmentVariables.Get("CacheTimeInSeconds")));

        public static string RedisConnectionString => EnvironmentVariables.Get("Redis::ConnectionString");
        
        public static string FirstDataApiBaseAddress => EnvironmentVariables.Get("FirstData::ApiBaseAddress");
        
        public static string FirstDataApiResourceIdentifier => EnvironmentVariables.Get("FirstData::ApiResourceIdentifier");
        
        public static string HealthCheckDataAccountInquiryRequest => EnvironmentVariables.Get("HealthCheckData::AccountInquiryRequest");
        
        public static string HealthCheckDataMonetaryActionRequest => EnvironmentVariables.Get("HealthCheckData::MonetaryActionRequest");
    }
}
