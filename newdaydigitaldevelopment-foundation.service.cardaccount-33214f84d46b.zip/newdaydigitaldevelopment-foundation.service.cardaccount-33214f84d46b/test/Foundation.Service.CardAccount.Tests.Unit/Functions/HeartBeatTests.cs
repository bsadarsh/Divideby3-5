﻿using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using NewDay.Digital.Foundation.Service.CardAccount.Functions;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Functions
{
    public class HeartBeatTests
    {
        [Fact]
        public void Should_return_ok_object_result()
        {
            var loggerMock = new Mock<ILogger>();

            var result = HeartBeat.Run(null, loggerMock.Object);

            result.Should().BeOfType<OkObjectResult>();
            ((OkObjectResult)result).Value.Should().Be("OK");
        }
    }
}
