﻿using System.Threading.Tasks;
using AutoFixture;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using NewDay.Digital.Foundation.Core.HealthCheck.Models;
using NewDay.Digital.Foundation.Core.HealthCheck.Services;
using NewDay.Digital.Foundation.Service.CardAccount.Functions;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Functions
{
    public class HealthCheckTests
    {
        [Fact]
        public async Task Should_return_ok_object_result()
        {
            var healthCheckResult = new Fixture().Create<CompositeHealthCheckResult>();

            var healthCheckService = new Mock<IHealthCheckService>();
            healthCheckService.Setup(n => n.CheckAll())
                .ReturnsAsync(healthCheckResult);
            var loggerMock = new Mock<ILogger>();
            var healthCheckFunction = new HealthCheck(healthCheckService.Object);
            var result = await healthCheckFunction.Run(null, loggerMock.Object);

            result.Should().BeOfType<OkObjectResult>();
            ((OkObjectResult)result).Value.Should().BeEquivalentTo(healthCheckResult);
        }
    }
}
