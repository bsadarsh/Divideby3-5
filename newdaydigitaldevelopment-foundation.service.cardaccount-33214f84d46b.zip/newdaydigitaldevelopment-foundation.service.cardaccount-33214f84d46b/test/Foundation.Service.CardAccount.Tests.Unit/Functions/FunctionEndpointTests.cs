﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Threading.Tasks;
using System.Web.Http;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.Exceptions;
using NewDay.Digital.Foundation.Connector.FirstData.Models;
using NewDay.Digital.Foundation.Core.Azure.Function.Models;
using NewDay.Digital.Foundation.Core.Azure.Function.ServiceErrors;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Functions;
using Newtonsoft.Json;
using Xunit;
using ValidationException = NewDay.Digital.Foundation.Connector.FirstData.Exceptions.ValidationException;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Functions
{
    public class FunctionEndpointTests
    {
        private readonly Mock<ILogger> _loggerMock;
        private readonly Mock<IExecutable<FuncRequest, DataManagerResponse<FuncResponse>>> _serviceMock;

        public FunctionEndpointTests()
        {
            _loggerMock = new Mock<ILogger>();
            _serviceMock = new Mock<IExecutable<FuncRequest, DataManagerResponse<FuncResponse>>>();
        }

        [Fact]
        public async Task Should_return_ok_object_result()
        {
            var response = new DataManagerResponse<FuncResponse>();
            _serviceMock
                .Setup(x => x.ExecuteAsync(It.IsAny<FuncRequest>()))
                .ReturnsAsync(response);

            var sut = new FunctionEndpoint<FuncRequest, FuncResponse>("test", _serviceMock.Object, null, _loggerMock.Object);
            var httpRequest = HttpRequestHelper.CreateMockRequest(new FuncRequest());
            var actual = await sut.RunAsync(httpRequest.Object);
            actual.Should().BeOfType<OkObjectResult>();

            var okObjectResult = (OkObjectResult)actual;
            okObjectResult.Value.Should().Be(response.Value);
        }

        [Fact]
        public async Task Should_return_ok_cached_object_result()
        {
            var response = new DataManagerResponse<FuncResponse>(new FuncResponse(), DateTime.Now, TimeSpan.FromDays(1));

            _serviceMock
                .Setup(x => x.ExecuteAsync(It.IsAny<FuncRequest>()))
                .ReturnsAsync(response);

            var sut = new FunctionEndpoint<FuncRequest, FuncResponse>("test", _serviceMock.Object, null, _loggerMock.Object);
            var httpRequest = HttpRequestHelper.CreateMockRequest(new FuncRequest());
            var actual = await sut.RunAsync(httpRequest.Object);
            actual.Should().BeOfType<CachedObjectResult<FuncResponse>>();

            var okObjectResult = (CachedObjectResult<FuncResponse>)actual;
            okObjectResult.Value.Should().Be(response.Value);
        }

        [Fact]
        public async Task Should_return_bad_request_object_result_when_data_annotation_validation_failes()
        {
            var funcRequest = new FuncRequest
            {
                TestInt = -1
            };

            var sut = new FunctionEndpoint<FuncRequest, FuncResponse>("test", _serviceMock.Object, new ServiceErrorConverter(), _loggerMock.Object);
            var httpRequest = HttpRequestHelper.CreateMockRequest(funcRequest);
            var actual = await sut.RunAsync(httpRequest.Object);
            actual.Should().BeOfType<BadRequestObjectResult>();
        }

        [Theory]
        [InlineData("D003")]
        [InlineData("F003")]
        public async Task Should_return_bad_request_object_result_when_command_throws_first_data_api_exception_with_error_code(string errorCode)
        {
            var responseStatus = new ResponseStatus
            {
                ErrorCode = errorCode
            };

            _serviceMock
                .Setup(x => x.ExecuteAsync(It.IsAny<FuncRequest>()))
                .ThrowsAsync(new FirstDataApiException(responseStatus));

            var sut = new FunctionEndpoint<FuncRequest, FuncResponse>("test", _serviceMock.Object, new ServiceErrorConverter(), _loggerMock.Object);
            var httpRequest = HttpRequestHelper.CreateMockRequest(new FuncRequest());
            var actual = await sut.RunAsync(httpRequest.Object);

            actual.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task Should_return_internal_server_error_object_result_when_command_throws_first_data_api_exception_with_error_code()
        {
            var responseStatus = new ResponseStatus
            {
                ErrorCode = "S003"
            };

            _serviceMock
                .Setup(x => x.ExecuteAsync(It.IsAny<FuncRequest>()))
                .ThrowsAsync(new FirstDataApiException(responseStatus));

            var sut = new FunctionEndpoint<FuncRequest, FuncResponse>("test", _serviceMock.Object, new ServiceErrorConverter(), _loggerMock.Object);
            var httpRequest = HttpRequestHelper.CreateMockRequest(new FuncRequest());
            var actual = await sut.RunAsync(httpRequest.Object);

            actual.Should().BeOfType<InternalServerErrorObjectResult>();
        }

        [Fact]
        public async Task Should_return_not_found_result_when_command_throw_account_not_found_exception()
        {
            _serviceMock
                .Setup(x => x.ExecuteAsync(It.IsAny<FuncRequest>()))
                .ThrowsAsync(new AccountNotFoundException(new ResponseStatus()));

            var sut = new FunctionEndpoint<FuncRequest, FuncResponse>("test", _serviceMock.Object, null, _loggerMock.Object);
            var httpRequest = HttpRequestHelper.CreateMockRequest(new FuncRequest());
            var actual = await sut.RunAsync(httpRequest.Object);
            actual.Should().BeOfType<NotFoundResult>();
        }

        [Fact]
        public async Task Should_return_bad_request_result_when_command_throw_data_exception()
        {
            _serviceMock
                .Setup(x => x.ExecuteAsync(It.IsAny<FuncRequest>()))
                .ThrowsAsync(new DataException());

            var sut = new FunctionEndpoint<FuncRequest, FuncResponse>("test", _serviceMock.Object, null, _loggerMock.Object);
            var httpRequest = HttpRequestHelper.CreateMockRequest(new FuncRequest());
            var actual = await sut.RunAsync(httpRequest.Object);
            actual.Should().BeOfType<BadRequestResult>();
        }

        [Fact]
        public async Task Should_return_bad_request_result_when_command_throw_connector_validation_exception()
        {
            _serviceMock
                .Setup(x => x.ExecuteAsync(It.IsAny<FuncRequest>()))
                .ThrowsAsync(new ValidationException(new ResponseStatus()));

            var sut = new FunctionEndpoint<FuncRequest, FuncResponse>("test", _serviceMock.Object, null, _loggerMock.Object);
            var httpRequest = HttpRequestHelper.CreateMockRequest(new FuncRequest());
            var actual = await sut.RunAsync(httpRequest.Object);
            actual.Should().BeOfType<BadRequestResult>();
        }

        [Fact]
        public async Task Should_return_bad_request_result_when_command_throw_json_exception()
        {
            _serviceMock
                .Setup(x => x.ExecuteAsync(It.IsAny<FuncRequest>()))
                .ThrowsAsync(new JsonException());

            var sut = new FunctionEndpoint<FuncRequest, FuncResponse>("test", _serviceMock.Object, null, _loggerMock.Object);
            var httpRequest = HttpRequestHelper.CreateMockRequest(new FuncRequest());
            var actual = await sut.RunAsync(httpRequest.Object);
            actual.Should().BeOfType<BadRequestResult>();
        }

        [Fact]
        public async Task Should_return_internal_server_error_when_command_throws_exception()
        {
            _serviceMock
                .Setup(x => x.ExecuteAsync(It.IsAny<FuncRequest>()))
                .ThrowsAsync(new Exception());

            var sut = new FunctionEndpoint<FuncRequest, FuncResponse>("test", _serviceMock.Object, null, _loggerMock.Object);
            var httpRequest = HttpRequestHelper.CreateMockRequest(new FuncRequest());
            var actual = await sut.RunAsync(httpRequest.Object);
            actual.Should().BeOfType<InternalServerErrorResult>();
        }

        [Fact]
        public async Task Should_return_bad_request_error_when_account_block_status_and_substatus_mismatch_exception_is_raised()
        {
            _serviceMock
                .Setup(x => x.ExecuteAsync(It.IsAny<FuncRequest>()))
                .ThrowsAsync(new AccountBlockStatusAndSubStatusInvalidCombinationException(""));

            var sut = new FunctionEndpoint<FuncRequest, FuncResponse>("test", _serviceMock.Object, new ServiceErrorConverter(), _loggerMock.Object);
            var httpRequest = HttpRequestHelper.CreateMockRequest(new FuncRequest());
            var actual = await sut.RunAsync(httpRequest.Object);

            actual.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task Should_return_bad_request_error_when_PlanNumberNotFoundException_is_raised()
        {
            _serviceMock
                .Setup(x => x.ExecuteAsync(It.IsAny<FuncRequest>()))
                .ThrowsAsync(new PlanNumberNotFoundException());

            var sut = new FunctionEndpoint<FuncRequest, FuncResponse>("test", _serviceMock.Object, new ServiceErrorConverter(), _loggerMock.Object);
            var httpRequest = HttpRequestHelper.CreateMockRequest(new FuncRequest());
            var actual = await sut.RunAsync(httpRequest.Object);

            actual.Should().BeOfType<BadRequestObjectResult>();
        }
    }

    public class FuncRequest
    {
        [Range(0, 10)]
        public int TestInt { get; set; }
    }

    public class FuncResponse
    {
    }
}