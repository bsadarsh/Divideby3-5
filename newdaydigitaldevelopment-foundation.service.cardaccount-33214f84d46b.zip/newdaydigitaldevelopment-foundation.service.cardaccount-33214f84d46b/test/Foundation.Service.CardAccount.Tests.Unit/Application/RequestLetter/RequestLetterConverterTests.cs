﻿using System;
using AutoFixture;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Letters.v2.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.RequestLetter;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.RequestLetter;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.RequestLetter
{
    public class RequestLetterConverterTests
    {
        [Fact]
        public void Should_throw_InvalidBrandException_for_invalid_card_account_number_on_LetterRequestRequest_conversion()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns((Brand)null)
                .Verifiable();

            var converter = new RequestLetterConverter(brandHelperMock.Object);

            Action act = () => converter.ToLetterRequestRequest(new RequestLetterRequest() { CardAccountId = "0000111122223333" });
            act.Should().Throw<InvalidBrandException>();
        }

        [Fact]
        public void Should_convert_request_letter_request_to_fd_request()
        {
            const string accountNumber = "0001234123412341234";
            const string letterCode = "409";
            const string org = "123";

            var domainRequest = new RequestLetterRequest()
            {
                CardAccountId = accountNumber,
                LetterCode = letterCode
            };

            var brand = new Fixture().Create<Brand>();

            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(brand)
                .Verifiable();

            var expectedRequest = new LetterRequestRequest2(brand.ClientNumber)
            {
                LetterCode = letterCode,
                LetterOrg = org,
                KiCmsSelect = "X",
                KiCmsAcct = accountNumber,
                KiCmsOrg = org
            };

            var converter = new RequestLetterConverter(brandHelperMock.Object);

            var fdRequest = converter.ToLetterRequestRequest(domainRequest);

            fdRequest.Should().BeEquivalentTo(expectedRequest);
        }
    }
}