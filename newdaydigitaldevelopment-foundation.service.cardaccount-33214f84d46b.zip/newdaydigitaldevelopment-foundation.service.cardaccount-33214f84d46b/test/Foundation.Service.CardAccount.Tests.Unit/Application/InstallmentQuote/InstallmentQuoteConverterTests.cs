﻿using System;
using AutoFixture;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Loans.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Loans.v2.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.InstallmentQuote;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.InstallmentQuote;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.InstallmentQuote
{
    public class InstallmentQuoteConverterTests
    {
        private Mock<IBrandHelper> GetBrandHelperMock()
        {
            var brand = new Fixture().Create<Brand>();

            var brandHelperMock = new Mock<IBrandHelper>();

            brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(brand)
                .Verifiable();

            return brandHelperMock;
        }

        [Fact]
        public void Should_throw_InvalidBrandException_for_invalid_card_account_number_on_fppQuoteGenerationRequest_conversion()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns((Brand)null)
                .Verifiable();

            var installmentQuoteRequest = new InstallmentQuoteRequest()
            {
                CardAccountId = "0000111122223333",
                Plan = "50900"
            };

            var matchingPlan = new PlanCtdData2ForAccountPlanList2()
            {
                FppAgrdPmtAmt = "1200",
                FppOrigTerm = "022"
            };

            var converter = new InstallmentQuoteConverter(brandHelperMock.Object);

            Action act = () => converter.ToFppQuoteGenerationRequest(installmentQuoteRequest, matchingPlan);
            act.Should().Throw<InvalidBrandException>();
        }

        [Fact]
        public void Should_convert_installment_quote_request_to_fd_request()
        {
            var brandHelperMock = GetBrandHelperMock();

            var domainRequest = new InstallmentQuoteRequest()
            {
                CardAccountId = "0000111122223333",
                Plan = "50900",
                FixedAmount = 12,
                TotalAmount = 300
            };

            var matchingPlan = new PlanCtdData2ForAccountPlanList2()
            {
                FppAgrdPmtAmt = "1200",
                FppOrigTerm = "22"
            };

            var converter = new InstallmentQuoteConverter(brandHelperMock.Object);

            var fdRequest = converter.ToFppQuoteGenerationRequest(domainRequest, matchingPlan);

            fdRequest.Acct.Should().Be("0000111122223333");
            fdRequest.FppPlan.Should().Be("50900");
            fdRequest.InitAmt.Should().Be("30000");
            fdRequest.EmiAmount.Should().Be("1200");
            fdRequest.OrigTerm.Should().Be("22");
            fdRequest.Common.Org.Should().Be("111");
        }

        [Fact]
        public void Should_convert_fd_response_to_installment_quote_response()
        {
            var brandHelperMock = GetBrandHelperMock();

            var fdResponse = new FppQuoteGenerationResponse()
            {
                FppFixedPmtAmt = "2222",
                FppTotalCost = "57906",
                FppEstInt = "2222",
                FppNbrOfPmts = "022",
                FppMthlyRate = "1122",
                FppCurrAer = "1122"
            };

            var converter = new InstallmentQuoteConverter(brandHelperMock.Object);

            var domainResponse = converter.ToInstallmentQuoteResponse(fdResponse);

            domainResponse.FixedAmount.Should().Be(22.22m);
            domainResponse.TotalCost.Should().Be(579.06m);
            domainResponse.InterestEstimated.Should().Be(22.22m);
            domainResponse.Terms.Should().Be(22);
            domainResponse.MonthlyRate.Should().Be(1122);
            domainResponse.AnnualRate.Should().Be(1122);
        }
    }
}