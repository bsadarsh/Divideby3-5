﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoFixture;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Loans.v2.Models;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.InstallmentQuote;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.InstallmentQuote;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.InstallmentQuote
{
    public class InstallmentQuoteServiceTests
    {
        private readonly IExecutable<InstallmentQuoteRequest, DataManagerResponse<InstallmentQuoteResponse>>
            _installmentQuoteService;

        private readonly Mock<Connector.FirstData.Loans.v1.ILoansApiClient> _loansApiClientV1Mock;
        private readonly Mock<Connector.FirstData.Loans.v2.ILoansApiClient> _loansApiClientV2Mock;

        public InstallmentQuoteServiceTests()
        {
            var brand = new Fixture().Create<Brand>();
            var brandHelperMock = new Mock<IBrandHelper>();

            brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(brand)
                .Verifiable();

            _loansApiClientV1Mock = new Mock<Connector.FirstData.Loans.v1.ILoansApiClient>();
            _loansApiClientV2Mock = new Mock<Connector.FirstData.Loans.v2.ILoansApiClient>();

            var converter = new InstallmentQuoteConverter(brandHelperMock.Object);

            var dataManagerMock = new Mock<IDataManager>();

            _installmentQuoteService =
                new InstallmentQuoteService(converter, _loansApiClientV1Mock.Object, _loansApiClientV2Mock.Object,
                    dataManagerMock.Object, new TimeoutProvider(TimeSpan.FromSeconds(1)));
        }

        [Fact]
        public void Should_make_plans_orchestration_call()
        {
            var installmentQuoteRequest = new InstallmentQuoteRequest()
            {
                CardAccountId = "0000111122223333",
                Plan = "50900",
                FixedAmount = 12,
                TotalAmount = 300,
                Terms = 22
            };

            _installmentQuoteService.ExecuteAsync(installmentQuoteRequest);

            _loansApiClientV2Mock.Verify(m => m.AccountPlanListAsync(It.IsAny<AccountPlanListRequest2>()), Times.Once);
        }

        [Fact]
        public async void Should_throw_eligible_balance_exceeded_exception_if_total_amount_is_bigger_than_fd_value()
        {
            var installmentQuoteRequest = new InstallmentQuoteRequest()
            {
                CardAccountId = "0000111122223333",
                Plan = "50900",
                FixedAmount = 12,
                TotalAmount = 300,
                Terms = 22
            };

            var accountPlanListResponse = new AccountPlanListResponse2()
            {
                AcctFppEligBal = "10000"
            };

            _loansApiClientV2Mock.Setup(m => m.AccountPlanListAsync(It.IsAny<AccountPlanListRequest2>())).ReturnsAsync(accountPlanListResponse);

            Task Action() => _installmentQuoteService.ExecuteAsync(installmentQuoteRequest);

            await Assert.ThrowsAsync<EligibleBalanceExceededException>(Action);
        }

        [Fact]
        public async void Should_throw_installment_plan_match_exception_if_no_plans_match_given_id()
        {
            var installmentQuoteRequest = new InstallmentQuoteRequest()
            {
                CardAccountId = "0000111122223333",
                Plan = "50900",
                FixedAmount = 12,
                TotalAmount = 300,
                Terms = 22
            };

            var accountPlanListResponse = new AccountPlanListResponse2()
            {
                AcctFppEligBal = "50000",
                PlanCtdData = new []
                {
                    new PlanCtdData2ForAccountPlanList2()
                    {
                        PlanNbr = "50901"
                    },
                    new PlanCtdData2ForAccountPlanList2()
                    {
                        PlanNbr = "50902"
                    }
                }
            };

            _loansApiClientV2Mock.Setup(m => m.AccountPlanListAsync(It.IsAny<AccountPlanListRequest2>())).ReturnsAsync(accountPlanListResponse);

            Task Action() => _installmentQuoteService.ExecuteAsync(installmentQuoteRequest);

            await Assert.ThrowsAsync<InstallmentPlanMatchException>(Action);
        }

        [Fact]
        public async void Should_throw_installment_plan_match_exception_if_no_plans_found_in_fd()
        {
            var installmentQuoteRequest = new InstallmentQuoteRequest()
            {
                CardAccountId = "0000111122223333",
                Plan = "50900",
                FixedAmount = 12,
                TotalAmount = 300,
                Terms = 22
            };

            var accountPlanListResponse = new AccountPlanListResponse2()
            {
                AcctFppEligBal = "50000",
                PlanCtdData = new List<PlanCtdData2ForAccountPlanList2>(),
                NbrOfPlans = "0"
            };

            _loansApiClientV2Mock.Setup(m => m.AccountPlanListAsync(It.IsAny<AccountPlanListRequest2>())).ReturnsAsync(accountPlanListResponse);

            Task Action() => _installmentQuoteService.ExecuteAsync(installmentQuoteRequest);

            await Assert.ThrowsAsync<InstallmentPlanMatchException>(Action);
        }
    }
}