﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.SetSpendCap;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Cache;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.SetSpendCap;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.SetSpendCap
{
    public class SetSpendCapServiceTest
    {
        private readonly SetSpendCapService _setSpendCapService;
        private readonly Mock<IAccountMaintenanceApiClient> _accountMaintenanceApiClientMock;
        private readonly Mock<IDataManager> _dataManagerMock;
        private readonly ITimeoutProvider _timeoutProvider = new TimeoutProvider(TimeSpan.Zero);

        public SetSpendCapServiceTest()
        {
            var brandHelper = new Mock<IBrandHelper>();
            brandHelper.Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(new Brand("opus", "123", "123", new List<string>(), true));
            ISetSpendCapConverter converter = new SetSpendCapConverter(brandHelper.Object);
            _accountMaintenanceApiClientMock = new Mock<IAccountMaintenanceApiClient>();
            var accountManagementV3ApiClientMock = new Mock<IAccountManagementApiClient>();
            _dataManagerMock = new Mock<IDataManager>();
            var loggerMock = new Mock<ILogger<SetSpendCapService>>();

            var cacheKeyProviderMock = new Mock<IAccountDetailInquiryCacheKeyProvider>();
            cacheKeyProviderMock.Setup(x => x.GetKey(It.IsAny<string>())).Returns("cacheKey");
            _setSpendCapService = new SetSpendCapService(
                converter, 
                _accountMaintenanceApiClientMock.Object,
                accountManagementV3ApiClientMock.Object,
                cacheKeyProviderMock.Object, 
                _dataManagerMock.Object,
                _timeoutProvider,
                loggerMock.Object);
        }

        [Fact]
        private async Task Should_throw_exception_if_spend_cap_is_greater_than_spend_limit()
        {
            //arrange
            var setSpendCapRequest = new SetSpendCapRequest
            {
                AlertType = SpendCapAlertType.Email,
                CapAmount = 10,
                CapType = SpendCapType.Soft,
                CardAccountId = "7365110000030289"
            };
            var accountDetailInquiryResponse = new AccountDetailInquiryResponse3
            {
                CurrencyNod = "2",
                Crlim = "100"
            };
            _dataManagerMock
                .Setup(x => x.FetchWithCacheAsync(It.IsAny<string>(), It.IsAny<TimeSpan>(),
                    It.IsAny<Func<Task<AccountDetailInquiryResponse3>>>())).ReturnsAsync(
                    new DataManagerResponse<AccountDetailInquiryResponse3>(accountDetailInquiryResponse, DateTime.Now,
                        TimeSpan.Zero));

            //act
            Func<Task> act = async () => await _setSpendCapService.ExecuteAsync(setSpendCapRequest);

            //assert
            await act.Should().ThrowAsync<SpendCapLimitGreaterThanCreditLimitException>();
        }

        [Fact]
        private async Task When_removing_spend_cap_Then_should_not_check_credit_limit()
        {
            //arrange
            var setSpendCapRequest = new SetSpendCapRequest
            {
                CapType = SpendCapType.None,
                CardAccountId = "7365110000030289"
            };
            _dataManagerMock
                .Setup(x => x.FetchWithCacheAsync(It.IsAny<string>(), It.IsAny<TimeSpan>(),
                    It.IsAny<Func<Task<AccountDetailInquiryResponse3>>>())).Verifiable();
            _accountMaintenanceApiClientMock
                .Setup(x => x.AccountCustomFieldsUpdateAsync(It.IsAny<AccountCustomFieldsUpdateRequest>()))
                .ReturnsAsync(new AccountCustomFieldsUpdateResponse());
            _dataManagerMock.Setup(x => x.IsSetAsync(It.IsAny<string>())).ReturnsAsync(false);

            //act
            await _setSpendCapService.ExecuteAsync(setSpendCapRequest);

            //assert
            _dataManagerMock.Verify(x => x.FetchWithCacheAsync(It.IsAny<string>(), It.IsAny<TimeSpan>(),
                It.IsAny<Func<Task<AccountDetailInquiryResponse3>>>()), Times.Never);
        }

        [Fact]
        public async Task Should_set_spend_cap_if_spend_cap_is_less_then_credit_limit()
        {
            //arrange
            var setSpendCapRequest = new SetSpendCapRequest
            {
                AlertType = SpendCapAlertType.Email,
                CapAmount = 10,
                CapType = SpendCapType.Soft,
                CardAccountId = "7365110000030289"
            };
            var accountDetailInquiryResponse = new AccountDetailInquiryResponse3
            {
                CurrencyNod = "2",
                Crlim = "10000"
            };
            _dataManagerMock
                .Setup(x => x.FetchWithCacheAsync(It.IsAny<string>(), It.IsAny<TimeSpan>(),
                    It.IsAny<Func<Task<AccountDetailInquiryResponse3>>>())).ReturnsAsync(
                    new DataManagerResponse<AccountDetailInquiryResponse3>(accountDetailInquiryResponse, DateTime.Now,
                        TimeSpan.Zero)).Verifiable();
            _accountMaintenanceApiClientMock
                .Setup(x => x.AccountCustomFieldsUpdateAsync(It.IsAny<AccountCustomFieldsUpdateRequest>()))
                .ReturnsAsync(new AccountCustomFieldsUpdateResponse()).Verifiable();
            _dataManagerMock.Setup(x => x.IsSetAsync(It.IsAny<string>())).ReturnsAsync(false);

            //act
            await _setSpendCapService.ExecuteAsync(setSpendCapRequest);

            //assert
            _dataManagerMock.Verify(x => x.FetchWithCacheAsync(It.IsAny<string>(), It.IsAny<TimeSpan>(),
                It.IsAny<Func<Task<AccountDetailInquiryResponse3>>>()), Times.Once);
            _accountMaintenanceApiClientMock.Verify(
                x => x.AccountCustomFieldsUpdateAsync(It.IsAny<AccountCustomFieldsUpdateRequest>()), Times.Once);
        }
    }
}
