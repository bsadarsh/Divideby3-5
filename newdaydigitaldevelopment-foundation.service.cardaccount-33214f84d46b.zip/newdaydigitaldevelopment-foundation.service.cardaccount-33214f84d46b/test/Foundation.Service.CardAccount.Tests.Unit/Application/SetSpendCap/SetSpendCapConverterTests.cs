﻿using System.Collections.Generic;
using AutoFixture;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.SetSpendCap;
using NewDay.Digital.Foundation.Service.CardAccount.Application.SetSpendCap;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.SetSpendCap
{
    public class SetSpendCapConverterTests
    {
        private readonly ISetSpendCapConverter _setSpendCapConverter;
        private readonly Brand _brand = new Fixture().Create<Brand>();

        public SetSpendCapConverterTests()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(_brand)
                .Verifiable();

            _setSpendCapConverter = new SetSpendCapConverter(brandHelperMock.Object);
        }

        [Theory]
        [InlineData(SpendCapType.Soft, "1")]
        [InlineData(SpendCapType.Hard, "2")]
        public void Should_convert_an_enable_caps_request_to_fd_request(SpendCapType capType, string spendCapInd)
        {
            const string accountNumber = "0001234123412341234";

            var domainRequest = new SetSpendCapRequest()
            {
                CardAccountId = accountNumber,
                AlertType = SpendCapAlertType.Sms,
                CapAmount = 500,
                CapType = capType,
            };

            var expectedResponse = new AccountCustomFieldsUpdateRequest(_brand.ClientNumber)
            {
                Account = accountNumber,
                SpndLmtAlert = "1",
                SpndLmtAmt = "000000500",
                SpendCapInd = spendCapInd
            };

            var fdResult = _setSpendCapConverter.ToAccountCustomFieldsUpdate(domainRequest);

            fdResult.Should().BeEquivalentTo(expectedResponse);
        }

        [Theory]
        [MemberData(nameof(GetDisableSpendingCapsRequests))]
        public void Should_convert_a_disable_caps_request_to_fd_request(SetSpendCapRequest disableSpendCapRequest)
        {
            var expectedResponse = new AccountCustomFieldsUpdateRequest(_brand.ClientNumber)
            {
                Account = "0001234123412341234",
                SpndLmtAlert = "0",
                SpndLmtAmt = "0",
                SpendCapInd = "0"
            };

            var fdResult = _setSpendCapConverter.ToAccountCustomFieldsUpdate(disableSpendCapRequest);

            fdResult.Should().BeEquivalentTo(expectedResponse);
        }

        [Theory]
        [InlineData(100, "000000100")]
        [InlineData(99123, "000099123")]
        [InlineData(5, "000000005")]
        [InlineData(123456789, "123456789")]
        public void Should_add_leading_zeros_to_spndLmtAmt(int spendLimit, string fdSpendLimit)
        {
            var domainRequest = new SetSpendCapRequest()
            {
                CardAccountId = "0001234123412341234",
                AlertType = SpendCapAlertType.Sms,
                CapAmount = spendLimit,
                CapType = SpendCapType.Soft,
            };

            var fdRequest = _setSpendCapConverter.ToAccountCustomFieldsUpdate(domainRequest);

            fdRequest.SpndLmtAmt.Should().Be(fdSpendLimit);
        }

        public static IEnumerable<object[]> GetDisableSpendingCapsRequests()
        {
            const string cardAccountId = "0001234123412341234";

            // alert type and cap amount set
            yield return new object[] { new SetSpendCapRequest()
                {
                    CardAccountId = cardAccountId,
                    AlertType = SpendCapAlertType.Sms,
                    CapAmount = 500,
                    CapType = SpendCapType.None,
                }
            };

            // alert type set
            yield return new object[] { new SetSpendCapRequest()
                {
                    CardAccountId = cardAccountId,
                    AlertType = SpendCapAlertType.Sms,
                    CapAmount = 0,
                    CapType = SpendCapType.None,
                }
            };

            // only cap amount set
            yield return new object[] { new SetSpendCapRequest()
                {
                    CardAccountId = cardAccountId,
                    AlertType = SpendCapAlertType.None,
                    CapAmount = 500,
                    CapType = SpendCapType.None,
                }
            };
        }
    }
}