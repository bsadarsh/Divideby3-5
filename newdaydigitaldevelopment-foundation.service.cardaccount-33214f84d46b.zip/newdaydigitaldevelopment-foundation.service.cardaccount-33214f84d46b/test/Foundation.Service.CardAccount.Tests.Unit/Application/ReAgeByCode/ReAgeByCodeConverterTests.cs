﻿using System.Collections.Generic;
using System.Linq;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.ReAgeByCode;
using NewDay.Digital.Foundation.Service.CardAccount.Application.ReAgeByCode;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.ReAgeByCode
{
    public class ReAgeByCodeConverterTests
    {
        private readonly IReAgeByCodeConverter _reAgeByCodeConverter;

        public ReAgeByCodeConverterTests()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock.Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(new Brand("opus", "10005", "110", new string[] { }, true));

            _reAgeByCodeConverter = new ReAgeByCodeConverter(brandHelperMock.Object);
        }

        [Fact]
        public void Should_properly_convert_to_delinquency_calculation_request()
        {
            //arrange
            var reAgeRequest = new ReAgeByCodeRequest
            {
                CardAccountId = "1105500010092766",
                Code = 1
            };
            var delinquencyInquiryResponse = new DelinquencyAdjustmentsInquiryResponse3
            {
                PlanData = new List<PlanData3ForDelinquencyAdjustmentsInquiry3>
                {
                    new PlanData3ForDelinquencyAdjustmentsInquiry3
                    {
                        CurrBal = "12",
                        PlanNbr = "123",
                        RecNbr = "1234",
                        TotDue = "12345",
                    }
                },
                NbrReturnedItems = "1",
                CurrDue = "987654321",
                PastDue = "87654321",
                DaysDue030 = "7654321",
                DaysDue060 = "654321",
                DaysDue090 = "54321",
                DaysDue120 = "4321",
                DaysDue150 = "321",
                DaysDue180 = "21",
                DaysDue210 = "1"
            };

            //act
            var fdRequest =
                _reAgeByCodeConverter.ToDelinquencyAdjustmentCalculationRequest(reAgeRequest,
                    delinquencyInquiryResponse);

            //assert
            fdRequest.CardNbr.Should().Be("0001105500010092766");
            fdRequest.NbrItems.Should().Be("1");
            fdRequest.CurrDue.Should().Be("987654321");
            fdRequest.PastDue.Should().Be("87654321");
            fdRequest.DaysDue030.Should().Be("7654321");
            fdRequest.DaysDue060.Should().Be("654321");
            fdRequest.DaysDue090.Should().Be("54321");
            fdRequest.DaysDue120.Should().Be("4321");
            fdRequest.DaysDue150.Should().Be("321");
            fdRequest.DaysDue180.Should().Be("21");
            fdRequest.DaysDue210.Should().Be("1");
            fdRequest.ReageCd.Should().Be("1");
            fdRequest.Action.Should().Be("C");
            var paymentPsData = fdRequest.PaymentPsData.ToList();
            paymentPsData.Count.Should().Be(1);
            paymentPsData[0].RecNbr.Should().Be("1234");
            paymentPsData[0].TotDue.Should().Be("12345");
            paymentPsData[0].CurrBal.Should().Be("12");
            paymentPsData[0].PlanNbr.Should().Be("123");

        }

        [Fact]
        public void Should_properly_convert_to_delinquency_submit_request()
        {
            //arrange
            var reAgeRequest = new ReAgeByCodeRequest
            {
                CardAccountId = "1105500010092766",
                Code = 1
            };
            var delinquencyAdjustmentResponse = new DelinquencyAdjustmentUpdateResponse
            {
                PlanData = new List<PlanDataForDelinquencyAdjustmentUpdate1>
                {
                    new PlanDataForDelinquencyAdjustmentUpdate1
                    {
                        CurrBal = "12",
                        PlanNbr = "123",
                        RecNbr = "1234",
                        TotDue = "12345",
                    }
                },
                NbrReturnedItems = "1",
                CurrDue = "987654321",
                PastDue = "87654321",
                DaysDue30 = "7654321",
                DaysDue60 = "654321",
                DaysDue90 = "54321",
                DaysDue120 = "4321",
                DaysDue150 = "321",
                DaysDue180 = "21",
                DaysDue210 = "1"

            };

            //act
            var fdRequest =
                _reAgeByCodeConverter.ToDelinquencyAdjustmentSubmitRequest(reAgeRequest, delinquencyAdjustmentResponse);

            //assert
            fdRequest.CardNbr.Should().Be("0001105500010092766");
            fdRequest.NbrItems.Should().Be("1");
            fdRequest.CurrDue.Should().Be("987654321");
            fdRequest.PastDue.Should().Be("87654321");
            fdRequest.DaysDue030.Should().Be("7654321");
            fdRequest.DaysDue060.Should().Be("654321");
            fdRequest.DaysDue090.Should().Be("54321");
            fdRequest.DaysDue120.Should().Be("4321");
            fdRequest.DaysDue150.Should().Be("321");
            fdRequest.DaysDue180.Should().Be("21");
            fdRequest.DaysDue210.Should().Be("1");
            fdRequest.ReageCd.Should().Be("1");
            fdRequest.Action.Should().Be("S");
            var paymentPsData = fdRequest.PaymentPsData.ToList();
            paymentPsData.Count.Should().Be(1);
            paymentPsData[0].RecNbr.Should().Be("1234");
            paymentPsData[0].TotDue.Should().Be("12345");
            paymentPsData[0].CurrBal.Should().Be("12");
            paymentPsData[0].PlanNbr.Should().Be("123");
        }
    }
}
