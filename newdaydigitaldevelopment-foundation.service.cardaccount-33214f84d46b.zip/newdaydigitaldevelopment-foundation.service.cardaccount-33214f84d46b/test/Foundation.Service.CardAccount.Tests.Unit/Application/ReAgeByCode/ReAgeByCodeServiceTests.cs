﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.ReAgeByCode;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.ReAgeByCode;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.ReAgeByCode
{
    public class ReAgeByCodeServiceTests
    {
        private readonly ReAgeByCodeService _reAgeByCodeService;
        private readonly Mock<IAccountManagementApiClient> _accountManagementApiClientMock;
        private readonly Mock<IAccountMaintenanceApiClient> _accountMaintenanceApiClientMock;

        public ReAgeByCodeServiceTests()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock.Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(new Brand("opus", "10005", "110", new string[] { }, true));

            IReAgeByCodeConverter converter = new ReAgeByCodeConverter(brandHelperMock.Object);
            _accountManagementApiClientMock = new Mock<IAccountManagementApiClient>();
            _accountMaintenanceApiClientMock = new Mock<IAccountMaintenanceApiClient>();
            _reAgeByCodeService = new ReAgeByCodeService(converter, _accountManagementApiClientMock.Object,
                _accountMaintenanceApiClientMock.Object);
        }

        [Theory]
        [InlineData(5)]
        [InlineData(6)]
        public async Task When_delinquency_code_is_greater_or_equal_to_number_of_buckets_Then_exception_should_be_thrown(int delinquencyNumber)
        {
            //arrange
            var request = new ReAgeByCodeRequest
            {
                CardAccountId = "1105500010092766",
                Code = delinquencyNumber
            };

            _accountManagementApiClientMock
                .Setup(x => x.DelinquencyAdjustmentsInquiryAsync(It.IsAny<DelinquencyAdjustmentsInquiryRequest3>()))
                .ReturnsAsync(new DelinquencyAdjustmentsInquiryResponse3
                {
                    CurrDue = "100",
                    PastDue = "100",
                    DaysDue030 = "100",
                    DaysDue060 = "100",
                    DaysDue090 = "100"
                });

            //act
            Func<Task> act = async () => await _reAgeByCodeService.ExecuteAsync(request);

            //assert
            await act.Should().ThrowAsync<InvalidReAgeRequestValuesException>();
        }

        [Fact]
        public async Task When_diffInDue_in_calculation_call_is_different_than_zero_Then_exception_should_be_thrown()
        {
            //arrange
            var request = new ReAgeByCodeRequest
            {
                CardAccountId = "1105500010092766",
                Code = 1
            };

            _accountManagementApiClientMock
                .Setup(x => x.DelinquencyAdjustmentsInquiryAsync(It.IsAny<DelinquencyAdjustmentsInquiryRequest3>()))
                .ReturnsAsync(new DelinquencyAdjustmentsInquiryResponse3
                {
                    CurrDue = "100",
                    PastDue = "100",
                    PlanData = new List<PlanData3ForDelinquencyAdjustmentsInquiry3>(){
                        new PlanData3ForDelinquencyAdjustmentsInquiry3
                        {
                            CurrBal = "123",
                            PlanNbr = "123",
                            RecNbr = "123",
                            TotDue = "123"
                        }
                    },
                    NbrReturnedItems = "1"
                });
            _accountMaintenanceApiClientMock
                .Setup(x => x.DelinquencyAdjustmentUpdateAsync(It.IsAny<DelinquencyAdjustmentUpdateRequest>()))
                .ReturnsAsync(new DelinquencyAdjustmentUpdateResponse
                {
                    DiffInDue = "1"
                });

            //act
            Func<Task> act = async () => await _reAgeByCodeService.ExecuteAsync(request);

            //assert
            await act.Should().ThrowAsync<AccountRecalculationException>();
        }

        [Fact]
        public async Task When_diffInDue_in_submit_call_is_different_than_zero_Then_exception_should_be_thrown()
        {
            //arrange
            var request = new ReAgeByCodeRequest
            {
                CardAccountId = "1105500010092766",
                Code = 1
            };

            _accountManagementApiClientMock
                .Setup(x => x.DelinquencyAdjustmentsInquiryAsync(It.IsAny<DelinquencyAdjustmentsInquiryRequest3>()))
                .ReturnsAsync(new DelinquencyAdjustmentsInquiryResponse3
                {
                    CurrDue = "100",
                    PastDue = "100",
                    PlanData = new List<PlanData3ForDelinquencyAdjustmentsInquiry3>{
                        new PlanData3ForDelinquencyAdjustmentsInquiry3
                        {
                            CurrBal = "123",
                            PlanNbr = "123",
                            RecNbr = "123",
                            TotDue = "123"
                        }
                    },
                    NbrReturnedItems = "1"
                });
            _accountMaintenanceApiClientMock
                .SetupSequence(x => x.DelinquencyAdjustmentUpdateAsync(It.IsAny<DelinquencyAdjustmentUpdateRequest>()))
                .ReturnsAsync(new DelinquencyAdjustmentUpdateResponse
                {
                    DiffInDue = "0",
                    PlanData = new List<PlanDataForDelinquencyAdjustmentUpdate1>
                    {
                        new PlanDataForDelinquencyAdjustmentUpdate1
                        {
                            CurrBal = "123",
                            PlanNbr = "123",
                            RecNbr = "123",
                            TotDue = "123"
                        }
                    },
                    NbrReturnedItems = "1"

                })
                .ReturnsAsync(new DelinquencyAdjustmentUpdateResponse
                {
                    DiffInDue = "1"
                });

            //act
            Func<Task> act = async () => await _reAgeByCodeService.ExecuteAsync(request);

            //assert
            await act.Should().ThrowAsync<AccountRecalculationException>();
        }
    }
}
