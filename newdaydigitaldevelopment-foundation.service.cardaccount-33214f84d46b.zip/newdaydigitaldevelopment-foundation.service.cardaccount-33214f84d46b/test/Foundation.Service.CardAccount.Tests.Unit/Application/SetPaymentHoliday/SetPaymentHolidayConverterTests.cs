﻿using AutoFixture;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.SetPaymentHoliday;
using NewDay.Digital.Foundation.Service.CardAccount.Application.SetPaymentHoliday;
using System;
using FluentAssertions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.SetPaymentHoliday
{
    public class SetPaymentHolidayConverterTests
    {
        private Mock<IBrandHelper> GetBrandHelperMock()
        {
            var brand = new Fixture().Create<Brand>();

            var brandHelperMock = new Mock<IBrandHelper>();

            brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(brand)
                .Verifiable();

            return brandHelperMock;
        }

        private Mock<IBrandHelper> GetInvalidBrandHelperMock()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns((Brand)null)
                .Verifiable();

            return brandHelperMock;
        }

        private static readonly SetPaymentHolidayRequest SetPaymentHolidayRequest = new SetPaymentHolidayRequest()
        {
            CardAccountId = "0000111122223333",
            Term = "2"
        };

        [Fact]
        public void Should_throw_invalid_brand_exception_for_invalid_account_number_on_payment_holiday_request_conversion()
        {
            var brandHelperMock = GetInvalidBrandHelperMock();

            var converter = new SetPaymentHolidayConverter(brandHelperMock.Object);

            Action act = () => converter.ToPaymentHolidayRequest(SetPaymentHolidayRequest);
            act.Should().Throw<InvalidBrandException>();
        }

        [Fact]
        public void Should_convert_set_payment_holiday_request_to_fd_request()
        {
            var brandHelperMock = GetBrandHelperMock();

            var converter = new SetPaymentHolidayConverter(brandHelperMock.Object);

            var paymentHolidayRequest = converter.ToPaymentHolidayRequest(SetPaymentHolidayRequest);

            paymentHolidayRequest.Account.Should().Be("0000000111122223333");
            paymentHolidayRequest.PmtHolidayFlag.Should().Be("1");
            paymentHolidayRequest.HolidayTerm.Should().Be("2");
            paymentHolidayRequest.Common.ClientNumber.Should().NotBeEmpty();
            paymentHolidayRequest.Common.Org.Should().NotBeEmpty();
        }
    }
}