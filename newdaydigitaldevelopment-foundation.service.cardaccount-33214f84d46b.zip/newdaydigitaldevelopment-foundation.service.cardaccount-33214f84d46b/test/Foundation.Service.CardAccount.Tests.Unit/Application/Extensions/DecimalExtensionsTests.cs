﻿using FluentAssertions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Extensions;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.Extensions
{
    public class DecimalExtensionsTests
    {
        [Theory]
        [InlineData(0.0, "0")]
        [InlineData(1.00, "100")]
        [InlineData(249.99, "24999")]
        [InlineData(25.50, "2550")]
        [InlineData(25.49, "2549")]
        [InlineData(12.349, "1234")]
        [InlineData(50.50, "5050")]
        public void Should_convert_decimal_to_string_with_zero_decimal_places(decimal input, string expectedOutput)
        {
            var result = input.ToFDAmountString();

            result.Should().BeEquivalentTo(expectedOutput);
        }
    }
}