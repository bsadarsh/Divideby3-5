﻿using System;
using System.Linq;
using FluentAssertions;
using Microsoft.VisualStudio.TestPlatform.Utilities;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Extensions;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.Extensions
{
    public class StringExtensionsTests
    {
        [Fact]
        public void Should_split_given_string_into_five_array_elements()
        {
            var payload = "abcde";

            var result = payload.SplitByLength(1).ToList();

            result[0].Should().Be("a");
            result[1].Should().Be("b");
            result[2].Should().Be("c");
            result[3].Should().Be("d");
            result[4].Should().Be("e");
        }

        [Fact]
        public void Should_split_given_string_into_one_line()
        {
            var payload = "abcde";

            var result = payload.SplitByLength(5).ToList();

            result[0].Should().Be("abcde");
        }

        [Fact]
        public void Should_split_given_string_into_two_lines()
        {
            var payload = "abcdeab";

            var result = payload.SplitByLength(5).ToList();

            result[0].Should().Be("abcde");
            result[1].Should().Be("ab");
        }

        [Theory]
        [InlineData("1", true)]
        [InlineData("0", false)]
        public void Should_convert_binarystring_correctly(string input, bool expectedResult)
        {
            input.ToBoolFromBinaryString().Should().Be(expectedResult);
        }

        [Theory]
        [InlineData("-1")]
        [InlineData("")]
        [InlineData("A")]
        [InlineData("2")]
        public void Should_throw_InvalidOperationException_for_non_binarystring(string input)
        {
            var action = new Func<bool>(input.ToBoolFromBinaryString);

            action.Should().ThrowExactly<InvalidOperationException>();
        }
    }
}
