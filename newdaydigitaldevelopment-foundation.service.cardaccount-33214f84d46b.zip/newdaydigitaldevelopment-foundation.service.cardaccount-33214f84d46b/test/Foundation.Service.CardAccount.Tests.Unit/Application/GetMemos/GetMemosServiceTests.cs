﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoFixture;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountActivityUpdates.v2;
using NewDay.Digital.Foundation.Connector.FirstData.AccountActivityUpdates.v2.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.GetMemos;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.GetMemos
{
    public class GetMemosServiceTests
    {
        [Fact]
        public async Task Should_return_badRequest_if_cardaccountid_passed_in_is_not_recognised()
        {
            var request = new GetCardAccountMemosRequest
            {
                CardAccountId = "bad card account id"
            };

            var brandHelperMock = new Mock<IBrandHelper>();
            var timeoutMock = new Mock<ITimeoutProvider>();
            timeoutMock.SetupGet(x => x.Timeout).Returns(TimeSpan.FromSeconds(1));
            var service = new GetMemosService(timeoutMock.Object, new GetMemosConverter(brandHelperMock.Object), null, null);
            Func<Task<DataManagerResponse<GetCardAccountMemosResponse>>> func = () => service.ExecuteAsync(request);
            await func.Should().ThrowAsync<InvalidBrandException>();
        }

        [Fact]
        public async Task Should_Return_Correct_Response_with_one_memo_If_Valid_Account_Number_Is_Sent_In_The_Request()
        {
            var fixture = new Fixture();
            var request = fixture.Create<GetCardAccountMemosRequest>();

            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(request.CardAccountId))
                .Returns(fixture.Create<Brand>());

            var inquiryResponse = new MemoInquiryResponse2
            {
                MemoDtl = new List<MemoDtl2ForMemoInquiry2>
                {
                    new MemoDtl2ForMemoInquiry2
                    {
                        ActnCd = "1111",
                        MemoLine1 = "1",
                        MemoLine2 = "2",
                        MemoLine3 = "3",
                        MemoLine4 = "4",
                        MemoLine5 = "5"
                    }
                }
            };
            var dataManagerResponse = new DataManagerResponse<MemoInquiryResponse2>(inquiryResponse, DateTime.Now, TimeSpan.Zero);
            var expectedResponse = new DataManagerResponse<GetCardAccountMemosResponse>(new GetCardAccountMemosResponse
            {
                Memos = new List<CardAccountMemo>
                {
                    new CardAccountMemo
                    {
                        Code = "1111",
                        Text = "12345"
                    }
                }
            }, DateTime.Now, TimeSpan.Zero);

            var customerApiClientMock = new Mock<IAccountActivityUpdatesApiClient>(MockBehavior.Strict);
            customerApiClientMock
                .Setup(n => n.MemoInquiryAsync(It.IsAny<MemoInquiryRequest2>()))
                .ReturnsAsync(inquiryResponse);

            var dataManagerMock = new Mock<IDataManager>(MockBehavior.Strict);
            dataManagerMock
                .Setup(n => n.FetchWithCacheAsync(It.IsAny<string>(), It.IsAny<TimeSpan>(), It.IsAny<Func<Task<MemoInquiryResponse2>>>()))
                .ReturnsAsync(dataManagerResponse);
            
            var timeoutMock = new Mock<ITimeoutProvider>();
            timeoutMock.SetupGet(x => x.Timeout).Returns(TimeSpan.FromSeconds(1));

            var service = new GetMemosService(timeoutMock.Object, new GetMemosConverter(brandHelperMock.Object), customerApiClientMock.Object, dataManagerMock.Object);
            var actualResponse = await service.ExecuteAsync(request);

            actualResponse.Should().BeEquivalentTo(expectedResponse, config => config
                .Excluding(x => x.CacheAge)
                .Excluding(x => x.CacheExpires));
        }
    }
}
