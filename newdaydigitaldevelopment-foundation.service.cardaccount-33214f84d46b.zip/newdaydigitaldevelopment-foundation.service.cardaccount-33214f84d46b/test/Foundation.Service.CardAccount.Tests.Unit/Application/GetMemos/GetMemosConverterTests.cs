﻿using System.Collections.Generic;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountActivityUpdates.v2.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;
using NewDay.Digital.Foundation.Service.CardAccount.Application.GetMemos;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.GetMemos
{
    public class GetMemosConverterTests
    {
        [Fact]
        public void Should_convert_GetCardAccountMemosRequest_into_MemoInquiryRequest_and_populate_accountid()
        {
            const string accountNumber = "3915050004000066";
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(accountNumber))
                .Returns(new Brand("Marbles", "01030", "391", new[] { "505" }, true));
            var getMemosConverter = new GetMemosConverter(brandHelperMock.Object);

            var payload = new GetCardAccountMemosRequest
            {
                CardAccountId = accountNumber
            };

            var result = getMemosConverter.ToMemoInquiryRequest(payload);

            result.AcctNbr.Should().Be(accountNumber);
        }

        [Fact]
        public void Should_convert_ToGetCardAccountMemosResponse_into_GetCardAccountMemosResponse_and_return_two_memos()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            var getMemosConverter = new GetMemosConverter(brandHelperMock.Object);

            var payload = new MemoInquiryResponse2
            {
                MemoDtl = new List<MemoDtl2ForMemoInquiry2>
                {
                    new MemoDtl2ForMemoInquiry2
                    {
                        ActnCd = "1111",
                        MemoLine1 = "a1",
                        MemoLine2 = "b1",
                        MemoLine3 = "c1",
                        MemoLine4 = "d1",
                        MemoLine5 = "e1"
                    },
                    new MemoDtl2ForMemoInquiry2
                    {
                        ActnCd = "2222",
                        MemoLine1 = "a2",
                        MemoLine2 = "b2",
                        MemoLine3 = "c2",
                        MemoLine4 = "d2",
                        MemoLine5 = "e2"
                    }
                }
            };

            var result = getMemosConverter.ToGetCardAccountMemosResponse(payload);
            result.Should().BeEquivalentTo(new GetCardAccountMemosResponse
            {
                Memos = new List<CardAccountMemo>
                {
                    new CardAccountMemo
                    {
                        Code = "1111",
                        Text = "a1b1c1d1e1"
                    },
                    new CardAccountMemo
                    {
                        Code = "2222",
                        Text = "a2b2c2d2e2"
                    },
                }
            });
        }

        [Fact]
        public void Should_return_null_when_ToGetCardAccountMemosResponse_is_null()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            var getMemosConverter = new GetMemosConverter(brandHelperMock.Object);
            var result = getMemosConverter.ToGetCardAccountMemosResponse(null);

            result.Should().BeNull();
        }

        [Fact]
        public void Should_convert_MemoDtl_into_CardAccountMemo()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            var getMemosConverter = new GetMemosConverter(brandHelperMock.Object);

            var payload = new MemoDtl2ForMemoInquiry2
            {
                ActnCd = "1111",
                MemoLine1 = "a",
                MemoLine2 = "b",
                MemoLine3 = "c",
                MemoLine4 = "d",
                MemoLine5 = "e"
            };

            var result = getMemosConverter.ToCardAccountMemo(payload);
            result.Should().BeEquivalentTo(new CardAccountMemo
            {
                Code = payload.ActnCd,
                Text = "abcde"
            });
        }
    }
}
