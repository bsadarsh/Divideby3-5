﻿using System;
using System.IO;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v2;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v2.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Exceptions;
using NewDay.Digital.Foundation.Connector.FirstData.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Transactions.v1;
using NewDay.Digital.Foundation.Connector.FirstData.Transactions.v1.Models;
using NewDay.Digital.Foundation.Core.Azure.Function.ServiceErrors;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.ReturnFunds;
using NewDay.Digital.Foundation.Service.CardAccount.Application.ReturnFunds;
using Newtonsoft.Json;
using Xunit;
using ReturnFundsV1 = NewDay.Digital.Foundation.Service.CardAccount.Functions.v1.ReturnFunds;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.ReturnFunds
{
    public class ReturnFundsTest
    {
        private readonly Mock<ITransactionsApiClient> _transactionsApiClient;
        private readonly Mock<IAccountManagementApiClient> _accountManagementApiClient;
        private readonly Mock<IBrandHelper> _mockBrandHelper;
        private readonly ReturnFundsV1 _returnFunds;

        const string CardAccountId = "0001234567890123456";
        const string PlanNumber = "1234";
        const string PlanSequenceNumber = "5678";

        public ReturnFundsTest()
        {
            _transactionsApiClient = new Mock<ITransactionsApiClient>();
            _accountManagementApiClient = new Mock<IAccountManagementApiClient>();
            _mockBrandHelper = new Mock<IBrandHelper>();
           
            var converter = new ReturnFundsConverter(_mockBrandHelper.Object, NullLogger<ReturnFundsConverter>.Instance);
            var service = new ReturnFundsService(_transactionsApiClient.Object, _accountManagementApiClient.Object, converter, NullLogger<ReturnFundsService>.Instance);
            _returnFunds = new ReturnFundsV1(service, Mock.Of<IServiceErrorConverter>(), NullLogger<CardAccount.Functions.v1.ReturnFunds>.Instance);

        }
        
        [Fact]
        public void Should_Call_FiServ_Requesting_MonetaryActionRequest()
        {
            GivenBrandForClient("31");

            GivenPlanInquiryReturns(
                new AccountPlanInquiryResponse2 {
                PlanCtdData = new[] {CreatePlan("-3000"), CreatePlan("0", "8910")}
            });

            GivenMonetaryActionSucceeds();
            
            //when
            var request = new ReturnFundsRequest
            {
                CardAccountId = CardAccountId,
                Amount = 21.12m,
            };
            var result = _returnFunds.Run(HttpRequest(request)).Result;

            //then
            _transactionsApiClient.Verify(x => x.MonetaryActionAsync(It.Is<MonetaryActionRequest>(y => y.AcctNbr == request.CardAccountId 
                                                                                                       && y.Common.ClientNumber == "31"
                                                                                                       && y.ActionCode == "CBRD"
                                                                                                       && y.TxnAmount == "0000002112"
                                                                                                       && y.StoreNbr == "999999998"
                                                                                                       && y.ForeignUse == "0"
                                                                                                       && y.PlanNbr == PlanNumber
                                                                                                       && y.PlanSeq == PlanSequenceNumber
                                                                                                       && y.EffDate == DateTimeOffset.Now.ToString("yyyyMMdd")
                                                                                                       )));
            result.Should().BeOfType<OkObjectResult>();
        }

        [Fact]
        public void Should_Return_400_When_Request_Is_For_Negative_Amount()
        {
            GivenBrandForClient("31");

            GivenPlanInquiryReturns(
                new AccountPlanInquiryResponse2
                {
                    PlanCtdData = new []{CreatePlan("-30")}
                });

            GivenMonetaryActionSucceeds();

            //when
            var request = new ReturnFundsRequest
            {
                CardAccountId = CardAccountId,
                Amount = -21.12m,
            };
            var result = _returnFunds.Run(HttpRequest(request)).Result;

            //then
            result.Should().BeOfType<BadRequestObjectResult>();        
        }
        
        [Theory]
        [MemberData(nameof(InvalidPlans))]
        public void Should_Return_400_When_No_Plan_Has_Enough_Credit(PlanCtdData2ForAccountPlanInquiry2[] plans)
        {
            GivenBrandForClient("31");

            GivenPlanInquiryReturns(
                new AccountPlanInquiryResponse2
                {
                    PlanCtdData = plans
                });

            GivenMonetaryActionSucceeds();

            //when
            var request = new ReturnFundsRequest
            {
                CardAccountId = CardAccountId,
                Amount = 21.12m,
            };
            var result = _returnFunds.Run(HttpRequest(request)).Result;

            //then
            result.Should().BeOfType<BadRequestObjectResult>();        
        }

        public static TheoryData<PlanCtdData2ForAccountPlanInquiry2[]> InvalidPlans
        {
            get
            {
                return new TheoryData<PlanCtdData2ForAccountPlanInquiry2[]>()
                {
                    new[] {CreatePlan("0")},
                    new[] {CreatePlan("1")},
                    new[] {CreatePlan("-21.11")}, //positive balance but not enough for the refund.
                    new PlanCtdData2ForAccountPlanInquiry2[] {},
                };
            }
        }
        
        [Fact]
        public void Should_Return_400_When_MonetaryActionAsync_Throws_FirstDataApiException()
        {
            GivenBrandForClient("31");

            GivenPlanInquiryReturns(
                new AccountPlanInquiryResponse2
                {
                    PlanCtdData = new[] {CreatePlan("-1")}
                });

            GivenMonetaryActionFails();

            //when
            var request = new ReturnFundsRequest
            {
                CardAccountId = CardAccountId,
                Amount = 21.12m,
            };
            var result = _returnFunds.Run(HttpRequest(request)).Result;

            //then
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        private void GivenBrandForClient(string clientNumber)
        {
            _mockBrandHelper.Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(new Brand(
                    clientNumber,
                    clientNumber,
                    "123",
                    new[] {"1"},
                    true));
        }

        private void GivenMonetaryActionSucceeds()
        {
            _transactionsApiClient.Setup(x => x.MonetaryActionAsync(It.Is<MonetaryActionRequest>(y => y.AcctNbr == CardAccountId)))
                .ReturnsAsync(It.Is<MonetaryActionResponse>(x => x.AcctNbr == CardAccountId));
        }
        
        private void GivenMonetaryActionFails()
        {
            var responseStatus = new ResponseStatus()
            {
                ErrorCode = "FS000006",
                OdsMessages = new[]{ "VPE8SS CARD/ACCOUNT NUMBER NOT FOUND" }
            };
            
            var firstDataApiException = new FirstDataApiException(responseStatus);

            _transactionsApiClient.Setup(x => x.MonetaryActionAsync(It.Is<MonetaryActionRequest>(y => y.AcctNbr == CardAccountId)))
                .Throws(firstDataApiException);
        }

        private void GivenPlanInquiryReturns(AccountPlanInquiryResponse2 accountPlanInquiryResponse)
        {
            _accountManagementApiClient.Setup(x => x.AccountPlanInquiryAsync(It.Is<AccountPlanInquiryRequest2>(y => y.Acct == CardAccountId)))
                .ReturnsAsync(accountPlanInquiryResponse);
        }

        private static PlanCtdData2ForAccountPlanInquiry2 CreatePlan(string balance, string planNumber = PlanNumber)
        {
            return new PlanCtdData2ForAccountPlanInquiry2
            {
                PlanCurrBal = balance,
                PlanNbr = planNumber,
                PlanSeqNbr = PlanSequenceNumber
            };
        }

        private static HttpRequest HttpRequest(ReturnFundsRequest request)
        {
            var body = GenerateStreamFromString(JsonConvert.SerializeObject(request));

            var context = new DefaultHttpContext();
            context.Request.Body = body;
            return context.Request;
        }

        private static Stream GenerateStreamFromString(string s)
        {
            var stream = new MemoryStream();
            var writer = new StreamWriter(stream);
            writer.Write(s);
            writer.Flush();
            stream.Position = 0;
            return stream;
        }
    }
}