﻿using System;
using AutoFixture;
using AutoFixture.Idioms;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.ReturnFunds;
using NewDay.Digital.Foundation.Service.CardAccount.Application.ReturnFunds;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.ReturnFunds
{
    public class ReturnFundsConverterTests
    {
        private readonly IFixture _fixture = new Fixture();
        private const string ExpectedActionCode = "CBRD";


        public ReturnFundsConverterTests()
        {
            _fixture.Register(Mock.Of<IBrandHelper>);
            _fixture.Register(Mock.Of<ILogger<ReturnFundsConverter>>);
        }

        [Fact]
        public void Should_guard_constructor_parameter()
        {
            var assertion = new GuardClauseAssertion(_fixture);
            var constructors = typeof(ReturnFundsConverter).GetConstructors();
            assertion.Verify(constructors);
        }

        [Theory]
        [InlineData(nameof(ReturnFundsConverter.ToMonetaryActionRequest))]
        [InlineData(nameof(ReturnFundsConverter.ToAccountPlanInquiryRequest))]
        public void Methods_should_guard_parameters(string methodName)
        {
            var assertion = new GuardClauseAssertion(_fixture);
            var method = typeof(ReturnFundsConverter).GetMethod(methodName);
            assertion.Verify(method);
        }

        [Fact]
        public void Should_convert_to_monetary_action_request()
        {
            var mockBrandHelper = Mock.Of<IBrandHelper>();
            Mock.Get(mockBrandHelper).Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(new Brand(
                    "31",
                    "31",
                    "123",
                    new[] { "1" },
                    true));


            IReturnFundsConverter sut = new ReturnFundsConverter(mockBrandHelper, Mock.Of<ILogger<ReturnFundsConverter>>());

            var request = new ReturnFundsRequest
            {
                CardAccountId = "123141",
                Amount = 21.12m,
            };

            const string planNumber = "1234";
            const string planSequenceNumber = "1243";

            var response = sut.ToMonetaryActionRequest(request, planNumber, planSequenceNumber);


            response.Account.Should().Be(request.CardAccountId);
            response.Common.ClientNumber.Should().Be("31");
            response.ActionCode.Should().Be(ExpectedActionCode);
            response.TxnAmount.Should().Be("0000002112");
            response.StoreNbr.Should().Be("999999998");
            response.ForeignUse.Should().Be("0");
            response.PlanNbr.Should().Be(planNumber);
            response.PlanSeq.Should().Be(planSequenceNumber);
            response.EffDate.Should().Be(DateTimeOffset.Now.ToString("yyyyMMdd"));
        }

        [Fact]
        public void Should_convert_to_plan_inquiry_request()
        {
            var mockBrandHelper = Mock.Of<IBrandHelper>();
            Mock.Get(mockBrandHelper).Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(new Brand(
                    "31",
                    "31",
                    "123",
                    new[] { "1" },
                    true));


            IReturnFundsConverter sut = new ReturnFundsConverter(mockBrandHelper, Mock.Of<ILogger<ReturnFundsConverter>>());
            var request = new ReturnFundsRequest
            {
                CardAccountId = "1234576655"
            };

            var response = sut.ToAccountPlanInquiryRequest(request);

            response.Common.ClientNumber.Should().Be("31");
            response.Account.Should().Be(request.CardAccountId);
            response.Acct.Should().Be(request.CardAccountId);
        }
    }
}