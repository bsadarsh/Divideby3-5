﻿using System;
using System.Linq;
using System.Threading.Tasks;
using AutoFixture;
using FluentAssertions;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v2;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v2.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Transactions.v1;
using NewDay.Digital.Foundation.Connector.FirstData.Transactions.v1.Models;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.ReturnFunds;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.ReturnFunds;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.ReturnFunds
{
    public class ReturnFundsServiceTests
    {
        private readonly ReturnFundsService _sut;
        private readonly Mock<IReturnFundsConverter> _converter;
        private readonly Mock<ITransactionsApiClient> _transactionsApiClient;
        private readonly Mock<IAccountManagementApiClient> _accountManagementApiClient;
        private readonly IFixture _fixture;

        public ReturnFundsServiceTests()
        {
            _transactionsApiClient = new Mock<ITransactionsApiClient>();
            _accountManagementApiClient = new Mock<IAccountManagementApiClient>();
            _converter = new Mock<IReturnFundsConverter>();
            _sut = new ReturnFundsService(
                _transactionsApiClient.Object,
                _accountManagementApiClient.Object,
                _converter.Object,
                new NullLogger<ReturnFundsService>());

            _fixture = new Fixture();
        }

        [Fact]
        public void Should_guard_parameters()
        {
            Func<Task> f = async () => await _sut.ExecuteAsync(null);
            f.Should().ThrowExactly<ArgumentNullException>();
        }

        [Fact]
        public async Task Should_return_successful_response_for_a_valid_request()
        {
            var request = new ReturnFundsRequest
            {
                CardAccountId = _fixture.Create<string>(),
                Amount = 29.99m
            };

            var accountPlanInquiryResponse = new AccountPlanInquiryResponse2
            {
                PlanCtdData = new[]
                {
                    new PlanCtdData2ForAccountPlanInquiry2
                    {
                        PlanCurrBal = "-3000",
                        PlanNbr = _fixture.Create<string>(),
                        PlanSeqNbr = _fixture.Create<string>()
                    },
                }
            };

            _converter.Setup(x =>
                    x.ToAccountPlanInquiryRequest(It.Is<ReturnFundsRequest>(y =>
                        y.CardAccountId == request.CardAccountId)))
                .Returns(new AccountPlanInquiryRequest2("12313")
                {
                    Account = request.CardAccountId,
                    Acct = request.CardAccountId,
                });

            _converter.Setup(x =>
                    x.ToMonetaryActionRequest(It.Is<ReturnFundsRequest>(y => y.CardAccountId == request.CardAccountId),
                        It.Is<string>(y => y == accountPlanInquiryResponse.PlanCtdData.First().PlanNbr),
                        It.Is<string>(y => y == accountPlanInquiryResponse.PlanCtdData.First().PlanSeqNbr)))
                .Returns(new MonetaryActionRequest("1231231"));

            _accountManagementApiClient.Setup(x =>
                    x.AccountPlanInquiryAsync(It.Is<AccountPlanInquiryRequest2>(y => y.Acct == request.CardAccountId)))
                .ReturnsAsync(accountPlanInquiryResponse);

            _transactionsApiClient.Setup(x =>
                    x.MonetaryActionAsync(It.Is<MonetaryActionRequest>(y => y.AcctNbr == request.CardAccountId)))
                .ReturnsAsync(It.Is<MonetaryActionResponse>(x => x.AcctNbr == request.CardAccountId));

            var response = await _sut.ExecuteAsync(request);
            response.Should().BeOfType<DataManagerResponse<ReturnFundsResponse>>();
        }

        [Theory]
        [InlineData(101)]
        [InlineData(100.01)]
        public async Task Should_throw_exception_if_request_amount_is_bigger_than_plan_balance(decimal amount)
        {
            //arrange
            var request = new ReturnFundsRequest
            {
                Amount = amount,
                CardAccountId = _fixture.Create<string>()
            };

            var accountPlanInquiryResponse = new AccountPlanInquiryResponse2
            {
                PlanCtdData = new[]
                {
                    new PlanCtdData2ForAccountPlanInquiry2
                    {
                        PlanCurrBal = "-10000",
                        PlanNbr = _fixture.Create<string>(),
                        PlanSeqNbr = _fixture.Create<string>()
                    },
                }
            };

            _converter.Setup(x =>
                    x.ToAccountPlanInquiryRequest(It.Is<ReturnFundsRequest>(y =>
                        y.CardAccountId == request.CardAccountId)))
                .Returns(new AccountPlanInquiryRequest2("12313")
                {
                    Account = request.CardAccountId,
                    Acct = request.CardAccountId,
                });

            _accountManagementApiClient.Setup(x =>
                    x.AccountPlanInquiryAsync(It.Is<AccountPlanInquiryRequest2>(y => y.Acct == request.CardAccountId)))
                .ReturnsAsync(accountPlanInquiryResponse);

            //act
            Func<Task> act = async () => await _sut.ExecuteAsync(request);

            //assert
            await act.Should().ThrowAsync<PlanNumberNotFoundException>();
        }

        [Fact]
        public async Task Should_succeed_if_request_amount_is_equal_to_plan_balance()
        {
            //arrange
            var request = new ReturnFundsRequest
            {
                Amount = 100,
                CardAccountId = _fixture.Create<string>()
            };

            var accountPlanInquiryResponse = new AccountPlanInquiryResponse2
            {
                PlanCtdData = new[]
                {
                    new PlanCtdData2ForAccountPlanInquiry2
                    {
                        PlanCurrBal = "-10000",
                        PlanNbr = _fixture.Create<string>(),
                        PlanSeqNbr = _fixture.Create<string>()
                    },
                }
            };

            _converter.Setup(x =>
                    x.ToAccountPlanInquiryRequest(It.Is<ReturnFundsRequest>(y =>
                        y.CardAccountId == request.CardAccountId)))
                .Returns(new AccountPlanInquiryRequest2("12313")
                {
                    Account = request.CardAccountId,
                    Acct = request.CardAccountId,
                });

            _converter.Setup(x =>
                    x.ToMonetaryActionRequest(It.Is<ReturnFundsRequest>(y => y.CardAccountId == request.CardAccountId),
                        It.Is<string>(y => y == accountPlanInquiryResponse.PlanCtdData.First().PlanNbr),
                        It.Is<string>(y => y == accountPlanInquiryResponse.PlanCtdData.First().PlanSeqNbr)))
                .Returns(new MonetaryActionRequest("1231231"));

            _accountManagementApiClient.Setup(x =>
                    x.AccountPlanInquiryAsync(It.Is<AccountPlanInquiryRequest2>(y => y.Acct == request.CardAccountId)))
                .ReturnsAsync(accountPlanInquiryResponse);

            _transactionsApiClient.Setup(x =>
                    x.MonetaryActionAsync(It.Is<MonetaryActionRequest>(y => y.AcctNbr == request.CardAccountId)))
                .ReturnsAsync(It.Is<MonetaryActionResponse>(x => x.AcctNbr == request.CardAccountId));

            //act
            var response = await _sut.ExecuteAsync(request);

            //assert
            response.Should().BeOfType<DataManagerResponse<ReturnFundsResponse>>();
        }
    }
}