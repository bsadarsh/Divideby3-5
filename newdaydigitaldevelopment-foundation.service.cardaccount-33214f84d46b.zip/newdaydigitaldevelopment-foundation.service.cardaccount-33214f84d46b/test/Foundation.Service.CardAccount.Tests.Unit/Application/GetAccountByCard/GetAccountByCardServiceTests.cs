﻿using AutoFixture;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.GetAccountByCard;
using System;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.GetAccountByCard
{
    public class GetAccountByCardServiceTests
    {
        [Fact]
        public async Task Should_return_badRequest_if_cardnumber_passed_in_is_not_recognised()
        {
            var request = new Fixture().Create<GetAccountByCardRequest>();

            var brandHelperMock = new Mock<IBrandHelper>();
            var timeoutMock = new Mock<ITimeoutProvider>();
            timeoutMock.SetupGet(x => x.Timeout).Returns(TimeSpan.FromSeconds(1));
            

            var service = new GetAccountByCardService(timeoutMock.Object, new GetAccountByCardConverter(brandHelperMock.Object), null, null);
            Func<Task<DataManagerResponse<GetAccountByCardResponse>>> func = () => service.ExecuteAsync(request);
            await func.Should().ThrowAsync<InvalidBrandException>();
        }

        [Fact]
        public async Task Should_return_correct_response_if_valid_cardnumber_is_sent_in_the_request()
        {
            var fixture = new Fixture();
            var request = fixture.Create<GetAccountByCardRequest>();

            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(a => a.GetClientNumberFromCardNumber(request.CardNumber))
                .Returns(fixture.Create<string>());

            var inquiryResponse = fixture.Build<AccountDetailInquiryResponse3>()
                .With(n => n.BlockCode1, "0")
                .With(n => n.BlockCode2, "2")
                .With(n => n.BlockCode1Priority, "2")
                .With(n => n.BlockCode2Priority, "2")
                .With(n => n.CurrencyNod, "2")
                .With(n => n.AvailCredit, "200")
                .With(n => n.CurrBal, "200")
                .With(n => n.Crlim, "200")
                .With(n => n.Account, "1234567890123456")
                .With(n => n.InstSpndFl, "1")
                .Create();

            var dataManagerResponse = new DataManagerResponse<AccountDetailInquiryResponse3>(inquiryResponse, DateTime.Now, TimeSpan.Zero);
            var expectedResponse = new DataManagerResponse<GetAccountByCardResponse>(new GetAccountByCardResponse
            {
                CardAccountId = "1234567890123456"
            }, DateTime.Now, TimeSpan.Zero);

            var accountApiClientMock = new Mock<IAccountManagementApiClient>(MockBehavior.Strict);
            accountApiClientMock
                .Setup(n => n.AccountDetailInquiryAsync(It.IsAny<AccountDetailInquiryRequest3>()))
                .ReturnsAsync(inquiryResponse);

            var dataManagerMock = new Mock<IDataManager>(MockBehavior.Strict);
            dataManagerMock
                .Setup(n => n.FetchWithCacheAsync(It.IsAny<string>(), It.IsAny<TimeSpan>(), It.IsAny<Func<Task<AccountDetailInquiryResponse3>>>()))
                .ReturnsAsync(dataManagerResponse);
            
            var timeoutMock = new Mock<ITimeoutProvider>();
            timeoutMock.SetupGet(x => x.Timeout).Returns(TimeSpan.FromSeconds(1));

            var service = new GetAccountByCardService(timeoutMock.Object, new GetAccountByCardConverter(brandHelperMock.Object), accountApiClientMock.Object, dataManagerMock.Object);
            var actualResponse = await service.ExecuteAsync(request);

            actualResponse.Should().BeEquivalentTo(expectedResponse, config => config
                .Excluding(x => x.CacheAge)
                .Excluding(x => x.CacheExpires));
        }
    }
}