﻿using System;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.GetAccountByCard;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.GetAccountByCard
{
    public class GetAccountByCardConverterTests
    {
        [Fact]
        public void Should_convert_GetAccountByCardRequest_to_AccountDetailInquiryRequest()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(x => x.GetClientNumberFromCardNumber(It.IsAny<string>()))
                .Returns("1234567890123456");
            var converter = new GetAccountByCardConverter(brandHelperMock.Object);

            var expected = new AccountDetailInquiryRequest3("1234567890123456")
            {
                Account = "0000111122223333"
            };

            var actual = converter.ToAccountDetailInquiryRequest(new GetAccountByCardRequest
            {
                CardNumber = "0000111122223333"
            });

            actual.Should().BeEquivalentTo(expected);
        }

        [Fact]
        public void Should_throw_InvalidBrandException_on_convert_null_GetAccountByCardRequest()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(x => x.GetClientNumberFromCardNumber(It.IsAny<string>()))
                .Returns((string)null);
            var converter = new GetAccountByCardConverter(brandHelperMock.Object);

            Action act = () => converter.ToAccountDetailInquiryRequest(new GetAccountByCardRequest
            {
                CardNumber = "0000111122223333"
            });

            act.Should().Throw<InvalidBrandException>();
        }

        [Fact]
        public void Should_convert_AccountDetailInquiryResponse_to_GetAccountByCardResponse()
        {
            var converter = new GetAccountByCardConverter(null);

            var expected = new GetAccountByCardResponse
            {
                CardAccountId = "1234567890123456"
            };

            var actual = converter.ToGetAccountByCardResponse(new AccountDetailInquiryResponse3
            {
                Account = "0001234567890123456"
            });
            actual.Should().BeEquivalentTo(expected);
        }
    }
}
