﻿using System.Collections.Generic;
using System.Linq;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Insurance.v3.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetInsuranceProducts;
using NewDay.Digital.Foundation.Service.CardAccount.Application.GetInsuranceProducts;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.GetInsuranceProducts
{
    public class GetInsuranceProductsConverterTests
    {
        private readonly IGetInsuranceProductsConverter _getPlansConverter;

        public GetInsuranceProductsConverterTests()
        {
            var brandHelperMock = new Mock<IBrandHelper>();

            brandHelperMock.Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(new Brand("opus", "1105500010092766", "110", new List<string>(), true));

            _getPlansConverter = new GetInsuranceProductsConverter(brandHelperMock.Object);
        }

        private static readonly InsData3ForInsuranceInquiry3 FdInsuranceProduct = new InsData3ForInsuranceInquiry3()
        {
            EffDt = "20200217",
            InsStatCd = "F",
            InsPrdDesc = "ProductName",
            InsBlngFreq = "0",
            PlcChnl = "1000000000",
            InsTyp = "0",
            InsCanDt = "20200317",
            InsInsPrem = "1000",
            CanRsn = "A"
        };

        private static readonly InsuranceInquiryResponse3 FdResponse = new InsuranceInquiryResponse3()
        {
            InsData = new List<InsData3ForInsuranceInquiry3>()
            {
                FdInsuranceProduct
            }
        };

        [Fact]
        public void Should_map_get_insurance_products_request_to_insurance_inquiry()
        {
            var request = new GetInsuranceProductsRequest()
            {
                CardAccountId = "1105500010092766"
            };

            var inquiry = _getPlansConverter.ToInsuranceInquiryRequest(request);

            inquiry.Account.Should().Be("1105500010092766");
        }

        [Fact]
        public void Should_map_insurance_inquiry_response_to_get_insurance_products_response()
        {
            var response = _getPlansConverter.ToGetInsuranceProductsResponse(FdResponse);

            response.InsuranceProducts.Should().HaveCount(1);
            var insuranceProduct = response.InsuranceProducts.ToList()[0];

            insuranceProduct.EffectiveDate.Should().Be("20200217");
            insuranceProduct.Active.Should().Be(true);
            insuranceProduct.ProductName.Should().Be("ProductName");
            insuranceProduct.BillingFrequency.Should().Be("0");
            insuranceProduct.PolicyReferenceNumber.Should().Be("1000000000");
            insuranceProduct.ProductCode.Should().Be("0");
            insuranceProduct.CancellationDate.Should().Be("20200317");
            insuranceProduct.Premium.Should().Be("1000");
            insuranceProduct.CancellationReason.Should().Be(CancellationReason.ReachedExpirationAge);
        }

        [Theory]
        [InlineData("A", CancellationReason.ReachedExpirationAge)]
        [InlineData("B", CancellationReason.BlockCode)]
        [InlineData("C", CancellationReason.ChargedOff)]
        [InlineData("D", CancellationReason.PastDue)]
        [InlineData("P", CancellationReason.CreditLineAccountClosed)]
        [InlineData("R", CancellationReason.RequestOfCustomer)]
        public void Should_map_cancellation_reason_to_correct_enum_value(string cancellationReason, CancellationReason enumValue)
        {
            FdInsuranceProduct.CanRsn = cancellationReason;

            var response = _getPlansConverter.ToGetInsuranceProductsResponse(FdResponse);

            response.InsuranceProducts.ToList()[0].CancellationReason.Should().Be(enumValue);
        }
    }
}
