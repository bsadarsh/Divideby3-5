﻿using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.ChargeOff;
using System;
using AutoFixture;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Service.CardAccount.Application.ChargeOff;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.ChargeOff
{
    public class ChargeOffConverterTests
    {
        [Fact]
        public void Should_throw_InvalidBrandException_for_invalid_card_account_number_on_AccountCloseRequest_conversion()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns((Brand)null)
                .Verifiable();

            var converter = new ChargeOffConverter(brandHelperMock.Object);

            Action act = () => converter.ToAccountCloseRequest(new ChargeOffRequest()
            {
                CardAccountId = "0000111122223333",
                Reason = ChargeOffReason.B1
            });
            act.Should().Throw<InvalidBrandException>();
        }

        [Fact]
        public void Should_convert_to_AccountCloseRequest()
        {
            var brand = new Fixture().Create<Brand>();

            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(brand)
                .Verifiable();

            var domainRequest = new ChargeOffRequest()
            {
                CardAccountId = "0000111122223333",
                Reason = ChargeOffReason.B1
            };

            var converter = new ChargeOffConverter(brandHelperMock.Object);

            var fdRequest = converter.ToAccountCloseRequest(domainRequest);

            fdRequest.AcctNbr.Should().Be("0000111122223333");
            fdRequest.FunctionCode.Should().Be("2");
            fdRequest.ChgoffReason.Should().Be("B1");
        }
    }
}