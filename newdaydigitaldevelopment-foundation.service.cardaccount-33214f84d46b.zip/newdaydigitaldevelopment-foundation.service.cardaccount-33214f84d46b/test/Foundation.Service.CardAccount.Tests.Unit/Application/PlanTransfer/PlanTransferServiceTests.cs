﻿using AutoFixture;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Loans.v2.Models;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.PlanTransfer;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.PlanTransfer;
using System.Threading.Tasks;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Cache;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.PlanTransfer
{
    public class PlanTransferServiceTests
    {
        private readonly IExecutable<PlanTransferRequest, DataManagerResponse<PlanTransferResponse>>
            _planTransferService;

        private readonly Mock<Connector.FirstData.AccountMaintenance.v1.IAccountMaintenanceApiClient> _accountMaintenanceApiClientV1Mock;
        private readonly Mock<Connector.FirstData.Loans.v2.ILoansApiClient> _loansApiClientV2Mock;

        public PlanTransferServiceTests()
        {
            _accountMaintenanceApiClientV1Mock = new Mock<Connector.FirstData.AccountMaintenance.v1.IAccountMaintenanceApiClient>();
            _loansApiClientV2Mock = new Mock<Connector.FirstData.Loans.v2.ILoansApiClient>();

            var brand = new Fixture().Create<Brand>();
            var brandHelperMock = new Mock<IBrandHelper>();

            brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(brand)
                .Verifiable();

            var converter = new PlanTransferConverter(brandHelperMock.Object);

            var cacheKeyProviderMock = new Mock<IAccountPlanInquiryCacheKeyProvider>();
            cacheKeyProviderMock.Setup(x => x.GetKey(It.IsAny<string>())).Returns("cacheKey");

            var dataManagerMock = new Mock<IDataManager>();

            _planTransferService = new PlanTransferService(converter, _accountMaintenanceApiClientV1Mock.Object,
                _loansApiClientV2Mock.Object, dataManagerMock.Object, cacheKeyProviderMock.Object);
        }

        [Fact]
        public void Should_make_orchestration_call_if_not_given_recNbr()
        {
            var planTransferRequest = new PlanTransferRequest()
            {
                CardAccountId = "0000111122223333",
                FromPlan = "50900",
                ToPlan = "50100"
            };

            var accountPlanListResponse = new AccountPlanListResponse2()
            {
                PlanCtdData = new[]
                {
                    new PlanCtdData2ForAccountPlanList2()
                    {
                        PlanNbr = "50900",
                        PlanRecNbr = "123"
                    },
                    new PlanCtdData2ForAccountPlanList2()
                    {
                        PlanNbr = "50100",
                        PlanRecNbr = "321"
                    }
                }
            };

            _loansApiClientV2Mock.Setup(m => m.AccountPlanListAsync(It.IsAny<AccountPlanListRequest2>()))
                .ReturnsAsync(accountPlanListResponse);
            _planTransferService.ExecuteAsync(planTransferRequest);

            _loansApiClientV2Mock.Verify(m => m.AccountPlanListAsync(It.IsAny<AccountPlanListRequest2>()), Times.Once);
        }

        [Fact]
        public async void Should_throw_no_plan_found_exception()
        {
            var planTransferRequest = new PlanTransferRequest()
            {
                CardAccountId = "0000111122223333",
                FromPlan = "50900",
                ToPlan = "50100"
            };
            var accountPlanListResponse = new AccountPlanListResponse2()
            {
                PlanCtdData = new[]
                {
                    new PlanCtdData2ForAccountPlanList2()
                    {
                        PlanNbr = "50899",
                        PlanRecNbr = "123"
                    },
                    new PlanCtdData2ForAccountPlanList2()
                    {
                        PlanNbr = "50100",
                        PlanRecNbr = "321"
                    }
                }
            };
            _loansApiClientV2Mock.Setup(m => m.AccountPlanListAsync(It.IsAny<AccountPlanListRequest2>()))
                .ReturnsAsync(accountPlanListResponse);
            Task Action() => _planTransferService.ExecuteAsync(planTransferRequest);
            await Assert.ThrowsAsync<NoPlanFoundException>(Action);
        }
    }
}
