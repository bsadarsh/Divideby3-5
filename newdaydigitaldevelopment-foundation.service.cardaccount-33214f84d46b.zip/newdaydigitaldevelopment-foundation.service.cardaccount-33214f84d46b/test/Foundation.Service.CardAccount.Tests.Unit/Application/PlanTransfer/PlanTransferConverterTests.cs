﻿using AutoFixture;
using FluentAssertions;
using Moq;
using FirstDataPlanTransferRequest = NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models.PlanTransferRequest;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.PlanTransfer;
using NewDay.Digital.Foundation.Service.CardAccount.Application.PlanTransfer;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.PlanTransfer
{
    public class PlanTransferConverterTests
    {
        private Mock<IBrandHelper> GetBrandHelperMock()
        {
            var brand = new Fixture().Create<Brand>();

            var brandHelperMock = new Mock<IBrandHelper>();

            brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(brand)
                .Verifiable();

            return brandHelperMock;
        }

        [Fact]
        public void Should_convert_transfer_plan_request_to_first_data_request()
        {
            var brandHelperMock = GetBrandHelperMock();

            var domainRequest = new PlanTransferRequest()
            {
                CardAccountId = "0000000111122223333",
                FromPlan = "50900",
                FromRecordNumber = "123",
                ToPlan = "50901",
                ToRecordNumber = "321"
            };

            var converter = new PlanTransferConverter(brandHelperMock.Object);

            var fdRequest = converter.ToFirstDataPlanTransferRequest(domainRequest);

            fdRequest.Account.Should().Be("0000000111122223333");
            fdRequest.PlanNbr.Should().Be("50900");
            fdRequest.RecNbr.Should().Be(123.ToString());
            fdRequest.ToPlanNbr.Should().Be("50901");
            fdRequest.ToRecNbr.Should().Be(321.ToString());
            fdRequest.TransferFunction.Should().Be(PlanTransferConverter.TransferTypeCode);
        }

        [Fact]
        public void Should_convert_first_data_PlanTransferRequest_to_orchestration_request()
        {
            var brandHelperMock = GetBrandHelperMock();
            var clientNumber = "clientNumbere19cd7a3-8995-4ac7-b7e9-3b6440b00690";
            var firstDataRequest = new FirstDataPlanTransferRequest(clientNumber)
            {
                Account = "0000000111122223333"
            };

            var converter = new PlanTransferConverter(brandHelperMock.Object);
            var orchestrationRequest = converter.ToAccountPlanListRequest2(firstDataRequest);
            orchestrationRequest.Acct.Should().Be("0000000111122223333");
        }

        [Fact]
        public void Should_add_leading_zeroes_to_16_digits_long_cardAccountId()
        {
            var brandHelperMock = GetBrandHelperMock();

            var domainRequest = new PlanTransferRequest()
            {
                CardAccountId = "0000111122223333",
                FromPlan = "50900",
                FromRecordNumber = "123",
                ToPlan = "50901",
                ToRecordNumber = "321"
            };

            var converter = new PlanTransferConverter(brandHelperMock.Object);

            var fdRequest = converter.ToFirstDataPlanTransferRequest(domainRequest);

            fdRequest.Account.Should().Be("0000000111122223333");
            fdRequest.PlanNbr.Should().Be("50900");
            fdRequest.RecNbr.Should().Be(123.ToString());
            fdRequest.ToPlanNbr.Should().Be("50901");
            fdRequest.ToRecNbr.Should().Be(321.ToString());
            fdRequest.TransferFunction.Should().Be(PlanTransferConverter.TransferTypeCode);
        }
    }
}
