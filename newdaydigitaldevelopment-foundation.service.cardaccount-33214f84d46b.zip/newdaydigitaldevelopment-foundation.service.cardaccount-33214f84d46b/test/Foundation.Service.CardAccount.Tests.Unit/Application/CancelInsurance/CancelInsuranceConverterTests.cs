﻿using System;
using System.Collections.Generic;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.CancelInsurance;
using NewDay.Digital.Foundation.Service.CardAccount.Application.CancelInsurance;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.CancelInsurance
{
    public class CancelInsuranceConverterTests
    {
        IBrandHelper mockBrand;
        ICancelInsuranceConverter sut;

        public CancelInsuranceConverterTests()
        {
            mockBrand = Mock.Of<IBrandHelper>();
            Mock.Get(mockBrand).Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>())).Returns(new Brand("31", "31", "123", new[] { "1" }, true));

            sut = new CancelInsuranceConverter(mockBrand);
        }

        [Theory]
        [InlineData("01", CancellationReason.AmountAtRisk, "T")]
        [InlineData("3d", CancellationReason.DOBEnrollment, "G")]
        public void Should_convert_cancelIsuranceRequest_into_insurance_status_update_request(string productCode, CancellationReason reason, string expectedReasonCode)
        {
            var request = new CancelInsuranceRequest
            {
                CardAccountId = "123141",
                ProductCode = productCode,
                CancellationReason = reason,
            };

            var response = sut.ToInsuranceStatusUpdateRequest(request);

            response.Account.Should().Be(request.CardAccountId);
            response.InsProdCode.Should().Be(request.ProductCode);
            response.InsStatusCode.Should().Be("C");
            response.CanReasonCode.Should().Be(expectedReasonCode);
        }

        [Fact]
        public void Should_ToInsuranceStatusUpdateRequest_throw_exception_when_CancellationReason_is_unknown()
        {
            Action act = () =>
            {
                sut.ToInsuranceStatusUpdateRequest(new CancelInsuranceRequest
                {
                    CardAccountId = "123141",
                    ProductCode = "PC",
                    CancellationReason = (CancellationReason)15,
                });
            };

            act.Should().ThrowExactly<KeyNotFoundException>();
        }
    }
}
