﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Insurance.v1;
using NewDay.Digital.Foundation.Connector.FirstData.Insurance.v1.Models;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.CancelInsurance;
using NewDay.Digital.Foundation.Service.CardAccount.Application.CancelInsurance;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.CancelInsurance
{
    public class CancelInsuranceServiceTests
    {
        [Fact]
        public async Task Should_return_badRequest_if_cardaccountid_passed_in_is_not_recognised()
        {
            var request = new CancelInsuranceRequest
            {
                CardAccountId = "bad card account id"
            };

            var insuranceApiClient = new Mock<IInsuranceApiClient>();
            var brandHelperMock = new Mock<IBrandHelper>();
            var service = new CancelInsuranceService(new CancelInsuranceConverter(brandHelperMock.Object), insuranceApiClient.Object);
            Func<Task<DataManagerResponse<CancelInsuranceResponse>>> func = () => service.ExecuteAsync(request);

            await func.Should().ThrowAsync<InvalidBrandException>();
        }

        [Fact]
        public async Task Should_return_badRequest_if_cancellationReason_is_not_recognised()
        {
            var request = new CancelInsuranceRequest
            {
                CardAccountId = "1234567890123456",
                CancellationReason = (CancellationReason)12
            };

            var insuranceApiClient = new Mock<IInsuranceApiClient>();
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock.Setup(a => a.GetBrandFromAccountNumber(request.CardAccountId)).Returns(new Brand("31", "31", "123", new[] { "1" }, true));

            var service = new CancelInsuranceService(new CancelInsuranceConverter(brandHelperMock.Object), insuranceApiClient.Object);
            Func<Task<DataManagerResponse<CancelInsuranceResponse>>> func = () => service.ExecuteAsync(request);

            await func.Should().ThrowAsync<KeyNotFoundException>();
        }

        [Theory]
        [MemberData(nameof(GetValidRequests))]
        public async Task Should_return_successful_response_for_a_valid_request(CancelInsuranceRequest request)
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock.Setup(a => a.GetBrandFromAccountNumber(request.CardAccountId)).Returns(new Brand("31", "31", "123", new[] { "1" }, true));

            var insuranceApiClient = new Mock<IInsuranceApiClient>();
            insuranceApiClient.Setup(x =>
                    x.InsuranceStatusUpdateAsync(It.Is<InsuranceStatusUpdateRequest>(y => y.Account == request.CardAccountId)))
                .ReturnsAsync(It.Is<InsuranceStatusUpdateResponse>(x => x.Account == request.CardAccountId));

            var service = new CancelInsuranceService(new CancelInsuranceConverter(brandHelperMock.Object), insuranceApiClient.Object);
            var response = await service.ExecuteAsync(request);

            response.Should().NotBeNull();
        }


        #region GetValidRequests
        public static TheoryData<CancelInsuranceRequest> GetValidRequests()
        {
            var blockCode = new CancelInsuranceRequest()
            {
                CardAccountId = "123412341234",
                ProductCode = "p1",
                CancellationReason = CancellationReason.Delinquency
            };

            var creditLineAccountClosed = new CancelInsuranceRequest()
            {
                CardAccountId = "123412341235",
                ProductCode = "p2",
                CancellationReason = CancellationReason.CreditLineAccountClosed
            };

            var pastDue = new CancelInsuranceRequest()
            {
                CardAccountId = "123412341236",
                ProductCode = "p2",
                CancellationReason = CancellationReason.Other
            };

            return new TheoryData<CancelInsuranceRequest>()
            {
                blockCode,
                creditLineAccountClosed,
                pastDue
            };
        }
        #endregion
    }
}
