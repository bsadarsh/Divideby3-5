﻿using System.Collections.Generic;
using System.Linq;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v2.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetPlans;
using NewDay.Digital.Foundation.Service.CardAccount.Application.GetPlans;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.GetPlans
{
    public class GetPlansConverterTests
    {
        private readonly IGetPlansConverter _getPlansConverter;

        public GetPlansConverterTests()
        {
            var brandHelperMock = new Mock<IBrandHelper>();

            brandHelperMock.Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(new Brand("opus", "1105500010092766", "110", new List<string>(), true));

            _getPlansConverter = new GetPlansConverter(brandHelperMock.Object);
        }
        private static readonly PlanCtdData2ForAccountPlanInquiry2 CustomerPlan = new PlanCtdData2ForAccountPlanInquiry2()
        {
            PlanNbr = "10004",
            PlanCurrBal = "1010",
            PlanCurrAer = "1234000",
            PerDiemInterest = "1000",
            EstimatedInterest = "14",
            PlanType = "C",
            AccruedInterest = "1812",
            PlanDesc = "super plan",
            PlanOpenDte = "20201224",
        };
        private static readonly AccountPlanInquiryResponse2 FdResponse = new AccountPlanInquiryResponse2()
        {
            PlanCtdData = new List<PlanCtdData2ForAccountPlanInquiry2>()
            {
                CustomerPlan
            }
        };

        [Fact]
        public void Should_map_get_plans_request_to_account_plan_inquiry()
        {
            var request = new GetPlansRequest()
            {
                CardAccountId = "1105500010092766"
            };

            var inquiry = _getPlansConverter.ToAccountPlanInquiry(request);

            inquiry.Acct.Should().Be("1105500010092766");
        }

        [Fact]
        public void Should_map_account_inquiry_response_to_get_plans_response()
        {
            var response = _getPlansConverter.ToGetPlansResponse(FdResponse);

            response.Plans.Should().HaveCount(1);
            var plan = response.Plans.ToList()[0];

            plan.Identifier.Should().Be(CustomerPlan.PlanNbr);
            plan.Balance.Should().Be("10.1");
            plan.Aer.Should().Be("0.1234");
            plan.DailyInterest.Should().Be("0.1");
            plan.InterestEstimated.Should().Be("0.14");
            plan.Type.Should().Be(PlanType.Cash);
            plan.InterestAccrued.Should().Be("0.1812");
            plan.Description.Should().Be(CustomerPlan.PlanDesc);
            plan.OpenDate.Should().HaveYear(2020);
            plan.OpenDate.Should().HaveMonth(12);
            plan.OpenDate.Should().HaveDay(24);
            plan.Active.Should().Be("Y");
        }

        [Theory]
        [InlineData("A", PlanType.AccessCheck)]
        [InlineData("B", PlanType.BalanceTransfer)]
        [InlineData("T", PlanType.BalanceTransfer)]
        [InlineData("C", PlanType.Cash)]
        [InlineData("L", PlanType.ClosedEndInstallmentLoan)]
        [InlineData("R", PlanType.Retail)]
        [InlineData("Y", PlanType.Prepaid)]
        [InlineData("XYZ", PlanType.Unknown)]
        public void Should_map_plan_type_to_correct_enum_value(string planType, PlanType enumValue)
        {
            CustomerPlan.PlanType = planType;

            var response = _getPlansConverter.ToGetPlansResponse(FdResponse);

            response.Plans.ToList()[0].Type.Should().Be(enumValue);
        }
    }
}
