﻿using System;
using AutoFixture;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.UpdateAccount;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.UpdateAccount;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.UpdateAccount
{
    public class UpdateAccountConverterTests
    {
        private Mock<IBrandHelper> GetInvalidBrandHelperMock()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns((Brand)null)
                .Verifiable();

            return brandHelperMock;
        }

        private Mock<IBrandHelper> GetBrandHelperMock()
        {
            var brand = new Fixture().Create<Brand>();

            var brandHelperMock = new Mock<IBrandHelper>();

            brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(brand)
                .Verifiable();

            return brandHelperMock;
        }

        private static readonly UpdateAccountRequest DisabilityIndicatorUpdateAccountRequest = new UpdateAccountRequest()
        {
            CardAccountId = "3915000011686878",
            DisabilityIndicator = DisabilityIndicator.Audio
        };

        private static readonly UpdateAccountRequest CustomFieldsUpdateAccountRequest = new UpdateAccountRequest()
        {
            CardAccountId = "3915000011686878",
            FixedPaymentAmount = 14.30m
        };

        private static readonly UpdateAccountRequest DisabilityIndicatorUpdateAccountRequestLeadingZeros = new UpdateAccountRequest()
        {
            CardAccountId = "0003915000011686878",
            DisabilityIndicator = DisabilityIndicator.Audio
        };

        private static readonly UpdateAccountRequest CustomFieldsUpdateAccountRequestLeadingZeros = new UpdateAccountRequest()
        {
            CardAccountId = "0003915000011686878",
            FixedPaymentAmount = 14.30m
        };

        private static readonly UpdateAccountRequest BlockCodeUpdateAccountRequest = new UpdateAccountRequest()
        {
            CardAccountId = "3915000011686878",
            Status = Status.NFA,
            SubStatus = "01",
            StatusIndicator = "0",
            ProductCode = "02",
            RestructureFlag = false
        };

        private static readonly UpdateAccountRequest UserFieldsUpdateAccountRequest = new UpdateAccountRequest()
        {
            CardAccountId = "3915000011686878",
            Code1 = "T1",
            Amount1 = 14.30m,
            Miscellaneous1 = "Test",
            Date1 = new DateTime(2021,02,11)
        };

        [Fact]
        public void Should_throw_InvalidBrandException_for_invalid_card_account_number_on_disability_indicator_request_conversion()
        {
            var brandHelperMock = GetInvalidBrandHelperMock();

            var converter = new UpdateAccountConverter(brandHelperMock.Object);

            Action act = () => converter.ToAccountDisabilityIndicatorUpdateRequest(DisabilityIndicatorUpdateAccountRequest);
            act.Should().Throw<InvalidBrandException>();
        }

        [Fact]
        public void Should_throw_InvalidBrandException_for_invalid_card_account_number_on_custom_fields_request_conversion()
        {
            var brandHelperMock = GetInvalidBrandHelperMock();

            var converter = new UpdateAccountConverter(brandHelperMock.Object);

            Action act = () => converter.ToAccountCustomFieldsUpdateRequest(CustomFieldsUpdateAccountRequest);
            act.Should().Throw<InvalidBrandException>();
        }

        [Fact]
        public void Should_throw_InvalidBrandException_for_invalid_card_account_number_on_block_code_request_conversion()
        {
            var brandHelperMock = GetInvalidBrandHelperMock();

            var converter = new UpdateAccountConverter(brandHelperMock.Object);

            Action act = () => converter.ToAccountBlockCodeUpdateRequest(BlockCodeUpdateAccountRequest);
            act.Should().Throw<InvalidBrandException>();
        }

        [Fact]
        public void Should_throw_InvalidBrandException_for_invalid_card_account_number_on_user_fields_request_conversion()
        {
            var brandHelperMock = GetInvalidBrandHelperMock();

            var converter = new UpdateAccountConverter(brandHelperMock.Object);

            Action act = () => converter.ToAccountUserFieldsUpdateRequest(UserFieldsUpdateAccountRequest);
            act.Should().Throw<InvalidBrandException>();
        }

        [Fact]
        public void Should_convert_disability_indicator_domain_request_to_fd_request()
        {
            var brandHelperMock = GetBrandHelperMock();

            var converter = new UpdateAccountConverter(brandHelperMock.Object);

            var accountDisabilityIndicatorUpdateRequest = converter.ToAccountDisabilityIndicatorUpdateRequest(DisabilityIndicatorUpdateAccountRequest);

            accountDisabilityIndicatorUpdateRequest.AcctNbr.Should().Be("0003915000011686878");
            accountDisabilityIndicatorUpdateRequest.DisabltyInd.Should().Be("A");
        }

        [Fact]
        public void Should_convert_disability_indicator_domain_request_with_leading_zeros_in_cardAccountId_to_fd_request()
        {
            var brandHelperMock = GetBrandHelperMock();

            var converter = new UpdateAccountConverter(brandHelperMock.Object);

            var accountDisabilityIndicatorUpdateRequest = converter.ToAccountDisabilityIndicatorUpdateRequest(DisabilityIndicatorUpdateAccountRequestLeadingZeros);

            accountDisabilityIndicatorUpdateRequest.AcctNbr.Should().Be("0003915000011686878");
            accountDisabilityIndicatorUpdateRequest.DisabltyInd.Should().Be("A");
        }

        [Fact]
        public void Should_convert_custom_fields_domain_request_to_fd_request()
        {
            var brandHelperMock = GetBrandHelperMock();

            var converter = new UpdateAccountConverter(brandHelperMock.Object);

            var accountCustomFieldsUpdateRequest = converter.ToAccountCustomFieldsUpdateRequest(CustomFieldsUpdateAccountRequest);
            accountCustomFieldsUpdateRequest.Account.Should().Be("0003915000011686878");
            accountCustomFieldsUpdateRequest.FixedPmtAmt.Should().Be("1430");
            accountCustomFieldsUpdateRequest.PlanPmtOvrdFlag.Should().Be("F");
        }

        [Fact]
        public void Should_convert_custom_fields_domain_request_with_leading_zeros_in_cardAccountId_to_fd_request()
        {
            var brandHelperMock = GetBrandHelperMock();

            var converter = new UpdateAccountConverter(brandHelperMock.Object);

            var accountCustomFieldsUpdateRequest = converter.ToAccountCustomFieldsUpdateRequest(CustomFieldsUpdateAccountRequestLeadingZeros);
            accountCustomFieldsUpdateRequest.Account.Should().Be("0003915000011686878");
            accountCustomFieldsUpdateRequest.FixedPmtAmt.Should().Be("1430");
            accountCustomFieldsUpdateRequest.PlanPmtOvrdFlag.Should().Be("F");
        }

        [Fact]
        public void Should_convert_block_code_domain_request_to_fd_request()
        {
            var brandHelperMock = GetBrandHelperMock();

            var converter = new UpdateAccountConverter(brandHelperMock.Object);

            var accountBlockCodeUpdateRequest = converter.ToAccountBlockCodeUpdateRequest(BlockCodeUpdateAccountRequest);

            accountBlockCodeUpdateRequest.CardNbr.Should().Be("3915000011686878");
            accountBlockCodeUpdateRequest.BlkCd.Should().Be("N");
            accountBlockCodeUpdateRequest.FunctionCd.Should().Be("B");
            accountBlockCodeUpdateRequest.BlkCdInd.Should().Be("0");
            accountBlockCodeUpdateRequest.SubStatus.Should().Be("01");
            accountBlockCodeUpdateRequest.ProdCodeAccType.Should().Be("02");
            accountBlockCodeUpdateRequest.AcctRestructure.Should().Be("N");
        }

        [Fact]
        public void Should_convert_user_fields_domain_request_to_fd_request()
        {
            var brandHelperMock = GetBrandHelperMock();

            var converter = new UpdateAccountConverter(brandHelperMock.Object);

            var accountUserFieldsUpdateRequest = converter.ToAccountUserFieldsUpdateRequest(UserFieldsUpdateAccountRequest);

            accountUserFieldsUpdateRequest.AcctNbr.Should().Be("3915000011686878");
            accountUserFieldsUpdateRequest.UserCode1.Should().Be("T1");
            accountUserFieldsUpdateRequest.UserAmt1.Should().Be("1430");
            accountUserFieldsUpdateRequest.MiscUser1.Should().Be("Test");
            accountUserFieldsUpdateRequest.UserDate1.Should().Be("20210211");
        }

        [Fact]
        public void Should_convert_update_account_request_to_detail_inquiry_request()
        {
            var brandHelperMock = GetBrandHelperMock();

            var converter = new UpdateAccountConverter(brandHelperMock.Object);

            var detailInquiryRequest = converter.ToAccountDetailInquiryRequest(BlockCodeUpdateAccountRequest);

            detailInquiryRequest.Account.Should().Be("3915000011686878");
        }
    }
}