﻿using System.Threading.Tasks;
using AutoFixture;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v2.Models;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.UpdateAccount;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Cache;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.UpdateAccount;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.UpdateAccount
{
    public class UpdateAccountServiceTests
    {
        private readonly UpdateAccountService _service;
        private readonly Mock<IAccountManagementApiClient> _accountManagementApiClientMock = new Mock<IAccountManagementApiClient>();

        private readonly Mock<Connector.FirstData.AccountMaintenance.v1.IAccountMaintenanceApiClient>
            _accountMaintenanceV1ApiClientMock =
                new Mock<Connector.FirstData.AccountMaintenance.v1.IAccountMaintenanceApiClient>();

        private readonly Mock<Connector.FirstData.AccountMaintenance.v2.IAccountMaintenanceApiClient>
            _accountMaintenanceV2ApiClientMock =
                new Mock<Connector.FirstData.AccountMaintenance.v2.IAccountMaintenanceApiClient>();

        public UpdateAccountServiceTests()
        {
            var brand = new Fixture().Create<Brand>();

            var brandHelperMock = new Mock<IBrandHelper>();

            brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(brand)
                .Verifiable();

            var cacheKeyProviderMock = new Mock<IAccountDetailInquiryCacheKeyProvider>();
            cacheKeyProviderMock.Setup(x => x.GetKey(It.IsAny<string>())).Returns("cacheKey");

            var dataManagerMock = new Mock<IDataManager>();

            _service = new UpdateAccountService(new UpdateAccountConverter(brandHelperMock.Object),
                _accountMaintenanceV1ApiClientMock.Object, _accountMaintenanceV2ApiClientMock.Object,
                _accountManagementApiClientMock.Object, dataManagerMock.Object, cacheKeyProviderMock.Object);
        }

        [Fact]
        public async Task Should_not_call_user_fields_endpoint_if_no_fields_are_defined()
        {
            var updateAccountRequest = new UpdateAccountRequest()
            {
                CardAccountId = "0000111122223333",
                Status = Status.NFA
            };

            
            await _service.ExecuteAsync(updateAccountRequest);

            _accountMaintenanceV2ApiClientMock.Verify(m => m.AccountUserFieldsUpdateAsync(It.IsAny<AccountUserFieldsUpdateRequest2>()), Times.Never);
        }

        [Theory]
        [InlineData("Code1", "T01")]
        [InlineData("Code12", "T12")]
        [InlineData("Miscellaneous1", "Test")]
        public async Task Should_call_user_fields_endpoint_if_any_string_user_field_is_defined(string property, string value)
        {
            var updateAccountRequest = new UpdateAccountRequest()
            {
                CardAccountId = "0000111122223333",
            };

            var propertyInfo = updateAccountRequest.GetType().GetProperty(property);
            propertyInfo?.SetValue(updateAccountRequest, value);

            await _service.ExecuteAsync(updateAccountRequest);

            _accountMaintenanceV2ApiClientMock.Verify(
                m => m.AccountUserFieldsUpdateAsync(It.IsAny<AccountUserFieldsUpdateRequest2>()), Times.Once);
        }

        [Fact]
        public async Task Should_throw_empty_update_account_request_exception_when_request_is_empty()
        {
            var updateAccountRequest = new UpdateAccountRequest()
            {
                CardAccountId = "0000111122223333",
            };

            Task Action() => _service.ExecuteAsync(updateAccountRequest);

            await Assert.ThrowsAsync<EmptyUpdateAccountRequestException>(Action);
        }

        [Fact]
        public async Task Should_call_account_detail_inquiry_when_remove_function_code_is_present()
        {
            var updateAccountRequest = new UpdateAccountRequest()
            {
                CardAccountId = "0000111122223333",
                Status = Status.NFA,
                FunctionCode = FunctionCode.REMOVE
            };

            var accountDetailInquiryResponse = new AccountDetailInquiryResponse3()
            {
                BlockCode1 = "N"
            };

            _accountManagementApiClientMock
                .Setup(a => a.AccountDetailInquiryAsync(It.IsAny<AccountDetailInquiryRequest3>()))
                .Returns(Task.FromResult(accountDetailInquiryResponse));

            await _service.ExecuteAsync(updateAccountRequest);

            _accountManagementApiClientMock.Verify(
                m => m.AccountDetailInquiryAsync(It.IsAny<AccountDetailInquiryRequest3>()), Times.Once);
        }

        [Fact]
        public async Task Should_throw_block_code_match_exception_if_no_valid_block_code_was_found_in_account_detail_inquiry()
        {
            var updateAccountRequest = new UpdateAccountRequest()
            {
                CardAccountId = "0000111122223333",
                Status = Status.NFA,
                FunctionCode = FunctionCode.REMOVE
            };

            var accountDetailInquiryResponse = new AccountDetailInquiryResponse3()
            {
            };

            _accountManagementApiClientMock
                .Setup(a => a.AccountDetailInquiryAsync(It.IsAny<AccountDetailInquiryRequest3>()))
                .Returns(Task.FromResult(accountDetailInquiryResponse));


            Task Action() => _service.ExecuteAsync(updateAccountRequest);

            await Assert.ThrowsAsync<BlockCodeMatchException>(Action);
        }
    }
}