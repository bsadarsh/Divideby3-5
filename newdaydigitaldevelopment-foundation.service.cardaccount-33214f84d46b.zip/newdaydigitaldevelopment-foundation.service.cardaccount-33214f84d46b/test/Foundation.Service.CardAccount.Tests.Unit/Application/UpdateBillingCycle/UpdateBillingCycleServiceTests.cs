﻿using System;
using System.Threading.Tasks;
using AutoFixture;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.UpdateBillingCycle;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.UpdateBillingCycle;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.UpdateBillingCycle
{
    public class UpdateBillingCycleServiceTests
    {
        [Fact]
        public async Task Should_return_correct_response_for_a_valid_request()
        {
            var fixture = new Fixture();
            var expectedResponse = new DataManagerResponse<UpdateBillingCycleResponse>(new UpdateBillingCycleResponse(), DateTime.Now, TimeSpan.Zero);

            var brand = new Fixture().Create<Brand>();
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(brand);
            var accountMaintenanceApiClientMock = new Mock<IAccountMaintenanceApiClient>();

            var service = new UpdateBillingCycleService(new UpdateBillingCycleConverter(brandHelperMock.Object), accountMaintenanceApiClientMock.Object);
            var response = await service.ExecuteAsync(fixture.Create<UpdateBillingCycleRequest>());

            response.Should().BeEquivalentTo(expectedResponse, config => config
                .Excluding(x => x.CacheAge)
                .Excluding(x => x.CacheExpires));
        }

        [Fact]
        public async Task Should_return_badRequest_for_request_with_invalid_CardAccountId()
        {
            var request = new UpdateBillingCycleRequest()
            {
                CardAccountId = "0000000000000000000"
            };

            var brandHelperMock = new Mock<IBrandHelper>();
            var service = new UpdateBillingCycleService(new UpdateBillingCycleConverter(brandHelperMock.Object), null);

            Func<Task<DataManagerResponse<UpdateBillingCycleResponse>>> func = () => service.ExecuteAsync(request);
            await func.Should().ThrowAsync<InvalidBrandException>();
        }
    }
}