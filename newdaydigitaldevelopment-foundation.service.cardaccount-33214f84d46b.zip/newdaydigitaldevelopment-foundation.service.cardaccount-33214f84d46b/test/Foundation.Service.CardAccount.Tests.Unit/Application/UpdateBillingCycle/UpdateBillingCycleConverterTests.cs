﻿using System;
using AutoFixture;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using Xunit;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.UpdateBillingCycle;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.UpdateBillingCycle;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.UpdateBillingCycle
{
    public class UpdateBillingCycleConverterTests
    {
        [Fact]
        public void Should_convert_update_billing_cycle_request_to_fd_request()
        {
            const string accountNumber = "0001234123412341234";
            const int billingCycle = 7;

            var domainRequest = new UpdateBillingCycleRequest
            {
                CardAccountId = accountNumber,
                BillingCycle = billingCycle
            };

            var brand = new Fixture().Create<Brand>();

            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(brand)
                .Verifiable();

            var expectedRequest = new BillingCycleUpdateRequest(brand.ClientNumber)
            {
                Account = accountNumber,
                BillCyc = billingCycle.ToString()
            };

            var converter = new UpdateBillingCycleConverter(brandHelperMock.Object);

            var fdRequest = converter.ToBillingCycleUpdateRequest(domainRequest);

            fdRequest.Should().BeEquivalentTo(expectedRequest);
        }

        [Fact]
        public void Should_throw_InvalidBrandException_for_invalid_card_account_number_on_UpdateBillingCycleRequest_conversion()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns((Brand)null)
                .Verifiable();

            var converter = new UpdateBillingCycleConverter(brandHelperMock.Object);

            Action act = () => converter.ToBillingCycleUpdateRequest(new UpdateBillingCycleRequest { CardAccountId = "0000111122223333" });
            act.Should().Throw<InvalidBrandException>();
        }
    }
}