﻿using System;
using System.Collections.Generic;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.GetCardAccountV1;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.GetCardAccountV1
{
    public class GetCardAccountConverterTests
    {
        private IBrandHelper getMockBrandHelper()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(new Brand("", "1234567890123456", "", new List<string>(), false));

            return brandHelperMock.Object;
        }

        [Fact]
        public void Should_convert_GetCardAccountRequest_to_AccountDetailInquiryRequest()
        {
            var brandHelper = getMockBrandHelper();
            var iLogger = new Mock<ILogger<GetCardAccountConverter>>();
            var expected = new AccountDetailInquiryRequest3("1234567890123456")
            {
                Account = "0000111122223333"
            };

            var converter = new GetCardAccountConverter(brandHelper, iLogger.Object);
            var actual = converter.ToAccountDetailInquiryRequest(new GetCardAccountRequest
            {
                CardAccountId = "0000111122223333"
            });

            actual.Should().BeEquivalentTo(expected);
        }

        [Fact]
        public void Should_throw_InvalidBrandException_for_invalid_card_account_number_on_GetCardAccountRequest_conversion()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            var iLogger = new Mock<ILogger<GetCardAccountConverter>>();
            brandHelperMock
                .Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns((Brand)null);

            var converter = new GetCardAccountConverter(brandHelperMock.Object, iLogger.Object);

            Action act = () => converter.ToAccountDetailInquiryRequest(new GetCardAccountRequest { CardAccountId = "0000111122223333" });
            act.Should().Throw<InvalidBrandException>();
        }

        [Fact]
        public void Should_convert_AccountDetailInquiryResponse_to_GetCardAccountResponse()
        {
            var iLogger = new Mock<ILogger<GetCardAccountConverter>>();
            var converter = new GetCardAccountConverter(null, iLogger.Object);

            var expected = new GetCardAccountResponse
            {
                Account = new Core.Domain.CardAccount.CardAccount
                {
                    CardAccountId = "0000111122223333",
                    AccountHolder = new AccountHolder
                    {
                        AccountHolderId = "1234567890123456",
                        FirstName = "John",
                        LastName = "Doe",
                        Title = "Mr"
                    },
                    AvailableCredit = 2M,
                    CurrentBalance = 2M,
                    CreditLimit = 2M,
                    BlockCode = "1",
                    DateOpened = new DateTime(2000, 12, 31),
                    Status = "A",
                    ShortName = "John Doe",
                    CustomerEmbossedName = "Mr John Doe",
                    CurrentCycleBillWasPaid = true,
                    IsCustomerDelinquent = true,
                    IsCustomerOverlimit = false,
                    PaymentDueDate = new DateTime(2020, 05, 30),
                    NextStatementDate = new DateTime(2020, 08, 03),
                    InstantSpend = true
                }
            };

            var actual = converter.ToGetCardAccountResponse(new AccountDetailInquiryResponse3
            {
                Account = "0000111122223333",
                BlockCode1 = "1",
                BlockCode2 = "1",
                BlockCode1Priority = "1",
                CurrencyNod = "2",
                CustomerNumber = "1234567890123456",
                FirstName1 = "John",
                LastName1 = "Doe",
                AvailCredit = "200",
                CurrBal = "200",
                Crlim = "200",
                DateOpened = "20001231",
                IntStatus = "A",
                ShortName = "John Doe",
                Title1 = "Mr",
                PmtCtd = "0",
                PmtTotAmtDue = "0",
                PmtCycleDue = "2",
                OverlimitFlag = "0",
                DatePmtDue = "20200530",
                DateNextStmt = "20200803",
                InstSpndFl = "1"
            });

            actual.Should().BeEquivalentTo(expected);
        }

        [Fact]
        public void Should_return_null_for_null_AccountDetailInquiryResponse()
        {
            var iLogger = new Mock<ILogger<GetCardAccountConverter>>();
            var converter = new GetCardAccountConverter(null, iLogger.Object);
            var actual = converter.ToGetCardAccountResponse(null);
            actual.Should().BeNull();
        }

        [Fact]
        public void Should_set_currentCycleBill_true_when_cycletodate_is_full_payment()
        {
            var pmtCtd = "0";
            var pmtTotAmtDue = "0";
            var iLogger = new Mock<ILogger<GetCardAccountConverter>>();

            var converter = new GetCardAccountConverter(getMockBrandHelper(), iLogger.Object);

            var fdResponse = new AccountDetailInquiryResponse3
            {
                PmtCtd = pmtCtd,
                PmtTotAmtDue = pmtTotAmtDue
            };

            var domainResponse = converter.ToGetCardAccountResponse(fdResponse);

            domainResponse.Account.CurrentCycleBillWasPaid.Should().BeTrue();
        }

        [Fact]
        public void Should_set_currentCycleBill_false_when_cycletodate_is_partial_payment()
        {
            var pmtCtd = "12";
            var pmtTotAmtDue = "15";
            var iLogger = new Mock<ILogger<GetCardAccountConverter>>();

            var converter = new GetCardAccountConverter(getMockBrandHelper(), iLogger.Object);

            var fdResponse = new AccountDetailInquiryResponse3
            {
                PmtCtd = pmtCtd,
                PmtTotAmtDue = pmtTotAmtDue
            };

            var domainResponse = converter.ToGetCardAccountResponse(fdResponse);

            domainResponse.Account.CurrentCycleBillWasPaid.Should().BeFalse();
        }

        [Theory]
        [InlineData(true, "1")]
        [InlineData(false, "")]
        [InlineData(false, null)]
        [InlineData(false, "0")]
        [InlineData(false, "2")]
        [InlineData(false, "3")]
        [InlineData(false, "4")]
        [InlineData(false, "9")]
        public void Should_set_instantSpend_to_X_when_InstSpndFl_is_Y(bool instantSpend, string instSpndFl)
        {
            var iLogger = new Mock<ILogger<GetCardAccountConverter>>();

            var converter = new GetCardAccountConverter(getMockBrandHelper(), iLogger.Object);

            var fdResponse = new AccountDetailInquiryResponse3
            {
                InstSpndFl = instSpndFl
            };

            var domainResponse = converter.ToGetCardAccountResponse(fdResponse);

            domainResponse.Account.InstantSpend.Should().Be(instantSpend);
        }
    }
}
