using System;
using System.Threading.Tasks;
using AutoFixture;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Cache;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.GetCardAccountV1;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.GetCardAccountV1
{
    public class GetCardAccountServiceTests
    {
        private readonly GetCardAccountService _service;
        private readonly Mock<IAccountManagementApiClient> _customerApiClientMock = new Mock<IAccountManagementApiClient>();
        private readonly Mock<IBrandHelper> _brandHelperMock = new Mock<IBrandHelper>();
        private readonly Mock<IDataManager> _dataManagerMock = new Mock<IDataManager>();

        public GetCardAccountServiceTests()
        {
            var iLogger = new Mock<ILogger<GetCardAccountConverter>>();

            var timeoutMock = new Mock<ITimeoutProvider>();
            timeoutMock.SetupGet(x => x.Timeout).Returns(TimeSpan.FromSeconds(1));

            var cacheKeyProviderMock = new Mock<IAccountDetailInquiryCacheKeyProvider>();
            cacheKeyProviderMock.Setup(x => x.GetKey(It.IsAny<string>())).Returns("cacheKey");

            var converter = new GetCardAccountConverter(_brandHelperMock.Object, iLogger.Object);
            _service = new GetCardAccountService(timeoutMock.Object, _customerApiClientMock.Object, converter,
                _dataManagerMock.Object, cacheKeyProviderMock.Object);
        }

        [Fact]
        public async Task Should_return_badRequest_if_cardaccountid_passed_in_is_not_recognised()
        {
            var request = new GetCardAccountRequest { CardAccountId = "bad card account id" };

            Func<Task<DataManagerResponse<GetCardAccountResponse>>> func = () => _service.ExecuteAsync(request);
            await func.Should().ThrowAsync<InvalidBrandException>();
        }

        [Fact]
        public async Task Should_Return_Correct_Response_If_Valid_Account_Number_Is_Sent_In_The_Request()
        {
            var fixture = new Fixture();
            var request = fixture.Create<GetCardAccountRequest>();

            _brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(request.CardAccountId))
                .Returns(fixture.Create<Brand>());

            var inquiryResponse = fixture.Build<AccountDetailInquiryResponse3>()
                .With(n => n.FirstName1, "John")
                .With(n => n.LastName1, "Doe")
                .With(n => n.BlockCode1, "0")
                .With(n => n.BlockCode2, "2")
                .With(n => n.BlockCode1Priority, "2")
                .With(n => n.BlockCode2Priority, "2")
                .With(n => n.CurrencyNod, "2")
                .With(n => n.AvailCredit, "200")
                .With(n => n.CurrBal, "200")
                .With(n => n.Crlim, "200")
                .With(n => n.Account, "1234567890123456")
                .With(n => n.CustomerNumber, "0000111122223333")
                .With(n => n.IntStatus, "A")
                .With(n => n.ShortName, "John Doe")
                .With(n => n.EdEmbFullName, "John Doe")
                .With(n => n.Title1, "Mr")
                .With(n => n.ProjAchPmt, "200")
                .With(n => n.PmtPastDue, "200")
                .With(n => n.PmtTotAmtDue, "200")
                .With(n => n.PmtCtd, "200")
                .With(n => n.PmtCycleDue, "0")
                .With(n => n.Title1, "Mr")
                .With(n => n.XfrAcct, "2345678901234567")
                .Create();

            var dataManagerResponse = new DataManagerResponse<AccountDetailInquiryResponse3>(inquiryResponse, DateTime.Now, TimeSpan.Zero);
            var expectedResponse = new DataManagerResponse<GetCardAccountResponse>(new GetCardAccountResponse
            {
                Account = new Core.Domain.CardAccount.CardAccount
                {
                    CardAccountId = "1234567890123456",
                    AccountHolder = new AccountHolder
                    {
                        AccountHolderId = "0000111122223333",
                        FirstName = "John",
                        LastName = "Doe",
                        Title = "Mr"
                    },
                    AvailableCredit = 2M,
                    CurrentBalance = 2M,
                    BlockCode = "0",
                    Status = "A",
                    ShortName = "John Doe",
                    CustomerEmbossedName = "Mr John Doe",
                    CustomerSignatureName = "John Doe",
                    CreditLimit = 2M,
                    TotalAmountDue = 2M,
                    DirectDebitAmount = 2m,
                    ArrearsAmount = 2M,
                    CurrentCycleBillWasPaid = true,
                    IsCustomerDelinquent = false,
                    TransferCardAccountId = "2345678901234567"
                }
            }, DateTime.Now, TimeSpan.Zero);

            _customerApiClientMock
                .Setup(n => n.AccountDetailInquiryAsync(It.IsAny<AccountDetailInquiryRequest3>()))
                .ReturnsAsync(inquiryResponse);

            _dataManagerMock
                .Setup(n =>
                    n.FetchWithCacheAsync(It.IsAny<string>(), It.IsAny<TimeSpan>(), It.IsAny<Func<Task<AccountDetailInquiryResponse3>>>()))
                .ReturnsAsync(dataManagerResponse);

            var actualResponse = await _service.ExecuteAsync(request);

            actualResponse.Should().BeEquivalentTo(expectedResponse, config => config
                .Excluding(x => x.CacheAge)
                .Excluding(x => x.CacheExpires));
        }
    }
}
