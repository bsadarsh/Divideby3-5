﻿using AutoFixture;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountActivityUpdates.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;
using NewDay.Digital.Foundation.Service.CardAccount.Application.CreateMemo;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.CreateMemo
{
    public class CreateMemoConverterTests
    {
        [Fact]
        public void Should_convert_CreateCardAccountMemoRequest_into_AddAMemoRequest_with_one_memoline()
        {
            const string accountNumber = "3915050004000066";
            var brand = new Fixture().Create<Brand>();

            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock.Setup(a => a.GetBrandFromAccountNumber(accountNumber))
                .Returns(brand);

            var createMemoConverter = new CreateMemoConverter(brandHelperMock.Object);

            var payload = new CreateCardAccountMemoRequest
            {
                CardAccountId = accountNumber,
                Text = "abc"
            };

            var actualRequest = createMemoConverter.ToAddAMemoRequest(payload);

            var expectedRequest = new MemoAddRequest(brand.ClientNumber)
            {
                Account = accountNumber,
                ActnCd = "CSPM",
                MemoLine1 = payload.Text,
                MemoLine2 = "",
                MemoLine3 = "",
                MemoLine4 = "",
                MemoLine5 = ""
            };

            actualRequest.Should().BeEquivalentTo(expectedRequest);
        }

        [Fact]
        public void Should_convert_CreateCardAccountMemoRequest_with_string_of_360_chars_into_AddAMemoRequest_with_five_memolines_populated()
        {
            const string accountNumber = "3915050004000066";
            const string text = "xzraxmfqfcyzdikbxfwbhfzmbfvcejnrunacmqrufrdgjncfvxcqmpbrxugdyeuttekccrhgvprhcepupqdmxqrgyvtqbnqrbtyxwtnjpwjuiwpguaiuapnixkdeqwtjyaucgnkzpwnximubhqxuxmejudkmmupfwhaeehuunpvumwgvynaaqxwhvzzjyyxyevtpjuktiutckfjwtzwpanbbxqgedtqziqxuvwwajxjibgqtedragdfjicragfywdwvmxjvzekmrjerxyvukuadyqvigzerpbdzfmhtffffy";

            var brand = new Fixture().Create<Brand>();
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock.Setup(a => a.GetBrandFromAccountNumber(accountNumber))
                .Returns(brand);

            var createMemoConverter = new CreateMemoConverter(brandHelperMock.Object);

            var payload = new CreateCardAccountMemoRequest
            {
                CardAccountId = accountNumber,
                Text = text
            };

            var actualRequest = createMemoConverter.ToAddAMemoRequest(payload);

            var expectedRequest = new MemoAddRequest(brand.ClientNumber)
            {
                Account = accountNumber,
                ActnCd = "CSPM",
                MemoLine1 = "xzraxmfqfcyzdikbxfwbhfzmbfvcejnrunacmqrufrdgjncfvxcqmpbrxugd",
                MemoLine2 = "yeuttekccrhgvprhcepupqdmxqrgyvtqbnqrbtyxwtnjpwjuiwpguaiuapni",
                MemoLine3 = "xkdeqwtjyaucgnkzpwnximubhqxuxmejudkmmupfwhaeehuunpvumwgvynaa",
                MemoLine4 = "qxwhvzzjyyxyevtpjuktiutckfjwtzwpanbbxqgedtqziqxuvwwajxjibgqt",
                MemoLine5 = "edragdfjicragfywdwvmxjvzekmrjerxyvukuadyqvigzerpbdzfmhtffffy"
            };

            actualRequest.Should().BeEquivalentTo(expectedRequest);
        }
    }
}