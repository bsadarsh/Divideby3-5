﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoFixture;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountActivityUpdates.v1;
using NewDay.Digital.Foundation.Connector.FirstData.AccountActivityUpdates.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;
using NewDay.Digital.Foundation.Service.CardAccount.Application.CreateMemo;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.CreateMemo
{
    public class CreateMemoServiceTests
    {
        [Fact]
        public async Task Should_return_badRequest_if_cardaccountid_passed_in_is_not_recognised()
        {
            var request = new CreateCardAccountMemoRequest
            {
                CardAccountId = "bad card account id"
            };

            var brandHelperMock = new Mock<IBrandHelper>();
            var service = new CreateMemoService(new CreateMemoConverter(brandHelperMock.Object), null);

            Func<Task<DataManagerResponse<MemoAddResponse>>> func = () => service.ExecuteAsync(request);
            await func.Should().ThrowAsync<InvalidBrandException>();
        }

        [Fact]
        public async Task Should_return_badRequest_if_cardaccountid_passed_but_no_memo()
        {
            var request = new CreateCardAccountMemoRequest
            {
                CardAccountId = "123456789123456"
            };

            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock.Setup(a => a.GetBrandFromAccountNumber(request.CardAccountId)).Returns(new Fixture().Create<Brand>());

            var service = new CreateMemoService(new CreateMemoConverter(brandHelperMock.Object), null);
            Func<Task<DataManagerResponse<MemoAddResponse>>> func = () => service.ExecuteAsync(request);
            await func.Should().ThrowAsync<ArgumentNullException>();
        }

        [Fact]
        public async Task Should_return_correct_response_if_correct_payload_is_passed()
        {
            var fixture = new Fixture();
            var expectedResponse = new DataManagerResponse<MemoAddResponse>(new MemoAddResponse(), DateTime.Now, TimeSpan.Zero);

            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(new Brand("", "01030", "", new List<string>(), true));
            var memoApiClientMock = new Mock<IAccountActivityUpdatesApiClient>();

            var service = new CreateMemoService(new CreateMemoConverter(brandHelperMock.Object), memoApiClientMock.Object);
            var actualResponse = await service.ExecuteAsync(fixture.Create<CreateCardAccountMemoRequest>());
            actualResponse.Should().BeEquivalentTo(expectedResponse, config => config
                .Excluding(x => x.CacheAge)
                .Excluding(x => x.CacheExpires));
        }
    }
}
