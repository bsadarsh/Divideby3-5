﻿using System;
using System.Collections.Generic;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.CardManagement.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.CardManagement.v2.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetCardsByAccount;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.GetCardsByAccount;
using Xunit;
using CardInfo = NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetCardsByAccount.CardInfo;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.GetCardsByAccount
{
    public class GetCardsByAccountConverterTests
    {
        [Fact]
        public void Should_convert_GetCardsByAccountRequest_to_CardsListByCardRequest()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(new Brand("", "1234567890123456", "", new List<string>(), false));

            var expected = new CardsListbyCardRequest("1234567890123456")
            {
                CardNbr = "0000111122223333"
            };

            var converter = new GetCardsByAccountConverter(brandHelperMock.Object);

            var actual = converter.ToCardsListByAccountRequest(new GetCardsByAccountRequest
            {
                CardAccountId = "0000111122223333"
            });

            actual.Should().BeEquivalentTo(expected);
        }

        [Fact]
        public void Should_throw_InvalidBrandException_for_invalid_card_account_number_on_GetCardsByAccountRequest_conversion()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns((Brand)null);

            var converter = new GetCardsByAccountConverter(brandHelperMock.Object);

            Action act = () => converter.ToCardsListByAccountRequest(new GetCardsByAccountRequest{CardAccountId = "0000111122223333"});
            act.Should().Throw<InvalidBrandException>();
        }

        [Fact]
        public void Should_convert_CardsListbyCardResponse_to_GetCardsByAccountResponse()
        {
            var converter = new GetCardsByAccountConverter(null);

            var expected = new GetCardsByAccountResponse
            {
                Cards = new List<CardInfo>
                {
                    new CardInfo
                    {
                        CardNumber = "1111111111111111111",
                        IsActive = true,
                        IsBlocked = false,
                        IsPendingActivation = true,
                        IsPrimary = true,
                        CustomerEmbossedName = "Test",
                        ExpiryDate = "20230731"
                    }
                }
            };

            var actual = converter.ToGetCardsByAccountResponse(new Connector.FirstData.CardManagement.v2.Models.CardsListByCardResponse2
            {
                OutputData = new List<OutputData2ForCardsListByCard2>
                {
                    new OutputData2ForCardsListByCard2
                    {
                        CardNbr = "0001111111111111111111",
                        Stat = "0",
                        BlkCd = "",
                        CurrFstUsgFlg = "Y",
                        CardholderType = "1",
                        DtExp = "20230731",
                        EmbossedName1 = "Test" 
                    }
                }
            });

            actual.Should().BeEquivalentTo(expected);
        }
    }
}
