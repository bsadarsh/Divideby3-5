﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoFixture;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.CardManagement.v1;
using NewDay.Digital.Foundation.Connector.FirstData.CardManagement.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.CardManagement.v2;
using NewDay.Digital.Foundation.Connector.FirstData.CardManagement.v2.Models;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetCardsByAccount;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.GetCardsByAccount;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;
using Xunit;
using CardInfo = NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetCardsByAccount.CardInfo;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.GetCardsByAccount
{
    public class GetCardsByAccountServiceTests
    {
        private readonly GetCardsByAccountRequest _request;
        private readonly CardsListByCardResponse2 _inquiryResponse;
        private readonly Mock<IBrandHelper> _brandHelperMock;
        private readonly Mock<Connector.FirstData.CardManagement.v2.ICardManagementApiClient> _customerApiClientMock2;
        private readonly Mock<Connector.FirstData.CardManagement.v1.ICardManagementApiClient> _customerApiClientMock1;
        private readonly Mock<IDataManager> _dataManagerMock;
        private readonly string _cardNumber;

        public GetCardsByAccountServiceTests()
        {
            var fixture = new Fixture();
            _request = fixture.Create<GetCardsByAccountRequest>();

            _cardNumber = "1234567890123456";

            _inquiryResponse = new CardsListByCardResponse2
            {
                OutputData = new List<OutputData2ForCardsListByCard2>
                {
                    new OutputData2ForCardsListByCard2
                    {
                        CardNbr = _cardNumber,
                        Stat = "0",
                        BlkCd = "",
                        CurrFstUsgFlg = "N",
                        CardholderType = "1",
                    }
                }
            };

            var dataManagerResponse = new DataManagerResponse<CardsListByCardResponse2>(_inquiryResponse, DateTime.Now, TimeSpan.Zero);

            _brandHelperMock = new Mock<IBrandHelper>();
            _brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(_request.CardAccountId))
                .Returns(fixture.Create<Brand>());

            _customerApiClientMock2 = new Mock<Connector.FirstData.CardManagement.v2.ICardManagementApiClient>(MockBehavior.Strict);
            _customerApiClientMock2
                .Setup(n => n.CardsListByCardAsync(It.Is<CardsListByCardRequest2>(card => card.CardNbr.Equals(_cardNumber))))
                .ReturnsAsync(_inquiryResponse);

            _customerApiClientMock1 = new Mock<Connector.FirstData.CardManagement.v1.ICardManagementApiClient>(MockBehavior.Strict);

            _dataManagerMock = new Mock<IDataManager>(MockBehavior.Strict);
            _dataManagerMock
                .Setup(n => n.FetchWithCacheAsync(It.IsAny<string>(), It.IsAny<TimeSpan>(), It.IsAny<Func<Task<CardsListByCardResponse2>>>()))
                .ReturnsAsync(dataManagerResponse);
        }

        [Fact]
        public async Task Should_return_badRequest_if_cardaccountid_passed_in_is_not_recognised()
        {
            var request = new Fixture().Create<GetCardsByAccountRequest>();

            var brandHelperMock = new Mock<IBrandHelper>();
            var timeoutMock = new Mock<ITimeoutProvider>();
            timeoutMock.SetupGet(x => x.Timeout).Returns(TimeSpan.FromSeconds(1));
            
            var service = new GetCardsByAccountService(timeoutMock.Object, new GetCardsByAccountConverter(brandHelperMock.Object),null, null, null);
            Func<Task<DataManagerResponse<GetCardsByAccountResponse>>> func = () => service.ExecuteAsync(request);
            await func.Should().ThrowAsync<InvalidBrandException>();
        }

        [Fact]
        public async Task Should_return_correct_response_if_valid_cardaccountid_is_sent_in_the_request()
        {
            var expectedResponse = new DataManagerResponse<GetCardsByAccountResponse>(new GetCardsByAccountResponse
            {
                Cards = new List<CardInfo>
                {
                    new CardInfo
                    {
                        CardNumber = "1234567890123456",
                        IsActive = true,
                        IsBlocked = false,
                        IsPendingActivation = false,
                        IsPrimary = true,
                        IsFrozen = false
                    }
                }
            }, DateTime.Now, TimeSpan.Zero);

            _customerApiClientMock1
                .Setup(n => n.CardInquiryAsync(It.Is<CardInquiryRequest>(x => x.Account.Equals(_cardNumber))))
                .ReturnsAsync(new CardInquiryResponse { RestrAll = "0" });
            
            var timeoutMock = new Mock<ITimeoutProvider>();
            timeoutMock.SetupGet(x => x.Timeout).Returns(TimeSpan.FromSeconds(1));

            var service = new GetCardsByAccountService(timeoutMock.Object, new GetCardsByAccountConverter(_brandHelperMock.Object), _dataManagerMock.Object, _customerApiClientMock1.Object, _customerApiClientMock2.Object);
            var actualResponse = await service.ExecuteAsync(_request);

            actualResponse.Should().BeEquivalentTo(expectedResponse, config => config
                .Excluding(x => x.CacheAge)
                .Excluding(x => x.CacheExpires));
        }

        [Fact]
        public async Task Should_update_card_isFrozen_set_to_false_when_card_isActive_set_to_false()
        {
            _inquiryResponse.OutputData.First().Stat = "Y";
            
            var timeoutMock = new Mock<ITimeoutProvider>();
            timeoutMock.SetupGet(x => x.Timeout).Returns(TimeSpan.FromSeconds(1));

            var service = new GetCardsByAccountService(timeoutMock.Object, new GetCardsByAccountConverter(_brandHelperMock.Object), _dataManagerMock.Object, _customerApiClientMock1.Object, _customerApiClientMock2.Object);
            var actualResponse = await service.ExecuteAsync(_request);

            var card = actualResponse.Value.Cards.Single();
            card.IsFrozen.Should().BeFalse();
            card.IsActive.Should().BeFalse();
        }

        [Fact]
        public async Task Should_update_card_isFrozen_set_to_false_when_card_isActive_set_to_true_and_PendingActivation_set_to_true()
        {
            _inquiryResponse.OutputData.First().CurrFstUsgFlg = "Y";
            
            var timeoutMock = new Mock<ITimeoutProvider>();
            timeoutMock.SetupGet(x => x.Timeout).Returns(TimeSpan.FromSeconds(1));

            var service = new GetCardsByAccountService(timeoutMock.Object, new GetCardsByAccountConverter(_brandHelperMock.Object), _dataManagerMock.Object, _customerApiClientMock1.Object, _customerApiClientMock2.Object);
            var actualResponse = await service.ExecuteAsync(_request);

            var card = actualResponse.Value.Cards.Single();
            card.IsFrozen.Should().BeFalse();
            card.IsActive.Should().BeTrue();
            card.IsPendingActivation.Should().BeTrue();
        }

        [Fact]
        public async Task Should_update_card_isFrozen_to_true_when_card_isActive_is_true_and_isBlocked_is_false_and_PendingActivation_is_false()
        {
            _customerApiClientMock1
                .Setup(n => n.CardInquiryAsync(It.Is<CardInquiryRequest>(x => x.Account.Equals(_cardNumber))))
                .ReturnsAsync(new CardInquiryResponse { RestrAll = "1" });
            
            var timeoutMock = new Mock<ITimeoutProvider>();
            timeoutMock.SetupGet(x => x.Timeout).Returns(TimeSpan.FromSeconds(1));

            var service = new GetCardsByAccountService(timeoutMock.Object, new GetCardsByAccountConverter(_brandHelperMock.Object), _dataManagerMock.Object, _customerApiClientMock1.Object, _customerApiClientMock2.Object);
            var actualResponse = await service.ExecuteAsync(_request);

            var card = actualResponse.Value.Cards.Single();
            card.IsFrozen.Should().BeTrue();
        }
    }
}
