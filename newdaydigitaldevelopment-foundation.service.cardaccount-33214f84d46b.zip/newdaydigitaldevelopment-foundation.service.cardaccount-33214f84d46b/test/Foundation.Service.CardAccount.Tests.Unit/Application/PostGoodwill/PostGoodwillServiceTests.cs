﻿using System;
using System.Threading.Tasks;
using AutoFixture;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Transactions.v1;
using NewDay.Digital.Foundation.Connector.FirstData.Transactions.v1.Models;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.CreatePlan;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetPlans;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.PostGoodwill;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.PostGoodwill;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.PostGoodwill
{
    public class PostGoodwillServiceTests
    {
        private readonly Mock<IBrandHelper> _brandHelperMock;
        private readonly Mock<ITransactionsApiClient> _transactionsApiMock;
        private readonly Mock<IExecutable<GetPlansRequest, DataManagerResponse<GetPlansResponse>>> _getPlansServiceMock;
        private readonly Mock<IExecutable<CreatePlanRequest, DataManagerResponse<CreatePlanResponse>>> _createPlansServiceMock;

        private readonly PostGoodwillRequest PostGoodwillRequest = new PostGoodwillRequest()
        {
            CardAccountId = "0000111122223333",
            Amount = 12
        };

        private Mock<IBrandHelper> GetBrandHelperMock()
        {
            var brand = new Fixture().Create<Brand>();

            var brandHelperMock = new Mock<IBrandHelper>();

            brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(brand)
                .Verifiable();

            return brandHelperMock;
        }

        public PostGoodwillServiceTests()
        {
            _brandHelperMock = GetBrandHelperMock();
            _transactionsApiMock = new Mock<ITransactionsApiClient>();
            _getPlansServiceMock = new Mock<IExecutable<GetPlansRequest, DataManagerResponse<GetPlansResponse>>>();
            _createPlansServiceMock = new Mock<IExecutable<CreatePlanRequest, DataManagerResponse<CreatePlanResponse>>>();
        }

        [Fact]
        public async Task Should_call_get_plans_endpoint()
        {
            var getPlansResponse = new GetPlansResponse()
            {
                Plans = new[]
                {
                    new Plan()
                    {
                        Identifier = "1010",
                        Type = PlanType.Retail,
                        Active = "Y"
                    }
                }
            };

            var dataManagerResponse =
                new DataManagerResponse<GetPlansResponse>(getPlansResponse, DateTime.UtcNow, TimeSpan.Zero);

            _getPlansServiceMock.Setup(m => m.ExecuteAsync(It.IsAny<GetPlansRequest>())).Returns(Task.FromResult(dataManagerResponse));

            var postGoodwillService = new PostGoodwillService(new PostGoodwillConverter(_brandHelperMock.Object),
                _transactionsApiMock.Object, _getPlansServiceMock.Object, _createPlansServiceMock.Object);

            await postGoodwillService.ExecuteAsync(PostGoodwillRequest);

            _getPlansServiceMock.Verify(m => m.ExecuteAsync(It.IsAny<GetPlansRequest>()), Times.Once);
        }

        [Fact]
        public async Task Should_call_create_plan_if_no_active_retail_plan_found()
        {
            var getPlansResponse = new GetPlansResponse()
            {
                Plans = new[]
                {
                    new Plan()
                    {
                        Identifier = "1010",
                        Type = PlanType.Retail,
                        Active = "N"
                    }
                }
            };

            var dataManagerResponse =
                new DataManagerResponse<GetPlansResponse>(getPlansResponse, DateTime.UtcNow, TimeSpan.Zero);

            _getPlansServiceMock.Setup(m => m.ExecuteAsync(It.IsAny<GetPlansRequest>())).Returns(Task.FromResult(dataManagerResponse));

            var postGoodwillService = new PostGoodwillService(new PostGoodwillConverter(_brandHelperMock.Object),
                _transactionsApiMock.Object, _getPlansServiceMock.Object, _createPlansServiceMock.Object);

            await postGoodwillService.ExecuteAsync(PostGoodwillRequest);

            _createPlansServiceMock.Verify(m => m.ExecuteAsync(It.IsAny<CreatePlanRequest>()), Times.Once);
        }

        [Fact]
        public async Task Should_throw_retail_plan_not_found_exception_when_get_plans_returns_no_retail_plans()
        {
            var getPlansResponse = new GetPlansResponse()
            {
                Plans = new[]
                {
                    new Plan()
                    {
                        Identifier = "1010",
                        Type = PlanType.Cash,
                        Active = "N"
                    }
                }
            };

            var dataManagerResponse =
                new DataManagerResponse<GetPlansResponse>(getPlansResponse, DateTime.UtcNow, TimeSpan.Zero);

            _getPlansServiceMock.Setup(m => m.ExecuteAsync(It.IsAny<GetPlansRequest>())).Returns(Task.FromResult(dataManagerResponse));

            var postGoodwillService = new PostGoodwillService(new PostGoodwillConverter(_brandHelperMock.Object),
                _transactionsApiMock.Object, _getPlansServiceMock.Object, _createPlansServiceMock.Object);

            Task Action() => postGoodwillService.ExecuteAsync(PostGoodwillRequest);

            await Assert.ThrowsAsync<RetailPlanNotFoundException>(Action);
        }

        [Fact]
        public async Task Should_call_monetary_action_request_with_most_recent_retail_plan_identifier()
        {
            var getPlansResponse = new GetPlansResponse()
            {
                Plans = new[]
                {
                    new Plan()
                    {
                        Identifier = "1010",
                        Type = PlanType.Retail,
                        Active = "Y",
                        OpenDate = new DateTime(2020, 3, 9)
                    },
                    new Plan()
                    {
                        Identifier = "1011",
                        Type = PlanType.Cash,
                        Active = "N",
                        OpenDate = new DateTime(2020, 3, 10)
                    },
                    new Plan()
                    {
                        Identifier = "1012",
                        Type = PlanType.Retail,
                        Active = "Y",
                        OpenDate = new DateTime(2020, 3, 10)
                    },
                }
            };

            var dataManagerResponse =
                new DataManagerResponse<GetPlansResponse>(getPlansResponse, DateTime.UtcNow, TimeSpan.Zero);

            _getPlansServiceMock.Setup(m => m.ExecuteAsync(It.IsAny<GetPlansRequest>())).Returns(Task.FromResult(dataManagerResponse));

            var postGoodwillService = new PostGoodwillService(new PostGoodwillConverter(_brandHelperMock.Object),
                _transactionsApiMock.Object, _getPlansServiceMock.Object, _createPlansServiceMock.Object);

            await postGoodwillService.ExecuteAsync(PostGoodwillRequest);

            _transactionsApiMock.Verify(m => m.MonetaryActionAsync(It.Is<MonetaryActionRequest>(r => r.PlanNbr == "1012")));
        }
    }
}