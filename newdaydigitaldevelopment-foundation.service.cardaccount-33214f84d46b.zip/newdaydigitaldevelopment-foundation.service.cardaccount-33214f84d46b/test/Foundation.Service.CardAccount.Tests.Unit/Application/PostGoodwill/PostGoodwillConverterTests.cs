﻿using System;
using AutoFixture;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.PostGoodwill;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.PostGoodwill;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.PostGoodwill
{
    public class PostGoodwillConverterTests
    {
        [Fact]
        public void Should_throw_InvalidBrandException_for_invalid_card_account_number_on_MonetaryActionRequest_conversion()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns((Brand)null)
                .Verifiable();

            var converter = new PostGoodwillConverter(brandHelperMock.Object);

            Action act = () => converter.ToMonetaryActionRequest(new PostGoodwillRequest()
            {
                CardAccountId = "0000111122223333",
                Amount = 12
            });
            act.Should().Throw<InvalidBrandException>();
        }

        [Fact]
        public void Should_convert_postgoodwill_request_to_monetary_action_request()
        {
            var brand = new Fixture().Create<Brand>();

            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(brand)
                .Verifiable();

            var domainRequest = new PostGoodwillRequest()
            {
                CardAccountId = "0001234123412341234",
                Amount = 12
            };

            var converter = new PostGoodwillConverter(brandHelperMock.Object);

            var fdRequest = converter.ToMonetaryActionRequest(domainRequest);

            fdRequest.AcctNbr.Should().Be("0001234123412341234");
            fdRequest.TxnAmount.Should().Be("1200");
            fdRequest.ActionCode.Should().Be("2GOG");
            fdRequest.StoreNbr.Should().Be("999999998");
            fdRequest.EffDate.Should().Be(DateTime.UtcNow.ToString("yyyyMMdd"));
        }
    }
}