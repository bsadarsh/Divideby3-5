﻿using System;
using System.Threading.Tasks;
using AutoFixture;
using FluentAssertions;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Exceptions;
using NewDay.Digital.Foundation.Connector.FirstData.Loans.v2.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Transactions.v1.Models;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.RemoveFee;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.RemoveFee;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Resources;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.RemoveFee
{
    public class RemoveFeeServiceTests
    {
        private readonly RemoveFeeService _sut;

        private readonly Mock<ITransactionsV1Resource> _transactionsV1ResourceMock;
        private readonly Mock<ILoansV2Resource> _loansV2ResourceMock;
        private readonly Mock<IBrandHelper> _brandHelperMock;

        private readonly IFixture _fixture;

        public RemoveFeeServiceTests()
        {
            _transactionsV1ResourceMock = new Mock<ITransactionsV1Resource>();
            _loansV2ResourceMock = new Mock<ILoansV2Resource>();

            _brandHelperMock = new Mock<IBrandHelper>();

            _sut = new RemoveFeeService(
                _transactionsV1ResourceMock.Object,
                _loansV2ResourceMock.Object,
                new RemoveFeeConverter(_brandHelperMock.Object),
                NullLogger<RemoveFeeService>.Instance);

            _fixture = new Fixture();
        }

        [Fact]
        public void Should_throw_ArgumentNullException_when_request_is_null()
        {
            Func<Task<DataManagerResponse<RemoveFeeResponse>>> action = async () => await _sut.ExecuteAsync(null);
            action.Should().ThrowExactlyAsync<ArgumentNullException>();
        }

        #region GetValidRequests
        public static TheoryData<RemoveFeeRequest> GetValidRequests()
        {
            var lateFee = new RemoveFeeRequest()
            {
                CardAccountId = "123412341234",
                Amount = 19.99m,
                FeeType = FeeType.LateFee,
                PlanNumber = "12345",
                PlanSeqNumber = "123"

            };

            var overLimit = new RemoveFeeRequest()
            {
                CardAccountId = "123412341234",
                Amount = 19.99m,
                FeeType = FeeType.OverLimit,
                PlanNumber = "12345",
                PlanSeqNumber = "123"
            };

            var interest = new RemoveFeeRequest()
            {
                CardAccountId = "123412341234",
                Amount = 19.99m,
                FeeType = FeeType.Interest,
                PlanNumber = "12345",
                PlanSeqNumber = "123"
            };

            var ddReturn = new RemoveFeeRequest()
            {
                CardAccountId = "123412341234",
                Amount = 19.99m,
                FeeType = FeeType.DDReturn,
                PlanNumber = "12345",
                PlanSeqNumber = "123"
            };

            return new TheoryData<RemoveFeeRequest>()
            {
                lateFee,
                overLimit,
                interest,
                ddReturn
            };
        }
        #endregion

        [Theory]
        [MemberData(nameof(GetValidRequests))]
        public async Task Should_return_successful_response_for_a_valid_request(RemoveFeeRequest request)
        {
            var fdTransactionsResponse = new MonetaryActionResponse
            {
                AcctNbr = request.CardAccountId
            };

            _brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(request.CardAccountId))
                .Returns(_fixture.Create<Brand>());

            _transactionsV1ResourceMock.Setup(x =>
                    x.MonetaryActionAsync(It.Is<MonetaryActionRequest>(y => y.AcctNbr == request.CardAccountId)))
                .ReturnsAsync(new DataManagerResponse<MonetaryActionResponse>(fdTransactionsResponse, DateTime.UtcNow, TimeSpan.Zero));
          

            var response = await _sut.ExecuteAsync(request);

            response.Should().NotBeNull();
        }

        [Theory]
        [InlineData(FeeType.DDReturn)]
        [InlineData(FeeType.Interest)]
        public void Should_throw_PlanNumberNotFoundException_when_specified_PlanNumber_is_not_valid_in_FiServe(FeeType feeType)
        {
            var request = new RemoveFeeRequest()
            {
                CardAccountId = "123412341234",
                FeeType = feeType,
                Amount = 19.99m,
                PlanNumber = "12345",
                PlanSeqNumber = "123"
            };

            _brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(request.CardAccountId))
                .Returns(_fixture.Create<Brand>());

            var expectedFiServeException = new FirstDataApiException(new ResponseStatus()
            {
                ErrorCode = "FS000006",
                OdsMessages = new[]
                    {"Backend request failed VPE8SE CREDIT PLAN RECORD NOT FOUND OR IN ADD PENDING STATUS"}
            });

            _transactionsV1ResourceMock.Setup(x =>
                    x.MonetaryActionAsync(It.IsAny<MonetaryActionRequest>()))
                .ThrowsAsync(expectedFiServeException);

            Func<Task<DataManagerResponse<RemoveFeeResponse>>> action = async () => await _sut.ExecuteAsync(request); action.Should().ThrowExactlyAsync<PlanNumberNotFoundException>();
            action.Should().ThrowExactlyAsync<PlanNumberNotFoundException>();
        }

        [Fact]
        public void Should_throw_RetailPlanNotFoundException_when_retail_plan_number_not_found_in_FiServe()
        {
            var request = new RemoveFeeRequest()
            {
                CardAccountId = "123412341234",
                PlanSeqNumber = "123"
            };

            _brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(request.CardAccountId))
                .Returns(_fixture.Create<Brand>());

            var fdAccountPlanListResponse = new AccountPlanListResponse2
            {
                PlanCtdData = new[] {
                    new PlanCtdData2ForAccountPlanList2
                    {
                        PlanNbr = "12334",
                        PlanRecNbr = "123"
                    }
                }
            };

            _loansV2ResourceMock.Setup(x =>
                    x.AccountPlanListAsyncAsync(It.Is<AccountPlanListRequest2>(y => y.Acct == request.CardAccountId)))
                .ReturnsAsync(new DataManagerResponse<AccountPlanListResponse2>(fdAccountPlanListResponse, DateTime.UtcNow, TimeSpan.Zero));

            Func<Task<DataManagerResponse<RemoveFeeResponse>>> action = async () => await _sut.ExecuteAsync(request);
            action.Should().Throw<RetailPlanNotFoundException>().And.Message.Should().Be("Default Retail Plan number not available");
        }

        #region GetAccountPlanListResponse
        public static TheoryData<AccountPlanListResponse2> GetAccountPlanListResponse()
        {
            var fdAccountRetailPlanListResponse = new AccountPlanListResponse2
            {
                PlanCtdData = new[] {
                    new PlanCtdData2ForAccountPlanList2
                    {
                        PlanType = "R",
                        PlanNbr = "12334",
                        PlanRecNbr = "123"
                    }
                }
            };

            var fdEmptyAccountPlanListResponse = new AccountPlanListResponse2
            {
                PlanCtdData = new[] {
                    new PlanCtdData2ForAccountPlanList2()
                }
            };

            var fdAccountPlanListWithoutPlanSeqNumberResponse = new AccountPlanListResponse2
            {
                PlanCtdData = new[] {
                    new PlanCtdData2ForAccountPlanList2
                    {
                        PlanNbr = "12345",
                    }
                }
            };

            return new TheoryData<AccountPlanListResponse2>()
            {
                fdAccountRetailPlanListResponse,
                fdEmptyAccountPlanListResponse,
                fdAccountPlanListWithoutPlanSeqNumberResponse
            };
        }
        #endregion

        [Theory]
        [MemberData(nameof(GetAccountPlanListResponse))]
        public void Should_throw_PlanNumberNotFoundException_when_plan_number_is_not_valid(AccountPlanListResponse2 response)
        {
            var request = new RemoveFeeRequest()
            {
                CardAccountId = "123412341234",
                PlanNumber = "12345"
            };

            _brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(request.CardAccountId))
                .Returns(_fixture.Create<Brand>());

            _loansV2ResourceMock.Setup(x =>
                    x.AccountPlanListAsyncAsync(It.Is<AccountPlanListRequest2>(y => y.Acct == request.CardAccountId)))
                .ReturnsAsync(new DataManagerResponse<AccountPlanListResponse2>(response, DateTime.UtcNow, TimeSpan.Zero));

            Func<Task<DataManagerResponse<RemoveFeeResponse>>> action = async () => await _sut.ExecuteAsync(request);
            action.Should().Throw<PlanNumberNotFoundException>().And.Message.Should().Be("Plan number is not valid");
        }

        [Fact]
        public async Task Should_return_successful_response_for_a_valid_request_without_planNumber_and_planSeqNumber()
        {
            var request = new RemoveFeeRequest()
            {
                CardAccountId = "123412341234",
                Amount = 19.99m,
                FeeType = FeeType.LateFee
            };

            _brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(request.CardAccountId))
                .Returns(_fixture.Create<Brand>());

            var fdAccountRetailPlanListResponse = new AccountPlanListResponse2
            {
                PlanCtdData = new[] {
                    new PlanCtdData2ForAccountPlanList2
                    {
                        PlanType = "R",
                        PlanNbr = "12334",
                        PlanRecNbr = "123"
                    }
                }
            };

            _loansV2ResourceMock.Setup(x =>
                    x.AccountPlanListAsyncAsync(It.Is<AccountPlanListRequest2>(y => y.Acct == request.CardAccountId)))
                .ReturnsAsync(new DataManagerResponse<AccountPlanListResponse2>(fdAccountRetailPlanListResponse, DateTime.UtcNow, TimeSpan.Zero));

            var fdTransactionsResponse = new MonetaryActionResponse
            {
                AcctNbr = request.CardAccountId
            };

            _transactionsV1ResourceMock.Setup(x =>
                    x.MonetaryActionAsync(It.Is<MonetaryActionRequest>(y => y.AcctNbr == request.CardAccountId)))
                .ReturnsAsync(new DataManagerResponse<MonetaryActionResponse>(fdTransactionsResponse, DateTime.UtcNow, TimeSpan.Zero));

            var response = await _sut.ExecuteAsync(request);

            response.Value.Should().BeOfType<RemoveFeeResponse>();
        }

        [Fact]
        public async Task Should_return_successful_response_for_a_valid_request_without_planSeqNumber()
        { 
            var request = new RemoveFeeRequest()
            {
                CardAccountId = "123412341234",
                Amount = 19.99m,
                FeeType = FeeType.LateFee,
                PlanNumber = "12345"
            };

            _brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(request.CardAccountId))
                    .Returns(_fixture.Create<Brand>());

            var fdAccountRetailPlanListResponse = new AccountPlanListResponse2
            {
                PlanCtdData = new[] {
                    new PlanCtdData2ForAccountPlanList2
                    {
                        PlanNbr = "12345",
                        PlanRecNbr = "123"
                    }
                }
            };

            _loansV2ResourceMock.Setup(x =>
                        x.AccountPlanListAsyncAsync(It.Is<AccountPlanListRequest2>(y => y.Acct == request.CardAccountId)))
                    .ReturnsAsync(new DataManagerResponse<AccountPlanListResponse2>(fdAccountRetailPlanListResponse, DateTime.UtcNow, TimeSpan.Zero));

                var fdTransactionsResponse = new MonetaryActionResponse
                {
                    AcctNbr = request.CardAccountId
                };

            _transactionsV1ResourceMock.Setup(x =>
                        x.MonetaryActionAsync(It.Is<MonetaryActionRequest>(y => y.AcctNbr == request.CardAccountId)))
                    .ReturnsAsync(new DataManagerResponse<MonetaryActionResponse>(fdTransactionsResponse, DateTime.UtcNow, TimeSpan.Zero));

                var response = await _sut.ExecuteAsync(request);

            response.Value.Should().BeOfType<RemoveFeeResponse>();
        }
    }
}