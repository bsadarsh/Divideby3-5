﻿using System;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.RemoveFee;
using NewDay.Digital.Foundation.Service.CardAccount.Application.RemoveFee;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.RemoveFee
{
    public class RemoveFeeConverterTests
    {
        [Theory]
        [InlineData(FeeType.Interest, "2IRA", "1234", "12", true)]
        [InlineData(FeeType.DDReturn, "2DDR", "1234", "22", false)]
        [InlineData(FeeType.DDReturn, "2NSF", "1234", "21", true)]
        public void Should_convert_RemoveFee_request_to_fd_request(FeeType feeType, string expectedActionCode, string expectedPlanNumber, string expectedPlanSeqNumber, bool isOwnBrands)
        {
            var brand = new Brand(
                "31", "31", "123", new[] { "1" },
                isOwnBrands);

            var mockBrand = Mock.Of<IBrandHelper>();
            Mock.Get(mockBrand).Setup(x =>
                    x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(brand);

            IRemoveFeeConverter sut = new RemoveFeeConverter(mockBrand);

            var request = new RemoveFeeRequest
            {
                CardAccountId = "123141",
                Amount = 12.21m,
                FeeType = feeType,
                PlanNumber = expectedPlanNumber,
                PlanSeqNumber = expectedPlanSeqNumber
            };

            var response = sut.ToMonetaryActionRequest(request);
            response.Account.Should().Be(request.CardAccountId);
            response.ActionCode.Should().Be(expectedActionCode);
            response.TxnAmount.Should().Be("1221");
            response.StoreNbr.Should().Be("999999998");
            response.ForeignUse.Should().Be("0");
            response.PlanNbr.Should().Be(expectedPlanNumber);
            response.EffDate.Should().Be(DateTimeOffset.Now.ToString("yyyyMMdd"));
        }

        [Fact]
        public void When_date_is_passed_in_request_model_Then_should_map_it_to_effDate()
        {
            var brand = new Brand(
                "31", "31", "123", new[] { "1" },
                true);

            var mockBrand = Mock.Of<IBrandHelper>();
            Mock.Get(mockBrand).Setup(x =>
                    x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(brand);

            var date = new DateTime(2020, 06, 06);

            IRemoveFeeConverter sut = new RemoveFeeConverter(mockBrand);

            var request = new RemoveFeeRequest
            {
                CardAccountId = "123141",
                Amount = 12.21m,
                FeeType = FeeType.LateFee,
                Date = date
            };

            var response = sut.ToMonetaryActionRequest(request);
            response.EffDate.Should().Be(date.ToString("yyyyMMdd"));
        }

        [Fact]
        public void Should_throw_when_fee_type_not_mapped()
        {
            var mockBrand = Mock.Of<IBrandHelper>();
            Mock.Get(mockBrand).Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(new Brand("31", "31", "123", new[] { "1" }, true));

            IRemoveFeeConverter sut = new RemoveFeeConverter(mockBrand);

            Action act = () =>
            {
                sut.ToMonetaryActionRequest(new RemoveFeeRequest
                {
                    CardAccountId = "123141",
                    Amount = 12.21m,
                    FeeType = (FeeType)1000,
                    PlanNumber = "1231",
                });
            };

            act.Should().ThrowExactly<ArgumentOutOfRangeException>();
        }

        [Fact]
        public void Should_convert_RemoveFeeRequest_request_to_AccountPlanListRequest2()
        {
            var mockBrand = Mock.Of<IBrandHelper>();
            Mock.Get(mockBrand).Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(new Brand("31", "31", "123", new[] { "1" }, true));

            IRemoveFeeConverter sut = new RemoveFeeConverter(mockBrand);

            var request = new RemoveFeeRequest
            {
                CardAccountId = "123141"
            };

            var response = sut.ToAccountPlanListRequest2(request);
            response.Acct.Should().Be(request.CardAccountId);
        }
    }
}