﻿using System;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;
using FluentAssertions;
using Moq;
using Xunit;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Exceptions;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v2.GetCardAccount;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Entities.v2;
using NewDay.Digital.Foundation.Service.CardAccount.Application.GetCardAccountV2;
using CardAccountV2 = NewDay.Digital.Foundation.Core.Domain.CardAccount.Entities.v2.CardAccount;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.GetCardAccountV2
{
    public class GetCardAccountV2ConverterTests
    {
        private const string ClientNumber = "1234567890123456";
        private const string CardAccountId = "0000111122223333";


        private IBrandHelper getMockBrandHelper()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(new Brand("", ClientNumber, "", new List<string>(), false));

            return brandHelperMock.Object;
        }

        private AccountDetailInquiryResponse3 GetAccountDetailInquiryResponse(string intStatus = "X", string blockCode1 = "D",
            string blockCode2 = "A", string blockCode1Priority = "05", string blockCode2Priority = "99")
        {
            return new AccountDetailInquiryResponse3
            {
                Account = CardAccountId,
                BlockCode1 = blockCode1,
                BlockCode2 = blockCode2,
                BlockCode1Priority = blockCode1Priority,
                BlockCode2Priority = blockCode2Priority,
                CurrencyNod = "2",
                IntStatus = intStatus,
                DateOpened = "20201227",
                AvailCredit = "100",
                Crlim = "200",
                CurrBal = "300",
                CurrBnplBal = "400",
                CurrNonBnplBal = "600",
                PmtCurrDue = "700",
                PmtPastDue = "800",
                RpdAmount = "900",
                PmtLastAmt = "1000",
                DatePmtDue = "20201228",
                PsLastStmtBal = "500",
                DateLastStmt = "20201229",
                DateNextStmt = "20201230",
                DateLastPmt = "20201231",
                PmtCycleDue = "4",
                PmtAch = "7",
                NaData = new List<NaData3ForAccountDetailInquiry3>
                {
                    new NaData3ForAccountDetailInquiry3
                    {
                        Title = "Mr",
                        FirstName = "first name",
                        MidName = "mid name",
                        LastName = "last name",
                        Dob = "20210131",
                        HouseNumber = "some house number",
                        Addr1 = "some addr1",
                        Addr2 = "some addr2",
                        Addr3 = "some addr3",
                        CityState = "some city",
                        ZipCode = "8888888888",
                        CntryCd = "ABC",
                        Email = "someEmail@ggg.com",
                        MobPhone = "777777",
                        HomePhone = "666666",
                        EmpPhone = "555555"
                    }
                }
            };
        }


        [Fact]
        public void Should_convert_GetCardAccountRequest_to_AccountDetailInquiryRequest()
        {
            var brandHelper = getMockBrandHelper();
            var loggerMock = new Mock<ILogger<GetCardAccountConverter>>();
            var expected = new AccountDetailInquiryRequest3(ClientNumber)
            {
                Account = CardAccountId
            };

            var converter = new GetCardAccountConverter(brandHelper, loggerMock.Object);
            var actual = converter.ToAccountDetailInquiryRequestV3(
                new GetCardAccountRequest
                {
                    CardAccountId = CardAccountId
                });

            actual.Should().BeEquivalentTo(expected);
        }

        [Fact]
        public void Should_throw_BrandNotFoundException_for_invalid_card_account_number_on_GetCardAccountRequest_conversion()
        {
            var loggerMock = new Mock<ILogger<GetCardAccountConverter>>();

            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Throws<BrandNotFoundException>();

            var converter = new GetCardAccountConverter(brandHelperMock.Object, loggerMock.Object);

            Action act = () => converter.ToAccountDetailInquiryRequestV3(new GetCardAccountRequest { CardAccountId = CardAccountId });
            act.Should().Throw<BrandNotFoundException>();
        }

        [Fact]
        public void Should_convert_AccountDetailInquiryResponse_to_GetCardAccountResponse()
        {
            var loggerMock = new Mock<ILogger<GetCardAccountConverter>>();
            var converter = new GetCardAccountConverter(null, loggerMock.Object);

            var expected = new GetCardAccountResponse
            {
                Account = new CardAccountV2
                {
                    AccountNumber = CardAccountId,
                    Status = CardAccountStatus.Unavailable,
                    SubStatus = CardAccountSubStatus.Collections,
                    OpenDate = new DateTime(2020, 12, 27),
                    AvailableCredit = 1m,
                    CreditLimit = 2m,
                    CurrentBalance = 3m,
                    BnplBalance = 4m,
                    NonBnplBalance = 6m,
                    CurrentPaymentDue = 7m,
                    ArrearAmount = 8m,
                    PaymentRequested = 9m,
                    LastPaymentAmount = 10m,
                    PaymentDueDate = new DateTime(2020, 12, 28),
                    LastStatementBalance = 5m,
                    LastStatementDate = new DateTime(2020, 12, 29),
                    NextStatementDate = new DateTime(2020, 12, 30),
                    LastPaymentDate = new DateTime(2020, 12, 31),
                    CycleDue = "4",
                    DirectDebitStatus = "7",
                    AccountHolder = new AccountHolder
                    {
                        Title = "Mr",
                        FirstName = "first name",
                        MiddleName = "mid name",
                        LastName = "last name",
                        DateOfBirth = new DateTime(2021, 1, 31)
                    },
                    Address = new Address
                    {
                        HouseNumber = "some house number",
                        AddressLine1 = "some addr1",
                        AddressLine2 = "some addr2",
                        AddressLine3 = "some addr3",
                        City = "some city",
                        PostCode = "8888888888",
                        CountryCode = "ABC"
                    },
                    ContactDetails = new ContactDetails
                    {
                        Email = "someEmail@ggg.com",
                        MobileNumber = "777777",
                        HomePhoneNumber = "666666",
                        WorkPhoneNumber = "555555"
                    },
                    VulnerableCustomerFlag = null,
                    BoostedPayment = null,
                    PersistentDebt = new PersistentDebt
                    {
                        CurrentTerm = null,
                        OriginalTerm = null,
                        TotalInstallmentAmount = null,
                        TotalBalance = null
                    }
                }
            };

            var actual = converter.ToGetCardAccountResponseV2(GetAccountDetailInquiryResponse());

            actual.Should().BeEquivalentTo(expected);
        }

        [Fact]
        public void Should_return_null_for_null_AccountDetailInquiryResponse()
        {
            var loggerMock = new Mock<ILogger<GetCardAccountConverter>>();
            var converter = new GetCardAccountConverter(null, loggerMock.Object);
            var actual = converter.ToGetCardAccountResponseV2(null);
            actual.Should().BeNull();
        }
        
        [Theory]
        [InlineData("D", CardAccountStatus.Dormant)]
        [InlineData("8", CardAccountStatus.Closed)]
        [InlineData("9", CardAccountStatus.Closed)]
        [InlineData("A", CardAccountStatus.Active)]
        [InlineData("P", CardAccountStatus.Unavailable)]
        [InlineData("R", CardAccountStatus.Unavailable)]
        [InlineData("S", CardAccountStatus.Unavailable)]
        [InlineData("3", CardAccountStatus.Unavailable)]
        [InlineData("4", CardAccountStatus.Unavailable)]
        public void Should_properly_convert_intStatus_to_Status(string intStatus, CardAccountStatus status)
        {
            var loggerMock = new Mock<ILogger<GetCardAccountConverter>>();
            var converter = new GetCardAccountConverter(null, loggerMock.Object);
            
            var accountDetailInquiryResponse = GetAccountDetailInquiryResponse(intStatus);
            var response = converter.ToGetCardAccountResponseV2(accountDetailInquiryResponse);

            response.Account.Status.Should().BeEquivalentTo(status);
        }

        [Theory]
        [InlineData("D", "", "05", "99", CardAccountSubStatus.SuspectedFraud)]
        [InlineData("D", " ", "05", "99", CardAccountSubStatus.SuspectedFraud)]
        [InlineData("D", "  ", "05", "99", CardAccountSubStatus.SuspectedFraud)]
        [InlineData("D", null, "05", "99", CardAccountSubStatus.SuspectedFraud)]
        [InlineData("", "D", "05", "99", CardAccountSubStatus.SuspectedFraud)]
        [InlineData(" ", "D", "05", "99", CardAccountSubStatus.SuspectedFraud)]
        [InlineData("  ", "D", "05", "99", CardAccountSubStatus.SuspectedFraud)]
        [InlineData(null, "D", "05", "99", CardAccountSubStatus.SuspectedFraud)]
        [InlineData("A", "D", "05", "99", CardAccountSubStatus.SuspectedFraud)]
        [InlineData("A", "D", "99", "05", CardAccountSubStatus.Collections)]
        [InlineData("A", "D", "05", "05", CardAccountSubStatus.Collections)]
        [InlineData("D", "A", "99", "99", CardAccountSubStatus.SuspectedFraud)]
        [InlineData("G", "", "99", "99", CardAccountSubStatus.DeceasedPending)]
        [InlineData("Y", "", "99", "99", CardAccountSubStatus.ChargeOffFraud)]
        [InlineData("Z", "", "99", "99", CardAccountSubStatus.ChargeOffCollections)]
        [InlineData("F", "", "99", "99", CardAccountSubStatus.ConfirmedFraud)]
        [InlineData("W", "", "99", "99", CardAccountSubStatus.NoContact)]
        [InlineData("R", "", "99", "99", CardAccountSubStatus.ClosedByBusiness)]
        [InlineData("I", "", "99", "99", CardAccountSubStatus.PersistentDebtSpendFreeze)]
        [InlineData("", "", "99", "99", CardAccountSubStatus.Normal)]
        [InlineData(" ", "", "99", "99", CardAccountSubStatus.Normal)]
        [InlineData("  ", "", "99", "99", CardAccountSubStatus.Normal)]
        [InlineData(null, "", "99", "99", CardAccountSubStatus.Normal)]
        [InlineData("X", "", "99", "99", null)]
        [InlineData("6", "", "99", "99", null)]
        public void Should_properly_convert_blockCodes_and_priorities_to_SubStatus(string blockCode1, string blockCode2, string blockCode1Priority,
            string blockCode2Priority, CardAccountSubStatus? subStatus)
        {
            var loggerMock = new Mock<ILogger<GetCardAccountConverter>>();
            var converter = new GetCardAccountConverter(null, loggerMock.Object);

            var accountDetailInquiryResponse = GetAccountDetailInquiryResponse("", blockCode1, blockCode2, blockCode1Priority, blockCode2Priority);
            var response = converter.ToGetCardAccountResponseV2(accountDetailInquiryResponse);

            response.Account.SubStatus.Should().BeEquivalentTo(subStatus);
        }
    }
}
