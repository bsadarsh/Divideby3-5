using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using AutoFixture;
using FluentAssertions;
using Moq;
using Xunit;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;
using NewDay.Digital.Foundation.Service.CardAccount.Application.GetCardAccountV2;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Exceptions;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v2.GetCardAccount;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Entities.v2;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Cache;
using IAccountManagementApiClient = NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.IAccountManagementApiClient;
using CardAccountV2 = NewDay.Digital.Foundation.Core.Domain.CardAccount.Entities.v2.CardAccount;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.GetCardAccountV2
{
    public class GetCardAccountV2ServiceTests
    {
        private readonly GetCardAccountService _service;
        private readonly Mock<IAccountManagementApiClient> _customerApiClientMock = new Mock<IAccountManagementApiClient>();
        private readonly Mock<IBrandHelper> _brandHelperMock = new Mock<IBrandHelper>();
        private readonly Mock<IDataManager> _dataManagerMock = new Mock<IDataManager>();

        public GetCardAccountV2ServiceTests()
        {
            var iLogger = new Mock<ILogger<GetCardAccountConverter>>();

            var timeoutMock = new Mock<ITimeoutProvider>();
            timeoutMock.SetupGet(x => x.Timeout).Returns(TimeSpan.FromSeconds(1));

            var cacheKeyProviderMock = new Mock<IAccountDetailInquiryCacheKeyProvider>();
            cacheKeyProviderMock.Setup(x => x.GetKey(It.IsAny<string>())).Returns("cacheKey");

            var converter = new GetCardAccountConverter(_brandHelperMock.Object, iLogger.Object);
            _service = new GetCardAccountService(timeoutMock.Object, _customerApiClientMock.Object, converter,
                _dataManagerMock.Object, cacheKeyProviderMock.Object);
        }
        [Fact]
        public async Task Should_throw_BrandNotFoundException_if_CardAccountId_is_not_recognized()
        {
            _brandHelperMock
                .Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Throws<BrandNotFoundException>();

            var request = new GetCardAccountRequest { CardAccountId = "bad card account id" };

            Func<Task<DataManagerResponse<GetCardAccountResponse>>> func = () => _service.ExecuteAsync(request);
            await func.Should().ThrowAsync<BrandNotFoundException>();
        }

        [Fact]
        public async Task Should_Return_Correct_Response_If_Valid_Account_Number_Is_Sent_In_The_Request()
        {
            var fixture = new Fixture();
            var request = fixture.Create<GetCardAccountRequest>();

            _brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(request.CardAccountId))
                .Returns(fixture.Create<Brand>());

            var inquiryResponse = fixture.Build<AccountDetailInquiryResponse3>()
                .With(n => n.Account, "1234567890123456")
                .With(n => n.CurrencyNod, "2")
                .With(n => n.IntStatus, "X")
                .With(n => n.BlockCode1, "D")
                .With(n => n.BlockCode1Priority, "05")
                .With(n => n.BlockCode2, "A")
                .With(n => n.BlockCode2Priority, "99")
                .With(n => n.DateOpened, "20201227")
                .With(n => n.AvailCredit, "100")
                .With(n => n.Crlim, "200")
                .With(n => n.CurrBal, "300")
                .With(n => n.CurrBnplBal, "400")
                .With(n => n.CurrNonBnplBal, "600")
                .With(n => n.PmtCurrDue, "700")
                .With(n => n.PmtPastDue, "800")
                .With(n => n.RpdAmount, "900")
                .With(n => n.PmtLastAmt, "1000")
                .With(n => n.DatePmtDue, "20201228")
                .With(n => n.PsLastStmtBal, "500")
                .With(n => n.DateLastStmt, "20201229")
                .With(n => n.DateNextStmt, "20201230")
                .With(n => n.DateLastPmt, "20201231")
                .With(n => n.PmtCycleDue, "4")
                .With(n => n.PmtAch, "7")
                .With(n => n.NaData, new List<NaData3ForAccountDetailInquiry3>
                    {
                        new NaData3ForAccountDetailInquiry3
                        {
                            Title = "Mr",
                            FirstName = "first name",
                            MidName = "mid name",
                            LastName = "last name",
                            Dob = "20210131",
                            HouseNumber = "some house number",
                            Addr1 = "some addr1",
                            Addr2 = "some addr2",
                            Addr3 = "some addr3",
                            CityState = "some city",
                            ZipCode = "8888888888",
                            CntryCd = "ABC",
                            Email = "someEmail@ggg.com",
                            MobPhone = "777777",
                            HomePhone = "666666",
                            EmpPhone = "555555",
                        }
                    })
                .Create();

            var dataManagerResponse = new DataManagerResponse<AccountDetailInquiryResponse3>(inquiryResponse, DateTime.Now, TimeSpan.Zero);
            var expectedResponse = new DataManagerResponse<GetCardAccountResponse>(new GetCardAccountResponse
            {
                Account = new CardAccountV2
                {
                    AccountNumber =  "1234567890123456",
                    Status = CardAccountStatus.Unavailable,
                    SubStatus = CardAccountSubStatus.Collections,
                    OpenDate = new DateTime(2020, 12, 27),
                    AvailableCredit = 1m,
                    CreditLimit = 2m,
                    CurrentBalance = 3m,
                    BnplBalance = 4m,
                    NonBnplBalance = 6m,
                    CurrentPaymentDue = 7m,
                    ArrearAmount = 8m,
                    PaymentRequested = 9m,
                    LastPaymentAmount = 10m,
                    PaymentDueDate = new DateTime(2020, 12, 28),
                    LastStatementBalance = 5m,
                    LastStatementDate = new DateTime(2020, 12, 29),
                    NextStatementDate = new DateTime(2020, 12, 30),
                    LastPaymentDate = new DateTime(2020, 12, 31),
                    CycleDue = "4",
                    DirectDebitStatus = "7",
                    AccountHolder = new AccountHolder
                    {
                        Title = "Mr",
                        FirstName = "first name",
                        MiddleName = "mid name",
                        LastName = "last name",
                        DateOfBirth = new DateTime(2021, 1, 31)
                    },
                    Address = new Address
                    {
                        HouseNumber = "some house number",
                        AddressLine1 = "some addr1",
                        AddressLine2 = "some addr2",
                        AddressLine3 = "some addr3",
                        City = "some city",
                        PostCode = "8888888888",
                        CountryCode = "ABC"
                    },
                    ContactDetails = new ContactDetails
                    {
                        Email = "someEmail@ggg.com",
                        MobileNumber = "777777",
                        HomePhoneNumber = "666666",
                        WorkPhoneNumber = "555555"
                    },
                    VulnerableCustomerFlag = null,
                    BoostedPayment = null,
                    PersistentDebt = new PersistentDebt
                    {
                        CurrentTerm = null,
                        OriginalTerm = null,
                        TotalInstallmentAmount = null,
                        TotalBalance = null
                    }
                }
            }, DateTime.Now, TimeSpan.Zero);

            _customerApiClientMock
                .Setup(n => n.AccountDetailInquiryAsync(It.IsAny<AccountDetailInquiryRequest3>()))
                .ReturnsAsync(inquiryResponse);

            _dataManagerMock
                .Setup(n =>
                    n.FetchWithCacheAsync(It.IsAny<string>(), It.IsAny<TimeSpan>(), It.IsAny<Func<Task<AccountDetailInquiryResponse3>>>()))
                .ReturnsAsync(dataManagerResponse);
            
            var actualResponse = await _service.ExecuteAsync(request);

            actualResponse.Should().BeEquivalentTo(expectedResponse, config => config
                .Excluding(x => x.CacheAge)
                .Excluding(x => x.CacheExpires));
        }
    }
}
