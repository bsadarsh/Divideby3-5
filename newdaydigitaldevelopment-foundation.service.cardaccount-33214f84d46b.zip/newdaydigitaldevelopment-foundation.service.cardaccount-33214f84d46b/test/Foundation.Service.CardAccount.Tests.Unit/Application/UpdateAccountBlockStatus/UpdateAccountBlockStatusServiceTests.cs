﻿using System.Threading.Tasks;
using AutoFixture;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.UpdateBlockCode;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.UpdateAccountBlockStatus;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.UpdateAccountBlockStatus
{
    public class UpdateAccountBlockStatusServiceTests
    {
        [Fact]
        public async Task should_return_correct_response_if_valid_card_number_is_sent()
        {
            var fixture = new Fixture();
            var request = fixture.Create<UpdateAccountBlockStatusRequest>();
            request.Status = Status.COLHOLDOUT;
            request.SubStatus = SubStatus.BREATHING_SPACE;
            var expectedFdRequest = fixture.Create<AccountBlockCodeUpdateRequest>();
            var expectedFdResponse = fixture.Create<AccountBlockCodeUpdateResponse>();
            var expectedResponse = fixture.Create<UpdateAccountBlockStatusResponse>();

            var converterMock = new Mock<IUpdateAccountBlockStatusConverter>();
            converterMock.Setup(m => m.ToAccountBlockCodeUpdateRequest(request)).Returns(expectedFdRequest);
            converterMock.Setup(m => m.ToUpdateAccountBlockStatusResponse(expectedFdResponse)).Returns(expectedResponse);
            var fdApiMock = new Mock<IAccountMaintenanceApiClient>();
            fdApiMock.Setup(m =>
                m.AccountBlockCodeUpdateAsync(expectedFdRequest)).ReturnsAsync(expectedFdResponse);
            var dataManagerMock = new Mock<IDataManager>();
            dataManagerMock.Setup(m => m.IsSetAsync(It.IsAny<string>())).ReturnsAsync(false);
            var response = await new UpdateAccountBlockStatusService(converterMock.Object, fdApiMock.Object, dataManagerMock.Object).ExecuteAsync(request);

            response.Value.Should().BeEquivalentTo(expectedResponse);
        }

        [Fact]
        public async Task should_invalidate_cache_when_update_successful()
        {
            var fixture = new Fixture();
            var request = fixture.Create<UpdateAccountBlockStatusRequest>();
            request.Status = Status.COLHOLDOUT;
            request.SubStatus = SubStatus.BREATHING_SPACE;
            var expectedFdRequest = fixture.Create<AccountBlockCodeUpdateRequest>();
            var expectedFdResponse = fixture.Create<AccountBlockCodeUpdateResponse>();
            var expectedResponse = fixture.Create<UpdateAccountBlockStatusResponse>();

            var converterMock = new Mock<IUpdateAccountBlockStatusConverter>();
            converterMock.Setup(m => m.ToAccountBlockCodeUpdateRequest(request)).Returns(expectedFdRequest);
            converterMock.Setup(m => m.ToUpdateAccountBlockStatusResponse(expectedFdResponse)).Returns(expectedResponse);
            var fdApiMock = new Mock<IAccountMaintenanceApiClient>();
            fdApiMock.Setup(m =>
                m.AccountBlockCodeUpdateAsync(expectedFdRequest)).ReturnsAsync(expectedFdResponse);
            var dataManagerMock = new Mock<IDataManager>();
            dataManagerMock.Setup(m => m.IsSetAsync(It.IsAny<string>())).ReturnsAsync(true);

            await new UpdateAccountBlockStatusService(converterMock.Object, fdApiMock.Object, dataManagerMock.Object).ExecuteAsync(request);

            dataManagerMock.Verify(m => m.RemoveAsync(It.IsAny<string>()));
        }

        [Fact]
        public async Task should_throw_account_block_status_and_substatus_mismatch_exception_when_substatus_is_not_correct()
        {
            var fixture = new Fixture();
            var request = fixture.Create<UpdateAccountBlockStatusRequest>();
            request.Status = Status.NORMAL;
            request.SubStatus = SubStatus.BREATHING_SPACE;

            await Assert.ThrowsAsync<AccountBlockStatusAndSubStatusInvalidCombinationException>(async () => await new UpdateAccountBlockStatusService(null, null, null).ExecuteAsync(request));
        }
    }
}