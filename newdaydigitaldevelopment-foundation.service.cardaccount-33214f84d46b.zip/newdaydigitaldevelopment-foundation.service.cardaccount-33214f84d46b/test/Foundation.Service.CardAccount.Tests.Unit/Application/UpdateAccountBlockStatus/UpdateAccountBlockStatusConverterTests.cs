﻿using AutoFixture;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.UpdateBlockCode;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.UpdateAccountBlockStatus;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.UpdateAccountBlockStatus
{
    public class UpdateAccountBlockStatusConverterTests
    {
        [Fact]
        public void Should_convert_request_to_fd_request()
        {
            const string cardNumber = "0001234123412341234";
            const string cardAccountId = "1234123412341234";
            var domainRequest = new UpdateAccountBlockStatusRequest
            {
                CardAccountId = cardAccountId,
                Status = Status.COLHOLDOUT,
                SubStatus = SubStatus.BREATHING_SPACE,
                CardNumber = cardNumber,
            };

            var brand = new Fixture().Create<Brand>();

            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(brand)
                .Verifiable();

            var expectedResponse = new AccountBlockCodeUpdateRequest(brand.ClientNumber)
            {
                CardNbr = cardNumber,
                BlkCd = "A",
                BlkCdInd = "1",
                FunctionCd = "B",
                SubStatus = "01",
                Account = cardAccountId,
                AcctRestructure = "Y"
            };

            var converter = new UpdateAccountBlockStatusConverter(brandHelperMock.Object);

            var fdResult = converter.ToAccountBlockCodeUpdateRequest(domainRequest);

            fdResult.Should().BeEquivalentTo(expectedResponse);
        }

        [Fact]
        public void Should_throw_exception_when_brand_is_not_found()
        {
            const string cardNumber = "0001234123412341234";
            const string cardAccountId = "1234123412341234";
            var domainRequest = new UpdateAccountBlockStatusRequest
            {
                CardAccountId = cardAccountId,
                CardNumber = cardNumber,
            };

            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns((Brand) null)
                .Verifiable();

            var converter = new UpdateAccountBlockStatusConverter(brandHelperMock.Object);

            Assert.Throws<InvalidBrandException>(() => converter.ToAccountBlockCodeUpdateRequest(domainRequest));
        }

        [Fact]
        public void Account_restructure_flag_should_be_null_if_not_breathing_space()
        {
            const string cardNumber = "0001234123412341234";
            const string cardAccountId = "1234123412341234";
            var domainRequest = new UpdateAccountBlockStatusRequest
            {
                CardAccountId = cardAccountId,
                Status = Status.NORMAL,
                CardNumber = cardNumber,
            };

            var brand = new Fixture().Create<Brand>();

            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(brand)
                .Verifiable();

            var converter = new UpdateAccountBlockStatusConverter(brandHelperMock.Object);

            var fdResult = converter.ToAccountBlockCodeUpdateRequest(domainRequest);

            fdResult.AcctRestructure.Should().BeNull();
        }

        [Fact]
        public void Account_restructure_flag_should_be_yes_if_nfa()
        {
            const string cardNumber = "0001234123412341234";
            const string cardAccountId = "1234123412341234";
            var domainRequest = new UpdateAccountBlockStatusRequest
            {
                CardAccountId = cardAccountId,
                Status = Status.NFA,
                CardNumber = cardNumber,
            };

            var brand = new Fixture().Create<Brand>();

            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(brand)
                .Verifiable();

            var converter = new UpdateAccountBlockStatusConverter(brandHelperMock.Object);

            var fdResult = converter.ToAccountBlockCodeUpdateRequest(domainRequest);

            fdResult.AcctRestructure.Should().Be("Y");
        }
    }
}