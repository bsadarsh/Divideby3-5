﻿using System;
using System.Collections.Generic;
using System.Linq;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.GetSpendCap;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.SetSpendCap;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.GetSpendCap;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.GetSpendCap
{
    public class GetSpendCapConverterTests
    {
        private readonly IGetSpendCapConverter _spendCapConverter;
        private readonly Mock<IBrandHelper> _brandHelperMock;

        public GetSpendCapConverterTests()
        {
            _brandHelperMock = new Mock<IBrandHelper>();
            _brandHelperMock
                .Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(new Brand("", "1234567890123456", "", new List<string>(), false))
                .Verifiable();

            _spendCapConverter = new GetSpendCapConverter(_brandHelperMock.Object);
        }
        
        private List<AtmOtcQsiRtlAccum3ForAccountDetailInquiry3> initAmountList(string authAmtAccum)
        {
            return new List<AtmOtcQsiRtlAccum3ForAccountDetailInquiry3>
                {
                    new AtmOtcQsiRtlAccum3ForAccountDetailInquiry3
                    {
                        DlyCtdYtdLtd = new List<DlyCtdYtdLtd3ForAccountDetailInquiry3>
                        {
                            new DlyCtdYtdLtd3ForAccountDetailInquiry3 {AuthAmtAccum = "0"},
                            new DlyCtdYtdLtd3ForAccountDetailInquiry3 {AuthAmtAccum = authAmtAccum},
                        },
                    },
                    new AtmOtcQsiRtlAccum3ForAccountDetailInquiry3
                    {
                        DlyCtdYtdLtd = new List<DlyCtdYtdLtd3ForAccountDetailInquiry3>
                        {
                            new DlyCtdYtdLtd3ForAccountDetailInquiry3 {AuthAmtAccum = "0"},
                            new DlyCtdYtdLtd3ForAccountDetailInquiry3 {AuthAmtAccum = authAmtAccum},
                        },
                    },
                    new AtmOtcQsiRtlAccum3ForAccountDetailInquiry3
                    {
                        DlyCtdYtdLtd = new List<DlyCtdYtdLtd3ForAccountDetailInquiry3>
                        {
                            new DlyCtdYtdLtd3ForAccountDetailInquiry3 {AuthAmtAccum = "0"},
                            new DlyCtdYtdLtd3ForAccountDetailInquiry3 {AuthAmtAccum = authAmtAccum},
                        },
                    },
                    new AtmOtcQsiRtlAccum3ForAccountDetailInquiry3
                    {
                        DlyCtdYtdLtd = new List<DlyCtdYtdLtd3ForAccountDetailInquiry3>
                        {
                            new DlyCtdYtdLtd3ForAccountDetailInquiry3 {AuthAmtAccum = "0"},
                            new DlyCtdYtdLtd3ForAccountDetailInquiry3 {AuthAmtAccum = authAmtAccum},
                        },
                    },
                };
        }
        

        [Fact]
        public void Should_convert_AccountDetailInquiryRequest3_to_GetSpendCapRequest()
        {
            var request = new GetSpendCapRequest()
            {
                CardAccountId = "1234123412341234"
            };
            var expected = new AccountDetailInquiryRequest3("1234567890123456")
            {
                Account = "1234123412341234"
            };

            var fdRequest = _spendCapConverter.ToAccountDetailInquiryRequest(request);

            fdRequest.Should().BeEquivalentTo(expected);
        }

        [Fact]
        public void Should_throw_InvalidBrandException_for_invalid_card_account_number_on_GetSpendCapRequest_conversion()
        {
            _brandHelperMock
                .Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns((Brand)null)
                .Verifiable();
            
            Action act = () => _spendCapConverter.ToAccountDetailInquiryRequest(new GetSpendCapRequest { CardAccountId = "0000111122223333" });
            act.Should().Throw<InvalidBrandException>();
        }

        [Fact]
        public void Should_convert_CapExceeded_AccountDetailInquiryResponse3_to_GetSpendCapResponse()
        {
            var expected = new GetSpendCapResponse()
            {
                SpendCapType = SpendCapType.Soft,
                SpendCapEnabled = true,
                SpendCapAmount = 500,
                SpendCapReached = true,
                SpendCapExceededAmount = 300.00m
            };

            var fdRequest = new AccountDetailInquiryResponse3()
            {
                SpndLmtAlert = "1",
                SpndLmtAmt = "500",
                SpendCapInd = "1",
                Freq = "2",
                AtmOtcQsiRtlAccum = initAmountList("20000")
            };

            var actual = _spendCapConverter.ToGetSpendCapResponse(fdRequest);

            actual.Should().BeEquivalentTo(expected);
        }

        [Theory]
        [InlineData("1")] //sms
        [InlineData("2")] //email
        [InlineData("3")] //email + sms
        public void Should_convert_SpendCapAlertTypes_to_SpendCaps_enabled(string spendLimitAlertType)
        {
            var fdRequest = new AccountDetailInquiryResponse3()
            {
                SpndLmtAlert = spendLimitAlertType,
                SpndLmtAmt = "50000",
                SpendCapInd = "2",
                Freq = "2",
                AtmOtcQsiRtlAccum = initAmountList("20000")
            };

            var actual = _spendCapConverter.ToGetSpendCapResponse(fdRequest);
            actual.SpendCapEnabled.Should().BeTrue();
        }


        [Fact]
        public void Should_convert_disabled_SpendCapAlertType_to_SpendCaps_disabled()
        {
            var fdRequest = new AccountDetailInquiryResponse3()
            {
                SpndLmtAlert = "0",
                SpndLmtAmt = "50000",
                SpendCapInd = "0",
                Freq = "2",
                AtmOtcQsiRtlAccum = initAmountList("20000")
            };

            var actual = _spendCapConverter.ToGetSpendCapResponse(fdRequest);
            actual.SpendCapEnabled.Should().BeFalse();
        }

        [Fact]
        public void Should_convert_CapNotExceeded_AccountDetailInquiryResponse3_to_GetSpendCapResponse()
        {
            var expected = new GetSpendCapResponse()
            {
                SpendCapType = SpendCapType.Soft,
                SpendCapEnabled = true,
                SpendCapAmount = 500,
                SpendCapReached = false,
                SpendCapExceededAmount = 0.00m
            };

            var fdRequest = new AccountDetailInquiryResponse3()
            {
                SpndLmtAlert = "1",
                SpndLmtAmt = "500",
                SpendCapInd = "1",
                Freq = "2",
                AtmOtcQsiRtlAccum = initAmountList("10000")
            };

            var actual = _spendCapConverter.ToGetSpendCapResponse(fdRequest);

            actual.Should().BeEquivalentTo(expected);
        }

        [Fact]
        public void Should_convert_with_largest_possible_retail_and_cash_amount_values()
        {
            // length taken from the FD fields
            var largest9DigitNumber = string.Concat(Enumerable.Repeat("9", 9));
            var largest3DigitNumber = string.Concat(Enumerable.Repeat("9", 3));

            var fdResponse = new AccountDetailInquiryResponse3()
            {
                SpndLmtAlert = "1",
                SpendCapInd = "2",
                AtmOtcQsiRtlAccum = initAmountList(largest9DigitNumber),

                Freq = "2",

                SpndLmtAmt = largest3DigitNumber
            };

            var expected = new GetSpendCapResponse()
            {
                SpendCapType = SpendCapType.Hard,
                SpendCapAmount = 999,
                SpendCapEnabled = true,
                SpendCapReached = true,
                SpendCapExceededAmount = 39999000.96m
            };

            var result = _spendCapConverter.ToGetSpendCapResponse(fdResponse);

            result.Should().BeEquivalentTo(expected);
        }

        [Theory]
        [InlineData("0", SpendCapType.None)]
        [InlineData("1", SpendCapType.Soft)]
        [InlineData("2", SpendCapType.Hard)]
        public void Should_convert_spend_cap_indicator_to_correct_enum_value(string spendCapIndicator, SpendCapType spendCapType)
        {
            var expected = new GetSpendCapResponse()
            {
                SpendCapType = spendCapType,
                SpendCapEnabled = true,
                SpendCapAmount = 500,
                SpendCapReached = true,
                SpendCapExceededAmount = 300.00m
            };

            var fdRequest = new AccountDetailInquiryResponse3()
            {
                SpndLmtAlert = "1",
                SpndLmtAmt = "500",
                SpendCapInd = spendCapIndicator,
                Freq = "2",
                AtmOtcQsiRtlAccum = initAmountList("20000")
            };

            var actual = _spendCapConverter.ToGetSpendCapResponse(fdRequest);

            actual.Should().BeEquivalentTo(expected);
        }
    }
}