﻿using System.Collections.Generic;
using System.Linq;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.ReAgeByAmount;
using NewDay.Digital.Foundation.Service.CardAccount.Application.ReAgeByAmount;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.ReAgeByAmount
{
    public class ReAgeByAmountConverterTests
    {
        private readonly IReAgeByAmountConverter _reAgeByAmountConverter;

        public ReAgeByAmountConverterTests()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock.Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(new Brand("opus", "10005", "110", new string[] { }, true));

            _reAgeByAmountConverter = new ReAgeByAmountConverter(brandHelperMock.Object);
        }

        [Fact]
        public void Should_properly_convert_to_delinquency_calculation_request()
        {
            //arrange
            var request = new ReAgeByAmountRequest
            {
                CardAccountId = "1105500010092766",
                DueBuckets = new List<decimal>
                {
                    100m, 200m, 300m, 400m, 500m, 600m, 700m, 800m, 900m
                }
            };
            var delinquencyInquiryResponse = new DelinquencyAdjustmentsInquiryResponse3
            {
                PlanData = new List<PlanData3ForDelinquencyAdjustmentsInquiry3>
                {
                    new PlanData3ForDelinquencyAdjustmentsInquiry3
                    {
                        CurrBal = "12",
                        PlanNbr = "123",
                        RecNbr = "1234",
                        TotDue = "12345",
                    }
                },
                NbrReturnedItems = "1"
            };

            //act
            var fdRequest =
                _reAgeByAmountConverter.ToDelinquencyAdjustmentCalculationRequest(request,
                    delinquencyInquiryResponse);

            //assert
            fdRequest.CardNbr.Should().Be("0001105500010092766");
            fdRequest.NbrItems.Should().Be("1");
            fdRequest.CurrDue.Should().Be("10000");
            fdRequest.PastDue.Should().Be("20000");
            fdRequest.DaysDue030.Should().Be("30000");
            fdRequest.DaysDue060.Should().Be("40000");
            fdRequest.DaysDue090.Should().Be("50000");
            fdRequest.DaysDue120.Should().Be("60000");
            fdRequest.DaysDue150.Should().Be("70000");
            fdRequest.DaysDue180.Should().Be("80000");
            fdRequest.DaysDue210.Should().Be("90000");
            fdRequest.ReageCd.Should().Be("x");
            fdRequest.Action.Should().Be("C");
            var paymentPsData = fdRequest.PaymentPsData.ToList();
            paymentPsData.Count.Should().Be(1);
            paymentPsData[0].RecNbr.Should().Be("1234");
            paymentPsData[0].TotDue.Should().Be("12345");
            paymentPsData[0].CurrBal.Should().Be("12");
            paymentPsData[0].PlanNbr.Should().Be("123");

        }

        [Fact]
        public void Should_properly_convert_to_delinquency_submit_request()
        {
            //arrange
            var request = new ReAgeByAmountRequest
            {
                CardAccountId = "1105500010092766",
                DueBuckets = new List<decimal>
                {
                    100m, 200m, 300m, 400m, 500m, 600m, 700m, 800m, 900m
                }
            };
            var delinquencyAdjustmentResponse = new DelinquencyAdjustmentUpdateResponse
            {
                PlanData = new List<PlanDataForDelinquencyAdjustmentUpdate1>
                {
                    new PlanDataForDelinquencyAdjustmentUpdate1
                    {
                        CurrBal = "12",
                        PlanNbr = "123",
                        RecNbr = "1234",
                        TotDue = "12345",
                    }
                },
                NbrReturnedItems = "1"

            };

            //act
            var fdRequest =
                _reAgeByAmountConverter.ToDelinquencyAdjustmentSubmitRequest(request, delinquencyAdjustmentResponse);

            //assert
            fdRequest.CardNbr.Should().Be("0001105500010092766");
            fdRequest.NbrItems.Should().Be("1");
            fdRequest.CurrDue.Should().Be("10000");
            fdRequest.PastDue.Should().Be("20000");
            fdRequest.DaysDue030.Should().Be("30000");
            fdRequest.DaysDue060.Should().Be("40000");
            fdRequest.DaysDue090.Should().Be("50000");
            fdRequest.DaysDue120.Should().Be("60000");
            fdRequest.DaysDue150.Should().Be("70000");
            fdRequest.DaysDue180.Should().Be("80000");
            fdRequest.DaysDue210.Should().Be("90000");
            fdRequest.ReageCd.Should().Be("x");
            fdRequest.Action.Should().Be("S");
            var paymentPsData = fdRequest.PaymentPsData.ToList();
            paymentPsData.Count.Should().Be(1);
            paymentPsData[0].RecNbr.Should().Be("1234");
            paymentPsData[0].TotDue.Should().Be("12345");
            paymentPsData[0].CurrBal.Should().Be("12");
            paymentPsData[0].PlanNbr.Should().Be("123");
        }

        [Fact]
        public void Should_set_rest_of_buckets_to_zero()
        {
            //arrange
            var request = new ReAgeByAmountRequest
            {
                CardAccountId = "1105500010092766",
                DueBuckets = new List<decimal>
                {
                    100m
                }
            };
            var delinquencyAdjustmentResponse = new DelinquencyAdjustmentUpdateResponse
            {
                PlanData = new List<PlanDataForDelinquencyAdjustmentUpdate1>
                {
                    new PlanDataForDelinquencyAdjustmentUpdate1
                    {
                        CurrBal = "12",
                        PlanNbr = "123",
                        RecNbr = "1234",
                        TotDue = "12345",
                    }
                },
                NbrReturnedItems = "1"

            };

            //act
            var fdRequest =
                _reAgeByAmountConverter.ToDelinquencyAdjustmentSubmitRequest(request, delinquencyAdjustmentResponse);

            //assert
            fdRequest.CardNbr.Should().Be("0001105500010092766");
            fdRequest.NbrItems.Should().Be("1");
            fdRequest.CurrDue.Should().Be("10000");
            fdRequest.PastDue.Should().Be("0");
            fdRequest.DaysDue030.Should().Be("0");
            fdRequest.DaysDue060.Should().Be("0");
            fdRequest.DaysDue090.Should().Be("0");
            fdRequest.DaysDue120.Should().Be("0");
            fdRequest.DaysDue150.Should().Be("0");
            fdRequest.DaysDue180.Should().Be("0");
            fdRequest.DaysDue210.Should().Be("0");
            fdRequest.ReageCd.Should().Be("x");
            fdRequest.Action.Should().Be("S");
            var paymentPsData = fdRequest.PaymentPsData.ToList();
            paymentPsData.Count.Should().Be(1);
            paymentPsData[0].RecNbr.Should().Be("1234");
            paymentPsData[0].TotDue.Should().Be("12345");
            paymentPsData[0].CurrBal.Should().Be("12");
            paymentPsData[0].PlanNbr.Should().Be("123");
        }
    }
}
