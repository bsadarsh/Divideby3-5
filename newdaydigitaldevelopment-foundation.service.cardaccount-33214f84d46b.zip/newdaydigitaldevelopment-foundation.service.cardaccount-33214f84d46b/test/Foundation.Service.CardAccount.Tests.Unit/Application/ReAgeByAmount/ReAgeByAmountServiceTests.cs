﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1;
using NewDay.Digital.Foundation.Connector.FirstData.AccountMaintenance.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.ReAgeByAmount;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.ReAgeByAmount;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.ReAgeByAmount
{
    public class ReAgeByAmountServiceTests
    {
        private readonly ReAgeByAmountService _reAgeByAmountService;
        private readonly Mock<IAccountManagementApiClient> _accountManagementApiClientMock;
        private readonly Mock<IAccountMaintenanceApiClient> _accountMaintenanceApiClientMock;

        public ReAgeByAmountServiceTests()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock.Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(new Brand("opus", "10005", "110", new string[] { }, true));

            IReAgeByAmountConverter converter = new ReAgeByAmountConverter(brandHelperMock.Object);
            _accountManagementApiClientMock = new Mock<IAccountManagementApiClient>();
            _accountMaintenanceApiClientMock = new Mock<IAccountMaintenanceApiClient>();
            _reAgeByAmountService = new ReAgeByAmountService(converter, _accountManagementApiClientMock.Object,
                _accountMaintenanceApiClientMock.Object);
        }

        [Fact]
        public async Task When_sum_of_bucket_amount_in_request_is_greater_than_current_balance_Then_exception_should_be_thrown()
        {
            //arrange
            var request = new ReAgeByAmountRequest
            {
                CardAccountId = "1105500010092766",
                DueBuckets = new List<decimal>
                {
                    100m, 200m, 300m
                }
            };

            _accountManagementApiClientMock
                .Setup(x => x.DelinquencyAdjustmentsInquiryAsync(It.IsAny<DelinquencyAdjustmentsInquiryRequest3>()))
                .ReturnsAsync(new DelinquencyAdjustmentsInquiryResponse3
                {
                    CurrentBalance = "50000"
                });

            //act
            Func<Task> act = async () => await _reAgeByAmountService.ExecuteAsync(request);

            //assert
            await act.Should().ThrowAsync<InvalidReAgeRequestValuesException>();
        }

        [Fact]
        public async Task When_diffInDue_in_calculation_call_is_different_than_zero_Then_exception_should_be_thrown()
        {
            //arrange
            var request = new ReAgeByAmountRequest
            {
                CardAccountId = "1105500010092766",
                DueBuckets = new List<decimal>
                {
                    100m, 200m, 300m
                }
            };

            _accountManagementApiClientMock
                .Setup(x => x.DelinquencyAdjustmentsInquiryAsync(It.IsAny<DelinquencyAdjustmentsInquiryRequest3>()))
                .ReturnsAsync(new DelinquencyAdjustmentsInquiryResponse3
                {
                    CurrentBalance = "70000",
                    PlanData = new List<PlanData3ForDelinquencyAdjustmentsInquiry3>(){
                        new PlanData3ForDelinquencyAdjustmentsInquiry3
                        {
                            CurrBal = "123",
                            PlanNbr = "123",
                            RecNbr = "123",
                            TotDue = "123"
                        }
                    },
                    NbrReturnedItems = "1"
                });
            _accountMaintenanceApiClientMock
                .Setup(x => x.DelinquencyAdjustmentUpdateAsync(It.IsAny<DelinquencyAdjustmentUpdateRequest>()))
                .ReturnsAsync(new DelinquencyAdjustmentUpdateResponse
                {
                    DiffInDue = "1"
                });

            //act
            Func<Task> act = async () => await _reAgeByAmountService.ExecuteAsync(request);

            //assert
            await act.Should().ThrowAsync<AccountRecalculationException>();
        }

        [Fact]
        public async Task When_diffInDue_in_submit_call_is_different_than_zero_Then_exception_should_be_thrown()
        {
            //arrange
            var request = new ReAgeByAmountRequest
            {
                CardAccountId = "1105500010092766",
                DueBuckets = new List<decimal>
                {
                    100m, 200m, 300m
                }
            };

            _accountManagementApiClientMock
                .Setup(x => x.DelinquencyAdjustmentsInquiryAsync(It.IsAny<DelinquencyAdjustmentsInquiryRequest3>()))
                .ReturnsAsync(new DelinquencyAdjustmentsInquiryResponse3
                {
                    CurrentBalance = "70000",
                    PlanData = new List<PlanData3ForDelinquencyAdjustmentsInquiry3>{
                        new PlanData3ForDelinquencyAdjustmentsInquiry3
                        {
                            CurrBal = "123",
                            PlanNbr = "123",
                            RecNbr = "123",
                            TotDue = "123"
                        }
                    },
                    NbrReturnedItems = "1"
                });
            _accountMaintenanceApiClientMock
                .SetupSequence(x => x.DelinquencyAdjustmentUpdateAsync(It.IsAny<DelinquencyAdjustmentUpdateRequest>()))
                .ReturnsAsync(new DelinquencyAdjustmentUpdateResponse
                {
                    DiffInDue = "0",
                    PlanData = new List<PlanDataForDelinquencyAdjustmentUpdate1>
                    {
                        new PlanDataForDelinquencyAdjustmentUpdate1
                        {
                            CurrBal = "123",
                            PlanNbr = "123",
                            RecNbr = "123",
                            TotDue = "123"
                        }
                    },
                    NbrReturnedItems = "1"

                })
                .ReturnsAsync(new DelinquencyAdjustmentUpdateResponse
                {
                    DiffInDue = "1"
                });

            //act
            Func<Task> act = async () => await _reAgeByAmountService.ExecuteAsync(request);

            //assert
            await act.Should().ThrowAsync<AccountRecalculationException>();
        }
    }
}
