﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AutoFixture;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Loans.v2.Models;
using NewDay.Digital.Foundation.Core.Azure.Function.Services;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.CreateInstallmentPlan;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Cache;
using NewDay.Digital.Foundation.Service.CardAccount.Application.CreateInstallmentPlan;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.CreateInstallmentPlan
{
    public class CreateInstallmentPlanServiceTests
    {
        private readonly IExecutable<CreateInstallmentPlanRequest, DataManagerResponse<CreateInstallmentPlanResponse>> _createInstallmentPlanService;

        private readonly Mock<Connector.FirstData.Loans.v1.ILoansApiClient> _loansApiClientV1Mock;
        private readonly Mock<Connector.FirstData.Loans.v2.ILoansApiClient> _loansApiClientV2Mock;

        public CreateInstallmentPlanServiceTests()
        {
            var brand = new Fixture().Create<Brand>();
            var brandHelperMock = new Mock<IBrandHelper>();

            brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(brand)
                .Verifiable();

            _loansApiClientV1Mock = new Mock<Connector.FirstData.Loans.v1.ILoansApiClient>();
            _loansApiClientV2Mock = new Mock<Connector.FirstData.Loans.v2.ILoansApiClient>();

            var converter = new CreateInstallmentPlanConverter(brandHelperMock.Object);

            var cacheKeyProviderMock = new Mock<IAccountPlanInquiryCacheKeyProvider>();
            cacheKeyProviderMock.Setup(x => x.GetKey(It.IsAny<string>())).Returns("cacheKey");

            var dataManagerMock = new Mock<IDataManager>();

            _createInstallmentPlanService =
                new CreateInstallmentPlanService(converter, _loansApiClientV1Mock.Object, _loansApiClientV2Mock.Object,
                    dataManagerMock.Object, cacheKeyProviderMock.Object);
        }

        [Fact]
        public void Should_make_plans_orchestration_call()
        {
            var createInstallmentPlanRequest = new CreateInstallmentPlanRequest()
            {
                CardAccountId = "0000111122223333",
                Amount = 20,
                SourcePlan = "50900",
                InstallmentPlan = "50901"
            };

            _createInstallmentPlanService.ExecuteAsync(createInstallmentPlanRequest);

            _loansApiClientV2Mock.Verify(m => m.AccountPlanListAsync(It.IsAny<AccountPlanListRequest2>()), Times.Once);
        }

        [Fact]
        public async void Should_throw_eligible_balance_exceeded_exception_if_amount_is_bigger_than_plan_value()
        {
            var createInstallmentPlanRequest = new CreateInstallmentPlanRequest()
            {
                CardAccountId = "0000111122223333",
                Amount = 20,
                SourcePlan = "50900",
                InstallmentPlan = "50901"
            };

            var accountPlanListResponse = new AccountPlanListResponse2()
            {
                PlanCtdData = new[]
                {
                    new PlanCtdData2ForAccountPlanList2()
                    {
                        PlanNbr = "50900",
                        FppEligBal = "0"
                    },
                    new PlanCtdData2ForAccountPlanList2()
                    {
                        PlanNbr = "50901"
                    }
                }
            };

            _loansApiClientV2Mock.Setup(m => m.AccountPlanListAsync(It.IsAny<AccountPlanListRequest2>())).ReturnsAsync(accountPlanListResponse);

            Task Action() => _createInstallmentPlanService.ExecuteAsync(createInstallmentPlanRequest);

            await Assert.ThrowsAsync<EligibleBalanceExceededException>(Action);
        }

        [Theory]
        [InlineData("00000", "50901")]
        [InlineData("50900", "00000")]
        public async void Should_throw_plan_match_exception_if_source_or_installment_plan_not_found(string sourcePlan, string installmentPlan)
        {
            var createInstallmentPlanRequest = new CreateInstallmentPlanRequest()
            {
                CardAccountId = "0000111122223333",
                Amount = 20,
                SourcePlan = sourcePlan,
                InstallmentPlan = installmentPlan
            };

            var accountPlanListResponse = new AccountPlanListResponse2()
            {
                PlanCtdData = new[]
                {
                    new PlanCtdData2ForAccountPlanList2()
                    {
                        PlanNbr = "50900"
                    },
                    new PlanCtdData2ForAccountPlanList2()
                    {
                        PlanNbr = "50901"
                    }
                }
            };

            _loansApiClientV2Mock.Setup(m => m.AccountPlanListAsync(It.IsAny<AccountPlanListRequest2>())).ReturnsAsync(accountPlanListResponse);

            Task Action() => _createInstallmentPlanService.ExecuteAsync(createInstallmentPlanRequest);

            await Assert.ThrowsAsync<InstallmentPlanMatchException>(Action);
        }

        [Fact]
        public async void Should_throw_plan_match_exception_if_no_plans_found_in_fd()
        {
            var createInstallmentPlanRequest = new CreateInstallmentPlanRequest()
            {
                CardAccountId = "0000111122223333",
                Amount = 20,
                SourcePlan = "50900",
                InstallmentPlan = "50901"
            };

            var accountPlanListResponse = new AccountPlanListResponse2()
            {
                PlanCtdData = new List<PlanCtdData2ForAccountPlanList2>(),
                NbrOfPlans = "0"
            };

            _loansApiClientV2Mock.Setup(m => m.AccountPlanListAsync(It.IsAny<AccountPlanListRequest2>())).ReturnsAsync(accountPlanListResponse);

            Task Action() => _createInstallmentPlanService.ExecuteAsync(createInstallmentPlanRequest);

            await Assert.ThrowsAsync<InstallmentPlanMatchException>(Action);
        }
    }
}