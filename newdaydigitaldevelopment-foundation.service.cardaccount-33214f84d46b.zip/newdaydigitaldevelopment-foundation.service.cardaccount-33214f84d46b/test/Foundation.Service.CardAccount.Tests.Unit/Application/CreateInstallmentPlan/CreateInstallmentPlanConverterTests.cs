﻿using System;
using System.Linq;
using AutoFixture;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Loans.v2.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.CreateInstallmentPlan;
using NewDay.Digital.Foundation.Service.CardAccount.Application.CreateInstallmentPlan;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.CreateInstallmentPlan
{
    public class CreateInstallmentPlanConverterTests
    {
        private Mock<IBrandHelper> GetBrandHelperMock()
        {
            var brand = new Fixture().Create<Brand>();

            var brandHelperMock = new Mock<IBrandHelper>();

            brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(brand)
                .Verifiable();

            return brandHelperMock;
        }

        [Fact]
        public void Should_throw_InvalidBrandException_for_invalid_card_account_number_on_fppAddRequest_conversion()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns((Brand)null)
                .Verifiable();

            var installmentQuoteRequest = new CreateInstallmentPlanRequest()
            {
                CardAccountId = "0000111122223333",
                Amount = 20,
                SourcePlan = "50900",
                InstallmentPlan = "50901"
            };

            var matchingSourcePlan = new PlanCtdData2ForAccountPlanList2()
            {
                PlanNbr = "50900",
                FppEligBal = "30000",
                FppAgrdPmtAmt = "1200",
                FppOrigTerm = "22",
                PlanRecNbr = "01"
            };

            var matchingInstallmentPlan = new PlanCtdData2ForAccountPlanList2()
            {
                PlanNbr = "50901",
                FppAgrdPmtAmt = "1200",
                FppOrigTerm = "22"
            };

            var converter = new CreateInstallmentPlanConverter(brandHelperMock.Object);

            Action act = () => converter.ToFppAddRequest(installmentQuoteRequest, matchingSourcePlan, matchingInstallmentPlan);
            act.Should().Throw<InvalidBrandException>();
        }

        [Fact]
        public void Should_convert_create_installment_plan_request_to_fd_request()
        {
            var brandHelperMock = GetBrandHelperMock();

            var domainRequest = new CreateInstallmentPlanRequest()
            {
                CardAccountId = "0000111122223333",
                Amount = 20,
                SourcePlan = "50900",
                InstallmentPlan = "50901"
            };

            var matchingSourcePlan = new PlanCtdData2ForAccountPlanList2()
            {
                PlanNbr = "50900",
                FppEligBal = "30000",
                FppAgrdPmtAmt = "1200",
                FppOrigTerm = "22",
                PlanRecNbr = "01"
            };

            var matchingInstallmentPlan = new PlanCtdData2ForAccountPlanList2()
            {
                PlanNbr = "50901",
                FppAgrdPmtAmt = "1200",
                FppOrigTerm = "22"
            };

            var converter = new CreateInstallmentPlanConverter(brandHelperMock.Object);

            var fdRequest = converter.ToFppAddRequest(domainRequest, matchingSourcePlan, matchingInstallmentPlan);

            fdRequest.Acct.Should().Be("0000111122223333");
            fdRequest.Plan.Should().Be("50901");
            fdRequest.AgrdPmtAmt.Should().Be("1200");
            fdRequest.FppBal.Should().Be("2000");
            fdRequest.Term.Should().Be("22");
            fdRequest.Function.Should().Be("O");
            fdRequest.PlanGroup.Count().Should().Be(1);
            fdRequest.PlanGroup.FirstOrDefault()?.AzfxPlan.Should().Be("50900");
            fdRequest.PlanGroup.FirstOrDefault()?.AzfxPlanBal.Should().Be("30000");
            fdRequest.PlanGroup.FirstOrDefault()?.AzfxPlanRec.Should().Be("01");
        }
    }
}