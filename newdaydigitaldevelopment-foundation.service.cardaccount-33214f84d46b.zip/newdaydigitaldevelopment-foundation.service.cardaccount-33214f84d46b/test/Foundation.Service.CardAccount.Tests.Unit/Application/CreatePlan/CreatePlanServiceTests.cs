﻿using System;
using System.Collections.Generic;
using System.Text;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Transactions.v1;
using NewDay.Digital.Foundation.Connector.FirstData.Transactions.v1.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.CreatePlan;
using NewDay.Digital.Foundation.Service.CardAccount.Application.CreatePlan;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.CreatePlan
{
    public class CreatePlanServiceTests
    {
        private readonly CreatePlanService _createPlanService;
        private readonly Mock<ITransactionsApiClient> _transactionApiClientMock = new Mock<ITransactionsApiClient>();
        private readonly Mock<IBrandHelper> _brandHelperMock = new Mock<IBrandHelper>();

        public CreatePlanServiceTests()
        {

            _brandHelperMock.Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(new Brand("opus", "3915000001749033", "391", new List<string>(), true));
            var createPlanConverter = new CreatePlanConverter(_brandHelperMock.Object);
            _createPlanService = new CreatePlanService(_transactionApiClientMock.Object, createPlanConverter);
        }

        [Fact]
        public async void Should_call_monetary_action_endpoint_twice_with_two_action_codes()
        {
            //arrange
            _transactionApiClientMock
                .Setup(x => x.MonetaryActionAsync(It.Is<MonetaryActionRequest>(r => r.ActionCode == "1MPU")))
                .ReturnsAsync(new MonetaryActionResponse()).Verifiable();
            _transactionApiClientMock
                .Setup(x => x.MonetaryActionAsync(It.Is<MonetaryActionRequest>(r => r.ActionCode == "2MPU")))
                .ReturnsAsync(new MonetaryActionResponse()).Verifiable();

            //act
            await _createPlanService.ExecuteAsync(new CreatePlanRequest {CardAccountId = "123", RetailPlan = "1234"});


            //assert
            _transactionApiClientMock.Verify(x => x.MonetaryActionAsync(It.Is<MonetaryActionRequest>(r => r.ActionCode == "1MPU")),Times.Exactly(1));
            _transactionApiClientMock.Verify(x => x.MonetaryActionAsync(It.Is<MonetaryActionRequest>(r => r.ActionCode == "2MPU")), Times.Exactly(1));
        }
    }
}
