﻿using System;
using System.Collections.Generic;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Extensions;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.CreatePlan;
using NewDay.Digital.Foundation.Service.CardAccount.Application.CreatePlan;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.CreatePlan
{
    public class CreatePlanConverterTests
    {
        private readonly ICreatePlanConverter _createPlanConverter;
        private readonly Mock<IBrandHelper> _brandHelperMock = new Mock<IBrandHelper>();

        public CreatePlanConverterTests()
        {
            _brandHelperMock.Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(new Brand("opus", "3915000001749033", "391", new List<string>(), true));
            _createPlanConverter = new CreatePlanConverter(_brandHelperMock.Object);
        }

        private readonly CreatePlanRequest _createPlanRequest = new CreatePlanRequest()
        {
            CardAccountId = "3915000001749033",
            RetailPlan = "10004"
        };

        [Fact]
        public void Should_convert_to_monetary_action_with_with_create_plan_action_code()
        {
            var fdRequest = _createPlanConverter.CreatePlanMonetaryActionRequest(_createPlanRequest);

            fdRequest.TxnAmount.Should().Be("1");
            fdRequest.AcctNbr.Should().Be(_createPlanRequest.CardAccountId);
            fdRequest.ActionCode.Should().Be("1MPU");
            fdRequest.PlanNbr.Should().Be(_createPlanRequest.RetailPlan);
            fdRequest.StoreNbr.Should().Be("999999998");
            fdRequest.EffDate.Should().Be(DateTime.UtcNow.ToFDDateString());
            fdRequest.ForeignUse.Should().Be("0");
        }

        [Fact]
        public void Should_convert_to_monetary_action_with_with_reverse_payment_action_code()
        {
            var fdRequest = _createPlanConverter.ReversePaymentMonetaryActionRequest(_createPlanRequest);

            fdRequest.TxnAmount.Should().Be("1");
            fdRequest.AcctNbr.Should().Be(_createPlanRequest.CardAccountId);
            fdRequest.ActionCode.Should().Be("2MPU");
            fdRequest.PlanNbr.Should().Be(_createPlanRequest.RetailPlan);
            fdRequest.StoreNbr.Should().Be("999999998");
            fdRequest.EffDate.Should().Be(DateTime.UtcNow.ToFDDateString());
            fdRequest.ForeignUse.Should().Be("0");
        }
    }
}
