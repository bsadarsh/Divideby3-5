﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v1.Models;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3;
using NewDay.Digital.Foundation.Connector.FirstData.AccountManagement.v3.Models;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.RemovePaymentHoliday;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.RemovePaymentHoliday;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.RemovePaymentHoliday
{
    public class RemovePaymentHolidayServiceTests
    {
        private readonly Mock<IAccountManagementApiClient> _accountManagementApiMock;
        private readonly Mock<Connector.FirstData.AccountManagement.v1.IAccountManagementApiClient>
            _accountManagementApiMockV1;
        private readonly RemovePaymentHolidayService _paymentHolidayService;

        public RemovePaymentHolidayServiceTests()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock.Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(new Brand("opus", "123", "392", new List<string>(), false));
            var paymentHolidayConverter = new RemovePaymentHolidayConverter(brandHelperMock.Object);

            _accountManagementApiMock = new Mock<IAccountManagementApiClient>();
            _accountManagementApiMockV1 = new Mock<Connector.FirstData.AccountManagement.v1.IAccountManagementApiClient>();


            _paymentHolidayService = new RemovePaymentHolidayService(paymentHolidayConverter, _accountManagementApiMock.Object, _accountManagementApiMockV1.Object);
        }

        private static readonly RemovePaymentHolidayRequest RemovePaymentHolidayRequest = new RemovePaymentHolidayRequest
        {
            CardAccountId = "3915000011686878"
        };

        [Theory]
        [InlineData("")]
        [InlineData(null)]
        public async void Should_make_orchestration_call_for_term_value_if_term_passed_is_null_or_empty(
            string termValue)
        {
            //arrange
            RemovePaymentHolidayRequest.Term = termValue;
            _accountManagementApiMock.Setup(x => x.AccountDetailInquiryAsync(It.IsAny<AccountDetailInquiryRequest3>())).ReturnsAsync(new AccountDetailInquiryResponse3(){PmtHolidayTerm = "2" }).Verifiable();
            _accountManagementApiMockV1.Setup(x => x.PaymentHolidayAsync(It.IsAny<PaymentHolidayRequest>())).Verifiable();

            //act
            await _paymentHolidayService.ExecuteAsync(RemovePaymentHolidayRequest);

            //assert
            _accountManagementApiMock.Verify(x => x.AccountDetailInquiryAsync(It.Is<AccountDetailInquiryRequest3>(
                r => 
                    r.Account == RemovePaymentHolidayRequest.CardAccountId)), Times.Once);
            _accountManagementApiMockV1.Verify(x => x.PaymentHolidayAsync(It.Is<PaymentHolidayRequest>(
                r => 
                    r.Account == $"000{RemovePaymentHolidayRequest.CardAccountId}" &&
                    r.HolidayTerm == "2" &&
                    r.PmtHolidayFlag == "0")), Times.Once);
        }

        [Fact]
        public async void When_orchestration_call_is_made_and_returned_term_from_fd_is_zero_Then_exception_is_thrown()
        {
            //arrange
            RemovePaymentHolidayRequest.Term = "";
            _accountManagementApiMock.Setup(x => x.AccountDetailInquiryAsync(It.IsAny<AccountDetailInquiryRequest3>())).ReturnsAsync(new AccountDetailInquiryResponse3() { PmtHolidayTerm = "0" }).Verifiable();

            //act
            Func<Task> act = async () => await _paymentHolidayService.ExecuteAsync(RemovePaymentHolidayRequest);

            //assert
            await act.Should().ThrowAsync<NoPaymentHolidaySetException>();
            _accountManagementApiMock.Verify(x => x.AccountDetailInquiryAsync(It.IsAny<AccountDetailInquiryRequest3>()), Times.Once);
        }

        [Fact]
        public async void When_term_value_is_passed_from_client_Then_no_orchestration_call_is_made()
        {
            //arrange
            RemovePaymentHolidayRequest.Term = "1";
            _accountManagementApiMock.Setup(x => x.AccountDetailInquiryAsync(It.IsAny<AccountDetailInquiryRequest3>())).Verifiable();
            _accountManagementApiMockV1.Setup(x => x.PaymentHolidayAsync(It.IsAny<PaymentHolidayRequest>())).Verifiable();

            //act
            await _paymentHolidayService.ExecuteAsync(RemovePaymentHolidayRequest);

            //assert
            _accountManagementApiMock.Verify(x => x.AccountDetailInquiryAsync(It.Is<AccountDetailInquiryRequest3>(
                r =>
                    r.Account == RemovePaymentHolidayRequest.CardAccountId)), Times.Never);
            _accountManagementApiMockV1.Verify(x => x.PaymentHolidayAsync(It.Is<PaymentHolidayRequest>(
                r =>
                    r.Account == $"000{RemovePaymentHolidayRequest.CardAccountId}" &&
                    r.HolidayTerm == "1" &&
                    r.PmtHolidayFlag == "0")), Times.Once);
        }
    }
}
