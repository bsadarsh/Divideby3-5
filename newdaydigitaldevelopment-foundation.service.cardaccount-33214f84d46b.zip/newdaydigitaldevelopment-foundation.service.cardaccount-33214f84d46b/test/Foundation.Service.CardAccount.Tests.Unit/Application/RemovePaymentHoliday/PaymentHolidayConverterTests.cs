﻿using System;
using System.Collections.Generic;
using System.Text;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1.RemovePaymentHoliday;
using NewDay.Digital.Foundation.Service.CardAccount.Application.RemovePaymentHoliday;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.RemovePaymentHoliday
{
    public class PaymentHolidayConverterTests
    {
        private readonly IRemovePaymentHolidayConverter _paymentHolidayConverter;

        public PaymentHolidayConverterTests()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock.Setup(x => x.GetBrandFromAccountNumber(It.IsAny<string>()))
                .Returns(new Brand("opus", "123", "392", new List<string>(), false));
            _paymentHolidayConverter = new RemovePaymentHolidayConverter(brandHelperMock.Object);
        }

        private static readonly RemovePaymentHolidayRequest RemovePaymentHolidayRequest = new RemovePaymentHolidayRequest
        {
            CardAccountId = "3915000011686878",
            Term = "2"
        };

        [Fact]
        public void Should_convert_to_account_inquiry_detail_request_model()
        {
            //act
            var accountInquiryRequest = _paymentHolidayConverter.ToAccountDetailInquiry(RemovePaymentHolidayRequest);

            //assert
            accountInquiryRequest.Common.ClientNumber.Should().Be("123");
            accountInquiryRequest.Account.Should().Be(RemovePaymentHolidayRequest.CardAccountId);
        }

        [Fact]
        public void Should_convert_to_payment_holiday_request_model()
        {
            //act
            var paymentHolidayRequest = _paymentHolidayConverter.ToPaymentHolidayRequest(RemovePaymentHolidayRequest);

            //arrange
            paymentHolidayRequest.Common.ClientNumber.Should().Be("123");
            paymentHolidayRequest.Common.Org.Should().Be("391");
            paymentHolidayRequest.Account.Should().Be($"000{RemovePaymentHolidayRequest.CardAccountId}");
            paymentHolidayRequest.HolidayTerm.Should().Be(RemovePaymentHolidayRequest.Term);
            paymentHolidayRequest.PmtHolidayFlag.Should().Be("0");
        }
    }
}
