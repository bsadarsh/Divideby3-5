﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoFixture;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Customer.v1;
using NewDay.Digital.Foundation.Connector.FirstData.Customer.v1.Models;
using NewDay.Digital.Foundation.Core.Caching;
using NewDay.Digital.Foundation.Core.Caching.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Exceptions;
using NewDay.Digital.Foundation.Service.CardAccount.Application.GetAccountHolder;
using NewDay.Digital.Foundation.Service.CardAccount.Application.Utils;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.GetAccountHolder
{
    public class GetAccountHolderServiceTests
    {
        [Fact]
        public async Task Should_return_badRequest_if_cardaccountid_passed_in_is_not_recognised()
        {
            var request = new GetAccountHolderByCardAccountIdRequest
            {
                CardAccountId = "bad card account id"
            };

            var customerApiClientMock = new Mock<ICustomerApiClient>();
            var dataManagerMock = new Mock<IDataManager>();
            
            var timeoutMock = new Mock<ITimeoutProvider>();
            timeoutMock.SetupGet(x => x.Timeout).Returns(TimeSpan.FromSeconds(1));
            
            var brandHelperMock = new Mock<IBrandHelper>();
            var service = new GetAccountHolderService(timeoutMock.Object, new GetAccountHolderConverter(brandHelperMock.Object), customerApiClientMock.Object, dataManagerMock.Object);
            Func<Task<DataManagerResponse<GetAccountHolderResponse>>> func = () => service.ExecuteAsync(request);
            await func.Should().ThrowAsync<InvalidBrandException>();
        }

        [Fact]
        public async Task Should_Return_Correct_Response_If_Valid_Account_Number_Is_Sent_In_The_Request()
        {
            var fixture = new Fixture();
            var request = fixture.Create<GetAccountHolderByCardAccountIdRequest>();

            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock.Setup(a => a.GetBrandFromAccountNumber(request.CardAccountId)).Returns(fixture.Create<Brand>());

            var ownerCoownerData = new OwnerCoownerData
            {
                Dob = "19991231"
            };

            var inquiryResponse = fixture
                .Build<CustomerDemographicInquiryResponse>()
                .With(x => x.CustNbr, "1234567890123456")
                .With(x => x.OwnerCoownerData, new List<OwnerCoownerData>{ ownerCoownerData })
                .Create();

            var dataManagerResponse = new DataManagerResponse<CustomerDemographicInquiryResponse>(inquiryResponse, DateTime.Now, TimeSpan.Zero);
            var expectedResponse = new DataManagerResponse<GetAccountHolderResponse>(new GetAccountHolderResponse
            {
                AccountHolder = new AccountHolder
                {
                    AccountHolderId = "1234567890123456"
                },
                PersonalDetails = new PersonalDetails
                {
                    DateOfBirth = new DateTime(1999, 12, 31),
                    Addresses = new List<Address>
                    {
                        new Address()
                    }
                }
            }, DateTime.Now, TimeSpan.Zero);

            var customerApiClientMock = new Mock<ICustomerApiClient>(MockBehavior.Strict);
            customerApiClientMock
                .Setup(n => n.CustomerDemographicInquiryAsync(It.IsAny<CustomerDemographicInquiryRequest>()))
                .ReturnsAsync(inquiryResponse);

            var timeoutMock = new Mock<ITimeoutProvider>();
            timeoutMock.SetupGet(x => x.Timeout).Returns(TimeSpan.FromSeconds(1));
            
            var dataManagerMock = new Mock<IDataManager>(MockBehavior.Strict);
            dataManagerMock.Setup(n =>
                n.FetchWithCacheAsync(It.IsAny<string>(), It.IsAny<TimeSpan>(), It.IsAny<Func<Task<CustomerDemographicInquiryResponse>>>()))
                .ReturnsAsync(dataManagerResponse);

            var service = new GetAccountHolderService(timeoutMock.Object, new GetAccountHolderConverter(brandHelperMock.Object), customerApiClientMock.Object, dataManagerMock.Object);
            var actualResponse = await service.ExecuteAsync(request);

            actualResponse.Should().BeEquivalentTo(expectedResponse, config => config
                .Excluding(x => x.CacheAge)
                .Excluding(x => x.CacheExpires));
        }
    }
}
