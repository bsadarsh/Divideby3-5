﻿using System;
using System.Collections.Generic;
using System.Linq;
using FluentAssertions;
using Moq;
using NewDay.Digital.Foundation.Connector.FirstData.Brands;
using NewDay.Digital.Foundation.Connector.FirstData.Customer.v1.Models;
using NewDay.Digital.Foundation.Core.Domain.CardAccount;
using NewDay.Digital.Foundation.Core.Domain.CardAccount.Contracts.v1;
using NewDay.Digital.Foundation.Service.CardAccount.Application.GetAccountHolder;
using Xunit;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit.Application.GetAccountHolder
{
    public class GetAccountHolderConverterTests
    {
        [Fact]
        public void Should_convert_GetAccountHolderByCardAccountIdRequest_into_CustomerDemographicInquiryRequest()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            brandHelperMock
                .Setup(a => a.GetBrandFromAccountNumber("3915050004000066"))
                .Returns(new Brand("Marbles", "01030", "391", new[] { "505" }, true));
            var sut = new GetAccountHolderConverter(brandHelperMock.Object);

            var request = new GetAccountHolderByCardAccountIdRequest { CardAccountId = "3915050004000066" };
            var actual = sut.ToCustomerDemographicInquiryRequest(request);
            actual.CustAcctCardNbr.Should().Be(request.CardAccountId);
        }

        [Fact]
        public void Should_convert_CustomerDemographicInquiryResponse_into_GetAccountHolderResponse()
        {
            var brandHelperMock = new Mock<IBrandHelper>();
            var sut = new GetAccountHolderConverter(brandHelperMock.Object);

            var response = new CustomerDemographicInquiryResponse
            {
                CustNbr = "Customer Number",
                OwnerCoownerData = new List<OwnerCoownerData>
                {
                    new OwnerCoownerData
                    {
                        Title = "Mr",
                        FirstName = "First Name",
                        LastName = "Last Name",
                        Email = "me@email.com",
                        HomePhone = "123456789",
                        MobilePhone = "987654321",
                        HouseName = "My House",
                        HouseNumber = "25",
                        Addr1 = "My Address",
                        Address4 = "Address4",
                        PstlCd = "N1 9AL",
                        City = "My City",
                        County = "My County",
                        Dob = "19890225"
                    }
                }
            };

            var address = response.OwnerCoownerData.First();

            var expected = new GetAccountHolderResponse
            {
                AccountHolder = new AccountHolder
                {
                    Title = "Mr",
                    AccountHolderId = "Customer Number",
                    FirstName = "First Name",
                    LastName = "Last Name",
                },
                PersonalDetails = new PersonalDetails
                {
                    Email = "me@email.com",
                    Phone = "123456789",
                    Mobile = "987654321",
                    DateOfBirth = new DateTime(1989, 2, 25, 0, 0, 0, DateTimeKind.Utc),
                    Addresses = new List<Address>
                    {
                        new Address
                        {
                            HouseName = address.HouseName,
                            HouseNumber = address.HouseNumber,
                            AddressLine1 = address.Addr1,
                            AddressLine4 = address.Address4,
                            PostCode = address.PstlCd,
                            City = address.City,
                            County = address.County
                        }
                    }
                }
            };

            var actual = sut.ToGetAccountHolderResponse(response);
            actual.Should().BeEquivalentTo(expected);
        }
    }
}
