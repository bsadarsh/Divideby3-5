﻿using System.IO;
using Microsoft.AspNetCore.Http;
using Moq;
using Newtonsoft.Json;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Unit
{
    internal static class HttpRequestHelper
    {
        internal static Mock<HttpRequest> CreateMockRequest(object requestObject)
        {
            var jsonString = JsonConvert.SerializeObject(requestObject);

            var ms = new MemoryStream();
            var sw = new StreamWriter(ms);

            sw.Write(jsonString);
            sw.Flush();

            ms.Position = 0;

            var mockRequest = new Mock<HttpRequest>();
            mockRequest.Setup(x => x.Body).Returns(ms);

            return mockRequest;
        }

        internal static Mock<HttpRequest> CreateMockRequest(string body)
        {
            var ms = new MemoryStream();
            var sw = new StreamWriter(ms);

            sw.Write(body);
            sw.Flush();

            ms.Position = 0;

            var mockRequest = new Mock<HttpRequest>();
            mockRequest.Setup(x => x.Body).Returns(ms);

            return mockRequest;
        }
    }
}