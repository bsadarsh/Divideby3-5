﻿using System;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using BoDi;
using Microsoft.Extensions.Configuration;
using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration
{
    [Binding]
    public class DependenciesRegistry
    {
        private readonly IObjectContainer _objectContainer;
        private readonly HttpClient _cardAccountHttpClient;
        private readonly HttpClient _firstDataMockHttpClient;

        public DependenciesRegistry(IObjectContainer objectContainer)
        {
            _objectContainer = objectContainer;

            var configurationRoot = ConfigurationHelper.GetConfigurationRoot(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
            _objectContainer.RegisterInstanceAs<IConfiguration>(configurationRoot);

            var mockConfiguration = new MockConfiguration(_objectContainer.Resolve<IConfiguration>());
            _objectContainer.RegisterInstanceAs(mockConfiguration);

            FirstDataEndpoints.BaseAddress = new Uri(mockConfiguration.FirstDataBaseAddress);
            FirstDataMockEndpoints.BaseAddress = new Uri(mockConfiguration.FirstDataMockBaseAddress);
            CardAccountEndpoints.BaseAddress = new Uri(mockConfiguration.ServiceAddress);
            Azure.FunctionBaseAddress = mockConfiguration.AzureFunctionBaseAddress;
            
            var accessToken = TokenProvider.GetToken(CardAccountEndpoints.AudienceUrl);

            _firstDataMockHttpClient = new HttpClient
            {
                BaseAddress = FirstDataMockEndpoints.BaseAddress
            };

            _cardAccountHttpClient = new HttpClient
            {
                BaseAddress = CardAccountEndpoints.BaseAddress
            };
            _cardAccountHttpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
        }

        [BeforeScenario(Order = 1)]
        public void SetupConfig()
        {
            var mockClient = new MockClient(_firstDataMockHttpClient);
            var fdMock = new Mock(mockClient);
            _objectContainer.RegisterInstanceAs(fdMock);

            var cardAccountClient = new HttpApiClient(_cardAccountHttpClient);
            _objectContainer.RegisterInstanceAs<IHttpApiClient>(cardAccountClient);

            _objectContainer.RegisterInstanceAs<IDataFixtureReader>(new DataFixtureReader(Directory.GetCurrentDirectory()));
        }
        
        [AfterScenario(Order = 1)]
        public void DeleteMockedEndpoints()
        {
            var fdMock = _objectContainer.Resolve<Mock>();
            fdMock.DeleteMockedEndpoints();
        }

        [AfterScenario(Order = 2)]
        public void DisposeHttpClients()
        {
            _firstDataMockHttpClient.Dispose();
            _cardAccountHttpClient.Dispose();
        }
    }
}
