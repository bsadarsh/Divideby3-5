﻿$exePath = "C:\Program Files\dotnet\dotnet.exe"
$testDllName = "Foundation.Service.CardAccount.Tests.Integration.dll"

$filter = "#{SpecFlow:IntegrationTestsFilter}"

Write-Host "Test config content:"
Get-Content .\testappsettings.json

if([string]::IsNullOrEmpty($filter)) {
    $filter = "Category=IntegrationTest"
}

Write-Host "Test filter: " $filter
& $exePath vstest $testDllName --testCaseFilter:"$filter" --logger:"console;verbosity=normal"
