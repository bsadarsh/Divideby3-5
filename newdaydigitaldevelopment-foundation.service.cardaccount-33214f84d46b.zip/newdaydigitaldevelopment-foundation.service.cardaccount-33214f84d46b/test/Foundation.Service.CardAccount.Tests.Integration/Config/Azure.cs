﻿namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config
{
    public static class Azure
    {
        public static string FunctionBaseAddress { get; set; }
    }
}