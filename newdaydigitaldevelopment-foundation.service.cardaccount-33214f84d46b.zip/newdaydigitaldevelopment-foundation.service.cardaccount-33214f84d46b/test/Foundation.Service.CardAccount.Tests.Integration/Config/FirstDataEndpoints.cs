﻿using System;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config
{
    public static class FirstDataEndpoints
    {
        public static Uri BaseAddress { get; set; }

        public static string AccountDetailInquiry { get; } = "api/fs/fv_emea/v1/accountDetailInquiry";

        public static string AccountDetailInquiryV2 { get; } = "api/fs/fv_emea/v2/accountDetailInquiry";
        public static string AccountDetailInquiryV3 { get; } = "api/fs/fv_emea/v3/accountDetailInquiry";

        public static string CustomerDemographicInquiry { get;  }= "api/fs/fv_emea/v1/customerDemographicInquiry";

        public static string MemoInquiry { get; } = "api/fs/fv_emea/v2/memoInquiry";

        public static string AddAMemo { get;  }= "api/fs/fv_emea/v1/memoAdd";

        public static string CreateAccountEmbosserAdd { get; } = "api/fs/fv_emea/v1/customerAccountEmbosserAdd";

        public static string GetCardList { get; } = "api/fs/fv_emea/v2/cardsListByCard";

        public static string AccountCustomFieldsUpdate { get; } = "api/fs/fv_emea/v1/accountCustomFieldsUpdate";

        public static string CardInquiry { get; } = "api/fs/fv_emea/v1/cardInquiry";

        public static string BillingCycleUpdate { get; } = "api/fs/fv_emea/v1/billingCycleUpdate";

        public static string AccountBlockCodeUpdate { get; } = "api/fs/fv_emea/v1/accountBlockCodeUpdate";
        public static string MonetaryAction { get; } = "api/fs/fv_emea/v1/monetaryAction";
        public static string AccountPlanInquiry { get; } = "api/fs/fv_emea/v2/accountPlanInquiry";

        public static string letterRequest { get; } = "api/fs/fv/emea/v2/letterRequest";

        public static string Accountclose { get; } = "api/fs/fv_emea/v1/accountClose";

        public static string GetPlans { get; } = "api/fs/fv_emea/v2/accountPlanInquiry";

        public static string FppQuoteGeneration { get; } = "api/fs/fv_emea/v1/fppQuoteGeneration";

        public static string FppAdd { get; } = "api/fs/fv_emea/v1/fppAdd";

        public static string AccountPlanList { get; } = "api/fs/fv_emea/v2/accountPlanList";

        public static string UpdateAccountBlockCode { get; } = "api/fs/fv_emea/v1/accountBlockCodeUpdate";

        public static string UpdateAccountCustomField { get; } = "api/fs/fv_emea/v1/accountCustomFieldsUpdate";

        public static string UpdateAccountUserField { get; } = "api/fs/fv_emea/v2/accountUserFieldsUpdate";

        public static string UpdateAccountDisabilityIndicator { get; } = "api/fs/fv_emea/v1/accountDisabilityIndicatorUpdate";

        public static string InsuranceInquiry { get; } = "api/fs/fv_emea/v3/insuranceInquiry";

        public static string PaymentHoliday { get; } = "api/fs/fv_emea/v1/paymentHoliday";

        public static string InsuranceStatusUpdate { get; } = "api/fs/fv_emea/v1/insuranceStatusUpdate";

        public static string DelinquencyAdjustmentsInquiry { get; } = "api/fs/fv_emea/v3/delinquencyAdjustmentsInquiry";

        public static string DelinquencyAdjustmentUpdate { get; } = "api/fs/fv_emea/v1/delinquencyAdjustmentUpdate";
        public static string PlanTransfer { get; } = "api/fs/fv_emea/v1/planTransfer";

    }
}
