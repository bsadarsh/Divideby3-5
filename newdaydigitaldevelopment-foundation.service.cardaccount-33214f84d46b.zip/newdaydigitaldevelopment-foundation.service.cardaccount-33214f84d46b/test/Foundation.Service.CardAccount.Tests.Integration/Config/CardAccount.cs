﻿namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config
{
    public static class CardAccount
    {
        public static string CardAccountId { get; set; }

        public static string CardNumber { get; set; }
    }
}
