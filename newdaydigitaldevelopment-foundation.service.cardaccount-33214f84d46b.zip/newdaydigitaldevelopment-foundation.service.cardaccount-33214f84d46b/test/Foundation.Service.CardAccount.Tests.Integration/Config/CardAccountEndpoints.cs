﻿using System;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config
{
    public static class CardAccountEndpoints
    {
        public static Uri BaseAddress { get; set; }

        public static string AudienceUrl => BaseAddress.AbsoluteUri.TrimEnd('/');

        public static string GetAccountHolder { get; } = "api/v1/getAccountHolder";

        public static string GetCardAccount { get; } = "api/v1/getCardAccount";       

        public static string HeartBeat { get; } = "api/HeartBeat";

        public static string HealthCheck { get; } = "api/HealthCheck";

        public static string GetMemos { get; } = "api/v1/getMemos";

        public static string CreateMemo { get; } = "api/v1/createMemo";

        public static string CreateCardAccount { get; } = "api/v1/CreateCardAccount";

        public static string GetCardList { get; } = "api/v1/getCardsByAccount";

        public static string GetAccountByCard { get; } = "api/v1/getAccountByCard";

        public static string SetSpendCap { get; } = "api/v1/setSpendCap";

        public static string GetSpendCap { get; } = "api/v1/getSpendCap";

        public static string UpdateBillingCycle { get; } = "api/v1/updateBillingCycle";

        public static string UpdateAccountBlockCodes { get; } = "api/v1/updateAccountBlockStatus";
        public static string RemoveFee { get; } = "api/v1/RemoveFee";
        public static string ReturnFunds { get; } = "api/v1/ReturnFunds";

        public static string letterRequest { get; } = "api/v1/RequestLetter";

        public static string ChargeOff { get; } = "api/v1/chargeOff";

        public static string PostGoodWill { get; } = "api/v1/postGoodwill";

        public static string CreatePlan { get; } = "api/v1/createPlan";
        public static string GetPlans { get; } = "api/v1/getPlans";

        public static string UpdateAccount { get; } = "api/v1/updateAccount";

        public static string GetInsurance { get; } = "api/v1/getInsuranceProducts";

        public static string SetPaymentHoliday { get; } = "api/v1/setPaymentHoliday";

        public static string RemovePaymentHoliday { get; } = "api/v1/removePaymentHoliday";

        public static string CancelInsurance { get; } = "api/v1/cancelInsurance";

        public static string ReAgeByAmount { get; } = "api/v1/ReAgeByAmount";

        public static string ReAgeByCode { get; } = "api/v1/ReAgeByCode";

        public static string InstallmentQuote { get; } = "api/v1/installmentQuote";
        public static string PlanTransfer { get; } = "api/v1/planTransfer";

        public static string createInstallmentPlan { get; } = "api/v1/createInstallmentPlan";

        public static string GetCardAccountV2 { get; } = "api/v2/getCardAccount";

    }
}
