﻿using System;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config
{
    public static class FirstDataMockEndpoints
    {
        public static Uri BaseAddress { get; set; }
    }
}