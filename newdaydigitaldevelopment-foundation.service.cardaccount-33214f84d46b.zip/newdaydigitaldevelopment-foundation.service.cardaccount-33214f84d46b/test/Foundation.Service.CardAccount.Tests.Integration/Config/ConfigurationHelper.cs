﻿using Microsoft.Extensions.Configuration;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config
{
    public static class ConfigurationHelper
    {
        public static IConfigurationRoot GetConfigurationRoot(string outputPath)
        {
            return new ConfigurationBuilder()
                .SetBasePath(outputPath)
                .AddJsonFile("testappsettings.json", false)
                .AddJsonFile("testappsettings.local.json", true)
                .AddEnvironmentVariables()
                .Build();
        }
    }
}