﻿using Microsoft.Extensions.Configuration;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config
{
    public class MockConfiguration
    {
        private readonly IConfiguration _configuration;

        public MockConfiguration(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public string ServiceAddress => _configuration["SpecFlowTest:ServiceAddress"];

        public string AzureFunctionBaseAddress => _configuration["SpecFlowTest:AzureFunctionBaseAddress"];

        public string FirstDataBaseAddress => _configuration["SpecFlowTest:FirstDataEndpoints:FirstDataBaseAddress"];

        public string FirstDataMockBaseAddress => _configuration["SpecFlowTest:FirstDataEndpoints:FirstDataMockBaseAddress"];

        public string ValidCardNumber => _configuration["SpecFlowTest:ValidCardNumber"];

        public string ValidCardAccountId => _configuration["SpecFlowTest:ValidCardAccountId"];

        public string ValidUATSoftCardAccountId => _configuration["SpecFlowTest:ValidUATSoftCardAccountId"];

        public string ValidUATHardCardAccountId => _configuration["SpecFlowTest:ValidUATHardCardAccountId"];
        public string ValidCardAccountIdInstantSpend => _configuration["SpecFlowTest:ValidCardAccountIdInstantSpend"];
        public string ValidCardAccountIdNonInstantSpend0 => _configuration["SpecFlowTest:ValidCardAccountIdNonInstantSpend0"];
        public string ValidCardAccountIdNonInstantSpend2 => _configuration["SpecFlowTest:ValidCardAccountIdNonInstantSpend2"];
        public string ValidCardAccountIdNonInstantSpend3 => _configuration["SpecFlowTest:ValidCardAccountIdNonInstantSpend3"];
        public string ValidCardAccountIdNonInstantSpend9 => _configuration["SpecFlowTest:ValidCardAccountIdNonInstantSpend9"];
        public string ValidCardAccountIdNonInstantSpend4 => _configuration["SpecFlowTest:ValidCardAccountIdNonInstantSpend4"];        

        public string ValidCobrandsCardAccountId => _configuration["SpecFlowTest:ValidCobrandsCardAccountId"];
        public string ValidOwnBrandsCardAccountId => _configuration["SpecFlowTest:ValidOwnBrandsCardAccountId"];


        public string HealthCheckAccountId => _configuration["SpecFlowTest:HealthCheckAccountId"];

        public string AccountNotFoundAccountId => _configuration["SpecFlowTest:AccountNotFoundAccountId"];

        public string InvalidAccountId => _configuration["SpecFlowTest:InvalidAccountId"];

        public string InvalidOrgAccountId => _configuration["SpecFlowTest:InvalidOrgAccountId"];

        public string CardAccountForUAT => _configuration["SpecFlowTest:CardAccountForUAT"];

        public string CardAccountForUATInstallmentQuote => _configuration["SpecFlowTest:CardAccountForUATInstallmentQuote"];

        public string CardAccountForCreateInstallmentPlan =>
            _configuration["SpecFlowTest:CardAccountForCreateInstallmentPlan"];

        public string CardAccountForUATChargeOff => _configuration["SpecFlowTest:CardAccountForUATChargeOff"];
        public string ValidCardAccountIdLetterRequest => _configuration["SpecFlowTest:ValidCardAccountIdLetterRequest"];

        public string ValidCardAccountIdCustomField => _configuration["SpecFlowTest:ValidCardAccountIdCustomField"];

        public string CardAccountForUATGetInsuranceProduct => _configuration["SpecFlowTest:CardAccountForUATGetInsuranceProduct"];

        public string CardAccountForUATCancelInsurance => _configuration["SpecFlowTest:CardAccountForUATCancelInsurance"];
        public string CardAccountForUATReAgeByAmount => _configuration["SpecFlowTest:CardAccountForUATReAgeByAmount"];
        public string CardAccountForUATReAgeByCode => _configuration["SpecFlowTest:CardAccountForUATReAgeByCode"];
    }
}