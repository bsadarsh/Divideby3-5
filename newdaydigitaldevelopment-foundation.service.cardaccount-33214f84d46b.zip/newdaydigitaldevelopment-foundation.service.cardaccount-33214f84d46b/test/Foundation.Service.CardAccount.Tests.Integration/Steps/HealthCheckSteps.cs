﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using FluentAssertions;
using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Extensions;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    public class HealthCheckSteps
    {
        private readonly Mock _mock;
        private readonly IHttpApiClient _cardAccountClient;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly ScenarioContext _scenarioContext;
        private readonly MockConfiguration _mockConfiguration;

        public HealthCheckSteps(
            ScenarioContext scenarioContext,
            Mock mock,
            IHttpApiClient cardAccountClient,
            IDataFixtureReader dataFixtureReader,
            MockConfiguration mockConfiguration)
        {
            _scenarioContext = scenarioContext;
            _mock = mock;
            _cardAccountClient = cardAccountClient;
            _dataFixtureReader = dataFixtureReader;
            _mockConfiguration = mockConfiguration;
        }

        [Given(@"card account service has been deployed")]
        public void GivenCardAccountServiceHasBeenDeployed()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.HealthCheckAccountId
                    : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var request = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );
            var response = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\200.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            _mock
                .GivenRequest(request)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiryV3)
                .ThenReturnAsync(response)
                .Wait();
        }

        [When(@"I call the health check endpoint")]
        public void WhenICallTheHealthCheckEndpoint()
        {
            var response = _cardAccountClient.Get(CardAccountEndpoints.HealthCheck);
            _scenarioContext.Set(response, "response");
        }

        [Then(@"the service should be healthy")]
        public void ThenTheServiceShouldBeHealthy()
        {
            var expectedResponse = _dataFixtureReader.Read(
                @"CardAccount\HealthCheck\healthy_response.json",
                new Dictionary<string, object> { { "FD_ENDPOINT", FirstDataEndpoints.BaseAddress.MakeRelativeUri(new Uri(FirstDataEndpoints.BaseAddress, FirstDataEndpoints.AccountDetailInquiryV3)).ToString() } }
            );

            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("response");
            var actualResponse = httpResponseMessage.Content.ReadAsStringAsync().Result;

            actualResponse.Should().MatchJson(expectedResponse);
        }

        [Given(@"First Data is not working properly")]
        public void GivenFirstDataIsNotWorkingProperly()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.InvalidAccountId
                    : AccountNumberGenerator.Generate();

            var request = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );
            var response = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\500_Warning.json"
            );

            _mock
                .GivenRequest(request)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiryV3)
                .ThenReturnAsync(response, 500)
                .Wait();
        }

        [Then(@"the service should be unhealthy")]
        public void ThenTheServiceShouldBeUnhealthy()
        {
            var expectedResponse = _dataFixtureReader.Read(
                @"CardAccount\HealthCheck\unhealthy_response.json",
                new Dictionary<string, object> { { "FD_ENDPOINT", FirstDataEndpoints.BaseAddress.MakeRelativeUri(new Uri(FirstDataEndpoints.BaseAddress, FirstDataEndpoints.AccountDetailInquiryV3)).ToString() } }
            );

            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("response");
            var actualResponse = httpResponseMessage.Content.ReadAsStringAsync().Result;

            actualResponse.Should().MatchJson(expectedResponse);
        }
    }
}
