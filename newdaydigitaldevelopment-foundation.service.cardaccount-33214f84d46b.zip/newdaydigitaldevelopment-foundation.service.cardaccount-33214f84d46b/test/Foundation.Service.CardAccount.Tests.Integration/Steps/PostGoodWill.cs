﻿using FluentAssertions;
using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    public class PostGoodWill
    {
        private readonly Mock _mock;
        private readonly IHttpApiClient _cardAccountClient;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly ScenarioContext _scenarioContext;
        private readonly MockConfiguration _mockConfiguration;
        private string foundationRequest = null;

        public PostGoodWill(
            ScenarioContext scenarioContext,
            Mock mock,
            IHttpApiClient cardAccountClient,
            IDataFixtureReader dataFixtureReader,
            MockConfiguration mockConfiguration)
        {
            _scenarioContext = scenarioContext;
            _mock = mock;
            _cardAccountClient = cardAccountClient;
            _dataFixtureReader = dataFixtureReader;
            _mockConfiguration = mockConfiguration;
        }

        [Given(@"I have entered an valid accountnumber")]
        public void GivenIHaveEnteredAnValidAccountnumber()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.CardAccountForUAT
                    : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var mockRequest = _dataFixtureReader.Read(
                @"FirstData\AccountPlanInquiry\request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } });
            var mockAccountRequest = _dataFixtureReader.Read(
                @"FirstData\MonetaryAction\Request_PostGoodwill.json",
                new Dictionary<string, object> {{"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId}});

            var response = _dataFixtureReader.Read(
                @"FirstData\AccountPlanInquiry\200.json"
            );

            var Monetaryresponse = _dataFixtureReader.Read(
                @"FirstData\MonetaryAction\200_PostGoodwill.json"
            );


            _mock
                .GivenRequest(mockRequest)
                .WithRequiredParam("acct")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.GetPlans)
                .ThenReturnAsync(response, 200)
                .Wait(); ;
            _mock
                .GivenRequest(mockAccountRequest)
                .WithRequiredParam("acctNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.MonetaryAction)
                .ThenReturnAsync(response, 200)
                .Wait();

        }

        [Given(@"I have entered an valid accountnumber with invalid Fiserv")]
        public void GivenIHaveEnteredAnValidAccountnumberWithInvalidFiserv()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.CardAccountForUAT
                    : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var mockRequest = _dataFixtureReader.Read(
                @"FirstData\AccountPlanInquiry\request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } });
            var mockAccountRequest = _dataFixtureReader.Read(
                @"FirstData\MonetaryAction\Request_InvalidPlanNumber.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } });

            var response = _dataFixtureReader.Read(
                @"FirstData\AccountPlanInquiry\200.json"
            );

            var Monetaryresponse = _dataFixtureReader.Read(
                @"FirstData\MonetaryAction\200.json"
            );


            _mock
                .GivenRequest(mockRequest)
                .WithRequiredParam("acct")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.GetPlans)
                .ThenReturnAsync(response, 200)
                .Wait(); ;
            _mock
                .GivenRequest(mockAccountRequest)
                .WithRequiredParam("acctNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.MonetaryAction)
                .ThenReturnAsync(response, 200)
                .Wait();
        }


        [Then(@"I post the Goodwill Transaction")]
        public void ThenIPostTheGoodwillTransaction()
        {
            _scenarioContext.Set(CallPostGoodWillEndpoint(Config.CardAccount.CardAccountId), "response");
        }
        private HttpResponseMessage CallPostGoodWillEndpoint(string cardAccountId)
        {

            var request = _dataFixtureReader.Read(
                @"CardAccount\PostGoodwill\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", cardAccountId } }
            );

            return _cardAccountClient.Post(CardAccountEndpoints.PostGoodWill, request);
        }

        [Then(@"I post the Goodwill Transaction reuest")]
        public void ThenIPostTheGoodwillTransactionReuest()
        {
            _scenarioContext.Set(CallPostGoodWillEndpointRequest(Config.CardAccount.CardAccountId), "response");
        }

        private HttpResponseMessage CallPostGoodWillEndpointRequest(string cardAccountId)
        {

            var request = _dataFixtureReader.Read(
                @"CardAccount\PostGoodwill\Request_Invalid.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", cardAccountId } }
            );

            return _cardAccountClient.Post(CardAccountEndpoints.PostGoodWill, request);
        }

    }

}



