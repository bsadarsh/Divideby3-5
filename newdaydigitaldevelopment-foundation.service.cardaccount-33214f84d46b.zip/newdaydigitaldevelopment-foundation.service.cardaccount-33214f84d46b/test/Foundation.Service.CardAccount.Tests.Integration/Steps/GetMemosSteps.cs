﻿using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using FluentAssertions;
using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Extensions;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    public class GetMemosSteps
    {
        private readonly Mock _mock;
        private readonly IHttpApiClient _apiClient;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly ScenarioContext _scenarioContext;
        private readonly MockConfiguration _mockConfiguration;

        public GetMemosSteps(
            ScenarioContext scenarioContext,
            Mock mock,
            IHttpApiClient apiClient,
            IDataFixtureReader dataFixtureReader, 
            MockConfiguration mockConfiguration)
        {
            _scenarioContext = scenarioContext;
            _mock = mock;
            _apiClient = apiClient;
            _dataFixtureReader = dataFixtureReader;
            _mockConfiguration = mockConfiguration;
        }

        [Given(@"I have a valid account with memos")]
        public void HaveAValidAccountWithMemos()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.ValidCardAccountId
                    : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var request = _dataFixtureReader.Read(
                @"FirstData\MemoInquiry\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );
            var response = _dataFixtureReader.Read(
                @"FirstData\MemoInquiry\200.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            _mock
                .GivenRequest(request)
                .WithRequiredParam("acctNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.MemoInquiry)
                .ThenReturnAsync(response)
                .Wait();
        }

        [When(@"I ask for an account list of memos")]
        public void WhenIAskForACardAccountMemos()
        {
            _scenarioContext.Set(CallGetMemosEndpoint(Config.CardAccount.CardAccountId), "response");
        }

        [Then(@"the result returns expected list of memos from ""(.*)""")]
        public void ThenTheResultReturnsExpectedCardAccountMemosFrom(string dataSource)
        {
            var expectedResponse = _dataFixtureReader.Read(
                @"CardAccount\GetMemos\response.json",
                new Dictionary<string, object> { { "accountHolderId", Config.CardAccount.CardAccountId } }
            );

            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("response");
            
            httpResponseMessage.StatusCode.Should().Match<HttpStatusCode>(p => p == HttpStatusCode.OK || p == HttpStatusCode.NonAuthoritativeInformation);

            if (TestContext.IsFirstData()) return;

            var actualResponse = httpResponseMessage.Content.ReadAsStringAsync().Result;
            actualResponse.Should().MatchJson(expectedResponse);
        }
        
        private HttpResponseMessage CallGetMemosEndpoint(string accountId)
        {
            var request = _dataFixtureReader.Read(
                @"CardAccount\GetMemos\request.json",
                new Dictionary<string, object> { { "cardAccountId", accountId } }
            );

            return _apiClient.Post(CardAccountEndpoints.GetMemos, request);
        }
    }
}
