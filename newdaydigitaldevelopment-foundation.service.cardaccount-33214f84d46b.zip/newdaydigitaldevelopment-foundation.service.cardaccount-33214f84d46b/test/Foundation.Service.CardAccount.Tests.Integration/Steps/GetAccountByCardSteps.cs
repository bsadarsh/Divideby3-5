﻿using System.Collections.Generic;
using System.Net.Http;
using FluentAssertions;
using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Extensions;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using Newtonsoft.Json.Linq;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    public class GetAccountByCardSteps
    {
        private readonly Mock _mock;
        private readonly IHttpApiClient _cardAccountClient;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly ScenarioContext _scenarioContext;
        private readonly MockConfiguration _mockConfiguration;

        public GetAccountByCardSteps(
            ScenarioContext scenarioContext,
            Mock mock,
            IHttpApiClient cardAccountClient,
            IDataFixtureReader dataFixtureReader,
            MockConfiguration mockConfiguration)
        {
            _scenarioContext = scenarioContext;
            _mock = mock;
            _cardAccountClient = cardAccountClient;
            _dataFixtureReader = dataFixtureReader;
            _mockConfiguration = mockConfiguration;
        }

        [Given(@"I have a valid account with card number details")]
        public void GivenIHaveAValidAccountWithCardNumberDetails()
        {
            Config.CardAccount.CardNumber =
                TestContext.IsFirstData() ?
                    _mockConfiguration.ValidCardNumber
                    : AccountNumberGenerator.Generate("547", "410");

            if (TestContext.IsFirstData()) return;

            var request = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\Request.json", new Dictionary<string, object>{{ "ACCOUNT_NUMBER", Config.CardAccount.CardNumber }}
                );
            var response = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\200_getAccountByCardNumber.json");

            _mock
               .GivenRequest(request)
               .WithRequiredParam("account")
               .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiryV3)
               .ThenReturnAsync(response)
               .Wait();
        }

        private string GetCardAccount(int flagValue)
        {
            return flagValue switch
            {
                0 => _mockConfiguration.ValidCardAccountIdNonInstantSpend0,
                1 => _mockConfiguration.ValidCardAccountIdInstantSpend,
                2 => _mockConfiguration.ValidCardAccountIdNonInstantSpend2,
                3 => _mockConfiguration.ValidCardAccountIdNonInstantSpend3,
                4 => _mockConfiguration.ValidCardAccountIdNonInstantSpend4,
                9 => _mockConfiguration.ValidCardAccountIdNonInstantSpend9,
                _ => throw new System.NotImplementedException(),
            };
        }

        [Given(@"request is received to retrieve customer’s account details (.*) and Set flag (.*)")]
        public void GivenRequestIsReceivedToRetrieveCustomerSAccountDetailsAndSetFlag(string Instantspend, int Flagvalue)
        {
            Config.CardAccount.CardNumber = GetCardAccount(Flagvalue);
            if (TestContext.IsFirstData()) return;
            var request = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\Request.json", new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber } }
                );
            var response = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\200_InstantSpend.json", new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber }, { "INSTANTSPEND", Flagvalue } });

            _mock
               .GivenRequest(request)
               .WithRequiredParam("account")
               .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiryV3)
               .ThenReturnAsync(response)
               .Wait();
        }

        [Given(@"a request is received to retrieve customer’s account details")]
        public void GivenARequestIsReceivedToRetrieveCustomerSAccountDetails()
        {
            Config.CardAccount.CardNumber =
                TestContext.IsFirstData() ?
                    _mockConfiguration.ValidCardNumber
                    : AccountNumberGenerator.Generate("547", "410");

            if (TestContext.IsFirstData()) return;

            var request = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\Request.json", new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber } }
                );
            var response = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\200_getAccountByCardNumber.json");

            _mock
               .GivenRequest(request)
               .WithRequiredParam("account")
               .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiryV3)
               .ThenReturnAsync(response)
               .Wait();
        }

        [Given(@"card account ids are stored in cache")]
        [Then(@"When I ask for a card number details again")]
        [When(@"I ask for a card number details")]
        public void WhenIAskForACardAccountNumber()
        {
            _scenarioContext.Set(CallGetAccountByCardEndpoint(), "response");
        }

        [When(@"I ask for a card number details (.*) and get flag (.*)")]
        public void WhenIAskForACardNumberDetailsAndGetFlag(string instantspend, int flag)
        {
          _scenarioContext.Set(CallGetCardAccountEndpoint(instantspend, flag), "response");
        }


        [Then(@"the result returns expected card account id from ""(.*)""")]
        public void ThenTheResultReturnsExpectedCardAccountIdFrom(string dataSource)
        {
            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("response");

            if (dataSource.Equals("First Data"))
            { 
                httpResponseMessage.StatusCode.ToString().Should().Be("OK");
            }
            else
            {
                httpResponseMessage.StatusCode.ToString().Should().Be("NonAuthoritativeInformation");
            }
            
            var expectedResponse = _dataFixtureReader.Read(
                @"CardAccount\GetAccountByCard\response.json");
            var actualResponse = httpResponseMessage.Content.ReadAsStringAsync().Result;

            actualResponse.Should().MatchJson(expectedResponse);
        }
    
        [When(@"I ask for a card account number with invalid account number")]
        public void WhenIAskForACardAccountNumberWithInvalidAccountNumber()
        {
            var response = _cardAccountClient.Post(CardAccountEndpoints.GetAccountByCard, "");
            _scenarioContext.Set(response, "response");
        }

        private HttpResponseMessage CallGetAccountByCardEndpoint()
        {
            var request = _dataFixtureReader.Read(
                @"CardAccount\GetAccountByCard\request.json",
                new Dictionary<string, object> { { "CARD_NUMBER", Config.CardAccount.CardNumber } }
            );

            return _cardAccountClient.Post(CardAccountEndpoints.GetAccountByCard, request);
        }

        private HttpResponseMessage CallGetCardAccountEndpoint(string Instantspend, int Flagvalue)
        {
            Config.CardAccount.CardNumber = GetCardAccount(Flagvalue);
            var request = _dataFixtureReader.Read(
                @"CardAccount\GetCardAccount\request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber } }
            );
            return _cardAccountClient.Post(CardAccountEndpoints.GetCardAccount, request);
        }

        [Then(@"I Verify Instantspend Flag is (.*)")]
        public void ThenIVerifyInstantspendFlagIs(string Instantspend)
        {
            var responseContent = _scenarioContext.Get<HttpResponseMessage>("response").Content.ReadAsStringAsync().Result;
            var jsonString = JObject.Parse(responseContent);
            var account = jsonString.GetValue("account") as JObject;
            account.GetValue("instantSpend").Value<bool>().Should().Equals(Instantspend);
        }

    }
}
