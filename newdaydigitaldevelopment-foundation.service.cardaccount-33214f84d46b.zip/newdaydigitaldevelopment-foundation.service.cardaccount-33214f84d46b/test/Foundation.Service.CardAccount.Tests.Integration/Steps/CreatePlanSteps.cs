﻿using FluentAssertions;
using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    public class CreatePlanSteps
    {
        private readonly Mock _mock;
        private readonly IHttpApiClient _cardAccountClient;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly ScenarioContext _scenarioContext;
        private readonly MockConfiguration _mockConfiguration;
        private string foundationRequest = null;

        public CreatePlanSteps(
            ScenarioContext scenarioContext,
            Mock mock,
            IHttpApiClient cardAccountClient,
            IDataFixtureReader dataFixtureReader,
            MockConfiguration mockConfiguration)
        {
            _scenarioContext = scenarioContext;
            _mock = mock;
            _cardAccountClient = cardAccountClient;
            _dataFixtureReader = dataFixtureReader;
            _mockConfiguration = mockConfiguration;
        }

        [Given(@"I have entered valid Accountnumber for create plan")]
        public void GivenIHaveEnteredValidAccountnumberForCreatePlan()
        {
           Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
            _mockConfiguration.CardAccountForUAT
                    : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var request = _dataFixtureReader.Read(
                @"FirstData\CreatePlan\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }                
            );

            var response = _dataFixtureReader.Read(
                @"FirstData\CreatePlan\200_Response.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            

            _mock
                .GivenRequest(request)
                .WithRequiredParam("acctNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.MonetaryAction)
                .ThenReturnAsync(response, 200)
                .Wait();

         }

        [When(@"I hit the create plan endpoint")]
        public void WhenIHitTheCreatePlanEndpoint()
        {
            foundationRequest = _dataFixtureReader.Read(@"CardAccount\CreatePlan\Request.json",
                 new Dictionary<string, object>
                 {
                        {"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId},
                 }
             );
            
            _scenarioContext.Set(_cardAccountClient.Post(CardAccountEndpoints.CreatePlan, foundationRequest), "response");

        }

        [Given(@"I have entered invalid Accountnumber for create plan")]
        public void GivenIHaveEnteredInvalidAccountnumberForCreatePlan()
        {
           Config.CardAccount.CardAccountId =
                     TestContext.IsFirstData() ?
                      _mockConfiguration.AccountNotFoundAccountId
                      : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var request = _dataFixtureReader.Read(
                @"FirstData\CreatePlan\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            var response = _dataFixtureReader.Read(
                @"FirstData\CreatePlan\465_Response.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );


            _mock
                .GivenRequest(request)
                .WithRequiredParam("acctNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.MonetaryAction)
                .ThenReturnAsync(response, 465)
                .Wait();
         
        }

        [Then(@"I verify the error status code ""(.*)"" in response")]
        public void ThenIVerifyTheErrorStatusCodeInResponse(HttpStatusCode statusCode)
        {
            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("response");
            httpResponseMessage.StatusCode.Should().Be(statusCode);
        }

    }
}
