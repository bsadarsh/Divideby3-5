﻿using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using System.Collections.Generic;
using System.Net.Http;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    class CreateInstallmentPlan
    {
        private readonly Mock _mock;
        private readonly IHttpApiClient _cardAccountClient;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly ScenarioContext _scenarioContext;
        private readonly MockConfiguration _mockConfiguration;
        private string _foundationRequest = string.Empty;

        public CreateInstallmentPlan(
            ScenarioContext scenarioContext,
            Mock mock,
            IHttpApiClient cardAccountClient,
            IDataFixtureReader dataFixtureReader,
            MockConfiguration mockConfiguration)
        {
            _scenarioContext = scenarioContext;
            _mock = mock;
            _cardAccountClient = cardAccountClient;
            _dataFixtureReader = dataFixtureReader;
            _mockConfiguration = mockConfiguration;
        }

        [Given(@"I have entered valid Accountnumber for createInstallmentplan")]
        public void GivenIHaveEnteredValidAccountnumberForCreateInstallmentplan()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.CardAccountForCreateInstallmentPlan
                    : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var mockRequest = _dataFixtureReader.Read(
                @"FirstData\CreateInstallmentPlan\Request_fppAdd.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } });
            var mockAccountRequest = _dataFixtureReader.Read(
                @"FirstData\CreateInstallmentPlan\Request_PlanList.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } });

            var response = _dataFixtureReader.Read(
                @"FirstData\CreateInstallmentPlan\Response_fppAdd.json"
            );

            var accountPlanresponse = _dataFixtureReader.Read(
                @"FirstData\CreateInstallmentPlan\Response_PlanList.json"
            );


            _mock
                .GivenRequest(mockRequest)
                .WithRequiredParam("acct")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.FppAdd)
                .ThenReturnAsync(response)
                .Wait();
            _mock
                .GivenRequest(mockAccountRequest)
                .WithRequiredParam("acct")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountPlanList)
                .ThenReturnAsync(accountPlanresponse)
                .Wait();
        }

        [When(@"I hit the createInstallmentplan endpoint")]
        public void WhenIHitTheCreateInstallmentplanEndpoint()
        {
            _foundationRequest = _dataFixtureReader.Read(@"CardAccount\CreateInstallmentPlan\Request.json",
                new Dictionary<string, object>
                {
                    {"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId},
                }
            );

            _scenarioContext.Set(_cardAccountClient.Post(CardAccountEndpoints.createInstallmentPlan, _foundationRequest), "response");
        }

        [When(@"I hit the createInstallmentplan endpoint with invalid request")]
        public void WhenIHitTheCreateInstallmentplanEndpointWithInvalidRequest()
        {
            _foundationRequest = _dataFixtureReader.Read(@"CardAccount\CreateInstallmentPlan\InvalidRequest.json",
                new Dictionary<string, object>
                {
                    {"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId},
                }
            );

            _scenarioContext.Set(_cardAccountClient.Post(CardAccountEndpoints.createInstallmentPlan, _foundationRequest), "response");
        }

        [When(@"I hit the createInstallmentplan endpoint with invalid source plan")]
        public void WhenIHitTheCreateInstallmentplanEndpointWithInvalidSourcePlan()
        {
            _foundationRequest = _dataFixtureReader.Read(@"CardAccount\CreateInstallmentPlan\Invalid_Source.json",
                new Dictionary<string, object>
                {
                    {"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId},
                }
            );

            _scenarioContext.Set(_cardAccountClient.Post(CardAccountEndpoints.createInstallmentPlan, _foundationRequest), "response");
        }

        [When(@"I hit the createInstallmentplan endpoint with amount higher")]
        public void WhenIHitTheCreateInstallmentplanEndpointWithAmountHigher()
        {
            _foundationRequest = _dataFixtureReader.Read(@"CardAccount\CreateInstallmentPlan\Request_HigherAmount.json",
                new Dictionary<string, object>
                {
                    {"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId},
                }
            );

            _scenarioContext.Set(_cardAccountClient.Post(CardAccountEndpoints.createInstallmentPlan, _foundationRequest), "response");
        }

        [Given(@"I have entered the createInstallmentplan details with previous cardAccountId")]
        public void GivenIHaveEnteredTheCreateInstallmentplanDetailsWithPreviousCardAccountId()
        {
            if (TestContext.IsFirstData()) return;

            var mockRequest = _dataFixtureReader.Read(
                @"FirstData\CreateInstallmentPlan\Request_fppAdd.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } });
            var mockAccountRequest = _dataFixtureReader.Read(
                @"FirstData\CreateInstallmentPlan\Request_PlanList.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } });

            var response = _dataFixtureReader.Read(
                @"FirstData\CreateInstallmentPlan\Response_fppAdd.json"
            );

            var accountPlanresponse = _dataFixtureReader.Read(
                @"FirstData\CreateInstallmentPlan\Response_PlanList.json"
            );


            _mock
                .GivenRequest(mockRequest)
                .WithRequiredParam("acct")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.FppAdd)
                .ThenReturnAsync(response)
                .Wait();
            _mock
                .GivenRequest(mockAccountRequest)
                .WithRequiredParam("acct")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountPlanList)
                .ThenReturnAsync(accountPlanresponse)
                .Wait();

        }

    }
}
