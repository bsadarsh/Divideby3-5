﻿using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using FluentAssertions;
using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    public sealed class CreateMemoSteps
    {
        private readonly Mock _mock;
        private readonly IHttpApiClient _apiClient;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly ScenarioContext _scenarioContext;
        private readonly MockConfiguration _mockConfiguration;

        public CreateMemoSteps(
            ScenarioContext scenarioContext,
            Mock mock,
            IHttpApiClient apiClient,
            IDataFixtureReader dataFixtureReader, 
            MockConfiguration mockConfiguration)
        {
            _scenarioContext = scenarioContext;
            _mock = mock;
            _apiClient = apiClient;
            _dataFixtureReader = dataFixtureReader;
            _mockConfiguration = mockConfiguration;
        }

        [Given(@"I have a valid account")]
        public async Task HaveAValidAccountWithMemos()
        {
            Config.CardAccount.CardAccountId = 
                TestContext.IsFirstData() ? 
                    _mockConfiguration.ValidCardAccountId
                : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData())
                return;

            await _mock
                .GivenRequest(_dataFixtureReader.Read(
                    @"FirstData\MemoAdd\Request.json", new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId }}
                ))
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AddAMemo)
                .ThenReturnAsync(_dataFixtureReader.Read( @"FirstData\MemoAdd\Response.json"));
          
        }

        [When(@"I submit new memo details it creates a record")]
        public void WhenIAskForACardAccountMemos()
        {
            _scenarioContext.Set(CallCreateMemosEndpoint(), "response");
        }

        [Then(@"I receive an OK status")]
        public void ThenTheResultReturnsExpectedCardAccountMemosFrom()
        {
            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("response");

            httpResponseMessage.StatusCode.Should().Be(HttpStatusCode.OK);
        }

        private HttpResponseMessage CallCreateMemosEndpoint()
        {
            var request = _dataFixtureReader.Read(
                @"CardAccount\CreateMemo\request.json",
                new Dictionary<string, object> { { "cardAccountId", Config.CardAccount.CardAccountId } }
            );

            return _apiClient.Post(CardAccountEndpoints.CreateMemo, request);
        }
    }
}
