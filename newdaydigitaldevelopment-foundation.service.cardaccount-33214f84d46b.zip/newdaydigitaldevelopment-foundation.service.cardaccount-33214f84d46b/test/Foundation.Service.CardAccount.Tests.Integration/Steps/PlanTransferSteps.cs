﻿using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using System;
using System.Collections.Generic;
using System.Net.Http;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    public class PlanTransferSteps
    {
        private readonly Mock _mock;
        private readonly IHttpApiClient _cardAccountClient;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly ScenarioContext _scenarioContext;
        private readonly MockConfiguration _mockConfiguration;
        private string foundationRequest = null;

        public PlanTransferSteps(
            ScenarioContext scenarioContext,
            Mock mock,
            IHttpApiClient cardAccountClient,
            IDataFixtureReader dataFixtureReader,
            MockConfiguration mockConfiguration)
        {
            _scenarioContext = scenarioContext;
            _mock = mock;
            _cardAccountClient = cardAccountClient;
            _dataFixtureReader = dataFixtureReader;
            _mockConfiguration = mockConfiguration;
        }

        [Given(@"I have entered valid Accountnumber for plan transfer")]
        public void GivenIHaveEnteredValidAccountnumberForPlanTransfer()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
            _mockConfiguration.CardAccountForUATReAgeByCode
                    : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var requestPlanTransfer = _dataFixtureReader.Read(@"FirstData\PlanTransfer\Request.json",
                new Dictionary<string, object> 
                { 
                    { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId },
                    { "FROM_PLAN_NBR", "12341" },
                    { "FROM_REC_NBR", "1" },
                    { "TO_PLAN_NBR", "12343" },
                    { "TO_REC_NBR", "3" }
                });
          
            var responsePlanTransfer = _dataFixtureReader.Read(@"FirstData\PlanTransfer\Response.json",
                new Dictionary<string, object>
                {
                    { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId },
                    { "TO_PLAN_NBR", "12343" },
                    { "TO_REC_NBR", "3" },
                });

            var requestAccountPlanList = _dataFixtureReader.Read(@"FirstData\AccountPlanList\Request.json",
                new Dictionary<string, object>
                {
                    { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId }
                });

            var responseAccountPlanList = _dataFixtureReader.Read(@"FirstData\AccountPlanList\Response.json",
                new Dictionary<string, object>
                {
                    { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId },
                    { "PLAN_NBR_1", "12341" },
                    { "PLAN_NBR_2", "12342" },
                    { "PLAN_NBR_3", "12343" },
                    { "PLAN_NBR_4", "12344" },
                    { "PLAN_NBR_5", "12345" }
                });


            _mock
                .GivenRequest(requestPlanTransfer)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.PlanTransfer)
                .ThenReturnAsync(responsePlanTransfer, 200)
                .Wait();

            _mock
                .GivenRequest(requestAccountPlanList)
                .WithRequiredParam("acct")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountPlanList)
                .ThenReturnAsync(responseAccountPlanList, 200)
                .Wait();
        }
        
        [When(@"I hit the plan transfer endpoint")]
        public void WhenIHitThePlanTransferEndpoint()
        {
            foundationRequest = _dataFixtureReader.Read(@"CardAccount\PlanTransfer\Request.json",
                 new Dictionary<string, object>
                 {
                        {"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId},
                        {"FROM_PLAN_NBR", "12341"},
                        {"FROM_REC_NBR", "1"},
                        {"TO_PLAN_NBR", "12343"},
                        {"TO_REC_NBR", "3"}
                 });

            _scenarioContext.Set(_cardAccountClient.Post(CardAccountEndpoints.PlanTransfer, foundationRequest), "response");
        }
        
        [When(@"I hit the plan transfer endpoint without record number")]
        public void WhenIHitThePlanTransferEndpointWithoutRecordNumber()
        {
            foundationRequest = _dataFixtureReader.Read(@"CardAccount\PlanTransfer\Request_WithoutRecordNumber.json",
                new Dictionary<string, object>
                {
                        {"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId},
                        {"FROM_PLAN_NBR", "12341"},
                        {"TO_PLAN_NBR", "12343"}
                });

            _scenarioContext.Set(_cardAccountClient.Post(CardAccountEndpoints.PlanTransfer, foundationRequest), "response");
        }

        [When(@"I hit the plan transfer endpoint with invalid plan number")]
        public void WhenIHitThePlanTransferEndpointWithInvalidPlanNumber()
        {
            foundationRequest = _dataFixtureReader.Read(@"CardAccount\PlanTransfer\Request_WithoutRecordNumber.json",
                new Dictionary<string, object>
                {
                        {"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId},
                        {"FROM_PLAN_NBR", "12341"},
                        {"TO_PLAN_NBR", "00000"}
                });

            _scenarioContext.Set(_cardAccountClient.Post(CardAccountEndpoints.PlanTransfer, foundationRequest), "response");
        }

        [Given(@"I have entered the planTransfer details with previous cardAccountId")]
        public void GivenIHaveEnteredThePlanTransferDetailsWithPreviousCardAccountId()
        {
            if (TestContext.IsFirstData()) return;

            var requestPlanTransfer = _dataFixtureReader.Read(@"FirstData\PlanTransfer\Request.json",
                new Dictionary<string, object>
                {
                    { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId },
                    { "FROM_PLAN_NBR", "12341" },
                    { "FROM_REC_NBR", "1" },
                    { "TO_PLAN_NBR", "12343" },
                    { "TO_REC_NBR", "3" }
                });

            var responsePlanTransfer = _dataFixtureReader.Read(@"FirstData\PlanTransfer\Response.json",
                new Dictionary<string, object>
                {
                    { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId },
                    { "TO_PLAN_NBR", "12343" },
                    { "TO_REC_NBR", "3" },
                });

            var requestAccountPlanList = _dataFixtureReader.Read(@"FirstData\AccountPlanList\Request.json",
                new Dictionary<string, object>
                {
                    { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId }
                });

            var responseAccountPlanList = _dataFixtureReader.Read(@"FirstData\AccountPlanList\Response.json",
                new Dictionary<string, object>
                {
                    { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId },
                    { "PLAN_NBR_1", "12341" },
                    { "PLAN_NBR_2", "12342" },
                    { "PLAN_NBR_3", "12343" },
                    { "PLAN_NBR_4", "12344" },
                    { "PLAN_NBR_5", "12345" }
                });


            _mock
                .GivenRequest(requestPlanTransfer)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.PlanTransfer)
                .ThenReturnAsync(responsePlanTransfer, 200)
                .Wait();

            _mock
                .GivenRequest(requestAccountPlanList)
                .WithRequiredParam("acct")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountPlanList)
                .ThenReturnAsync(responseAccountPlanList, 200)
                .Wait();

        }

    }
}
