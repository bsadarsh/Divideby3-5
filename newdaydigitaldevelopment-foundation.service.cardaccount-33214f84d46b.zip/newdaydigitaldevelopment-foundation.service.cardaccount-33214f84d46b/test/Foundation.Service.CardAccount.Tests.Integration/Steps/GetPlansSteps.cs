﻿using FluentAssertions;
using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    public class GetPlansSteps
    {
        private readonly Mock _mock;
        private readonly IHttpApiClient _cardAccountClient;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly ScenarioContext _scenarioContext;
        private readonly MockConfiguration _mockConfiguration;
        private string foundationRequest = null;

        public GetPlansSteps(
            ScenarioContext scenarioContext,
            Mock mock,
            IHttpApiClient cardAccountClient,
            IDataFixtureReader dataFixtureReader,
            MockConfiguration mockConfiguration)
        {
            _scenarioContext = scenarioContext;
            _mock = mock;
            _cardAccountClient = cardAccountClient;
            _dataFixtureReader = dataFixtureReader;
            _mockConfiguration = mockConfiguration;
        }

        [Given(@"I have entered valid Accountnumber")]
        public void GivenIHaveEnteredValidAccountnumber()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
            _mockConfiguration.CardAccountForUAT
                    : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var request = _dataFixtureReader.Read(
                @"FirstData\GetPlans\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            var response = _dataFixtureReader.Read(
                @"FirstData\GetPlans\200.json"
            );

            
            _mock
                .GivenRequest(request)
                .WithRequiredParam("acct")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.GetPlans)
                .ThenReturnAsync(response, 200)
                .Wait();
        }
        [When(@"I hit the get plan endpoint")]
        public void WhenIHitTheGetPlanEndpoint()
        {
            foundationRequest = _dataFixtureReader.Read(@"CardAccount\GetPlans\Request.json",
                 new Dictionary<string, object>
                 {
                        {"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId},
                 }
             );

            _scenarioContext.Set(_cardAccountClient.Post(CardAccountEndpoints.GetPlans, foundationRequest), "response");

        }
        [Then(@"I verify the successfull response with status (.*)")]
        public void ThenIVerifyTheSuccessfullResponseWithStatus(HttpStatusCode expectedStatusCode)
        {            
            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("response");
            (httpResponseMessage.StatusCode == HttpStatusCode.OK || httpResponseMessage.StatusCode == HttpStatusCode.NonAuthoritativeInformation).Should().Be(true);        
        
        }

        [Then(@"I verify a successfull response with status (.*)")]
        public void ThenIVerifyASuccessfullResponseWithStatusBadRequest(HttpStatusCode expectedStatusCode)
        {
            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("response");
        }


        [Given(@"I have entered invalid Accountnumber")]
        public void GivenIHaveEnteredInvalidAccountnumber()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.AccountNotFoundAccountId
                    : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var request = _dataFixtureReader.Read(
                @"FirstData\GetPlans\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            var response = _dataFixtureReader.Read(
                @"FirstData\GetPlans\465.json"
            );


            _mock
                .GivenRequest(request)
                .WithRequiredParam("acct")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.GetPlans)
                .ThenReturnAsync(response, 465)
                .Wait();

        }

        [Then(@"I received a ""(.*)"" error")]
        public void ThenIReceivedAError(HttpStatusCode statusCode)
        {
            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("response");
            httpResponseMessage.StatusCode.Should().Be(statusCode);
        }

        [Given(@"I have entered valid Accountnumber for GetPlan and ""(.*)"" details")]
        public void GivenIHaveEnteredValidAccountnumberForGetPlanAndDetails(string endpointName)
        {
            if (endpointName.Equals("CreateInstallment"))
            {
                Config.CardAccount.CardAccountId =
                   TestContext.IsFirstData() ?
               _mockConfiguration.CardAccountForCreateInstallmentPlan
                       : AccountNumberGenerator.Generate();
            }
            else
            {
                Config.CardAccount.CardAccountId =
                    TestContext.IsFirstData() ?
                _mockConfiguration.CardAccountForUATReAgeByAmount
                        : AccountNumberGenerator.Generate();
            }

            if (TestContext.IsFirstData()) return;

            var request = _dataFixtureReader.Read(
                @"FirstData\GetPlans\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            var response = _dataFixtureReader.Read(
                @"FirstData\GetPlans\200.json"
            );


            _mock
                .GivenRequest(request)
                .WithRequiredParam("acct")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.GetPlans)
                .ThenReturnAsync(response, 200)
                .Wait();
        }

    }


}