﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using FluentAssertions;
using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using Newtonsoft.Json.Linq;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    public class SetSpendCapSteps
    {
        private readonly ScenarioContext _scenarioContext;
        private readonly Mock _mock;
        private readonly IHttpApiClient _apiClient;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly MockConfiguration _mockConfiguration;

        public SetSpendCapSteps(
            IHttpApiClient apiClient,
            ScenarioContext scenarioContext,
            Mock mock,
            IDataFixtureReader dataFixtureReader,
            MockConfiguration mockConfiguration
        )
        {
            _apiClient = apiClient;
            _scenarioContext = scenarioContext;
            _mock = mock;
            _dataFixtureReader = dataFixtureReader;
            _mockConfiguration = mockConfiguration;
        }

        [Given(@"I have the request payload with (.*) as (.*)")]
        public void GivenIHaveTheRequestPayloadWithAs(string p0, string p1)
        {

            Config.CardAccount.CardNumber =
                TestContext.IsFirstData() ?
                    _mockConfiguration.ValidUATSoftCardAccountId
                    : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var mockRequest = _dataFixtureReader.Read(
                @"FirstData\AccountCustomFieldsUpdateAsync\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", "000"+Config.CardAccount.CardNumber } });
            var mockAccountRequest = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV2\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber } }
            );
            var mockAccountResponse = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV2\200_SetSpendCap.json",
                new Dictionary<string, object>
                {
                    { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber },
                    { "CREDIT_LIMIT", "250000" }
                });
            object mockResponse = "{}";

            string foundationRequest = null;
            if (_scenarioContext.ScenarioInfo.Title.Contains("BadRequest") || _scenarioContext.ScenarioInfo.Title.Contains("warning cap"))
            {
                switch (p0)
                {
                    case "CAP_TYPE":
                        foundationRequest = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\setSpendCap_request.json",
                            new Dictionary<string, object>
                            {
                                {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber}, {"CAP_TYPE", p1}, {"ENABLE_CAP", "true"},
                                {"ALERT_TYPE", "Sms"}, {"CAP_AMOUNT", "83.69"}
                            }
                        );
                        break;
                    case "ENABLE_CAP":
                        foundationRequest = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\setSpendCap_request.json",
                            new Dictionary<string, object>
                            {
                                {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber}, {"CAP_TYPE", "Soft"}, {"ENABLE_CAP", p1},
                                {"ALERT_TYPE", "Sms"}, {"CAP_AMOUNT", "83.69"}
                            }
                        );
                        break;
                    case "ALERT_TYPE":
                        foundationRequest = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\setSpendCap_request.json",
                            new Dictionary<string, object>
                            {
                                {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber}, {"CAP_TYPE", "Soft"},
                                {"ENABLE_CAP", "true"}, {"ALERT_TYPE", p1}, {"CAP_AMOUNT", "83.69"}
                            }
                        );
                        break;
                    case "CAP_AMOUNT":
                        foundationRequest = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\setSpendCap_request.json",
                            new Dictionary<string, object>
                            {
                                {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber}, {"CAP_TYPE", "Soft"},
                                {"ENABLE_CAP", "true"}, {"ALERT_TYPE", "Sms"}, {"CAP_AMOUNT", p1}
                            }
                        );
                        break;
                }
            }
            else
            {
                foundationRequest = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\request_Soft.json",
                    new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber }, { "CAP_TYPE", p1 } }
                );
            }
            _scenarioContext.Set(foundationRequest, "FoundationRequest");
            _mock
                .GivenRequest(mockRequest)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountCustomFieldsUpdate)
                .ThenReturnAsync(mockResponse)
                .Wait();
            _mock
                .GivenRequest(mockAccountRequest)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiryV3)
                .ThenReturnAsync(mockAccountResponse)
                .Wait();
        }

        [Given(@"I have the request payload decimal with (.*) as (.*)")]
        public void GivenIHaveTheRequestPayloadDecimalWithCAP_TYPEAsSoft(string p0, string p1)
        {
            Config.CardAccount.CardNumber =
                 TestContext.IsFirstData() ?
                     _mockConfiguration.ValidUATSoftCardAccountId
                     : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var mockRequest = _dataFixtureReader.Read(
                @"FirstData\AccountCustomFieldsUpdateAsync\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", "000" + Config.CardAccount.CardNumber } });
            var mockAccountRequest = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV2\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber } }
            );
            var mockAccountResponse = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV2\200_SetSpendCap.json",
                new Dictionary<string, object>
                {
                    { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber },
                    { "CREDIT_LIMIT", "250000" }
                });
            object mockResponse = "{}";

            string foundationRequest = null;
            if (_scenarioContext.ScenarioInfo.Title.Contains("BadRequest") || _scenarioContext.ScenarioInfo.Title.Contains("warning cap"))
            {
                switch (p0)
                {
                    case "CAP_TYPE":
                        foundationRequest = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\setSpendCap_request.json",
                            new Dictionary<string, object>
                            {
                                {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber}, {"CAP_TYPE", p1}, {"ENABLE_CAP", "true"},
                                {"ALERT_TYPE", "Sms"}, {"CAP_AMOUNT", "83.69"}
                            }
                        );
                        break;
                    case "ENABLE_CAP":
                        foundationRequest = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\setSpendCap_request.json",
                            new Dictionary<string, object>
                            {
                                {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber}, {"CAP_TYPE", "Soft"}, {"ENABLE_CAP", p1},
                                {"ALERT_TYPE", "Sms"}, {"CAP_AMOUNT", "83.69"}
                            }
                        );
                        break;
                    case "ALERT_TYPE":
                        foundationRequest = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\setSpendCap_request.json",
                            new Dictionary<string, object>
                            {
                                {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber}, {"CAP_TYPE", "Soft"},
                                {"ENABLE_CAP", "true"}, {"ALERT_TYPE", p1}, {"CAP_AMOUNT", "83.69"}
                            }
                        );
                        break;
                    case "CAP_AMOUNT":
                        foundationRequest = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\request_CapAmountDecimal.json",
                            new Dictionary<string, object>
                            {
                                {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber}, {"CAP_TYPE", "Soft"},
                                {"ENABLE_CAP", "true"}, {"ALERT_TYPE", "Sms"}, {"CAP_AMOUNT", p1}
                            }
                        );
                        break;
                }
            }
            else
            {
                foundationRequest = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\request_CapAmountDecimal.json",
                    new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber }, { "CAP_TYPE", p1 } }
                );
            }
            _scenarioContext.Set(foundationRequest, "FoundationRequest");
            _mock
                .GivenRequest(mockRequest)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountCustomFieldsUpdate)
                .ThenReturnAsync(mockResponse)
                .Wait();
            _mock
                .GivenRequest(mockAccountRequest)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiryV3)
                .ThenReturnAsync(mockAccountResponse)
                .Wait();
        }


        [Given(@"I have request payload with (.*) as (.*)")]
        public void GivenIHaveRequestPayloadWithCAP_TYPEAsHard(string p0, string p1)
        {
            Config.CardAccount.CardNumber =
                  TestContext.IsFirstData() ?
                      _mockConfiguration.ValidUATHardCardAccountId
                      : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var mockRequest = _dataFixtureReader.Read(
                @"FirstData\AccountCustomFieldsUpdateAsync\Request_Hard.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", "000" + Config.CardAccount.CardNumber } });
            var mockAccountRequest = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV2\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber } }
            );
            var mockAccountResponse = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV2\200_SetSpendCap.json",
                new Dictionary<string, object>
                {
                    { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber },
                    { "CREDIT_LIMIT", "250000" }
                });
            object mockResponse = "{}";

            string foundationRequest = null;
            if (_scenarioContext.ScenarioInfo.Title.Contains("BadRequest") || _scenarioContext.ScenarioInfo.Title.Contains("warning cap"))
            {
                switch (p0)
                {
                    case "CAP_TYPE":
                        foundationRequest = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\setSpendCap_request.json",
                            new Dictionary<string, object>
                            {
                                {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber}, {"CAP_TYPE", p1}, {"ENABLE_CAP", "true"},
                                {"ALERT_TYPE", "Sms"}, {"CAP_AMOUNT", "83.69"}
                            }
                        );
                        break;
                    case "ENABLE_CAP":
                        foundationRequest = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\setSpendCap_request.json",
                            new Dictionary<string, object>
                            {
                                {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber}, {"CAP_TYPE", "Hard"}, {"ENABLE_CAP", p1},
                                {"ALERT_TYPE", "Sms"}, {"CAP_AMOUNT", "83.69"}
                            }
                        );
                        break;
                    case "ALERT_TYPE":
                        foundationRequest = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\setSpendCap_request.json",
                            new Dictionary<string, object>
                            {
                                {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber}, {"CAP_TYPE", "Hard"},
                                {"ENABLE_CAP", "true"}, {"ALERT_TYPE", p1}, {"CAP_AMOUNT", "83.69"}
                            }
                        );
                        break;
                    case "CAP_AMOUNT":
                        foundationRequest = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\setSpendCap_request.json",
                            new Dictionary<string, object>
                            {
                                {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber}, {"CAP_TYPE", "Hard"},
                                {"ENABLE_CAP", "true"}, {"ALERT_TYPE", "Sms"}, {"CAP_AMOUNT", p1}
                            }
                        );
                        break;
                }
            }
            else
            {
                foundationRequest = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\request_Soft.json",
                    new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber }, { "CAP_TYPE", p1 } }
                );
            }
            _scenarioContext.Set(foundationRequest, "FoundationRequest");
            _mock
                .GivenRequest(mockRequest)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountCustomFieldsUpdate)
                .ThenReturnAsync(mockResponse)
                .Wait();
            _mock
                .GivenRequest(mockAccountRequest)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiryV3)
                .ThenReturnAsync(mockAccountResponse)
                .Wait();
        }

        [Given(@"I have request payloads with (.*) as (.*)")]
        public void GivenIHaveRequestPayloadsWithCAP_TYPEAsNone(string p0, string p1)
        {
            Config.CardAccount.CardNumber =
                   TestContext.IsFirstData() ?
                       _mockConfiguration.ValidCardAccountId
                       : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var mockRequest = _dataFixtureReader.Read(
                @"FirstData\AccountCustomFieldsUpdateAsync\Request_NoCap.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", "000" + Config.CardAccount.CardNumber } });
            var mockAccountRequest = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV2\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber } }
            );
            var mockAccountResponse = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV2\200_SetNoSpendCap.json",
                new Dictionary<string, object>
                {
                    { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber },
                    { "CREDIT_LIMIT", "250000" }
                });
            object mockResponse = "{}";

            string foundationRequest = null;
            if (_scenarioContext.ScenarioInfo.Title.Contains("BadRequest") || _scenarioContext.ScenarioInfo.Title.Contains("warning cap"))
            {
                switch (p0)
                {
                    case "CAP_TYPE":
                        foundationRequest = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\setSpendCap_request.json",
                            new Dictionary<string, object>
                            {
                                {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber}, {"CAP_TYPE", p1}, {"ENABLE_CAP", "true"},
                                {"ALERT_TYPE", "Sms"}, {"CAP_AMOUNT", "83.69"}
                            }
                        );
                        break;
                    case "ENABLE_CAP":
                        foundationRequest = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\setSpendCap_request.json",
                            new Dictionary<string, object>
                            {
                                {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber}, {"CAP_TYPE", "None"}, {"ENABLE_CAP", p1},
                                {"ALERT_TYPE", "Sms"}, {"CAP_AMOUNT", "83.69"}
                            }
                        );
                        break;
                    case "ALERT_TYPE":
                        foundationRequest = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\setSpendCap_request.json",
                            new Dictionary<string, object>
                            {
                                {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber}, {"CAP_TYPE", "None"},
                                {"ENABLE_CAP", "true"}, {"ALERT_TYPE", p1}, {"CAP_AMOUNT", "83.69"}
                            }
                        );
                        break;
                    case "CAP_AMOUNT":
                        foundationRequest = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\setSpendCap_request.json",
                            new Dictionary<string, object>
                            {
                                {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber}, {"CAP_TYPE", "None"},
                                {"ENABLE_CAP", "true"}, {"ALERT_TYPE", "Sms"}, {"CAP_AMOUNT", p1}
                            }
                        );
                        break;
                }
            }
            else
            {
                foundationRequest = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\request _NoCap.json",
                    new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber }, { "CAP_TYPE", p1 } }
                );
            }
            _scenarioContext.Set(foundationRequest, "FoundationRequest");
            _mock
                .GivenRequest(mockRequest)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountCustomFieldsUpdate)
                .ThenReturnAsync(mockResponse)
                .Wait();
            _mock
                .GivenRequest(mockAccountRequest)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiryV3)
                .ThenReturnAsync(mockAccountResponse)
                .Wait();
        }

        [When(@"I request the SetSpendCap service to set a spend cap for (.*)")]
        public void WhenIRequestTheSetSpendCapServiceToSetASpendCapFor(string p0)
        {
            if (p0.Equals("first time"))
            {
                _scenarioContext.Set(SetSpendCapEndpoint(p0), "InitSetSpendCapResponse");
            }
            else if (p0.Equals("second time"))
            {
                _scenarioContext.Set(SetSpendCapEndpoint(p0), "Re-SetSpendCapResponse");
            }
            else { _scenarioContext.Set(SetSpendCapEndpoint(p0), "SetSpendCapResponse"); }
        }

        [When(@"I request the SetSpendCap service to set a decimal value for (.*)")]
        public void WhenIRequestTheSetSpendCapServiceToSetADecimalValueFor(string p0)
        {
            if (p0.Equals("first time"))
            {
                _scenarioContext.Set(SetSpendCapEndpoint(p0), "InitSetSpendCapResponse");
            }
            else if (p0.Equals("second time"))
            {
                _scenarioContext.Set(SetSpendCapEndpoint(p0), "Re-SetSpendCapResponse");
            }
            else { _scenarioContext.Set(SetSpendCapEndpointAsDecimal(p0), "SetSpendCapResponse"); }
        }


        [When(@"I request the SetSpendCap service to set a Hard spend cap for (.*)")]
        public void WhenIRequestTheSetSpendCapServiceToSetAHardSpendCapForValidAccount(string p0)
        {
            if (p0.Equals("first time"))
            {
                _scenarioContext.Set(SetSpendCapEndpoint(p0), "InitSetSpendCapResponse");
            }
            else if (p0.Equals("second time"))
            {
                _scenarioContext.Set(SetSpendCapEndpoint(p0), "Re-SetSpendCapResponse");
            }
            else
            {
                _scenarioContext.Set(SetSpendCapEndpointUpdated(p0), "SetSpendCapResponse");
            }
        }

        [When(@"I request the SetSpendCap service to set a No spend cap for (.*)")]
        public void WhenIRequestTheSetSpendCapServiceToSetANoSpendCapForValidAccount(string p0)
        {
            if (p0.Equals("first time"))
            {
                _scenarioContext.Set(SetSpendCapEndpoint(p0), "InitSetSpendCapResponse");
            }
            else if (p0.Equals("second time"))
            {
                _scenarioContext.Set(SetSpendCapEndpoint(p0), "Re-SetSpendCapResponse");
            }
            else
            {
                _scenarioContext.Set(SetSpendCapEndpointNoCap(p0), "SetSpendCapResponse");
            }
        }

        private HttpResponseMessage SetSpendCapEndpointNoCap(string p0)
        {
            string requestBody;
            if (TestContext.IsFirstData())
            {
                if (p0.Equals("first time"))
                {
                    requestBody = _scenarioContext.Get<string>("FoundationRequest");
                }
                else if (p0.Equals("second time"))
                {
                    requestBody = _scenarioContext.Get<string>("updatedFoundationRequest");
                }
                else
                {
                    requestBody = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\request _NoCap.json",
                        new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber }, { "CAP_TYPE", "None" } });
                }
            }
            else
            {
                if (p0.Equals("first time"))
                {
                    requestBody = _scenarioContext.Get<string>("FoundationRequest");
                }
                else if (p0.Equals("second time"))
                {
                    requestBody = _scenarioContext.Get<string>("updatedFoundationRequest");
                }
                else
                {
                    requestBody = _scenarioContext.Get<string>("FoundationRequest");
                }
            }
            var response = _apiClient.Post(CardAccountEndpoints.SetSpendCap, requestBody);
            return response;
        }

        private HttpResponseMessage SetSpendCapEndpointUpdated(string p0)
        {
            string requestBody;
            if (TestContext.IsFirstData())
            {
                if (p0.Equals("first time"))
                {
                    requestBody = _scenarioContext.Get<string>("FoundationRequest");
                }
                else if (p0.Equals("second time"))
                {
                    requestBody = _scenarioContext.Get<string>("updatedFoundationRequest");
                }
                else
                {
                    requestBody = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\request_Soft.json",
                        new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber }, { "CAP_TYPE", "Hard" } });
                }
            }
            else
            {
                if (p0.Equals("first time"))
                {
                    requestBody = _scenarioContext.Get<string>("FoundationRequest");
                }
                else if (p0.Equals("second time"))
                {
                    requestBody = _scenarioContext.Get<string>("updatedFoundationRequest");
                }
                else
                {
                    requestBody = _scenarioContext.Get<string>("FoundationRequest");
                }
            }
            var response = _apiClient.Post(CardAccountEndpoints.SetSpendCap, requestBody);
            return response;
        }

        [Then(@"I verify the Response status as (.*)")]
        public void ThenIVerifyTheResponseStatusAs(string p0)
        {
            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("SetSpendCapResponse");
            httpResponseMessage.StatusCode.Should().Match<HttpStatusCode>(p => p == HttpStatusCode.OK || p == HttpStatusCode.NonAuthoritativeInformation);
        }

        [Then(@"I verify the response sucessfully ""(.*)""")]
        public void ThenIVerifyTheResponseSucessfully(HttpStatusCode expectedStatusCode)
        {
            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("SetSpendCapResponse");
            httpResponseMessage.StatusCode.Should().Be(expectedStatusCode);
        }
        private HttpResponseMessage SetSpendCapEndpoint(string p0)
        {
            string requestBody;
            if (TestContext.IsFirstData())
            {
                if (p0.Equals("first time"))
                {
                    requestBody = _scenarioContext.Get<string>("FoundationRequest");
                }
                else if (p0.Equals("second time"))
                {
                    requestBody = _scenarioContext.Get<string>("updatedFoundationRequest");
                }
                else
                {
                    requestBody = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\request_Soft.json",
                        new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber }, { "CAP_TYPE", "Soft" } });
                }
            }
            else
            {
                if (p0.Equals("first time"))
                {
                    requestBody = _scenarioContext.Get<string>("FoundationRequest");
                }
                else if (p0.Equals("second time"))
                {
                    requestBody = _scenarioContext.Get<string>("updatedFoundationRequest");
                }
                else
                {
                    requestBody = _scenarioContext.Get<string>("FoundationRequest");
                }
            }
            var response = _apiClient.Post(CardAccountEndpoints.SetSpendCap, requestBody);
            return response;
        }

        private HttpResponseMessage SetSpendCapEndpointAsDecimal(string p0)
        {
            string requestBody;
            if (TestContext.IsFirstData())
            {
                if (p0.Equals("first time"))
                {
                    requestBody = _scenarioContext.Get<string>("FoundationRequest");
                }
                else if (p0.Equals("second time"))
                {
                    requestBody = _scenarioContext.Get<string>("updatedFoundationRequest");
                }
                else
                {
                    requestBody = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\request_CapAmountDecimal.json",
                        new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber }, { "CAP_TYPE", "Soft" } });
                }
            }
            else
            {
                if (p0.Equals("first time"))
                {
                    requestBody = _scenarioContext.Get<string>("FoundationRequest");
                }
                else if (p0.Equals("second time"))
                {
                    requestBody = _scenarioContext.Get<string>("updatedFoundationRequest");
                }
                else
                {
                    requestBody = _scenarioContext.Get<string>("FoundationRequest");
                }
            }
            var response = _apiClient.Post(CardAccountEndpoints.SetSpendCap, requestBody);
            return response;
        }

        [Then(@"I verify the error Response status as (.*)")]
        public void ThenIVerifyTheErrorResponseStatusAsBadRequest(string memberNames)
        {
            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("SetSpendCapResponse");
            var actualResponseJson = httpResponseMessage.Content.ReadAsStringAsync().Result;
            var respCode = JObject.Parse(actualResponseJson);
            if (httpResponseMessage.StatusCode == HttpStatusCode.BadRequest)
            {
                httpResponseMessage.StatusCode.Should().Match<HttpStatusCode>(p => p == HttpStatusCode.BadRequest);

                switch (memberNames)
                {
                    case "CapType":
                        respCode["errors"][0]["memberNames"][0].ToString().Should().Contain(memberNames);
                        respCode["errors"][0]["errorMessage"].ToString().Should().Contain(memberNames);
                        break;
                    case "CapAmount":
                        respCode["errors"][0]["memberNames"][0].ToString().Should().Contain(memberNames);
                        respCode["errors"][0]["errorMessage"].ToString().Should().BeOneOf("Spend cap limit must be less than credit limit", "The field CapAmount must be between 0.01 and 79228162514264337593543950335.");
                        break;
                    case "capAmount":
                        respCode["errors"][0]["memberNames"][0].ToString().Should().Contain(memberNames);
                        respCode["errors"][0]["errorMessage"].ToString().Should().Contain(memberNames);
                        break;
                    case "AlertType":
                        respCode["errors"][0]["memberNames"][0].ToString().Should().Contain(memberNames);
                        respCode["errors"][0]["errorMessage"].ToString().Should().Contain(memberNames);
                        break;
                    case "enableCap":
                        respCode["errors"][0]["memberNames"][0].ToString().Should().Contain(memberNames);
                        respCode["errors"][0]["errorMessage"].ToString().Should().Contain(memberNames);
                        break;
                }
            }
            else
            {
                httpResponseMessage.StatusCode.Should().Match<HttpStatusCode>(p => p == HttpStatusCode.OK);
            }

        }
        [Given(@"I set the CAP_AMOUNT (.*) to a value (.*)")]
        public void GivenISetTheCAP_AMOUNTFirstToAValue(string p0, string p1)
        {
            string foundationRequest = null;
            if (p0.Equals("first"))
            {
                _scenarioContext.Set(p1, "InitSpendCapAmount");
                Config.CardAccount.CardNumber =
                    TestContext.IsFirstData() ?
                        _mockConfiguration.ValidUATSoftCardAccountId
                        : AccountNumberGenerator.Generate();

                if (TestContext.IsFirstData())
                {
                    foundationRequest = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\setSpendCap_request.json",
                        new Dictionary<string, object>
                        {
                            {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber}, {"CAP_TYPE", "Soft"},
                            {"ENABLE_CAP", "true"}, {"ALERT_TYPE", "Sms"}, {"CAP_AMOUNT", p1}
                        }
                    );
                    _scenarioContext.Set(foundationRequest, "FoundationRequest");
                    return;
                }

                var mockRequest = _dataFixtureReader.Read(
                    @"FirstData\AccountCustomFieldsUpdateAsync\Request_Warning.json",
                    new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber } });
                var mockAccountRequest = _dataFixtureReader.Read(
                    @"FirstData\AccountDetailInquiryV3\Request.json",
                    new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber } }
                );
                var mockAccountResponse = _dataFixtureReader.Read(
                    @"FirstData\AccountDetailInquiryV3\200_SetSpendCap.json",
                    new Dictionary<string, object> {
                        { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber },
                        { "CREDIT_LIMIT", "250000" },
                        {"SPEND_LIMIT", p1 }
                    });
                object mockResponse = "{}";
                foundationRequest = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\setSpendCap_request.json",
                    new Dictionary<string, object>
                    {
                        {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber},
                        {"CAP_TYPE", "Soft"},
                        {"ALERT_TYPE", "Sms"},
                        {"CAP_AMOUNT", p1}
                    }
                );
                _scenarioContext.Set(foundationRequest, "FoundationRequest");
                _mock
                    .GivenRequest(mockRequest)
                    .WithRequiredParam("account")
                    .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountCustomFieldsUpdate)
                    .ThenReturnAsync(mockResponse)
                    .Wait();
                _mock
                    .GivenRequest(mockAccountRequest)
                    .WithRequiredParam("account")
                    .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiryV3)
                    .ThenReturnAsync(mockAccountResponse)
                    .Wait();
            }
            else
            {
                _scenarioContext.Set(p1, "UpdatedSpendCapAmount");
                if (TestContext.IsFirstData())
                {
                    foundationRequest = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\setSpendCap_request.json",
                        new Dictionary<string, object>
                        {
                            {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber}, {"CAP_TYPE", "Soft"},
                            {"ENABLE_CAP", "true"}, {"ALERT_TYPE", "Sms"}, {"CAP_AMOUNT", p1}
                        }
                    );
                    _scenarioContext.Set(foundationRequest, "updatedFoundationRequest");
                    return;
                }
                if (TestContext.IsFirstData()) return;

                var mockRequest = _dataFixtureReader.Read(
                    @"FirstData\AccountCustomFieldsUpdateAsync\Request.json",
                    new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber } });
                var mockAccountRequest = _dataFixtureReader.Read(
                    @"FirstData\AccountDetailInquiryV3\Request.json",
                    new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber } }
                );
                var mockAccountResponse = _dataFixtureReader.Read(
                    @"FirstData\AccountDetailInquiryV3\200_SetSpendCap.json",
                    new Dictionary<string, object>
                    {
                        { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber },
                        { "CREDIT_LIMIT", "250000" }
                    });
                object mockResponse = "{}";
                foundationRequest = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\setSpendCap_request.json",
                    new Dictionary<string, object>
                    {
                        {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber},
                        {"CAP_TYPE", "Soft"},
                        {"ENABLE_CAP", "true"},
                        {"ALERT_TYPE", "Sms"},
                        {"CAP_AMOUNT", p1}
                    }
                );
                _scenarioContext.Set(foundationRequest, "updatedFoundationRequest");
                _mock
                    .GivenRequest(mockRequest)
                    .WithRequiredParam("account")
                    .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountCustomFieldsUpdate)
                    .ThenReturnAsync(mockResponse)
                    .Wait();
                _mock
                    .GivenRequest(mockAccountRequest)
                    .WithRequiredParam("account")
                    .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiryV3)
                    .ThenReturnAsync(mockAccountResponse)
                    .Wait();
            }
        }

        [Given(@"I have the account with the CREDIT_LIMIT as (.*) and with CAP_AMOUNT as (.*)")]
        public void GivenIHaveTheAccountWithTheCREDIT_LIMITAsAndWithCAP_AMOUNTAs(decimal creditLimit, decimal capAmount)
        {
            Config.CardAccount.CardNumber =
                 TestContext.IsFirstData() ?
                     _mockConfiguration.ValidCardAccountId
                     : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var mockRequest = _dataFixtureReader.Read(
                @"FirstData\AccountCustomFieldsUpdateAsync\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber } });
            var mockAccountRequest = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV2\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber } }
            );
            var mockAccountResponse = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV2\200_SetSpendCap.json",
                new Dictionary<string, object>
                {
                    { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber },
                    { "CREDIT_LIMIT", creditLimit }
                });
            object mockResponse = "{}";

            var foundationRequest = _dataFixtureReader.Read(@"CardAccount\SetSpendCap\setSpendCap_request.json",
                new Dictionary<string, object>
                {
                    {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber},
                    {"CAP_TYPE", "Soft"},
                    {"ENABLE_CAP", "true"},
                    {"ALERT_TYPE", "Sms"},
                    {"CAP_AMOUNT", capAmount}
                }
            );
            _scenarioContext.Set(foundationRequest, "FoundationRequest");
            _mock
                .GivenRequest(mockRequest)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountCustomFieldsUpdate)
                .ThenReturnAsync(mockResponse)
                .Wait();
            _mock
                .GivenRequest(mockAccountRequest)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiryV3)
                .ThenReturnAsync(mockAccountResponse)
                .Wait();
        }
    }
}
