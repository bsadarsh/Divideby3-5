﻿using System.Collections.Generic;
using System.Net.Http;
using FluentAssertions;
using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Extensions;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using Newtonsoft.Json.Linq;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    public class GetCardAccountSteps
    {
        private readonly Mock _mock;
        private readonly IHttpApiClient _cardAccountClient;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly ScenarioContext _scenarioContext;
        private readonly MockConfiguration _mockConfiguration;

        public GetCardAccountSteps(
            ScenarioContext scenarioContext,
            Mock mock,
            IHttpApiClient cardAccountClient,
            IDataFixtureReader dataFixtureReader,
            MockConfiguration mockConfiguration)
        {
            _scenarioContext = scenarioContext;
            _mock = mock;
            _cardAccountClient = cardAccountClient;
            _dataFixtureReader = dataFixtureReader;
            _mockConfiguration = mockConfiguration;
        }

        [Given(@"I have a valid account with card account details")]
        public void GivenIHaveAValidAccountWithCardAccountDetails()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.ValidCardAccountId
                    : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var request = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            var response = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\200.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            _mock
               .GivenRequest(request)
               .WithRequiredParam("account")
               .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiryV3)
               .ThenReturnAsync(response)
               .Wait();
        }

        [When(@"I ask for a card account details")]
        public void WhenIAskForACardAccountDetails()
        {
            _scenarioContext.Set(CallGetCardAccountEndpoint(), "response");
        }

        [When(@"I ask for a card account details again")]
        public void WhenIAskForACardAccountDetailsAgain()
        {
            WhenIAskForACardAccountDetails();
        }

        [Then(@"the result returns expected card account details from ""(.*)""")]
        public void ThenTheResultReturnsExpectedCardAccountDetailsFrom(string dataSource)
        {
            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("response");
            httpResponseMessage.StatusCode.ToString().Should().BeOneOf("NonAuthoritativeInformation", "OK");

            if (TestContext.IsFirstData()) return;

            var expectedResponse = _dataFixtureReader.Read(
                @"CardAccount\GetCardAccount\response.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            var actualResponse = httpResponseMessage.Content.ReadAsStringAsync().Result;
            actualResponse.Should().MatchJson(expectedResponse);
        }

        [Given(@"card account details are stored in cache")]
        public void GivenCardAccountDetailsAreStoredInCache()
        {
            CallGetCardAccountEndpoint();
        }

        [When(@"I ask for a card account details with invalid account number")]
        public void WhenIAskForACardAccountDetailsWithInvalidAccountNumber()
        {
            var response = _cardAccountClient.Post(CardAccountEndpoints.GetCardAccount, "");
            _scenarioContext.Set(response, "response");
        }

        private HttpResponseMessage CallGetCardAccountEndpoint()
        {
            var request = _dataFixtureReader.Read(
                @"CardAccount\GetCardAccount\request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            return _cardAccountClient.Post(CardAccountEndpoints.GetCardAccount, request);
        }


        private HttpResponseMessage CallGetCardAccountV2Endpoint()
        {
            var request = _dataFixtureReader.Read(
                @"CardAccount\GetCardAccountV2\request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            return _cardAccountClient.Post(CardAccountEndpoints.GetCardAccountV2, request);
        }

        [Given(@"The Card account details not exists for my account")]
        public void GivenCardAccountDetailsNotExistsForMyAccount()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.AccountNotFoundAccountId
                    : AccountNumberGenerator.Generate();

            var request = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiry\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            var response = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiry\465_AccountNotFound.json"
            );

            _mock
                .GivenRequest(request)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiry)
                .ThenReturnAsync(response, 465)
                .Wait();
        }

        [Given(@"The Card account details not exists for not existing organisation")]
        public void GivenAccountDetailsNotExistsForNotExistingOrganisation()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.InvalidOrgAccountId
                    : AccountNumberGenerator.Generate();

            var request = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            var response = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiry\465_OrganisationNotFound.json"
            );

            _mock
                .GivenRequest(request)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiryV3)
                .ThenReturnAsync(response, 465)
                .Wait();
        }
       
        [Given(@"I have a valid card account with ""(.*)"" and ""(.*)""")]
        
        public void GivenIHaveAValidCardAccountWithStatusAndSubStatusDetails(string statusType, string subStatusType)
        {
            Config.CardAccount.CardAccountId =
                 TestContext.IsFirstData() ?
                     _mockConfiguration.ValidCardAccountId
                     : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var request = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            var response = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\200_Status_SubStatus.json",
                new Dictionary<string, object> { 
                    { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId },                
                    {"INTSTATUS", statusType},
                    {"BLOCKCODE2", subStatusType}
                }
            );

            _mock
               .GivenRequest(request)
               .WithRequiredParam("account")
               .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiryV3)
               .ThenReturnAsync(response)
               .Wait();
        }

        [When(@"I hit the getcardaccount endpoint")]
        public void WhenIHitTheGetcardaccountEndpoint()
        {
            _scenarioContext.Set(CallGetCardAccountV2Endpoint(), "response");
        }

        [Then(@"I verify the status as ""(.*)"" and subStatus as ""(.*)""")]
        public void ThenIVerifyTheStatusAsAndSubStatusAs(string status, string subStatus)
        {
            var responseContent = _scenarioContext.Get<HttpResponseMessage>("response").Content.ReadAsStringAsync().Result;
            var jsonString = JObject.Parse(responseContent);
            var account = jsonString.GetValue("account") as JObject;
            account.GetValue("status").Value<string>().Should().Equals(status);
            account.GetValue("subStatus").Value<string>().Should().Equals(subStatus);
        }

        [Given(@"I have a valid card account with (.*), (.*), (.*), (.*)")]
        public void GivenIHaveAValidCardAccountWithaccountHolderDetails(string title, string firstName, string lastName, string dob)
        {
            Config.CardAccount.CardAccountId =
                 TestContext.IsFirstData() ?
                     _mockConfiguration.ValidCardAccountId
                     : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var request = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            var response = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\200_AccountHolder.json",
                new Dictionary<string, object> {
                    { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId },
                    {"TITLE", title},
                    {"FIRSTNAME", firstName},
                    {"LASTNAME", lastName},
                    {"DOB", dob}
                }
            );

            _mock
               .GivenRequest(request)
               .WithRequiredParam("account")
               .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiryV3)
               .ThenReturnAsync(response)
               .Wait();
        }

        [Then(@"I verify the accountholder response as (.*), (.*), (.*), (.*)")]
        public void ThenIVerifyTheAccountholderResponseAs(string title, string firstName, string lastName, string dob)
        {
            var responseContent = _scenarioContext.Get<HttpResponseMessage>("response").Content.ReadAsStringAsync().Result;
            var jsonString = JObject.Parse(responseContent);
            var account = jsonString.GetValue("account") as JObject;
            var accountHolder = account.GetValue("accountHolder") as JObject;
            accountHolder.GetValue("title").Value<string>().Should().Equals(title);
            accountHolder.GetValue("firstName").Value<string>().Should().Equals(firstName);
            accountHolder.GetValue("lastName").Value<string>().Should().Equals(lastName);
            accountHolder.GetValue("dateOfBirth").Value<string>().Should().Equals(dob);
        }

        [Given(@"I have entered valid Accountnumber for GetCardAccount and UpdateAccount details")]
        public void GivenIHaveEnteredValidAccountnumberForGetCardAccountAndUpdateAccountDetails()
        {
            Config.CardAccount.CardAccountId =
                  TestContext.IsFirstData() ?
                      _mockConfiguration.ValidCardAccountIdCustomField
                      : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var request = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            var response = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\200.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            _mock
               .GivenRequest(request)
               .WithRequiredParam("account")
               .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiryV3)
               .ThenReturnAsync(response)
               .Wait();

        }

        [Given(@"I have a valid account with card account details with blockCode details")]
        public void GivenIHaveAValidAccountWithCardAccountDetailsWithBlockCodeDetails()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.ValidCardAccountId
                    : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var request = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            var response = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\Response_BlockCode_null.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            _mock
               .GivenRequest(request)
               .WithRequiredParam("account")
               .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiryV3)
               .ThenReturnAsync(response)
               .Wait();
        }

    }

}
