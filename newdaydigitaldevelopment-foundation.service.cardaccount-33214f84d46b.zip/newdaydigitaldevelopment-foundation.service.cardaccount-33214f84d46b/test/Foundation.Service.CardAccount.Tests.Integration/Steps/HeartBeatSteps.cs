﻿using System.Net;
using System.Net.Http;
using FluentAssertions;
using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    public class HeartBeatSteps
    {
        private readonly IHttpApiClient _cardAccountClient;
        private readonly ScenarioContext _scenarioContext;

        public HeartBeatSteps(ScenarioContext scenarioContext, IHttpApiClient cardAccountClient)
        {
            _scenarioContext = scenarioContext;
            _cardAccountClient = cardAccountClient;
        }

        [When(@"I call the heartbeat endpoint")]
        public void WhenICallTheHeartbeatEndpoint()
        {
            var response = _cardAccountClient.Get(CardAccountEndpoints.HeartBeat);
            _scenarioContext.Set(response, "response");
        }

        [Then(@"the heartbeat should return successful response")]
        public void ThenTheHeartbeatShouldReturnSuccessfulResponse()
        {
            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("response");

            httpResponseMessage.StatusCode.Should().Be(HttpStatusCode.OK);
        }
    }
}
