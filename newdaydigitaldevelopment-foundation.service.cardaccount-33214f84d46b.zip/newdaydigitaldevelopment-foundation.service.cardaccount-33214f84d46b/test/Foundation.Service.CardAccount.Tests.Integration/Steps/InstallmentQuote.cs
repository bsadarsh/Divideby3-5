﻿using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using System.Collections.Generic;
using System.Net.Http;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    class InstallmentQuote
    {
        private readonly Mock _mock;
        private readonly IHttpApiClient _cardAccountClient;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly ScenarioContext _scenarioContext;
        private readonly MockConfiguration _mockConfiguration;
        private string _foundationRequest = string.Empty;

        public InstallmentQuote(
            ScenarioContext scenarioContext,
            Mock mock,
            IHttpApiClient cardAccountClient,
            IDataFixtureReader dataFixtureReader,
            MockConfiguration mockConfiguration)
        {
            _scenarioContext = scenarioContext;
            _mock = mock;
            _cardAccountClient = cardAccountClient;
            _dataFixtureReader = dataFixtureReader;
            _mockConfiguration = mockConfiguration;
        }

        [Given(@"I have entered valid input request for Installmentquote")]
        public void GivenIHaveEnteredValidInputRequestForInstallmentquote()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.CardAccountForUATInstallmentQuote
                    : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var mockRequest = _dataFixtureReader.Read(
                @"FirstData\InstallmentQuote\Request_fppQuoteGeneration.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } });
            var mockAccountRequest = _dataFixtureReader.Read(
                @"FirstData\InstallmentQuote\Request_accountPlanList.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } });

            var response = _dataFixtureReader.Read(
                @"FirstData\InstallmentQuote\200_Response_fppQuoteGeneration.json"
            );

            var accountPlanresponse = _dataFixtureReader.Read(
                @"FirstData\InstallmentQuote\200_Response_accountPlanList.json"
            );


            _mock
                .GivenRequest(mockRequest)
                .WithRequiredParam("acct")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.FppQuoteGeneration)
                .ThenReturnAsync(response)
                .Wait(); 
            _mock
                .GivenRequest(mockAccountRequest)
                .WithRequiredParam("acct")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountPlanList)
                .ThenReturnAsync(accountPlanresponse)
                .Wait();
        }

        [When(@"I hit the Installmentquote endpoint")]
        public void WhenIHitTheInstallmentquoteEndpoint()
        {
            _foundationRequest = _dataFixtureReader.Read(@"CardAccount\InstallmentQuote\Request.json",
                new Dictionary<string, object>
                {
                    {"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId},
                }
            );

            _scenarioContext.Set(_cardAccountClient.Post(CardAccountEndpoints.InstallmentQuote, _foundationRequest), "response");
        }

        [When(@"I hit the Installmentquote endpoint with fixedamount and terms in request")]
        public void WhenIHitTheInstallmentquoteEndpointWithFixedamountAndTermsInRequest()
        {
            _foundationRequest = _dataFixtureReader.Read(@"CardAccount\InstallmentQuote\Request_Fixed_Term.json",
                new Dictionary<string, object>
                {
                    {"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId},
                }
            );

            _scenarioContext.Set(_cardAccountClient.Post(CardAccountEndpoints.InstallmentQuote, _foundationRequest), "response");
        }

        [When(@"I hit the Installmentquote endpoint with Invalid request")]
        public void WhenIHitTheInstallmentquoteEndpointWithInvalidRequest()
        {
            _foundationRequest = _dataFixtureReader.Read(@"CardAccount\InstallmentQuote\Request_Fixed_Term.json",
                new Dictionary<string, object>
                {
                    {"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId},
                }
            );

            _scenarioContext.Set(_cardAccountClient.Post(CardAccountEndpoints.InstallmentQuote, _foundationRequest), "response");
        }

        [When(@"I hit the Installmentquote endpoint with request with amount higher")]
        public void WhenIHitTheInstallmentquoteEndpointWithRequestWithAmountHigher()
        {
            _foundationRequest = _dataFixtureReader.Read(@"CardAccount\InstallmentQuote\Request_higherAmount.json",
                new Dictionary<string, object>
                {
                    {"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId},
                }
            );

            _scenarioContext.Set(_cardAccountClient.Post(CardAccountEndpoints.InstallmentQuote, _foundationRequest), "response");
        }



    }
}
