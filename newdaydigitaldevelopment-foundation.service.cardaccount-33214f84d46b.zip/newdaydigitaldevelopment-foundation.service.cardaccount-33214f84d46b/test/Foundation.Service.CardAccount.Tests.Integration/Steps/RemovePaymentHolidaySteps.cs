﻿using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using System;
using System.Collections.Generic;
using System.Net.Http;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    public class RemovePaymentHolidaySteps
    {
        private readonly Mock _mock;
        private readonly IHttpApiClient _cardAccountClient;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly ScenarioContext _scenarioContext;
        private readonly MockConfiguration _mockConfiguration;
        private string foundationRequest = null;

        public RemovePaymentHolidaySteps(
            ScenarioContext scenarioContext,
            Mock mock,
            IHttpApiClient cardAccountClient,
            IDataFixtureReader dataFixtureReader,
            MockConfiguration mockConfiguration)
        {
            _scenarioContext = scenarioContext;
            _mock = mock;
            _cardAccountClient = cardAccountClient;
            _dataFixtureReader = dataFixtureReader;
            _mockConfiguration = mockConfiguration;
        }

        [Given(@"I have entered valid AccountNumber to removed Payment Holiday")]
        public void GivenIHaveEnteredValidAccountNumberToRemovedPaymentHoliday()
        {
            Config.CardAccount.CardAccountId =
                   TestContext.IsFirstData() ?
               _mockConfiguration.CardAccountForUAT
                       : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var request = _dataFixtureReader.Read(
                @"FirstData\RemovePaymentHoliday\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            var response = _dataFixtureReader.Read(
                @"FirstData\RemovePaymentHoliday\200_Response.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            _mock
                .GivenRequest(request)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.PaymentHoliday)
                .ThenReturnAsync(response, 200)
                .Wait();

        }

        [When(@"I hit the remove payment holiday endpoint")]
        public void WhenIHitTheRemovePaymentHolidayEndpoint()
        {
            foundationRequest = _dataFixtureReader.Read(@"CardAccount\RemovePaymentHoliday\Request.json",
                 new Dictionary<string, object>
                 {
                        {"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId},
                 }
             );

            _scenarioContext.Set(_cardAccountClient.Post(CardAccountEndpoints.RemovePaymentHoliday, foundationRequest), "response");

        }

        [When(@"I request remove payment details from Account Enquiry with term ""(.*)""")]
        public void WhenIRequestRemovePaymentDetailsFromAccountEnquiryWithTerm(int term)
        {
            var enquiryRequest = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
                );
            var enquiryResponse = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\200_PaymentHoliday.json",
                new Dictionary<string, object> 
                { 
                    { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId },
                    { "PAYMENT_HOLIDAYTERM", term }
                }
                );

            _mock
                .GivenRequest(enquiryRequest)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiryV3)
                .ThenReturnAsync(enquiryResponse)
                .Wait();

        }

        [When(@"I hit the remove payment holiday endpoint without term")]
        public void WhenIHitTheRemovePaymentHolidayEndpointWithoutTerm()
        {
            foundationRequest = _dataFixtureReader.Read(@"CardAccount\RemovePaymentHoliday\Request_WithoutTerm.json",
                new Dictionary<string, object>
                {
                        {"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId},
                }
            );

            _scenarioContext.Set(_cardAccountClient.Post(CardAccountEndpoints.RemovePaymentHoliday, foundationRequest), "response");

        }

    }
}
