﻿using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using FluentAssertions;
using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Extensions;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    public class LetterRequest
    {
        private readonly Mock _mock;
        private readonly IHttpApiClient _cardAccountClient;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly ScenarioContext _scenarioContext;
        private readonly MockConfiguration _mockConfiguration;
        private string foundationRequest = null;
        private object expectedStatusCode;

        public LetterRequest(
            ScenarioContext scenarioContext,
            Mock mock,
            IHttpApiClient cardAccountClient,
            IDataFixtureReader dataFixtureReader,
            MockConfiguration mockConfiguration)
        {
            _scenarioContext = scenarioContext;
            _mock = mock;
            _cardAccountClient = cardAccountClient;
            _dataFixtureReader = dataFixtureReader;
            _mockConfiguration = mockConfiguration;
        }

        [Given(@"I have entered valid Accountnumber and (.*)")]
        public void GivenIHaveEnteredValidAccountnumberAnd(string Lettercodes)
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
            _mockConfiguration.ValidCardAccountIdLetterRequest
                    : AccountNumberGenerator.Generate();           

            if (TestContext.IsFirstData()) return;

            var request = _dataFixtureReader.Read(
                @"FirstData\LetterRequest\request.json", new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId }, { "Letter_Codes", Lettercodes } }
                );
            var response = _dataFixtureReader.Read(
                @"FirstData\LetterRequest\200_response.json");

            _mock
               .GivenRequest(request)
               .WithRequiredParam("letterCode")
               .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.letterRequest)
               .ThenReturnAsync(response)
               .Wait();
        }

        [Then(@"I request letter to fiserv (.*)")]
        public void ThenIRequestLetterToFiserv(string lettercodes)
        {
            _scenarioContext.Set(CallGetLetterRequestEndpoint(Config.CardAccount.CardAccountId, lettercodes), "response");
        }

        private HttpResponseMessage CallGetLetterRequestEndpoint(string cardAccountId, string lettercodes)
        {
            
            var request = _dataFixtureReader.Read(
                @"CardAccount\LetterRequest\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", cardAccountId }, { "Lettercodes", lettercodes } }
            );

            return _cardAccountClient.Post(CardAccountEndpoints.letterRequest, request);
        }

        [Then(@"I validate expected response from ""(.*)""")]
        public void ThenIValidateExpectedResponseFrom(string lettercodes)
        {
            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("response");
            httpResponseMessage.StatusCode.ToString().Should().BeOneOf("NonAuthoritativeInformation", "OK");

            if (TestContext.IsFirstData()) return;

            var expectedResponse = _dataFixtureReader.Read(
                @"CardAccount\LetterRequest\200_Response.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId }, { "Lettercodes", lettercodes } }
            );

            var actualResponse = httpResponseMessage.Content.ReadAsStringAsync().Result;
            actualResponse.Should().MatchJson(expectedResponse);
        }

        [Given(@"I have entered an invalid (.*) and (.*)")]
        public void GivenIHaveEnteredAnInvalidAnd(string Lettercodes, string Accountnumber)
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.ValidCardAccountId
                    : AccountNumberGenerator.Generate();
            if (TestContext.IsFirstData()) return;

            var request = _dataFixtureReader.Read(
                @"FirstData\LetterRequest\request.json", new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId }, { "Letter_Codes", Lettercodes } }
                );
            var response = _dataFixtureReader.Read(
                @"FirstData\LetterRequest\200_response.json");

            _mock
               .GivenRequest(request)
               .WithRequiredParam("letterCode")
               .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.letterRequest)
               .ThenReturnAsync(response)
               .Wait();
        }

        [Then(@"I request letter with invalid request to fiserv (.*)")]
        public void ThenIRequestLetterWithInvalidRequestToFiserv(string Lettercodes)
        {
            _scenarioContext.Set(CallGetLetterRequestEndpointforInvalidData(Config.CardAccount.CardAccountId, Lettercodes), "response");
        }

        private HttpResponseMessage CallGetLetterRequestEndpointforInvalidData(string cardAccountId, string lettercodes)
        {

            var request = _dataFixtureReader.Read(
                @"CardAccount\LetterRequest\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", cardAccountId }, { "Lettercodes", lettercodes } }
            );

            return _cardAccountClient.Post(CardAccountEndpoints.letterRequest, request);
        }

        [Then(@"I validate expected error response")]
        public void ThenIValidateExpectedErrorResponse(HttpStatusCode expectedStatusCode)
        {
            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("response");
            httpResponseMessage.StatusCode.Should().Be(expectedStatusCode);
        }

    }

}

