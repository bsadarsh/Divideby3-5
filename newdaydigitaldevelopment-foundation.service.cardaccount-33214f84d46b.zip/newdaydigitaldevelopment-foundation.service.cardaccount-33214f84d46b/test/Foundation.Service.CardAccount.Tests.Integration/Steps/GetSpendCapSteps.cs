﻿using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Net;
using System.Net.Http;
using FluentAssertions;
using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using Newtonsoft.Json.Linq;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    public class GetSpendCapSteps
    {
        private readonly ScenarioContext _scenarioContext;
        private readonly Mock _mock;
        private readonly IHttpApiClient _apiClient;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly MockConfiguration _mockConfiguration;

        public GetSpendCapSteps(
            IHttpApiClient apiClient,
            ScenarioContext scenarioContext,
            Mock mock,
            IDataFixtureReader dataFixtureReader,
            MockConfiguration mockConfiguration
        )
        {
            _apiClient = apiClient;
            _scenarioContext = scenarioContext;
            _mock = mock;
            _dataFixtureReader = dataFixtureReader;
            _mockConfiguration = mockConfiguration;
        }

        [Given(@"I have a (.*) account with Spend cap")]
        public void GivenIHaveAAccountWithSpendCap(string p0)
        {
            if (!p0.Equals("second time"))
            {
                Config.CardAccount.CardNumber =
                    TestContext.IsFirstData()
                        ? _mockConfiguration.ValidCardAccountId
                        : AccountNumberGenerator.Generate();

                if (TestContext.IsFirstData()) return;
                var request = _dataFixtureReader.Read(
                    @"FirstData\AccountDetailInquiryV3\Request.json",
                    new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber } }
                );
                var response = _dataFixtureReader.Read(
                    @"FirstData\AccountDetailInquiryV3\200_getSpendCap.json",
                    new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber }, { "SPEND_LIMIT", "150000" } }
                );
                _mock
                    .GivenRequest(request)
                    .WithRequiredParam("account")
                    .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiryV3)
                    .ThenReturnAsync(response)
                    .Wait();
            }
            else
            {
                if (TestContext.IsFirstData()) return;
                var request = _dataFixtureReader.Read(
                    @"FirstData\AccountDetailInquiryV3\Request.json",
                    new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber } }
                );
                var response = _dataFixtureReader.Read(
                    @"FirstData\AccountDetailInquiryV3\200_getSpendCap.json",
                    new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber }, { "SPEND_LIMIT", "150000" } }
                );
                _mock
                    .GivenRequest(request)
                    .WithRequiredParam("account")
                    .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiryV3)
                    .ThenReturnAsync(response)
                    .Wait();
            }
        }


        [When(@"I request the get spend cap for (.*) to get spend cap details")]
        public void WhenIRequestTheGetSpendCapForToGetSpenCapDetails(string accountType)
        {
            if (_scenarioContext.ScenarioInfo.Title.Contains("Get spend cap after setting a warning cap") && (accountType.Equals("first time")))
            {
                Config.CardAccount.CardNumber =
                    TestContext.IsFirstData()
                        ? _mockConfiguration.ValidUATSoftCardAccountId
                        : AccountNumberGenerator.Generate();

                if (TestContext.IsFirstData())
                {
                    if (accountType.Equals("first time"))
                    {
                        _scenarioContext.Set(CallGetSpendCapEndpoint(accountType), "firstResponse");
                    }
                    else if (accountType.Equals("second time"))
                    {
                        _scenarioContext.Set(CallGetSpendCapEndpoint(accountType), "secondResponse");
                    }
                    else
                    {
                        _scenarioContext.Set(CallGetSpendCapEndpoint(accountType), "response");
                    }
                    return;
                }
                var request = _dataFixtureReader.Read(
                    @"FirstData\AccountDetailInquiryV3\Request.json",
                    new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber } }
                );
                var spendLimit = _scenarioContext.Get<string>("InitSpendCapAmount");
                var response = _dataFixtureReader.Read(
                    @"FirstData\AccountDetailInquiryV3\200_getSpendCap.json",
                    new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber }, { "SPEND_LIMIT", spendLimit.Replace(".", string.Empty) } }
                );
                _mock
                    .GivenRequest(request)
                    .WithRequiredParam("account")
                    .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiryV3)
                    .ThenReturnAsync(response)
                    .Wait();
            }
            else if (_scenarioContext.ScenarioInfo.Title.Contains("Get spend cap after setting a warning cap") && (accountType.Equals("second time")))
            {
                Config.CardAccount.CardNumber =
                    TestContext.IsFirstData()
                        ? _mockConfiguration.ValidUATSoftCardAccountId
                        : AccountNumberGenerator.Generate();

                if (TestContext.IsFirstData())
                {
                    if (accountType.Equals("first time"))
                    {
                        _scenarioContext.Set(CallGetSpendCapEndpoint(accountType), "firstResponse");
                    }
                    else if (accountType.Equals("second time"))
                    {
                        _scenarioContext.Set(CallGetSpendCapEndpoint(accountType), "secondResponse");
                    }
                    else
                    {
                        _scenarioContext.Set(CallGetSpendCapEndpoint(accountType), "response");
                    }
                    return;
                }
                var request = _dataFixtureReader.Read(
                    @"FirstData\AccountDetailInquiryV3\Request.json",
                    new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber } }
                );
                var spendLimit = _scenarioContext.Get<string>("UpdatedSpendCapAmount");
                var response = _dataFixtureReader.Read(
                    @"FirstData\AccountDetailInquiryV3\200_getSpendCap.json",
                    new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber }, { "SPEND_LIMIT", spendLimit.Replace(".", string.Empty) } }
                );
                _mock
                    .GivenRequest(request)
                    .WithRequiredParam("account")
                    .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiryV3)
                    .ThenReturnAsync(response)
                    .Wait();
            }


            if (accountType.Equals("first time"))
            {
                _scenarioContext.Set(CallGetSpendCapEndpoint(accountType), "firstResponse");
            }
            else if (accountType.Equals("second time"))
            {
                _scenarioContext.Set(CallGetSpendCapEndpoint(accountType), "secondResponse");
            }
            else
            {
                _scenarioContext.Set(CallGetSpendCapEndpoint(accountType), "response");
            }
        }

        [Then(@"I verify the list of fields in the response")]
        public void ThenIVerifyTheListOfFieldsInTheResponse()
        {
            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("response");
            var actualResponseJson = httpResponseMessage.Content.ReadAsStringAsync().Result;
            if (_scenarioContext.ScenarioInfo.Title.Contains("NotFound"))
            {
                httpResponseMessage.StatusCode.Should().Match<HttpStatusCode>(p => p == HttpStatusCode.NotFound);
            }
            else if (_scenarioContext.ScenarioInfo.Title.Contains("BadRequest"))
            {
                httpResponseMessage.StatusCode.Should().Match<HttpStatusCode>(p => p == HttpStatusCode.BadRequest);
            }
            else if (_scenarioContext.ScenarioInfo.Title.Contains("InternalServerError"))
            {
                httpResponseMessage.StatusCode.Should().Match<HttpStatusCode>(p => p == HttpStatusCode.InternalServerError);
            }
            else if (_scenarioContext.ScenarioInfo.Title.Contains("warning cap"))
            {
                var respCode = JObject.Parse(actualResponseJson);
                httpResponseMessage.StatusCode.ToString().Should().BeOneOf("OK");
                respCode["spendCapType"].ToString().Should().Match("Soft");
                respCode["spendCapEnabled"].ToString().Should().MatchEquivalentOf("true");
                respCode["spendCapAmount"].ToString().Should().Match("69.59");
                respCode["spendCapExceededAmount"].ToString().Should().Match("");
                respCode["spendCapReached"].ToString().Should().NotBeNullOrEmpty();
            }
            else
            {
                var respCode = JObject.Parse(actualResponseJson);
                httpResponseMessage.StatusCode.ToString().Should().BeOneOf("NonAuthoritativeInformation", "OK");
                respCode["spendCapType"].ToString().Should().NotBeNullOrEmpty();
                respCode["spendCapEnabled"].ToString().Should().NotBeNullOrEmpty();
                respCode["spendCapAmount"].ToString().Should().NotBeNullOrEmpty();
                respCode["spendCapExceededAmount"].ToString().Should().NotBeNullOrEmpty();
                respCode["spendCapReached"].ToString().Should().NotBeNullOrEmpty();
            }
        }

        private HttpResponseMessage CallGetSpendCapEndpoint(string accountType)
        {
            string request;
            if (accountType.Equals("a valid account") || accountType.Equals("first time") || accountType.Equals("second time"))
            {
                request = _dataFixtureReader.Read(@"CardAccount\GetSpendCap\request.json",
                    new Dictionary<string, object>
                    {
                        {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber}
                    });
            }
            else if (accountType.Equals("an invalid account"))
            {
                request = _dataFixtureReader.Read(@"CardAccount\GetSpendCap\request.json",
                    new Dictionary<string, object>
                    {
                        { "ACCOUNT_NUMBER", "7325400000000000" }
                    });
            }
            else
            {
                request = _dataFixtureReader.Read(@"CardAccount\GetSpendCap\request.json",
                    new Dictionary<string, object>
                    {
                        { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber }
                    });
            }

            return _apiClient.Post(CardAccountEndpoints.GetSpendCap, request);
        }

        [Given(@"Get spend cap details not exists for not existing organisation")]
        public void GivenGetSpendCapDetailsNotExistsForNotExistingOrganisation()
        {
            Config.CardAccount.CardNumber =
                TestContext.IsFirstData() ?
                    _mockConfiguration.InvalidOrgAccountId
                    : AccountNumberGenerator.Generate();

            var request = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber } }
            );

            var response = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\465_OrganisationNotFound.json"
            );

            _mock
                .GivenRequest(request)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiryV3)
                .ThenReturnAsync(response, 465)
                .Wait();
        }
        [Then(@"I verify the cap amount against the get spend cap response (.*)")]
        public void ThenIVerifyTheCapAmountAgainstTheGetSpendCapResponse(string p0)
        {
            string capAmount = _scenarioContext.Get<string>("InitSpendCapAmount");
            if (p0.Equals("first"))
            {
                var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("firstResponse");
                var actualResponseJson = httpResponseMessage.Content.ReadAsStringAsync().Result;
                var respCode = JObject.Parse(actualResponseJson);
                httpResponseMessage.StatusCode.ToString().Should().BeOneOf("OK", "NonAuthoritativeInformation");
                respCode["spendCapAmount"].ToString().Should().Match(capAmount);
                _scenarioContext.Set(respCode["spendCapAmount"].ToString(), "firstCap");
            }
            else if (p0.Equals("again"))
            {
                var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("secondResponse");
                var actualResponseJson = httpResponseMessage.Content.ReadAsStringAsync().Result;
                var respCode = JObject.Parse(actualResponseJson);
                httpResponseMessage.StatusCode.ToString().Should().BeOneOf("OK", "NonAuthoritativeInformation");
                var secCapAmount = _scenarioContext.Get<string>("UpdatedSpendCapAmount");
                respCode["spendCapAmount"].ToString().Should().Match(secCapAmount);
                var secondCap = respCode["spendCapAmount"].ToString();
                var firstCap = _scenarioContext.Get<string>("firstCap");
                firstCap.Should().NotBe(secondCap);
            }
        }

        [Given(@"I have a valid account with SpendCapType (.*) and SpendCapValue (.*) and SpendLmtAmount (.*)")]
        public void GivenIHaveAValidAccountWithSpendCapTypeAndSpendCapValueAndSpendLmtAmount(string SpendCapType, string SpendCapValue, string SpendLmtAmount)
        {
            var SPEND_LMTALERT = "1";
            if (SpendCapType.ToUpper().Equals("SOFT"))
            {
                Config.CardAccount.CardNumber =
                    TestContext.IsFirstData()
                        ? _mockConfiguration.ValidUATSoftCardAccountId
                        : AccountNumberGenerator.Generate();
            }
            else if (SpendCapType.ToUpper().Equals("HARD"))
            {
                Config.CardAccount.CardNumber =
                    TestContext.IsFirstData()
                        ? _mockConfiguration.ValidUATHardCardAccountId
                        : AccountNumberGenerator.Generate();
            }
            else
            {
                Config.CardAccount.CardNumber =
                    TestContext.IsFirstData()
                        ? _mockConfiguration.ValidCardAccountId
                        : AccountNumberGenerator.Generate();
                
                SPEND_LMTALERT = "0";
            }

            if (TestContext.IsFirstData()) return;

            var request = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber } }
            );
            var response = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\200_getSpendCap_WithAllTypes.json",
                new Dictionary<string, object>
                { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber },
                  { "SPEND_LIMIT", SpendLmtAmount },
                   { "SPENDCAP_IND", SpendCapValue},
                    { "SPEND_LMTALERT" , SPEND_LMTALERT }  }
            );
            _mock
                .GivenRequest(request)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiryV3)
                .ThenReturnAsync(response)
                .Wait();
        }

        [When(@"I hit the Get Spend Cap Endpoint with (.*)")]
        public void WhenIHitTheGetSpendCapEndpointWith(string SpendCapType)
        {
            _scenarioContext.Set(CallGetSpendCapEndpoint(SpendCapType), "response");
        }

    }
}
