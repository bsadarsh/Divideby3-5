﻿using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using System;
using System.Collections.Generic;
using System.Net.Http;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    public class SetPaymentHolidaySteps
    {
        private readonly Mock _mock;
        private readonly IHttpApiClient _cardAccountClient;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly ScenarioContext _scenarioContext;
        private readonly MockConfiguration _mockConfiguration;
        private string foundationRequest = null;

        public SetPaymentHolidaySteps(
            ScenarioContext scenarioContext,
            Mock mock,
            IHttpApiClient cardAccountClient,
            IDataFixtureReader dataFixtureReader,
            MockConfiguration mockConfiguration)
        {
            _scenarioContext = scenarioContext;
            _mock = mock;
            _cardAccountClient = cardAccountClient;
            _dataFixtureReader = dataFixtureReader;
            _mockConfiguration = mockConfiguration;
        }

        [Given(@"I have entered valid AccountNumber to set Payment Holiday")]
        public void GivenIHaveEnteredValidAccountNumberToSetPaymentHoliday()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
            _mockConfiguration.CardAccountForUAT
                    : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var request = _dataFixtureReader.Read(
                @"FirstData\SetPaymentHoliday\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            var response = _dataFixtureReader.Read(
                @"FirstData\SetPaymentHoliday\200_Response.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            _mock
                .GivenRequest(request)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.PaymentHoliday)
                .ThenReturnAsync(response, 200)
                .Wait();

        }

                
        [When(@"I hit the set payment holiday endpoint")]
        public void WhenIHitTheSetPaymentHolidayEndpoint()
        {
            foundationRequest = _dataFixtureReader.Read(@"CardAccount\SetPaymentHoliday\Request.json",
                 new Dictionary<string, object>
                 {
                        {"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId},
                 }
             );

            _scenarioContext.Set(_cardAccountClient.Post(CardAccountEndpoints.SetPaymentHoliday, foundationRequest), "response");

        }
    }
}