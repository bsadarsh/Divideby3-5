﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using FluentAssertions;
using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Extensions;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    public class GetInsuranceProduct
    {
        private readonly Mock _mock;
        private readonly IHttpApiClient _cardAccountClient;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly ScenarioContext _scenarioContext;
        private readonly MockConfiguration _mockConfiguration;
        private string foundationRequest = null;
        private object expectedStatusCode;

        public GetInsuranceProduct(
            ScenarioContext scenarioContext,
            Mock mock,
            IHttpApiClient cardAccountClient,
            IDataFixtureReader dataFixtureReader,
            MockConfiguration mockConfiguration)
        {
            _scenarioContext = scenarioContext;
            _mock = mock;
            _cardAccountClient = cardAccountClient;
            _dataFixtureReader = dataFixtureReader;
            _mockConfiguration = mockConfiguration;
        }

        [Then(@"I hit the GetInsurance Products endpoint")]
        public void ThenIHitTheGetInsuranceProductsEndpoint()
        {
            _scenarioContext.Set(CallGetInsuranceEndpoint(Config.CardAccount.CardAccountId), "response");
        }

        private HttpResponseMessage CallGetInsuranceEndpoint(string cardAccountId)
        {

            var request = _dataFixtureReader.Read(
                @"CardAccount\GetInsuranceProduct\request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", cardAccountId } }
            );

            return _cardAccountClient.Post(CardAccountEndpoints.GetInsurance, request);
        }

        [Then(@"I verify the successfull status code ""(.*)"" in response")]
        public void ThenIVerifyTheSuccessfullStatusCodeInResponse(HttpStatusCode statusCode)
        {
            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("response");
            (httpResponseMessage.StatusCode == HttpStatusCode.OK || httpResponseMessage.StatusCode == HttpStatusCode.NonAuthoritativeInformation).Should().Be(true);
        }

        [Then(@"I verify the successfull status code ""(.*)"" in responses")]
        public void ThenIVerifyTheSuccessfullStatusCodeInResponses(string p0)
        {
            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("response");
            (httpResponseMessage.StatusCode == HttpStatusCode.OK || httpResponseMessage.StatusCode == HttpStatusCode.NonAuthoritativeInformation || httpResponseMessage.StatusCode == HttpStatusCode.InternalServerError || httpResponseMessage.StatusCode == HttpStatusCode.BadRequest).Should().Be(true);
        }


        [Given(@"I have entered valid AccountNumber to GetInsurance Products")]
        public void GivenIHaveEnteredValidAccountNumberToGetInsuranceProducts()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.CardAccountForUATGetInsuranceProduct
                    : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var request = _dataFixtureReader.Read(
                @"FirstData\GetInsuranceProduct\request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            var response = _dataFixtureReader.Read(
                @"FirstData\GetInsuranceProduct\response.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );



            _mock
                .GivenRequest(request)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.InsuranceInquiry)
                .ThenReturnAsync(response, 200)
                .Wait();
        }

    }
}
