﻿using System.Collections.Generic;
using System.Net.Http;
using FluentAssertions;
using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Extensions;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    public class GetAccountHolderSteps
    {
        private readonly Mock _mock;
        private readonly IHttpApiClient _cardAccountClient;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly ScenarioContext _scenarioContext;
        private readonly MockConfiguration _mockConfiguration;

        public GetAccountHolderSteps(
            ScenarioContext scenarioContext,
            Mock mock,
            IHttpApiClient cardAccountClient,
            IDataFixtureReader dataFixtureReader,
            MockConfiguration mockConfiguration)
        {
            _scenarioContext = scenarioContext;
            _mock = mock;
            _cardAccountClient = cardAccountClient;
            _dataFixtureReader = dataFixtureReader;
            _mockConfiguration = mockConfiguration;
        }

        [Given(@"I have a valid account with account holder details")]
        public void GivenIHaveAValidAccountWithAccountHolderDetails()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.ValidCardAccountId
                    : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var request = _dataFixtureReader.Read(
                @"FirstData\CustomerDemographicInquiry\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );
            
            var response = _dataFixtureReader.Read(
                @"FirstData\CustomerDemographicInquiry\200.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
                );

            _mock
                .GivenRequest(request)
                .WithRequiredParam("custAcctCardNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.CustomerDemographicInquiry)
                .ThenReturnAsync(response)
                .Wait();
        }

        [When(@"I ask for an account holder details")]
        public void WhenIAskForAnAccountHolderDetails()
        {
            _scenarioContext.Set(CallGetAccountHolderEndpoint(Config.CardAccount.CardAccountId), "response");
        }

        [When(@"I ask for an account holder details again")]
        public void WhenIAskForAnAccountHolderDetailsAgain()
        {
            WhenIAskForAnAccountHolderDetails();
        }

        [When(@"I ask for an account holder details with invalid account number")]
        public void WhenIAskForAnAccountHolderDetailsWithInvalidAccountNumber()
        {
            _scenarioContext.Set(CallGetAccountHolderEndpoint("123"), "response");
        }

        [Then(@"the result returns expected account holder details from ""(.*)""")]
        public void ThenTheResultReturnsExpectedAccountHolderDetailsFrom(string dataSource)
        {
            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("response");
            httpResponseMessage.StatusCode.ToString().Should().BeOneOf("NonAuthoritativeInformation", "OK");
            
            if (TestContext.IsFirstData()) return;
            
            var expectedResponse = _dataFixtureReader.Read(
                @"CardAccount\GetAccountHolder\response.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            var actualResponse = httpResponseMessage.Content.ReadAsStringAsync().Result;
            actualResponse.Should().MatchJson(expectedResponse);
        }

        [Given(@"account holder details are stored in cache")]
        public void GivenAccountHolderDetailsAreStoredInCache()
        {
            CallGetAccountHolderEndpoint(Config.CardAccount.CardAccountId);
        }

        private HttpResponseMessage CallGetAccountHolderEndpoint(string cardAccountId)
        {
            var request = _dataFixtureReader.Read(
                @"CardAccount\GetAccountHolder\request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", cardAccountId } }
            );

            return _cardAccountClient.Post(CardAccountEndpoints.GetAccountHolder, request);
        }

        [Given(@"Account holder details not exists for my account")]
        public void AccountHolderDetailsNotExistsForMyAccount()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.AccountNotFoundAccountId
                    : AccountNumberGenerator.Generate();

            var request = _dataFixtureReader.Read(
                @"FirstData\CustomerDemographicInquiry\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );
            
            var response = _dataFixtureReader.Read(
                @"FirstData\CustomerDemographicInquiry\465_AccountNotFound.json"
            );

            _mock
                .GivenRequest(request)
                .WithRequiredParam("custAcctCardNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.CustomerDemographicInquiry)
                .ThenReturnAsync(response, 465)
                .Wait();
        }

        [Given(@"Account holder details not exists for not existing organisation")]
        public void AccountHolderDetailsNotExistsForNotExistingOrganisation()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.InvalidOrgAccountId
                    : AccountNumberGenerator.Generate();

            var response = _dataFixtureReader.Read(
                @"FirstData\CustomerDemographicInquiry\465_OrganisationNotFound.json"
            );
            
            var request = _dataFixtureReader.Read(
                @"FirstData\CustomerDemographicInquiry\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            _mock
                .GivenRequest(request)
                .WithRequiredParam("custAcctCardNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.CustomerDemographicInquiry)
                .ThenReturnAsync(response, 465)
                .Wait();
        }
    }
}
