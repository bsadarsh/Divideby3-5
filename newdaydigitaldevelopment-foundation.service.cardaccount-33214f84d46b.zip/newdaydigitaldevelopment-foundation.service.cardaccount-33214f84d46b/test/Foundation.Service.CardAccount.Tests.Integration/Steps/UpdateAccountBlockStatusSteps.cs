﻿using System.Collections.Generic;
using System.Net.Http;
using FluentAssertions;
using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    public class UpdateAccountBlockStatusSteps
    {
        private readonly ScenarioContext _scenarioContext;
        private readonly Mock _mock;
        private readonly IHttpApiClient _apiClient;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly MockConfiguration _mockConfiguration;

        public UpdateAccountBlockStatusSteps(Mock mock, ScenarioContext scenarioContext, IHttpApiClient apiClient, IDataFixtureReader dataFixtureReader, MockConfiguration mockConfiguration)
        {
            _mock = mock;
            _scenarioContext = scenarioContext;
            _apiClient = apiClient;
            _dataFixtureReader = dataFixtureReader;
            _mockConfiguration = mockConfiguration;
        }

        [When(@"I request the Update account block status with valid status and subStatus combination")]
        public void WhenIRequestTheUpdateAccountBlockStatusWithValidStatusAndSubStatusCombination()
        {
            if (TestContext.IsFirstData()) return;
            Config.CardAccount.CardNumber = AccountNumberGenerator.Generate();
            Config.CardAccount.CardAccountId = AccountNumberGenerator.Generate();

            var fdRequest = _dataFixtureReader.Read(@"FirstData\AccountBlockCodeUpdateV1\Request.json",
                new Dictionary<string, object>
                {
                    {"CARD_NUMBER", Config.CardAccount.CardNumber},
                    {"BLOCKCODE", "A"},
                    {"SUBSTATUS", "01"},
                    {"FUNCTIONADD", "B"}
                });

            var fdResponse = _dataFixtureReader.Read(@"FirstData\AccountBlockCodeUpdateV1\200.json",
                new Dictionary<string, object> {{"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId}});

            AddToMock(fdRequest, fdResponse);

            var request = _dataFixtureReader.Read(
                @"CardAccount\UpdateAccountBlockStatus\request.json",
                new Dictionary<string, object> {{"CARD_NUMBER", Config.CardAccount.CardNumber},
                    {"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId},
                    {"STATUS", "COLHOLDOUT"},
                    {"SUBSTATUS", "BREATHING_SPACE"}
                });
            _scenarioContext.Set(CallUpdateAccountBlockCodes(request), "response");
        }

        [When(@"I request the Update account block status with invalid status and substatus combination")]
        public void WhenIRequestTheUpdateAccountBlockStatusWithInvalidStatusAndSubStatusCombination()
        {
            if (TestContext.IsFirstData()) return;
            Config.CardAccount.CardNumber = AccountNumberGenerator.Generate();
            Config.CardAccount.CardAccountId = AccountNumberGenerator.Generate();

            var request = _dataFixtureReader.Read(
                @"CardAccount\UpdateAccountBlockStatus\request.json",
                new Dictionary<string, object> {{"CARD_NUMBER", Config.CardAccount.CardNumber},
                    {"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId},
                    {"STATUS", "NORMAL"},
                    {"SUBSTATUS", "BREATHING_SPACE"}
                });
            _scenarioContext.Set(CallUpdateAccountBlockCodes(request), "response");
        }

        [When(@"I request the update account block status without substatus")]
        public void WhenIRequestTheUpdateAccountBlockStatusWithoutSubStatus()
        {
            if (TestContext.IsFirstData()) return;
            Config.CardAccount.CardNumber = AccountNumberGenerator.Generate();
            Config.CardAccount.CardAccountId = AccountNumberGenerator.Generate();

            var fdRequest = _dataFixtureReader.Read(@"FirstData\AccountBlockCodeUpdateV1\RequestWithoutSubStatus.json",
                new Dictionary<string, object>
                {
                    {"CARD_NUMBER", Config.CardAccount.CardNumber},
                    {"BLOCKCODE", ""},
                    {"FUNCTIONADD", "U"}
                });

            var fdResponse = _dataFixtureReader.Read(@"FirstData\AccountBlockCodeUpdateV1\200.json",
                new Dictionary<string, object> {{"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId}});

            AddToMock(fdRequest, fdResponse);

            var request = _dataFixtureReader.Read(
                @"CardAccount\UpdateAccountBlockStatus\request.json",
                new Dictionary<string, object> {{"CARD_NUMBER", Config.CardAccount.CardNumber},
                    {"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId},
                    {"STATUS", "NORMAL"},
                    {"SUBSTATUS", ""}
                });

            _scenarioContext.Set(CallUpdateAccountBlockCodes(request), "response");
        }

        [When(@"I request the update account block to NFA status without substatus")]
        public void WhenIRequestTheUpdateAccountBlockToNfaStatusWithoutSubstatus()
        {
            if (TestContext.IsFirstData()) return;

            var fdRequest = _dataFixtureReader.Read(@"FirstData\AccountBlockCodeUpdateV1\RequestWithoutSubStatus.json",
                new Dictionary<string, object>
                {
                    {"CARD_NUMBER", "5368391039455561"},
                    {"BLOCK_CODE", "N"},
                    {"FUNCTIONCD", "B"},
                    {"RESTRUCTURE_CODE", "Y"}
                });

            var fdResponse = _dataFixtureReader.Read(@"FirstData\AccountBlockCodeUpdateV1\200.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", "7365010001844912" } });

            AddToMock(fdRequest, fdResponse);

            var request = _dataFixtureReader.Read(
                @"CardAccount\UpdateAccountBlockStatus\request.json",
                new Dictionary<string, object> {{"CARD_NUMBER", "5368391039455561"},
                    {"ACCOUNT_NUMBER", "7365010001844912"},
                    {"STATUS", "NFA"},
                    {"SUBSTATUS", ""}
                });

            _scenarioContext.Set(CallUpdateAccountBlockCodes(request), "response");
        }

        [Then(@"I verify the response is OK")]
        public void ThenIVerifyTheResponseIsOk()
        {
            if (TestContext.IsFirstData()) return;
            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("response");
            httpResponseMessage.StatusCode.ToString().Should().BeOneOf("NonAuthoritativeInformation", "OK");
        }

        private void AddToMock(string request, string response)
        {
            _mock.GivenRequest(request)
                .WithRequiredParam("cardNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountBlockCodeUpdate)
                .ThenReturnAsync(response)
                .Wait();
        }

        private HttpResponseMessage CallUpdateAccountBlockCodes(string request)
        {
            var response = _apiClient.Post(CardAccountEndpoints.UpdateAccountBlockCodes, request);
            return response;
        }

        [When(@"I request the Update account for block code")]
        public void WhenIRequestTheUpdateAccountForBlockCode()
        {

            Config.CardAccount.CardAccountId =
                    TestContext.IsFirstData() ?
                        _mockConfiguration.ValidCardAccountIdCustomField
                        : AccountNumberGenerator.Generate();
            if (TestContext.IsFirstData()) return;

            var mockRequest = _dataFixtureReader.Read(
                @"FirstData\ExtendUpdateAccount\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
                );
            var mockResponse = _dataFixtureReader.Read(
                @"FirstData\ExtendUpdateAccount\Response.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
                );

            _mock
                .GivenRequest(mockRequest)
                .WithRequiredParam("cardNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.UpdateAccountBlockCode)
                .ThenReturnAsync(mockResponse)
                .Wait();
        }

        [Then(@"I hit the UpdateAccount endpoint with status field")]
        public void ThenIHitTheUpdateAccountEndpointWithStatusField()
        {

            var request = _dataFixtureReader.Read(
                    @"CardAccount\ExtendUpdateAccount\Request_Status.json",
                    new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
                );

            _scenarioContext.Set(_apiClient.Post(CardAccountEndpoints.UpdateAccount, request), "response");

        }
        [Then(@"I hit the UpdateAccount endpoint with statusindicator field")]
        public void ThenIHitTheUpdateAccountEndpointWithStatusindicatorField()
        {
            var request = _dataFixtureReader.Read(
                @"CardAccount\ExtendUpdateAccount\Request_StatusIndicator.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            _scenarioContext.Set(_apiClient.Post(CardAccountEndpoints.UpdateAccount, request), "response");

        }

        [Then(@"I hit the UpdateAccount endpoint with function ""(.*)"" field and status ""(.*)""")]
        public void ThenIHitTheUpdateAccountEndpointWithFunctionFieldAndStatus(string functioncode, string status)
        {
         
        var request = _dataFixtureReader.Read(
               @"CardAccount\ExtendUpdateAccount\Request_FunctionCode.json",
               new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId }, { "FUNCTION_CODE", functioncode }, { "STATUS", status } }
           );
            _scenarioContext.Clear();
            _scenarioContext.Set(_apiClient.Post(CardAccountEndpoints.UpdateAccount, request), "response");
        }

        [When(@"I request the valid block code from account enquiry")]
        public void WhenIRequestTheValidBlockCodeFromAccountEnquiry()
        {

            var enquiryRequest = _dataFixtureReader.Read(
                 @"FirstData\AccountDetailInquiryV3\Request.json",
                 new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
                 );
            var enquiryResponse = _dataFixtureReader.Read(
                @"FirstData\AccountDetailInquiryV3\Response_BlockCode.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
                );

            _mock
                .GivenRequest(enquiryRequest)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountDetailInquiryV3)
                .ThenReturnAsync(enquiryResponse)
                .Wait();

        }        
    }
}