﻿using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using System;
using System.Collections.Generic;
using System.Net.Http;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    public class ReAgeAccountSteps
    {
        private readonly ScenarioContext _scenarioContext;
        private readonly Mock _mock;
        private readonly IHttpApiClient _apiClient;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly MockConfiguration _mockConfiguration;
        private string foundationRequest = null;

        public ReAgeAccountSteps(
            IHttpApiClient apiClient,
            ScenarioContext scenarioContext,
            Mock mock,
            IDataFixtureReader dataFixtureReader,
            MockConfiguration mockConfiguration
        )
        {
            _apiClient = apiClient;
            _scenarioContext = scenarioContext;
            _mock = mock;
            _dataFixtureReader = dataFixtureReader;
            _mockConfiguration = mockConfiguration;
        }

        [Given(@"I have entered valid AccountNumber to increase the due bucket for ""(.*)""")]
        public void GivenIHaveEnteredValidAccountNumberToIncreaseTheDueBucketFor(string ReAgeBy)
        {
           if(ReAgeBy.ToUpper().Equals("REAGEBYAMOUNT")) {
                Config.CardAccount.CardAccountId =
               TestContext.IsFirstData() ?
           _mockConfiguration.CardAccountForUATReAgeByAmount
                   : AccountNumberGenerator.Generate();
            }
            else
            {
                Config.CardAccount.CardAccountId =
               TestContext.IsFirstData() ?
           _mockConfiguration.CardAccountForUATReAgeByCode
                   : AccountNumberGenerator.Generate();
            }
            

            if (TestContext.IsFirstData()) return;

            var DelinquencyInquiryRequest = _dataFixtureReader.Read(
                @"FirstData\ReAgeAccount\DelinquencyInquiryRequest.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            
            var DelinquencyInquiryResponse = _dataFixtureReader.Read(
                @"FirstData\ReAgeAccount\DelinquencyInquiryResponse_ByAmount.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId },
                    { "CURR_DUE", "4277" },{ "PAST_DUE", "0" },{ "DAYS_30","0"},
                    { "DAYS_60","0"},{ "DAYS_90","0"},{ "DAYS_120","0"},
                    { "DAYS_150","0"},{ "DAYS_180","0"},{ "DAYS_210","0"}, { "TOTAL_DUE", "4277" }}
            );

            var DelinquencyUpdateRequest = _dataFixtureReader.Read(
                @"FirstData\ReAgeAccount\DelinquencyUpdateRequest.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId },
                { "TOTAL_DUE", "4277" },{"ACTION", "C" },
                {"CURR_DUE", "4277" },{"PAST_DUE", "50002" },{ "DAYS_30","4477"},
                { "DAYS_60","4577"},{ "DAYS_90","4677"},{ "DAYS_120","4777"},
                { "DAYS_150","4877"},{ "DAYS_180","4977"},{ "DAYS_210","5077"}}
            );

            var DelinquencyUpdateResponse = _dataFixtureReader.Read(
                @"FirstData\ReAgeAccount\DelinquencyUpdateResponse_ByAmount.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId },
                {"TOTAL_DUE", "87718" },{"CURR_DUE", "4277" },{"PAST_DUE", "50002" },
                { "DAYS_30","4477"},{ "DAYS_60","4577"},{ "DAYS_90","4677"},
                { "DAYS_120","4777"},{ "DAYS_150","4877"},{ "DAYS_180","4977"},{ "DAYS_210","5077"},
                {"DIFF_IN_DUE", "0" } }
            );

            _mock
                .GivenRequest(DelinquencyInquiryRequest)
                .WithRequiredParam("acctNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.DelinquencyAdjustmentsInquiry)
                .ThenReturnAsync(DelinquencyInquiryResponse, 200)
                .Wait();

            _mock
                .GivenRequest(DelinquencyUpdateRequest)
                .WithRequiredParam("cardNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.DelinquencyAdjustmentUpdate)
                .ThenReturnAsync(DelinquencyUpdateResponse, 200)
                .Wait();
        }

        [Given(@"I have entered valid AccountNumber to decrease the due bucket using ReAgeByAmount")]
        public void GivenIHaveEnteredValidAccountNumberToDecreaseTheDueBucketUsingReAgeByAmount()
        {
            if (TestContext.IsFirstData()) return;

            var DelinquencyInquiryRequest = _dataFixtureReader.Read(
               @"FirstData\ReAgeAccount\DelinquencyInquiryRequest.json",
               new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
           );


            var DelinquencyInquiryResponse = _dataFixtureReader.Read(
                @"FirstData\ReAgeAccount\DelinquencyInquiryResponse_ByAmount.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId },
                { "CURR_DUE", "4277" },
                { "PAST_DUE", "50002" },
                { "DAYS_30","4477"},{ "DAYS_60","4577"},{ "DAYS_90","4677"},
                { "DAYS_120","4777"},{ "DAYS_150","4877"},{ "DAYS_180","4977"},{ "DAYS_210","5077"},
                { "TOTAL_DUE" , "87718"} }
            );

            var DelinquencyUpdateRequest = _dataFixtureReader.Read(
               @"FirstData\ReAgeAccount\DelinquencyUpdateRequest.json",
               new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId },
               { "TOTAL_DUE", "87718" },{ "ACTION", "C" },{"REAGE_CODE","x"},
                { "CURR_DUE", "4277" },{ "PAST_DUE", "0" },{ "DAYS_30","0"},
                { "DAYS_60","0"},{ "DAYS_90","0"},{ "DAYS_120","0"},
                { "DAYS_150","0"},{ "DAYS_180","0"},{ "DAYS_210","0"} }
           );

            var DelinquencyUpdateResponse = _dataFixtureReader.Read(
                @"FirstData\ReAgeAccount\DelinquencyUpdateResponse_ByAmount.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId },
                {"TOTAL_DUE", "4277" },
                {"CURR_DUE", "4277" },{"PAST_DUE", "0" },
                {"DAYS_30", "0" },{ "DAYS_60","0"},{ "DAYS_90","0"},{ "DAYS_120","0"},
                { "DAYS_150","0"},{ "DAYS_180","0"},{ "DAYS_210","0"}, {"DIFF_IN_DUE","0" } }
            );

            _mock
               .GivenRequest(DelinquencyInquiryRequest)
               .WithRequiredParam("acctNbr")
               .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.DelinquencyAdjustmentsInquiry)
               .ThenReturnAsync(DelinquencyInquiryResponse, 200)
               .Wait();

            _mock
                .GivenRequest(DelinquencyUpdateRequest)
                .WithRequiredParam("cardNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.DelinquencyAdjustmentUpdate)
                .ThenReturnAsync(DelinquencyUpdateResponse, 200)
                .Wait();

        }

        [Then(@"I hit the ReAgeByAmount endpoint to increase the due bucket")]
        public void ThenIHitTheReAgeByAmountEndpointToIncreaseTheDueBucket()
        {
        
            foundationRequest = _dataFixtureReader.Read(@"CardAccount\ReAgeByAmount\AddDue_ReAgeByAmount_Request.json",
                new Dictionary<string, object>
                {
                        {"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId},
                }
            );
            _scenarioContext.Clear();
            _scenarioContext.Set(_apiClient.Post(CardAccountEndpoints.ReAgeByAmount, foundationRequest), "response");

        }

        [Then(@"I hit the ReAgeByAmount endpoint to decrease the due bucket")]
        public void ThenIHitTheReAgeByAmountEndpointToDecreaseTheDueBucket()
        {
           foundationRequest = _dataFixtureReader.Read(@"CardAccount\ReAgeByAmount\ReAgeByAmount_Request.json",
                new Dictionary<string, object>
                {
                        {"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId},
                }
            );
            _scenarioContext.Clear();
            _scenarioContext.Set(_apiClient.Post(CardAccountEndpoints.ReAgeByAmount, foundationRequest), "response");

        }

        [Then(@"I hit the ReAgeByAmount endpoint with due amount greater than current balance using ReAgeByAmount")]
        public void ThenIHitTheReAgeByAmountEndpointWithDueAmountGreaterThanCurrentBalanceUsingReAgeByAmount()
        {
            foundationRequest = _dataFixtureReader.Read(@"CardAccount\ReAgeByAmount\DueGreater_ReAgeByAmount_Request.json",
                new Dictionary<string, object>
                {
                        {"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId},
                }
            );
            _scenarioContext.Clear();
            _scenarioContext.Set(_apiClient.Post(CardAccountEndpoints.ReAgeByAmount, foundationRequest), "response");

        }
        
        [Given(@"I have entered valid AccountNumber to decrease the due bucket using ReAgeByCode")]
        public void GivenIHaveEnteredValidAccountNumberToDecreaseTheDueBucketUsingReAgeByCode()
        {
            if (TestContext.IsFirstData()) return;

            var DelinquencyInquiryRequest = _dataFixtureReader.Read(
               @"FirstData\ReAgeAccount\DelinquencyInquiryRequest.json",
               new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
           );

            var DelinquencyInquiryResponse = _dataFixtureReader.Read(
                 @"FirstData\ReAgeAccount\DelinquencyInquiryResponse_ByAmount.json",
                 new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId },
                { "CURR_DUE", "4277" },
                { "PAST_DUE", "50002" },
                { "DAYS_30","4477"},{ "DAYS_60","4577"},{ "DAYS_90","4677"},
                { "DAYS_120","4777"},{ "DAYS_150","4877"},{ "DAYS_180","4977"},{ "DAYS_210","5077"},
                { "TOTAL_DUE" , "87718"} }
             );

            var DelinquencyUpdateRequest = _dataFixtureReader.Read(
               @"FirstData\ReAgeAccount\DelinquencyUpdateRequest.json",
               new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId },
               { "TOTAL_DUE", "87718" },{ "ACTION", "C" },{"REAGE_CODE","1"},
                { "CURR_DUE", "4277" },{ "PAST_DUE", "0" },{ "DAYS_30","0"},
                { "DAYS_60","0"},{ "DAYS_90","0"},{ "DAYS_120","0"},
                { "DAYS_150","0"},{ "DAYS_180","0"},{ "DAYS_210","0"} }
           );

            var DelinquencyUpdateResponse = _dataFixtureReader.Read(
                @"FirstData\ReAgeAccount\DelinquencyUpdateResponse_ByAmount.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId },
                {"TOTAL_DUE", "4277" }, 
                {"CURR_DUE", "4277" },{"PAST_DUE", "0" },
                {"DAYS_30", "0" },{ "DAYS_60","0"},{ "DAYS_90","0"},{ "DAYS_120","0"},
                { "DAYS_150","0"},{ "DAYS_180","0"},{ "DAYS_210","0"},{"DIFF_IN_DUE","0" } }
            );

            _mock
               .GivenRequest(DelinquencyInquiryRequest)
               .WithRequiredParam("acctNbr")
               .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.DelinquencyAdjustmentsInquiry)
               .ThenReturnAsync(DelinquencyInquiryResponse, 200)
               .Wait();

            _mock
                .GivenRequest(DelinquencyUpdateRequest)
                .WithRequiredParam("cardNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.DelinquencyAdjustmentUpdate)
                .ThenReturnAsync(DelinquencyUpdateResponse, 200)
                .Wait();
        }

        [Then(@"I hit the ReAgeByCode endpoint to decrease the due bucket with delinquency code ""(.*)""")]
        public void ThenIHitTheReAgeByCodeEndpointToDecreaseTheDueBucketWithDelinquencyCode(string Code)
        {
        foundationRequest = _dataFixtureReader.Read(@"CardAccount\ReAgeByCode\ReAgeByCode_Request.json",
                new Dictionary<string, object>
                {
                        {"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId},
                        {"CODE", Code}}
            );
            _scenarioContext.Clear();
            _scenarioContext.Set(_apiClient.Post(CardAccountEndpoints.ReAgeByCode, foundationRequest), "response");
        }

        [Given(@"I have entered valid AccountNumber with DifferenceInDue is greater than Zero")]
        public void GivenIHaveEnteredValidAccountNumberWithDifferenceInDueIsGreaterThanZero()
        {
            Config.CardAccount.CardAccountId =
               TestContext.IsFirstData() ?
           _mockConfiguration.CardAccountForUATReAgeByAmount
                   : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var DelinquencyInquiryRequest = _dataFixtureReader.Read(
               @"FirstData\ReAgeAccount\DelinquencyInquiryRequest.json",
               new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
           );


            var DelinquencyInquiryResponse = _dataFixtureReader.Read(
                @"FirstData\ReAgeAccount\DelinquencyInquiryResponse_ByAmount.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId },
                { "CURR_DUE", "4277" },
                { "PAST_DUE", "50002" },
                { "DAYS_30","4477"},{ "DAYS_60","4577"},{ "DAYS_90","4677"},
                { "DAYS_120","4777"},{ "DAYS_150","4877"},{ "DAYS_180","4977"},{ "DAYS_210","5077"},
                { "TOTAL_DUE" , "87718"} }
            );

            var DelinquencyUpdateRequest = _dataFixtureReader.Read(
               @"FirstData\ReAgeAccount\DelinquencyUpdateRequest.json",
               new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId },
               { "TOTAL_DUE", "87718" },{ "ACTION", "C" },{"REAGE_CODE","x"},
                { "CURR_DUE", "4277" },{ "PAST_DUE", "0" },{ "DAYS_30","0"},
                { "DAYS_60","0"},{ "DAYS_90","0"},{ "DAYS_120","0"},
                { "DAYS_150","0"},{ "DAYS_180","0"},{ "DAYS_210","0"} }
           );

            var DelinquencyUpdateResponse = _dataFixtureReader.Read(
                @"FirstData\ReAgeAccount\DelinquencyUpdateResponse_ByAmount.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId },
                {"TOTAL_DUE", "4277" },
                {"CURR_DUE", "4277" },{"PAST_DUE", "0" },
                {"DAYS_30", "0" },{ "DAYS_60","0"},{ "DAYS_90","0"},{ "DAYS_120","0"},
                { "DAYS_150","0"},{ "DAYS_180","0"},{ "DAYS_210","0"}, {"DIFF_IN_DUE","20" } }
            );

            _mock
               .GivenRequest(DelinquencyInquiryRequest)
               .WithRequiredParam("acctNbr")
               .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.DelinquencyAdjustmentsInquiry)
               .ThenReturnAsync(DelinquencyInquiryResponse, 200)
               .Wait();

            _mock
                .GivenRequest(DelinquencyUpdateRequest)
                .WithRequiredParam("cardNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.DelinquencyAdjustmentUpdate)
                .ThenReturnAsync(DelinquencyUpdateResponse, 200)
                .Wait();


        }
    }
}
