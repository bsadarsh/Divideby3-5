﻿using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using System.Collections.Generic;
using System.Net.Http;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    class ChargeOff
    {
        private readonly Mock _mock;
        private readonly IHttpApiClient _cardAccountClient;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly ScenarioContext _scenarioContext;
        private readonly MockConfiguration _mockConfiguration;
       

        public ChargeOff(
            ScenarioContext scenarioContext,
            Mock mock,
            IHttpApiClient cardAccountClient,
            IDataFixtureReader dataFixtureReader,
            MockConfiguration mockConfiguration)
        {
            _scenarioContext = scenarioContext;
            _mock = mock;
            _cardAccountClient = cardAccountClient;
            _dataFixtureReader = dataFixtureReader;
            _mockConfiguration = mockConfiguration;
        }

        [Given(@"I have entered valid Accountnumber with (.*)")]
        public void GivenIHaveEnteredValidAccountnumberWithC(string reasoncode)
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.CardAccountForUATChargeOff
                    : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var request = _dataFixtureReader.Read(
                @"FirstData\ChargeOff\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId }, { "Reasoncode", reasoncode } }
            );

            var response = _dataFixtureReader.Read(
                @"FirstData\ChargeOff\200_Response.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );



            _mock
                .GivenRequest(request)
                .WithRequiredParam("acctNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.Accountclose)
                .ThenReturnAsync(response)
                .Wait();
        }

        [When(@"I hit the Chargeoff endpoint with (.*)")]
        public void WhenIHitTheChargeoffEndpointWithC(string reasoncode)
        {
            _scenarioContext.Set(CallChargeOffRequestEndpoint(Config.CardAccount.CardAccountId, reasoncode), "response");
        }


        private HttpResponseMessage CallChargeOffRequestEndpoint(string cardAccountId, string reasoncode)
        {

            var request = _dataFixtureReader.Read(
                @"CardAccount\ChargeOff\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", cardAccountId }, { "Reasoncode", reasoncode } }
            );

            return _cardAccountClient.Post(CardAccountEndpoints.ChargeOff, request);
        }

        [Given(@"I have entered an valid input details")]
        public void GivenIHaveEnteredAnValidInputDetails()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.CardAccountForUATChargeOff
                    : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var request = _dataFixtureReader.Read(
                @"FirstData\ChargeOff\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            var response = _dataFixtureReader.Read(
                @"FirstData\ChargeOff\200_Response.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );



            _mock
                .GivenRequest(request)
                .WithRequiredParam("acctNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.Accountclose)
                .ThenReturnAsync(response)
                .Wait();
        }


        [When(@"I hit ChargeOff endpoint with invalid input details")]
        public void WhenIHitChargeOffEndpointWithInvalidInputDetails()
        {
            _scenarioContext.Set(CallInvalidChargeOffRequestEndpoint(Config.CardAccount.CardAccountId), "response");
        }

        private HttpResponseMessage CallInvalidChargeOffRequestEndpoint(string cardAccountId)
        {

            var request = _dataFixtureReader.Read(
                @"CardAccount\ChargeOff\InvalidRequest.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", cardAccountId } }
            );

            return _cardAccountClient.Post(CardAccountEndpoints.ChargeOff, request);
        }
    }
}
