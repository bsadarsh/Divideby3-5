﻿using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using FluentAssertions;
using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Extensions;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    public sealed class UpdateBillingCycleSteps
    {
        private readonly ScenarioContext _scenarioContext;
        private readonly Mock _mock;
        private readonly IHttpApiClient _apiClient;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly MockConfiguration _mockConfiguration;

        public UpdateBillingCycleSteps(
            IHttpApiClient apiClient,
            ScenarioContext scenarioContext,
            Mock mock,
            IDataFixtureReader dataFixtureReader,
            MockConfiguration mockConfiguration)
        {
            _apiClient = apiClient;
            _scenarioContext = scenarioContext;
            _mock = mock;
            _dataFixtureReader = dataFixtureReader;
            _mockConfiguration = mockConfiguration;
        }

        [Given(@"I want to validate successful response of UpdateBillingCycle endpoint with a valid request body")]
        public void GivenIWantToValidateSuccessfulResponseOfUpdateBillingCycleEndpointWithAValidRequestBody()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.ValidCardAccountId
                    : AccountNumberGenerator.Generate();

            var foundationRequest = _dataFixtureReader.Read(@"CardAccount\UpdateBillingCycle\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );
            _scenarioContext.Set(foundationRequest, "FoundationRequest");

            if (TestContext.IsFirstData()) return;

            var mockRequest = _dataFixtureReader.Read(
                @"FirstData\BillingCycleUpdate\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
                );
            var mockResponse = _dataFixtureReader.Read(
                @"FirstData\BillingCycleUpdate\200_response.json");

            _mock
                .GivenRequest(mockRequest)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.BillingCycleUpdate)
                .ThenReturnAsync(mockResponse)
                .Wait();
        }

        [When(@"I request the Update account for block code status")]
        public void WhenIRequestTheUpdateAccountForBlockCodeStatus()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.ValidCardAccountIdCustomField
                    : AccountNumberGenerator.Generate();
            if (TestContext.IsFirstData()) return;

            var mockRequest = _dataFixtureReader.Read(
                @"FirstData\UpdateAccountBlockCode\request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
                );
            var mockResponse = _dataFixtureReader.Read(
                @"FirstData\UpdateAccountBlockCode\response.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
                );

            _mock
                .GivenRequest(mockRequest)
                .WithRequiredParam("cardNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.UpdateAccountBlockCode)
                .ThenReturnAsync(mockResponse)
                .Wait();
        }

        [When(@"I request the Update account for CustomFields")]
        public void WhenIRequestTheUpdateAccountForCustomFields()
        {
            Config.CardAccount.CardAccountId =
                 TestContext.IsFirstData() ?
                     _mockConfiguration.ValidCardAccountIdCustomField
                     : AccountNumberGenerator.Generate();
            if (TestContext.IsFirstData()) return;

            var mockRequest = _dataFixtureReader.Read(
                @"FirstData\UpdateCardAccountCustomField\request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
                );
            var mockResponse = _dataFixtureReader.Read(
                @"FirstData\UpdateCardAccountCustomField\response.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
                );

            _mock
                .GivenRequest(mockRequest)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.UpdateAccountCustomField)
                .ThenReturnAsync(mockResponse)
                .Wait();
        }

        [When(@"I request remove fixed payment Update account for CustomFields")]
        public void WhenIRequestRemoveFixedPaymentUpdateAccountForCustomFields()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.ValidCardAccountIdCustomField
                    : AccountNumberGenerator.Generate();
            if (TestContext.IsFirstData()) return;

            var mockRequest = _dataFixtureReader.Read(
                @"FirstData\UpdateCardAccountCustomField\request_RemoveFixed.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );
            var mockResponse = _dataFixtureReader.Read(
                @"FirstData\UpdateCardAccountCustomField\response.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            _mock
                .GivenRequest(mockRequest)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.UpdateAccountCustomField)
                .ThenReturnAsync(mockResponse)
                .Wait();
        }


        [When(@"I request the Update account for UserFields")]
        public void WhenIRequestTheUpdateAccountForUserFields()
        {
            Config.CardAccount.CardAccountId =
                  TestContext.IsFirstData() ?
                      _mockConfiguration.ValidCardAccountIdCustomField
                      : AccountNumberGenerator.Generate();
            if (TestContext.IsFirstData()) return;

            var mockRequest = _dataFixtureReader.Read(
                @"FirstData\UpdateAccountUserFields\request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
                );
            var mockResponse = _dataFixtureReader.Read(
                @"FirstData\UpdateAccountUserFields\response.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
                );

            _mock
                .GivenRequest(mockRequest)
                .WithRequiredParam("acctNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.UpdateAccountUserField)
                .ThenReturnAsync(mockResponse)
                .Wait();
        }

        [When(@"I request the Update account for DisabilityIndicator")]
        public void WhenIRequestTheUpdateAccountForDisabilityIndicator()
        {
            Config.CardAccount.CardAccountId =
                   TestContext.IsFirstData() ?
                       _mockConfiguration.ValidCardAccountIdCustomField
                       : AccountNumberGenerator.Generate();
            if (TestContext.IsFirstData()) return;

            var mockRequest = _dataFixtureReader.Read(
                @"UpdateAccountDisabilityIndicator\request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
                );
            var mockResponse = _dataFixtureReader.Read(
                @"UpdateAccountDisabilityIndicator\response.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
                );

            _mock
                .GivenRequest(mockRequest)
                .WithRequiredParam("acctNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.UpdateAccountDisabilityIndicator)
                .ThenReturnAsync(mockResponse)
                .Wait();
        }


        [Then(@"I hit the UpdateAccount endpoint")]
        public void ThenIHitTheUpdateAccountEndpoint()
        {
            _scenarioContext.Set(CallGetUpdateAccountEndpoint(Config.CardAccount.CardAccountId), "response");
        }

        private HttpResponseMessage CallGetUpdateAccountEndpoint(string cardAccountId)
        {

            var request = _dataFixtureReader.Read(
                @"CardAccount\UpdateAccountBlockCode\request.json",
                 new Dictionary<string, object> { { "ACCOUNT_NUMBER", cardAccountId }}
            );

            return _apiClient.Post(CardAccountEndpoints.UpdateAccount, request);
        }

        [Then(@"I hit the UpdateAccountCustomField endpoint")]
        public void ThenIHitTheUpdateAccountCustomFieldEndpoint()
        {
            _scenarioContext.Set(CallGetUpdateAccountCustomFieldEndpoint(Config.CardAccount.CardAccountId), "response");
        }

        private HttpResponseMessage CallGetUpdateAccountCustomFieldEndpoint(string cardAccountId)
        {

            var request = _dataFixtureReader.Read(
                @"CardAccount\UpdateCardAccountCustomField\request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", cardAccountId } }
            );

            return _apiClient.Post(CardAccountEndpoints.UpdateAccount, request);
        }

        [Then(@"I hit the UpdateAccountUserField endpoint")]
        public void ThenIHitTheUpdateAccountUserFieldEndpoint()
        {
            _scenarioContext.Set(CallGetUpdateAccountUserFieldEndpoint(Config.CardAccount.CardAccountId), "response");
        }

        private HttpResponseMessage CallGetUpdateAccountUserFieldEndpoint(string cardAccountId)
        {

            var request = _dataFixtureReader.Read(
                @"CardAccount\UpdateAccountUserFields\request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", cardAccountId } }
            );

            return _apiClient.Post(CardAccountEndpoints.UpdateAccount, request);
        }

        [Then(@"I hit the UpdateAccountDisabilityIndicator endpoint")]
        public void ThenIHitTheUpdateAccountDisabilityIndicatorEndpoint()
        {
            _scenarioContext.Set(CallGetUpdateAccountDisabilityIndicatorEndpoint(Config.CardAccount.CardAccountId), "response");
        }

        private HttpResponseMessage CallGetUpdateAccountDisabilityIndicatorEndpoint(string cardAccountId)
        {

            var request = _dataFixtureReader.Read(
                @"CardAccount\UpdateAccountDisabilityIndicator\request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", cardAccountId } }
            );

            return _apiClient.Post(CardAccountEndpoints.UpdateAccount, request);
        }

        [Then(@"I hit the invalid request UpdateAccountCustomField endpoint")]
        public void ThenIHitTheInvalidRequestUpdateAccountCustomFieldEndpoint()
        {
            _scenarioContext.Set(CallGetInvalidUpdateAccountCustomFieldEndpoint(Config.CardAccount.CardAccountId), "response");
        }

        private HttpResponseMessage CallGetInvalidUpdateAccountCustomFieldEndpoint(string cardAccountId)
        {

            var request = _dataFixtureReader.Read(
                @"CardAccount\UpdateCardAccountCustomField\InvalidRequest.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", cardAccountId } }
            );
            return _apiClient.Post(CardAccountEndpoints.UpdateAccount, request);
        }

        [Then(@"I hit the invalid fixedPaymentAmount request UpdateAccountCustomField endpoint")]
        public void ThenIHitTheInvalidFixedPaymentAmountRequestUpdateAccountCustomFieldEndpoint()
        {
            _scenarioContext.Set(CallGetInvalidFixedPayment(Config.CardAccount.CardAccountId), "response");
        }

        private HttpResponseMessage CallGetInvalidFixedPayment(string cardAccountId)
        {
            var request = _dataFixtureReader.Read(
                @"CardAccount\UpdateCardAccountCustomField\Invalidrequest_RemoveFixedPayment.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", cardAccountId } }
            );
            return _apiClient.Post(CardAccountEndpoints.UpdateAccount, request);
        }

        [Then(@"I hit the UpdateAccountCustomField endpoint by fixedPaymentAmount as zero")]
        public void ThenIHitTheUpdateAccountCustomFieldEndpointByFixedPaymentAmountAsZero()
        {
            _scenarioContext.Set(CallGetUpdateAccountRemoveFixedPayment(Config.CardAccount.CardAccountId), "response");
        }

        private HttpResponseMessage CallGetUpdateAccountRemoveFixedPayment(string cardAccountId)
        {

            var request = _dataFixtureReader.Read(
                @"CardAccount\UpdateCardAccountCustomField\request_RemoveFixedPayment.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", cardAccountId } }
            );

            return _apiClient.Post(CardAccountEndpoints.UpdateAccount, request);
        }

        [Then(@"I hit the invalid UpdateAccountUserField endpoint")]
        public void ThenIHitTheInvalidUpdateAccountUserFieldEndpoint()
        {
            _scenarioContext.Set(CallGetInvalidUpdateAccountUserFieldEndpoint(Config.CardAccount.CardAccountId), "response");
        }
        private HttpResponseMessage CallGetInvalidUpdateAccountUserFieldEndpoint(string cardAccountId)
        {

            var request = _dataFixtureReader.Read(
                @"CardAccount\UpdateAccountUserFields\InvalidRequest.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", cardAccountId } }
            );
            return _apiClient.Post(CardAccountEndpoints.UpdateAccount, request);
        }

        [Then(@"I hit the invalid UpdateAccountDisabilityIndicator endpoint")]
        public void ThenIHitTheInvalidUpdateAccountDisabilityIndicatorEndpoint()
        {
            _scenarioContext.Set(CallGetInvalidUpdateAccountDisabilityIndicatorEndpoint(Config.CardAccount.CardAccountId), "response");
        }
        private HttpResponseMessage CallGetInvalidUpdateAccountDisabilityIndicatorEndpoint(string cardAccountId)
        {

            var request = _dataFixtureReader.Read(
                @"CardAccount\UpdateAccountUserFields\InvalidRequest.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", cardAccountId } }
            );
            return _apiClient.Post(CardAccountEndpoints.UpdateAccount, request);
        }

        [Then(@"I verify the response is OK sucessfully ""(.*)""")]
        public void ThenIVerifyTheResponseIsOKSucessfully(HttpStatusCode expectedStatusCode)
        {
            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("response");
            httpResponseMessage.StatusCode.Should().Be(expectedStatusCode);
        }

        [Then(@"I verify the response is sucessfully ""(.*)""")]
        public void ThenIVerifyTheResponseIsSucessfully(HttpStatusCode expectedStatusCode)
        {
            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("response");
            httpResponseMessage.StatusCode.Should().Be(expectedStatusCode);
        }

        [Then(@"I hit the invalid request UpdateAccount endpoint")]
        public void ThenIHitTheInvalidRequestUpdateAccountEndpoint()
        {
            _scenarioContext.Set(CallGetInvalidUpdateAccountEndpoint(Config.CardAccount.CardAccountId), "response");
        }

        private HttpResponseMessage CallGetInvalidUpdateAccountEndpoint(string cardAccountId)
        {

            var request = _dataFixtureReader.Read(
                @"CardAccount\UpdateAccountBlockCode\InvalidRequest.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", cardAccountId } }
            );

            return _apiClient.Post(CardAccountEndpoints.UpdateAccount, request);
        }


        [When(@"I hit the UpdateBillingCycle endpoint")]
        public void WhenIHitTheUpdateBillingCycleEndpoint()
        {
            _scenarioContext.Set(CallUpdateBillingCycleEndpoint(), "UpdateBillingCycleResponse");
        }

        [Then(@"I receive successful response with status ""(.*)""")]
        public void ThenIReceiveSuccessfulResponseWithStatus(HttpStatusCode statusCode)
        {
            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("UpdateBillingCycleResponse");
            httpResponseMessage.StatusCode.Should().Be(statusCode);

            if (TestContext.IsFirstData()) return;

            var expectedResponse = _dataFixtureReader.Read(
                @"CardAccount\UpdateBillingCycle\200_response.json");

            var actualResponse = httpResponseMessage.Content.ReadAsStringAsync().Result;
            actualResponse.Should().MatchJson(expectedResponse);
        }

        [When(@"I hit the UpdateBillingCycle endpoint  with missing field ""(.*)""")]
        public void WhenIHitTheUpdateBillingCycleEndpointWithMissingField(string missingField)
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.ValidCardAccountId
                    : AccountNumberGenerator.Generate();

            if (missingField.Equals("CardAccountId"))
            {
                var foundationRequest = _dataFixtureReader.Read(@"CardAccount\UpdateBillingCycle\Bad_Request_1.json");
                _scenarioContext.Set(foundationRequest, "FoundationRequest");
            }
            else
            {
                var foundationRequest = _dataFixtureReader.Read(@"CardAccount\UpdateBillingCycle\Bad_Request_2.json",
                    new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
                );
                _scenarioContext.Set(foundationRequest, "FoundationRequest");
            }
            _scenarioContext.Set(CallUpdateBillingCycleEndpoint(), "response");
        }

        [When(@"I hit the UpdateBillingCycle endpoint  with invalid value of field ""(.*)""")]
        public void WhenIHitTheUpdateBillingCycleEndpointWithInvalidValueOfField(string invalidField)
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.ValidCardAccountId
                    : AccountNumberGenerator.Generate();

            if (invalidField.Equals("CardAccountId"))
            {
                var foundationRequest = _dataFixtureReader.Read(@"CardAccount\UpdateBillingCycle\Bad_Request_3.json");
                _scenarioContext.Set(foundationRequest, "FoundationRequest");
            }
            else
            {
                var foundationRequest = _dataFixtureReader.Read(@"CardAccount\UpdateBillingCycle\Bad_Request_4.json",
                    new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
                );
                _scenarioContext.Set(foundationRequest, "FoundationRequest");
            }
            _scenarioContext.Set(CallUpdateBillingCycleEndpoint(), "response");
        }


        private HttpResponseMessage CallUpdateBillingCycleEndpoint()
        {
            var  requestBody = _scenarioContext.Get<string>("FoundationRequest");
            var response = _apiClient.Post(CardAccountEndpoints.UpdateBillingCycle, requestBody);
            return response;
        }

        [When(@"I request the Update account for CustomFields with previous CardAccountId")]
        public void WhenIRequestTheUpdateAccountForCustomFieldsWithPreviousCardAccountId()
        {
            if (TestContext.IsFirstData()) return;

            var mockRequest = _dataFixtureReader.Read(
                @"FirstData\UpdateCardAccountCustomField\request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
                );
            var mockResponse = _dataFixtureReader.Read(
                @"FirstData\UpdateCardAccountCustomField\response.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
                );

            _mock
                .GivenRequest(mockRequest)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.UpdateAccountCustomField)
                .ThenReturnAsync(mockResponse)
                .Wait();

        }

        [When(@"I request the Update account with block code status ""(.*)""")]
        public void WhenIRequestTheUpdateAccountWithBlockCodeStatus(string blockCode)
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.ValidCardAccountIdCustomField
                    : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var mockRequest = _dataFixtureReader.Read(
                @"FirstData\UpdateAccountBlockCode\request_BlockCode.json",
                new Dictionary<string, object> { 
                    { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId }, 
                    { "BLOCK_CODE", blockCode } 
                }
            );

            var mockResponse = _dataFixtureReader.Read(
                @"FirstData\UpdateAccountBlockCode\response_BlockCode.json",
                new Dictionary<string, object> { 
                    { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId },
                    { "BLOCK_CODE", blockCode } 
                }
            );

            _mock
                .GivenRequest(mockRequest)
                .WithRequiredParam("cardNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.UpdateAccountBlockCode)
                .ThenReturnAsync(mockResponse)
                .Wait();
        }

        [Then(@"I hit the UpdateAccount endpoint with status ""(.*)""")]
        public void ThenIHitTheUpdateAccountEndpointWithStatus(string status)
        {
            _scenarioContext.Set(CallGetUpdateAccountEndpoint(Config.CardAccount.CardAccountId, status), "response");
        }       

        private HttpResponseMessage CallGetUpdateAccountEndpoint(string cardAccountId, string status)
        {
            var request = _dataFixtureReader.Read(
                @"CardAccount\UpdateAccountBlockCode\request_Status.json",
                 new Dictionary<string, object> { 
                     { "ACCOUNT_NUMBER", cardAccountId },
                     { "STATUS", status } 
                 }
            );
            return _apiClient.Post(CardAccountEndpoints.UpdateAccount, request);
        }

    }
}
