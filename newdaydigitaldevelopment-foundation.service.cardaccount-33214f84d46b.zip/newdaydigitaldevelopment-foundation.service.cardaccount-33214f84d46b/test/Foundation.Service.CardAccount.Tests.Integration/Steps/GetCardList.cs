﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using FluentAssertions;
using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using Newtonsoft.Json.Linq;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    public sealed class GetCardList
    {
        // For additional details on SpecFlow step definitions see https://go.specflow.org/doc-stepdef

        private readonly ScenarioContext _scenarioContext;
        private readonly Mock _mock;
        private readonly IHttpApiClient _apiClient;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly MockConfiguration _mockConfiguration;

        public GetCardList(
            IHttpApiClient apiClient,
            ScenarioContext scenarioContext,
            Mock mock,
            IDataFixtureReader dataFixtureReader, 
            MockConfiguration mockConfiguration)
        {
            _apiClient = apiClient;
            _scenarioContext = scenarioContext;
            _mock = mock;
            _dataFixtureReader = dataFixtureReader;
            _mockConfiguration = mockConfiguration;
        }

        [Given(@"I Want to validate the list of cards available for the accountholder")]
        public void GivenIWantToValidateTheListOfCardsAvailableForTheAccountHolder()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.ValidCardAccountId
                    : AccountNumberGenerator.Generate();

            var mockRequest = _dataFixtureReader.Read(
                @"FirstData\CardsListbyCard\Request.json", new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );
            var mockResponse = _dataFixtureReader.Read(
               @"FirstData\CardsListbyCard\200_response.json"
            );
            var mockRequest_cardInquiry = _dataFixtureReader.Read(
                @"FirstData\CardInquiry\request.json", new Dictionary<string, object> { { "ACCOUNT_NUMBER", "5474106917071848" } }
            );
            var mockResponse_cardInquiry = _dataFixtureReader.Read(
               @"FirstData\CardInquiry\200_response.json"
            );
            var foundationRequest = _dataFixtureReader.Read(
                @"CardAccount\GetCardList\request.json", new Dictionary<string, object> { { "CardAccountId", Config.CardAccount.CardAccountId } });
            _scenarioContext.Set(foundationRequest, "FoundationRequest");

            _mock
                .GivenRequest(mockRequest)
                .WithRequiredParam("cardNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.GetCardList)
                .ThenReturnAsync(mockResponse)
                .Wait();
            _mock
                .GivenRequest(mockRequest_cardInquiry)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.CardInquiry)
                .ThenReturnAsync(mockResponse_cardInquiry)
                .Wait();
        }
        [When(@"I hit the getcardsbyaccount service")]
        public void WhenIHitTheGetCardsByAccountService()
        {
            _scenarioContext.Set(GetCardListEndpoint(), "GetCardListResponse");
        }
        [Then(@"I verify the list of cards available for account holder")]
        public void ThenIVerifyTheListOfCardsAvailableForAccountHolder()
        {
            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("GetCardListResponse");
            var actualResponseJson = httpResponseMessage.Content.ReadAsStringAsync().Result;
            var respCode = JObject.Parse(actualResponseJson);

            httpResponseMessage.StatusCode.Should().Match<HttpStatusCode>(status =>
                status == HttpStatusCode.OK ||
                status == HttpStatusCode.NonAuthoritativeInformation);
            var cards = (JArray)respCode.GetValue("Cards", StringComparison.InvariantCultureIgnoreCase);
            var strIsActive = "";
            foreach (var cardDetails in cards)
            {
                var obj = (JObject)cardDetails;

                strIsActive = (string)obj.GetValue("IsActive", StringComparison.InvariantCultureIgnoreCase);
                break;
            }
            strIsActive.Should().BeEquivalentTo("true");
        }

        [Given(@"I want to validate getcardsbyaccount for an invalid account")]
        public void GivenIWantToValidateGetCardsByAccountForAnInvalidAccount()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.AccountNotFoundAccountId
                    : AccountNumberGenerator.Generate();

            var mockRequest = _dataFixtureReader.Read(
                @"FirstData\CardsListbyCard\Request.json", new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );
            var mockResponse = _dataFixtureReader.Read(@"FirstData\CardsListbyCard\465_notFound_GetCards.json");
            var foundationRequest = _dataFixtureReader.Read(
                @"CardAccount\GetCardList\request.json",
                new Dictionary<string, object>
                {
                    { "CardAccountId", Config.CardAccount.CardAccountId } 
                });
            _scenarioContext.Set(foundationRequest, "FoundationRequest");

            _mock
                .GivenRequest(mockRequest)
                .WithRequiredParam("cardNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.GetCardList)
                .ThenReturnAsync(mockResponse, 465)
                .Wait();
        }
        [Then(@"the getcardlist service returns ""(.*)""")]
        public void ThenTheGetCardListServiceReturns(HttpStatusCode statusCode)
        {
            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("GetCardListResponse");
            httpResponseMessage.StatusCode.Should().Be(statusCode);
        }

        [Given(@"I Want to validate getcardsbyaccount by sending the bad request")]
        public void GivenIWantToValidateTheServiceBySendingTheBadRequest()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.InvalidAccountId
                    : AccountNumberGenerator.Generate();

            var mockRequest = _dataFixtureReader.Read(
                @"FirstData\CardsListbyCard\Request.json", new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );
            var mockResponse = _dataFixtureReader.Read(
              @"FirstData\CardsListbyCard\200_response.json"
            );
            var foundationRequest = _dataFixtureReader.Read(
                @"CardAccount\GetCardList\bad_request.json");
            _scenarioContext.Set(foundationRequest, "FoundationRequest");

            _mock
                .GivenRequest(mockRequest)
                .WithRequiredParam("cardNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.GetCardList)
                .ThenReturnAsync(mockResponse)
                .Wait();
        }

        [Given(@"I Want to validate frozen flag on getcardsbyaccount for pending card")]
        public void GivenIWantToValidateFrozenFlagOnGetcardsbyaccountForPendingCard()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.InvalidAccountId
                    : AccountNumberGenerator.Generate();

            var mockRequest = _dataFixtureReader.Read(
                @"FirstData\CardsListbyCard\Request.json", new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );
            var mockResponse = _dataFixtureReader.Read(
              @"FirstData\CardsListbyCard\200_response_Pending.json"
            );
            var foundationRequest = _dataFixtureReader.Read(
                @"CardAccount\GetCardList\request.json", new Dictionary<string, object> { { "CardAccountId", Config.CardAccount.CardAccountId } });
            _scenarioContext.Set(foundationRequest, "FoundationRequest");

            _mock
                .GivenRequest(mockRequest)
                .WithRequiredParam("cardNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.GetCardList)
                .ThenReturnAsync(mockResponse)
                .Wait();
        }

        [Then(@"the frozen flag getcardlist service returns ""(.*)""")]
        public void ThenTheFrozenFlagGetcardlistServiceReturns(string p0)
        {
            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("GetCardListResponse");
            var actualResponseJson = httpResponseMessage.Content.ReadAsStringAsync().Result;
            var respCode = JObject.Parse(actualResponseJson);

            httpResponseMessage.StatusCode.Should().Match<HttpStatusCode>(status =>
                status == HttpStatusCode.OK ||
                status == HttpStatusCode.NonAuthoritativeInformation);
            var cards = (JArray)respCode.GetValue("Cards", StringComparison.InvariantCultureIgnoreCase);
            var strIsFrozen = "";
            foreach (var cardDetails in cards)
            {
                var obj = (JObject)cardDetails;

                strIsFrozen = (string)obj.GetValue("IsFrozen", StringComparison.InvariantCultureIgnoreCase);
                break;
            }
            strIsFrozen.Should().BeEquivalentTo(p0);
        }

        [Given(@"I Want to validate frozen flag on getcardsbyaccount for active and not blocked card")]
        public void GivenIWantToValidateFrozenFlagOnGetcardsbyaccountForActiveAndNotBlockedCard()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.ValidCardAccountId
                    : AccountNumberGenerator.Generate();

            var mockRequest = _dataFixtureReader.Read(
                @"FirstData\CardsListbyCard\Request.json", new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );
            var mockResponse = _dataFixtureReader.Read(
               @"FirstData\CardsListbyCard\200_response.json"
            );
            var mockRequest_cardInquiry = _dataFixtureReader.Read(
                @"FirstData\CardInquiry\request.json", new Dictionary<string, object> { { "ACCOUNT_NUMBER", "5474106917071848" } }
            );
            var mockResponse_cardInquiry = _dataFixtureReader.Read(
               @"FirstData\CardInquiry\200_response.json"
            );
            var foundationRequest = _dataFixtureReader.Read(
                @"CardAccount\GetCardList\request.json", new Dictionary<string, object> { { "CardAccountId", Config.CardAccount.CardAccountId } });
            _scenarioContext.Set(foundationRequest, "FoundationRequest");

            _mock
                .GivenRequest(mockRequest)
                .WithRequiredParam("cardNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.GetCardList)
                .ThenReturnAsync(mockResponse)
                .Wait();
            _mock
                .GivenRequest(mockRequest_cardInquiry)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.CardInquiry)
                .ThenReturnAsync(mockResponse_cardInquiry)
                .Wait();
        }


        private HttpResponseMessage GetCardListEndpoint()
        {
            var requestBody = _scenarioContext.Get<string>("FoundationRequest");
            var result = _apiClient.Post(CardAccountEndpoints.GetCardList, requestBody);

            return result;
        }
    }
}
