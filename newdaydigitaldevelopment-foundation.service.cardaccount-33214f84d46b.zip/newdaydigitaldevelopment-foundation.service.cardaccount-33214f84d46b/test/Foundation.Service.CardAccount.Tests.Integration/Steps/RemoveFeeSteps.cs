﻿using FluentAssertions;
using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    public class RemoveFeeSteps
    {

        private readonly ScenarioContext _scenarioContext;
        private readonly Mock _mock;
        private readonly IHttpApiClient _apiClient;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly MockConfiguration _mockConfiguration;
        private string foundationRequest = null;

        public RemoveFeeSteps(
            IHttpApiClient apiClient,
            ScenarioContext scenarioContext,
            Mock mock,
            IDataFixtureReader dataFixtureReader,
            MockConfiguration mockConfiguration)
        {
            _apiClient = apiClient;
            _scenarioContext = scenarioContext;
            _mock = mock;
            _dataFixtureReader = dataFixtureReader;
            _mockConfiguration = mockConfiguration;
        }

        [Given(@"I have a valid (.*) account to remove fee for (.*)")]
        public async Task GivenIHaveAValidOwnBrandsAccountToRemoveFeeForLateFee(string accountType, string feeType)
        {
            var isOwnBrands = accountType == "OwnBrands";

            string planNumber = null;
            string actionCode = null;
            switch (feeType)
            {
                case "LateFee":
                    planNumber = "10000";
                    actionCode = "2LAF";
                    break;

                case "Overlimit":
                    planNumber = "10000";
                    actionCode = "2OLF";
                    break;

                case "Interest":
                    planNumber = "10000";
                    actionCode = "2IRA";
                    break;

                case "DDReturn":
                    planNumber = "10000";
                    actionCode = isOwnBrands ? "2NSF" : "2DDR";
                    break;
            }

            Config.CardAccount.CardNumber = (TestContext.IsFirstData(), isOwnBrands) switch
            {
                (true, true) => _mockConfiguration.ValidOwnBrandsCardAccountId,
                (true, false) => _mockConfiguration.ValidCobrandsCardAccountId,

                _ => AccountNumberGenerator.Generate()
            };

            if (TestContext.IsFirstData()) return;

            
            var requestMonetaryAction = _dataFixtureReader.Read(@"FirstData\MonetaryAction\Request.json",
                new Dictionary<string, object> {
                    { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber },
                    { "ACTION_CODE", actionCode },
                    { "EFFECTIVE_DATE", DateTime.Today.ToString("yyyyMMdd") },
                    { "PLAN_NUMBER", planNumber }
                }
            );

            var responseMonetaryAction = _dataFixtureReader.Read(@"FirstData\MonetaryAction\200.json",
                new Dictionary<string, object> {
                    { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber },
                    { "ACTION_CODE", actionCode },
                    { "CARD_NUMBER", Config.CardAccount.CardNumber },
                    { "PLAN_NUMBER", planNumber }
                }
            );

            var requestAccountPlanList = _dataFixtureReader.Read(@"FirstData\AccountPlanList\Request_WithoutZero.json",
                new Dictionary<string, object> {
                    { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber }
                }
            );

            var responseAccountPlanList = _dataFixtureReader.Read(@"FirstData\AccountPlanList\Response.json",
                new Dictionary<string, object> {
                    { "PLAN_NBR_1", planNumber }
                }
            );

            await _mock
                .GivenRequest(requestMonetaryAction)
                .WithRequiredParam("acctNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.MonetaryAction)
                .ThenReturnAsync(responseMonetaryAction, 200);

            await _mock
                .GivenRequest(requestAccountPlanList)
                .WithRequiredParam("acct")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountPlanList)
                .ThenReturnAsync(responseAccountPlanList, 200);

        }

        
        [When(@"I request to remove the fee or interest from an account (.*) (.*)")]
        public void WhenIRequestToRemoveTheFeeOrInterestFromAnAccount(string feeType, string requestOption)
        {
            if (requestOption.ToUpper().Equals("WITHPLANNUMANDSEQNUM"))
            {
                foundationRequest = _dataFixtureReader.Read(@"CardAccount\RemoveFee\request.json",
                  new Dictionary<string, object> {
                     {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber},
                     {"FEE_TYPE", feeType},
                     {"PLAN_NUMBER","10000"},
                     {"PLAN_SEQ_NUMBER","1"}});
            }

            if (requestOption.ToUpper().Equals("WITHPLANNUMANDWITHOUTSEQNUM"))
            {
                foundationRequest = _dataFixtureReader.Read(@"CardAccount\RemoveFee\request_WithoutPlanSeqNum.json",
                  new Dictionary<string, object> {
                     {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber},
                     {"FEE_TYPE", feeType},
                     {"PLAN_NUMBER","10000"}});
            }
            if (requestOption.ToUpper().Equals("WITHOUTPLANNUMANDWITHOUTSEQNUM"))
            {
                foundationRequest = _dataFixtureReader.Read(@"CardAccount\RemoveFee\request_WithoutPlanDetail.json",
                  new Dictionary<string, object> {
                     {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber},
                     {"FEE_TYPE", feeType}});
            }
            if (requestOption.ToUpper().Equals("WITHOUTDATE"))
            {
                foundationRequest = _dataFixtureReader.Read(@"CardAccount\RemoveFee\request_NoDate.json",
                  new Dictionary<string, object> {
                     {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber},
                     {"FEE_TYPE", feeType},
                     {"PLAN_NUMBER","10000"},
                     {"PLAN_SEQ_NUMBER","1"}});

            }
            _scenarioContext.Set(_apiClient.Post(CardAccountEndpoints.RemoveFee, foundationRequest), "response");
        }

        [When(@"I request to remove the fee or interest from an account")]
        public void WhenIRequestToRemoveTheFeeOrInterestFromAnAccount()
        {
            _scenarioContext.Set(_apiClient.Post(CardAccountEndpoints.RemoveFee, foundationRequest), "response");
        }

        [Then(@"I verify the successful response with status (.*)")]
        public void ThenIVerifyTheSuccessfulResponseWithStatus(HttpStatusCode statusCode)
        {
            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("response");
            httpResponseMessage.StatusCode.Should().Be(statusCode);
        }

        [Given(@"I have an invalid plan number in First Data to remove fee")]
        public async Task GivenIHaveAInvalidAccountinFirstDataToRemoveFee()
        {
            Config.CardAccount.CardNumber = TestContext.IsFirstData() ?
                _mockConfiguration.ValidCobrandsCardAccountId
                : AccountNumberGenerator.Generate();

            foundationRequest = _dataFixtureReader.Read(@"CardAccount\RemoveFee\request.json",
                 new Dictionary<string, object>
                 {
                     {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber},
                     {"FEE_TYPE","Interest"},
                     {"PLAN_NUMBER","99999"},
                     {"PLAN_SEQ_NUMBER","9" }
                 }
             );

            if (TestContext.IsFirstData()) return;

            var request = _dataFixtureReader.Read(@"FirstData\MonetaryAction\Request.json",
                new Dictionary<string, object> {
                    { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber },
                    { "ACTION_CODE", "2IRA" },
                    {"EFFECTIVE_DATE",DateTime.Today.ToString("yyyyMMdd") },
                    {"PLAN_NUMBER","10000"}
                }
            );

            var response = _dataFixtureReader.Read(
                @"FirstData\MonetaryAction\465_PlanNotFound.json"
            );

            await _mock
                .GivenRequest(request)
                .WithRequiredParam("acctNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.MonetaryAction)
                .ThenReturnAsync(response, 465);
        }

        [Given(@"I have an invalid feetype to remove fee")]
        public void GivenIHaveAInvalidFeeTypeToRemoveFee()
        {
            Config.CardAccount.CardNumber = TestContext.IsFirstData() ?
                _mockConfiguration.ValidCobrandsCardAccountId
                : AccountNumberGenerator.Generate();

            foundationRequest = _dataFixtureReader.Read(@"CardAccount\RemoveFee\request.json",
                 new Dictionary<string, object>
                 {
                        {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber},
                        {"FEE_TYPE","Overdraft"},
                        {"PLAN_NUMBER","10001"},
                        {"PLAN_SEQ_NUMBER","9" }
                 }
             );
        }
    }
}
