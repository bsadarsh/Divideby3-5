﻿using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    public class ReturnFundsSteps
    {

        private readonly ScenarioContext _scenarioContext;
        private readonly Mock _mock;
        private readonly IHttpApiClient _apiClient;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly MockConfiguration _mockConfiguration;
        private string foundationRequest = null;

        public ReturnFundsSteps(
            IHttpApiClient apiClient,
            ScenarioContext scenarioContext,
            Mock mock,
            IDataFixtureReader dataFixtureReader,
            MockConfiguration mockConfiguration)
        {
            _apiClient = apiClient;
            _scenarioContext = scenarioContext;
            _mock = mock;
            _dataFixtureReader = dataFixtureReader;
            _mockConfiguration = mockConfiguration;
        }
        [Given(@"I have a valid (.*) to return funds")]
        public async Task GivenIHaveAValidAccountToReturnFunds(string accountType)
        {
            var isOwnBrands = accountType == "OwnBrands";
            var cardAccountId = (TestContext.IsFirstData(), isOwnBrands) switch
            {
                (true, true) => _mockConfiguration.ValidOwnBrandsCardAccountId,
                (true, false) => _mockConfiguration.ValidCobrandsCardAccountId,

                _ => AccountNumberGenerator.Generate()
            };

            foundationRequest = _dataFixtureReader.Read(@"CardAccount\ReturnFunds\request.json",
                 new Dictionary<string, object>
                 {
                        {"ACCOUNT_NUMBER", cardAccountId},
                 }
             );
            if (TestContext.IsFirstData()) return;
            var monetaryActionRequest = _dataFixtureReader.Read(
                @"FirstData\MonetaryAction\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", cardAccountId },
                   { "ACTION_CODE", "" },
                    { "EFFECTIVE_DATE", DateTime.Today.ToString("yyyyMMdd") },
                    { "PLAN_NUMBER", "" }}
            );

            var accountPlanInquiryRequest = _dataFixtureReader.Read(
           @"FirstData\AccountPlanInquiry\request.json",
           new Dictionary<string, object> { { "ACCOUNT_NUMBER", cardAccountId } }
       );
            var monetaryActionResponse = _dataFixtureReader.Read(
                @"FirstData\MonetaryAction\200.json",
                                new Dictionary<string, object> { { "ACCOUNT_NUMBER", cardAccountId },
                        { "ACTION_CODE", "" },
                    { "CARD_NUMBER", cardAccountId },
                    { "PLAN_NUMBER", "" } }
            );
            var accountPlanInquiryResponse = _dataFixtureReader.Read(
               @"FirstData\AccountPlanInquiry\200.json", new Dictionary<string, object> {
                    { "PLAN_NUMBER","10000" } });
            await _mock
                .GivenRequest(monetaryActionRequest)
                .WithRequiredParam("acctNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.MonetaryAction)
                .ThenReturnAsync(monetaryActionResponse, 200);
            await _mock
               .GivenRequest(accountPlanInquiryRequest)
               .WithRequiredParam("acct")
               .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountPlanInquiry)
               .ThenReturnAsync(accountPlanInquiryResponse, 200);

        }
        [When(@"I request to return the funds for an account")]
        public void WhenIRequestToReturnTheFundsForAnAccount()
        {
            _scenarioContext.Set(_apiClient.Post(CardAccountEndpoints.ReturnFunds, foundationRequest), "response");
        }
        [Given(@"I have an invalid plan number in First Data to return funds")]
        public async Task GivenIHaveAInvalidPlanNumberinFirstDataToReturnFunds()
        {
            Config.CardAccount.CardNumber = TestContext.IsFirstData() ?
                _mockConfiguration.InvalidOrgAccountId
                : AccountNumberGenerator.Generate();

            foundationRequest = _dataFixtureReader.Read(@"CardAccount\ReturnFunds\request.json",
                 new Dictionary<string, object>
                 {
                     {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber},
                 }
             );

            var monetaryActionRequest = _dataFixtureReader.Read(@"FirstData\MonetaryAction\Request.json",
                new Dictionary<string, object> {
                    { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber },
                    { "ACTION_CODE", "" },
                    {"EFFECTIVE_DATE","" },
                    {"PLAN_NUMBER",""}
                }
            );
            var accountPlanInquiryRequest = _dataFixtureReader.Read(
    @"FirstData\AccountPlanInquiry\request.json",
    new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber } }
);
            var monetaryActionResponse = _dataFixtureReader.Read(
                @"FirstData\MonetaryAction\465_PlanNotFound.json"
            );
            var accountPlanInquiryResponse = _dataFixtureReader.Read(
                     @"FirstData\AccountPlanInquiry\200.json", new Dictionary<string, object> {
                    { "PLAN_NUMBER","1000000" } });

            await _mock
                .GivenRequest(monetaryActionRequest)
                .WithRequiredParam("acctNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.MonetaryAction)
                .ThenReturnAsync(monetaryActionResponse, 465);
            await _mock
         .GivenRequest(accountPlanInquiryRequest)
         .WithRequiredParam("acct")
         .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountPlanInquiry)
         .ThenReturnAsync(accountPlanInquiryResponse, 200);
        }
        [Given(@"I have no plan number from First Data to return funds")]
        public async Task GivenIHaveNoPlanNumberFromFirstDataToReturnFunds()
        {
            Config.CardAccount.CardNumber = TestContext.IsFirstData() ?
             _mockConfiguration.InvalidOrgAccountId
             : AccountNumberGenerator.Generate();

            foundationRequest = _dataFixtureReader.Read(@"CardAccount\ReturnFunds\request.json",
                 new Dictionary<string, object>
                 {
                     {"ACCOUNT_NUMBER", Config.CardAccount.CardNumber},
                 }
             );

            var accountPlanInquiryRequest = _dataFixtureReader.Read(
    @"FirstData\AccountPlanInquiry\request.json",
    new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardNumber } }
);
            var accountPlanInquiryResponse = _dataFixtureReader.Read(
                @"FirstData\MonetaryAction\465_PlanNotFound.json"
            );

            await _mock
                .GivenRequest(accountPlanInquiryRequest)
                .WithRequiredParam("acct")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.AccountPlanInquiry)
                .ThenReturnAsync(accountPlanInquiryResponse, 465);

        }


    }
}
