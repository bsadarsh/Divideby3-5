﻿using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using System;
using System.Collections.Generic;
using System.Net.Http;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    public class CancelInsuranceSteps
    {
        private readonly Mock _mock;
        private readonly IHttpApiClient _cardAccountClient;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly ScenarioContext _scenarioContext;
        private readonly MockConfiguration _mockConfiguration;
        private string foundationRequest = null;

        public CancelInsuranceSteps(
            ScenarioContext scenarioContext,
            Mock mock,
            IHttpApiClient cardAccountClient,
            IDataFixtureReader dataFixtureReader,
            MockConfiguration mockConfiguration)
        {
            _scenarioContext = scenarioContext;
            _mock = mock;
            _cardAccountClient = cardAccountClient;
            _dataFixtureReader = dataFixtureReader;
            _mockConfiguration = mockConfiguration;
        }

        [Given(@"I have entered valid AccountNumber to cancel insurance")]
        public void GivenIHaveEnteredValidAccountNumberToCancelInsurance()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
            _mockConfiguration.CardAccountForUATCancelInsurance
                    : AccountNumberGenerator.Generate();

            if (TestContext.IsFirstData()) return;

            var request = _dataFixtureReader.Read(
                @"FirstData\CancelInsurance\Request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            var response = _dataFixtureReader.Read(
                @"FirstData\CancelInsurance\200_Response.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            _mock
                .GivenRequest(request)
                .WithRequiredParam("account")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.InsuranceStatusUpdate)
                .ThenReturnAsync(response, 200)
                .Wait();
        }

        [Then(@"I hit the CancelInsurance endpoint with reasoncode (.*)")]
        public void ThenIHitTheCancelInsuranceEndpointWithReasoncode(string ReasonCode)
        {
         
        foundationRequest = _dataFixtureReader.Read(@"CardAccount\CancelInsurance\Request.json",
                  new Dictionary<string, object>
                  {
                        {"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId},
                        {"REASON_CODE",  ReasonCode}
                  }
              );

            _scenarioContext.Set(_cardAccountClient.Post(CardAccountEndpoints.CancelInsurance, foundationRequest), "response");

        }
    }
}
