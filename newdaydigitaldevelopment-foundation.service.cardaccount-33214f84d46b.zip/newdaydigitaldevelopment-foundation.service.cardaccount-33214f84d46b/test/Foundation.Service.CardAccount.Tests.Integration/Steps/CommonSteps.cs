﻿using System.Net;
using System.Net.Http;
using FluentAssertions;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    public class CommonSteps
    {
        private readonly ScenarioContext _scenarioContext;

        public CommonSteps(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }

        [Then(@"I receive a ""(.*)"" error")]
        public void ThenIReceiveAError(HttpStatusCode expectedStatusCode)
        {
            var httpResponseMessage = _scenarioContext.Get<HttpResponseMessage>("response");

            httpResponseMessage.StatusCode.Should().Be(expectedStatusCode);
        }
    }
}
