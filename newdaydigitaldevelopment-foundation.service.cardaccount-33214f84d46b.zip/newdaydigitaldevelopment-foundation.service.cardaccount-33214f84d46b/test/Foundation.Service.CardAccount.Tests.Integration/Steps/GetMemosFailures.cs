﻿using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using FluentAssertions;
using NewDay.Digital.Foundation.Core.TestingUtils;
using NewDay.Digital.Foundation.Core.TestingUtils.ApiMock;
using NewDay.Digital.Foundation.Core.TestingUtils.Tools;
using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Steps
{
    [Binding]
    public sealed class GetMemosFailures
    {
        private readonly ScenarioContext _scenarioContext;
        private readonly Mock _mock;
        private readonly IDataFixtureReader _dataFixtureReader;
        private readonly IHttpApiClient _apiClient;
        private readonly MockConfiguration _mockConfiguration;

        public GetMemosFailures(
            ScenarioContext scenarioContext,
            Mock mock,
            IDataFixtureReader dataFixtureReader,
            IHttpApiClient cardAccountClient, 
            MockConfiguration mockConfiguration)
        {
            _scenarioContext = scenarioContext;
            _mock = mock;
            _apiClient = cardAccountClient;
            _mockConfiguration = mockConfiguration;
            _dataFixtureReader = dataFixtureReader;
        }

        [Given(@"Memos do not exist for a not existing account")]
        public void MemosDoNotExistForANotExistingAccount()
        {
            Config.CardAccount.CardAccountId =
                TestContext.IsFirstData() ?
                    _mockConfiguration.AccountNotFoundAccountId
                    : AccountNumberGenerator.Generate();

            var request = _dataFixtureReader.Read(
                @"FirstData\MemoInquiry\Request.json", new Dictionary<string, object>{ {"ACCOUNT_NUMBER", Config.CardAccount.CardAccountId} }
            );
            var response = _dataFixtureReader.Read(
                @"FirstData\MemoInquiry\465_AccountNotFound.json"
            );

            _mock
                .GivenRequest(request)
                .WithRequiredParam("acctNbr")
                .WhenCallEndpoint(HttpMethod.Post, FirstDataEndpoints.MemoInquiry)
                .ThenReturnAsync(response, 465)
                .Wait();
        }

        [When(@"I ask for a list of memos with invalid account number")]
        public void WhenIAskForAListOfMemosWithInvalidAccountNumber()
        {
            var response = _apiClient.Post(CardAccountEndpoints.GetMemos, "");
            _scenarioContext.Set(response, "response");
        }

        [Then(@"I receive a ""(.*)"" error from memo API")]
        public void ThenIReceiveAError(HttpStatusCode expectedStatusCode)
        {
            var request = _dataFixtureReader.Read(
                @"CardAccount\GetCardAccount\request.json",
                new Dictionary<string, object> { { "ACCOUNT_NUMBER", Config.CardAccount.CardAccountId } }
            );

            var actualResponseMessage = _apiClient.Post(CardAccountEndpoints.GetCardAccount, request);

            actualResponseMessage.StatusCode.Should().Be(expectedStatusCode);
        }
    }
}
