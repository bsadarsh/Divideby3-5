﻿using Xunit;
[assembly: CollectionBehavior(DisableTestParallelization = true)]
namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration
{
    public class AssemblyInfo
    {
    }
}
