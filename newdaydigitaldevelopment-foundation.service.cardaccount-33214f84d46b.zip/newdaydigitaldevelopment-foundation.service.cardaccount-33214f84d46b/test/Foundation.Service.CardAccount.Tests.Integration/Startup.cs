﻿using System.Net;
using TechTalk.SpecFlow;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration
{
    [Binding]
    public class Startup
    {
        [BeforeTestRun]
        public static void EnableTls12ProtocolSupport() {
            ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
        }
    }
}