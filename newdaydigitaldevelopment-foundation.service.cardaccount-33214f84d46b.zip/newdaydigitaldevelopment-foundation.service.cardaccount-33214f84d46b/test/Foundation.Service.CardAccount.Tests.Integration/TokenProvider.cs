﻿using Microsoft.Azure.Services.AppAuthentication;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration
{
    public static class TokenProvider
    {
        public static string GetToken(string audienceUrl)
        {
            var accessToken = "";
            if (!TestContext.IsAzure()) return accessToken;

            var tokenProvider = new AzureServiceTokenProvider();

            accessToken = tokenProvider
                .GetAccessTokenAsync(audienceUrl)
                .GetAwaiter()
                .GetResult();

            return accessToken;
        }
    }
}