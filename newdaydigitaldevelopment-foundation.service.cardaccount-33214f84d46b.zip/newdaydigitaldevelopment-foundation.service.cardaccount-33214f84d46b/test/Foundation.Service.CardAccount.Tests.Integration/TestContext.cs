﻿using NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration.Config;

namespace NewDay.Digital.Foundation.Service.CardAccount.Tests.Integration
{
    public static class TestContext
    {
        public static bool IsAzure()
        {
            return CardAccountEndpoints.BaseAddress.Host.EndsWith(Azure.FunctionBaseAddress);
        }

        public static bool IsFirstData()
        {
            return !FirstDataEndpoints.BaseAddress.Host.EndsWith(FirstDataMockEndpoints.BaseAddress.Host);
        }
    }
}
